__all__ = ["twitter", "identica", "flickr", "facebook", "friendfeed", "statusnet", "digg", "qaiku", "buzz", "pingfm", "foursquare"]
