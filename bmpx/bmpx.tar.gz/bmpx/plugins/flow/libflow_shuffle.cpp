/*  BMPx - The Dumb Music Player
 *  Copyright (C) 2005 BMPx development team.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * The BMPx project hereby grant permission for non-gpl compatible GStreamer
 * plugins to be used and distributed together with GStreamer and BMPx. This
 * permission are above and beyond the permissions granted by the GPL license
 * BMPx is covered by.
 */


/* -*- Mode: C; tab-width: 8; indent-tabs-mode: nil; c-basic-offset: 8 -*- */

#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <time.h>

#include <glib.h>
#include <glib-object.h>

#include <bmp/plugin.h>
#include <bmp/playlist.hpp>
#include <bmp/plugin_interfaces.h>

#include "libflow_shuffle.h"

static char shuffle_history_data[] = "dummy data";
static GHashTable *shuffle_history = NULL;

static void
row_guid_free_key_func (RowGUID *key)
{
    g_free (key);
}

static RowGUID*
get_fileitem_guid (GtkTreeModel	      *playlist,
		   gint		       track)
{
    RowGUID	*guid;
    GtkTreeIter	 iter;

    gtk_tree_model_iter_nth_child (playlist, &iter, NULL, track); 
    gtk_tree_model_get (playlist, &iter, COLUMN_GUID, &guid, -1);

    return guid; 
}

static void
flow_shuffle_history_free ()
{
    if (shuffle_history)
      {
	g_hash_table_destroy (shuffle_history);
	shuffle_history = NULL;
      }
}

static void
flow_shuffle_history_item_insert (RowGUID *track)
{
    RowGUID *temp;

    temp = g_new0 (RowGUID,1);
    memcpy (temp, track, sizeof (RowGUID));
	
    g_hash_table_insert (shuffle_history, temp, shuffle_history_data);
}

static void
flow_shuffle_history_init (GtkTreeModel *playlist,
			   RowGUID	*current_guid)
{
    if (!shuffle_history)
      {
	shuffle_history = g_hash_table_new_full ((GHashFunc) row_guid_hash_func,
					    	 (GEqualFunc) row_guid_equal_func,
						 (GDestroyNotify) row_guid_free_key_func,
						 NULL);

	/* Append current track, so that we do not play it twice */
	flow_shuffle_history_item_insert (current_guid);
      }
}

static gboolean
flow_shuffle_history_item_played (RowGUID *track)
{
    if (g_hash_table_lookup (shuffle_history, track))
      return TRUE;

    return FALSE;
}

static gint
flow_shuffle_history_item_next (GtkTreeModel *playlist,
			        RowGUID	     *current_guid)
{
    GRand   *rand;
    RowGUID *guid;
    gint track, i = 0, list_length = gtk_tree_model_iter_n_children (GTK_TREE_MODEL(playlist), NULL);

    flow_shuffle_history_init (playlist, current_guid);

    rand = g_rand_new ();
   
    do
      {
	/* FIXME: g_rand_int_range () might skip up to 1% of the range
	 *        within the first list_length number of calls */
	if (i++ >= list_length)
	  {
	    g_rand_free (rand);
	    return -1;
	  }
	
	track = g_rand_int_range (rand, 0, list_length);
	guid = get_fileitem_guid (playlist, track);
	if (!guid)
	  continue;
      }
    while (row_guid_equal_func (guid, current_guid) ||
	   flow_shuffle_history_item_played (guid));

    g_rand_free (rand);
    flow_shuffle_history_item_insert (guid);
    g_free (guid);

    return track;
}

/* Shuffle Flow Control */
static gboolean
flow_shuffle_item_next (BmpPluginFlowInterface	    *self,
			GtkListStore		    *playlist,
			GtkTreeIter		    *iter)
{
    GtkTreeRowReference	   *reference;
    GtkTreePath		   *path;
    RowGUID		   *current_guid;
    gint		    length;
    gint		    current;
    gint		    random;

    length = gtk_tree_model_iter_n_children (GTK_TREE_MODEL(playlist), NULL)-1; 
    if (length <= 0) return FALSE;

    reference = reinterpret_cast<GtkTreeRowReference*>(g_object_get_data (G_OBJECT(playlist), "current"));
    if (!reference) return FALSE;

    path = gtk_tree_row_reference_get_path (reference);
    if (!path) return FALSE;

    current = gtk_tree_path_get_indices (path)[0]; 
    gtk_tree_path_free (path);

    current_guid = get_fileitem_guid (GTK_TREE_MODEL(playlist), current); 
    if (!current_guid) return FALSE;

    random = flow_shuffle_history_item_next (GTK_TREE_MODEL(playlist), current_guid); 
    if (random == -1) return FALSE;

    gtk_tree_model_iter_nth_child (GTK_TREE_MODEL(playlist), iter, NULL, random); 
    g_free (current_guid);

    return TRUE;
}

static gboolean
flow_shuffle_item_prev (BmpPluginFlowInterface	    *self,
			GtkListStore		    *playlist,
			GtkTreeIter		    *iter)
{
    GtkTreeRowReference	   *reference;
    GtkTreePath		   *path;
    RowGUID		   *current_guid;
    gint		    length;
    gint		    current;
    gint		    random;

    length = gtk_tree_model_iter_n_children (GTK_TREE_MODEL(playlist), NULL)-1; 
    if (length <= 0) return FALSE;

    reference = reinterpret_cast<GtkTreeRowReference*>(g_object_get_data (G_OBJECT(playlist), "current"));

    g_return_val_if_fail (reference != NULL, FALSE);

    path = gtk_tree_row_reference_get_path (reference);
    if (!path) return FALSE;

    current = gtk_tree_path_get_indices (path)[0]; 
    gtk_tree_path_free (path);

    current_guid = get_fileitem_guid (GTK_TREE_MODEL(playlist), current); 
    if (!current_guid) return FALSE;

    random = flow_shuffle_history_item_next (GTK_TREE_MODEL(playlist), current_guid); 
    if (random == -1) return FALSE;

    gtk_tree_model_iter_nth_child (GTK_TREE_MODEL(playlist), iter, NULL, random); 
    g_free (current_guid);

    return TRUE;
}

static void
reset_state (BmpPluginFlowInterface *self)
{
    flow_shuffle_history_free ();
}

/* IFaces */
static gchar* _metadata[] = {
    "Shuffle Playback",
    "Milosz Derezynski and Martin Schlemmer",
    "(C) GPL 2005",
    "http://bmpx.beep-media-player.org",
    "internalerror@gmail.com, azarah@gentoo.org",
};

static const gchar**
get_metadata (BmpPlugMetadataInterface *self)
{
    return (const gchar**)_metadata;
}

static void
metadata_init (gpointer         g_iface,
	       gpointer         iface_data)
{
	BmpPlugMetadataInterface *klass = (BmpPlugMetadataInterface *)g_iface;

	klass->get_metadata = get_metadata;
}


void
flow_shuffle_interface_init (gpointer         g_iface)
{
        BmpPluginFlowInterface *klass = (BmpPluginFlowInterface *)g_iface;

        klass->item_next   = flow_shuffle_item_next;
        klass->item_prev   = flow_shuffle_item_prev;
        klass->reset_state = reset_state; 
}


extern "C"

{

GType plugin_flow_shuffle_type = 0;

void 
plugin_flow_shuffle_register_type (GTypeModule *module)
{
	    static const GTypeInfo object_info = {
                        sizeof (BmpPluginFlowShuffleClass),
                        NULL,   /* base_init */
                        NULL,   /* base_finalize */
                        NULL,   /* class_init */
                        NULL,   /* class_finalize */
                        NULL,   /* class_data */
                        sizeof (BmpPluginFlowShuffle),
                        0,      /* n_preallocs */
                        NULL    /* instance_init */
                };

                static const GInterfaceInfo interface_flow_shuffle_info = {
                        (GInterfaceInitFunc) flow_shuffle_interface_init,    /* interface_init */
                        NULL,                                       /* interface_finalize */
                        NULL                                        /* interface_data */
                };

                static const GInterfaceInfo interface_metadata_info = {
                        (GInterfaceInitFunc) metadata_init,    /* interface_init */
                        NULL,                                       /* interface_finalize */
                        NULL                                        /* interface_data */
                };

                plugin_flow_shuffle_type = g_type_module_register_type (module,
					   G_TYPE_OBJECT,
					  "BmpPluginFlowShuffleType",
					   &object_info, GTypeFlags(0));

                g_type_module_add_interface (module,
					     plugin_flow_shuffle_type,
                                             BMP_TYPE_PLUG_METADATA,
                                             &interface_metadata_info);

                g_type_module_add_interface (module,
					     plugin_flow_shuffle_type,
                                             BMP_TYPE_PLUGIN_FLOW,
                                             &interface_flow_shuffle_info);
  } 
}
