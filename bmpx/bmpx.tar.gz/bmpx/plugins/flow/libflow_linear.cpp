/*  BMPx - The Dumb Music Player
 *  Copyright (C) 2005 BMPx development team.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * The BMPx project hereby grant permission for non-gpl compatible GStreamer
 * plugins to be used and distributed together with GStreamer and BMPx. This
 * permission are above and beyond the permissions granted by the GPL license
 * BMPx is covered by.
 */


/* -*- Mode: C; tab-width: 8; indent-tabs-mode: nil; c-basic-offset: 8 -*- */

#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <time.h>

#include <glib.h>
#include <glib-object.h>
#include <gtk/gtk.h>

#include <bmp/plugin.h>
#include <bmp/playlist.hpp>
#include <bmp/plugin_interfaces.h>

#include "libflow_linear.h"

/* Linear Flow Control */
static gboolean 
flow_linear_item_next (BmpPluginFlowInterface	  *self, 
		       GtkListStore		  *playlist,
		       GtkTreeIter		  *iter) 
{
    GtkTreeRowReference	   *reference;
    GtkTreePath		   *path;
    gint		    length;
    gint		    current;

    length = gtk_tree_model_iter_n_children (GTK_TREE_MODEL(playlist), NULL)-1; 
    if (length <= 0)
    {
	return FALSE;
    }

    reference = reinterpret_cast<GtkTreeRowReference*>(g_object_get_data (G_OBJECT(playlist), "current"));
    if (!reference)
    {
	gtk_tree_model_get_iter_first (GTK_TREE_MODEL(playlist), iter);
	return TRUE;
    }

    path = gtk_tree_row_reference_get_path (reference);
    if (!path)
    {
	return FALSE;
    }

    current = gtk_tree_path_get_indices (path)[0]; 
    gtk_tree_path_free (path);
  
    if ((current+1) > length)
	{
	    return FALSE;
	}
  
    current++;
    if (current <= length)
      {
	gtk_tree_model_iter_nth_child (GTK_TREE_MODEL(playlist), iter, NULL, current);
	return TRUE;
      }

  return FALSE;
}

static gboolean 
flow_linear_item_prev (BmpPluginFlowInterface	    *self,
		       GtkListStore		    *playlist,
		       GtkTreeIter		    *iter) 
{
    GtkTreeRowReference	   *reference;
    GtkTreePath		   *path;
    gint		    length;
    gint		    current;

    length = gtk_tree_model_iter_n_children (GTK_TREE_MODEL(playlist), NULL)-1; 
    reference = reinterpret_cast<GtkTreeRowReference*>(g_object_get_data (G_OBJECT(playlist), "current"));
    if (!reference) return FALSE; 

    path = gtk_tree_row_reference_get_path (reference);
    if (!path) return FALSE;

    current = gtk_tree_path_get_indices (path)[0]; 
    gtk_tree_path_free (path);

    current--;
    if (current >= 0)
      {
	gtk_tree_model_iter_nth_child (GTK_TREE_MODEL(playlist), iter, NULL, current);
	return TRUE;
      }

    return FALSE;
}

static gchar* _metadata[] = {
    "Linear Playback",
    "Milosz Derezynski",
    "(C) GPL 2005",
    "http://bmpx.beep-media-player.org",
    "internalerror@gmail.com",
};

const gchar**
get_metadata (BmpPlugMetadataInterface *self)
{
    return (const gchar**)_metadata;
}

static void
metadata_init (gpointer         g_iface,
               gpointer         iface_data)
{
        BmpPlugMetadataInterface *klass = (BmpPlugMetadataInterface *)g_iface;

        klass->get_metadata = get_metadata;
}


static void
flow_linear_interface_init (gpointer         g_iface,
                            gpointer         iface_data)
{
        BmpPluginFlowInterface *klass = (BmpPluginFlowInterface *)g_iface;

        klass->item_next   = flow_linear_item_next;
        klass->item_prev   = flow_linear_item_prev;
        klass->reset_state = NULL; 
}

extern "C"
{
GType plugin_flow_linear_type = 0;

void 
plugin_flow_linear_register_type (GTypeModule *module)
{
	    static const GTypeInfo object_info = {
                        sizeof (BmpPluginFlowLinearClass),
                        NULL,   /* base_init */
                        NULL,   /* base_finalize */
                        NULL,   /* class_init */
                        NULL,   /* class_finalize */
                        NULL,   /* class_data */
                        sizeof (BmpPluginFlowLinear),
                        0,      /* n_preallocs */
                        NULL,    /* instance_init */
                };

                plugin_flow_linear_type = g_type_module_register_type (module,
					   G_TYPE_OBJECT,
					  "BmpPluginFlowLinearType",
					   &object_info, GTypeFlags (0));

                static const GInterfaceInfo interface_flow_linear_info = {
                        (GInterfaceInitFunc) flow_linear_interface_init, 
                        NULL,                                    
                        NULL                                      
                };

                static const GInterfaceInfo interface_metadata_info = {
                        (GInterfaceInitFunc) metadata_init,    
                        NULL,                                 
                        NULL                                 
                };

                g_type_module_add_interface (module,
					     plugin_flow_linear_type,
                                             BMP_TYPE_PLUG_METADATA,
                                             &interface_metadata_info);

                g_type_module_add_interface (module,
					     plugin_flow_linear_type,
                                             BMP_TYPE_PLUGIN_FLOW,
                                             &interface_flow_linear_info);

  }
}
