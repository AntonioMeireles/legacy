/* -*- Mode: C; tab-width: 8; indent-tabs-mode: nil; c-basic-offset: 8 -*- */

#ifndef BMP_PLUGIN_FLOW_LINEAR_H
#define BMP_PLUGIN_FLOW_LINEAR_H

#include <glib-object.h>

G_BEGIN_DECLS

extern GType plugin_flow_linear_type; 

#define BMP_TYPE_PLUGIN_FLOW_LINEAR             plugin_flow_linear_type 
#define BMP_PLUGIN_FLOW_LINEAR(obj)             (G_TYPE_CHECK_INSTANCE_CAST ((obj), BMP_TYPE_PLUGIN_FLOW_LINEAR, BmpPluginFlowLinear))
#define BMP_PLUGIN_FLOW_LINEAR_CLASS(vtable)    (G_TYPE_CHECK_CLASS_CAST ((vtable), BMP_TYPE_PLUGIN_FLOW_LINEAR, BmpPluginFlowLinearClass))
#define BMP_IS_PLUGIN_FLOW_LINEAR(obj)          (G_TYPE_CHECK_INSTANCE_TYPE ((obj), BMP_TYPE_PLUGIN_FLOW_LINEAR))
#define BMP_IS_PLUGIN_FLOW_LINEAR_CLASS(vtable) (G_TYPE_CHECK_CLASS_TYPE ((vtable), BMP_TYPE_PLUGIN_FLOW_LINEAR))
#define BMP_PLUGIN_FLOW_LINEAR_GET_CLASS(inst)  (G_TYPE_INSTANCE_GET_CLASS ((inst), BMP_TYPE_PLUGIN_FLOW_LINEAR, BmpPluginFlowLinearClass))


typedef struct _BmpPluginFlowLinear BmpPluginFlowLinear;
typedef struct _BmpPluginFlowLinearClass BmpPluginFlowLinearClass;

struct _BmpPluginFlowLinear {
        GObject parent;
};

struct _BmpPluginFlowLinearClass {
        GObjectClass parent_class;
};

void plugin_flow_linear_register_type (GTypeModule *module);

G_END_DECLS

#endif //BMP_PLUGIN_FLOW_LINEAR_H
