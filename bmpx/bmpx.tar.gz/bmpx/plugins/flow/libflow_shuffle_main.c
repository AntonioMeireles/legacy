/*  BMPx - The Dumb Music Player
 *  Copyright (C) 2005 BMPx development team.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * The BMPx project hereby grant permission for non-gpl compatible GStreamer
 * plugins to be used and distributed together with GStreamer and BMPx. This
 * permission are above and beyond the permissions granted by the GPL license
 * BMPx is covered by.
 */

#include <config.h>
#include <config.h>
#include <gmodule.h>
#include <bmp/sanity.h>
#include "libflow_shuffle.h"

const guint plugin_version = PLUGIN_VERSION;

G_MODULE_EXPORT void
plugin_init (GTypeModule *module)
{
  plugin_flow_shuffle_register_type (module);
}

G_MODULE_EXPORT void
plugin_exit (void)
{
}

G_MODULE_EXPORT GObject*
create_instance (void)
{
  g_assert (BMP_TYPE_PLUGIN_FLOW_SHUFFLE != 0);

  return g_object_new (BMP_TYPE_PLUGIN_FLOW_SHUFFLE, NULL);
}

/* The following function will be called by GTK+ when the module
 * is loaded and checks to see if we are compatible with the
 * version of GTK+ that loads us.
 */
G_MODULE_EXPORT const gchar* g_module_check_init (GModule *module);
const gchar*
g_module_check_init (GModule *module)
{
  return sanity_check_glib ();
}

