//  BMPx - The Dumb Music Player
//  Copyright (C) 2005 BMPx development team.
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
//
//  --
//
//  The BMPx project hereby grants permission for non-GPL compatible GStreamer
//  plugins to be used and distributed together with GStreamer and BMPx. This
//  permission is above and beyond the permissions granted by the GPL license
//  BMPx is covered by.

#include <glibmm.h>
#include <iostream>
#include <fstream>

#include <bmp/vfs.hpp>

namespace Bmp
{
  namespace VFS
  {
      class PluginTransportFile
	  : public Bmp::VFS::PluginTransportBase
      {

	public:

	  virtual bool	
	  can_process (const std::string& uri)
	  {
	      return (!g_ascii_strncasecmp("file://", uri.c_str(), 7));
	  }

	  virtual bool
	  handle_read (Bmp::VFS::Handle& handle)	  
	  {
	    std::string filename; 

	    try {  filename = Glib::filename_from_uri (handle.get_uri ());
	    } catch (...) { return false; }
 
	    std::string buffer = Glib::file_get_contents (filename);	    
	    handle.set_buffer (reinterpret_cast<const unsigned char*>(buffer.c_str ()), buffer.length ());
            return true;
	  }

	  virtual bool
	  handle_write (const Bmp::VFS::Handle& handle)
	  {
	    std::string filename; 

	    try { filename = Glib::filename_from_uri (handle.get_uri ());
	    } catch (...) { return false; }

	    std::ofstream outfile;
	    outfile.open (filename.c_str());
	    outfile << handle.get_buffer ();
	    outfile.close ();
            return true;
	  }
      };

    }
}
  
extern "C" Bmp::VFS::PluginTransportBase* plugin_create ()
{
  return new Bmp::VFS::PluginTransportFile;
}

extern "C" void plugin_delete (Bmp::VFS::PluginTransportFile* p)
{
  delete p;
}
