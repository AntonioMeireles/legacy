//  BMPx - The Dumb Music Player
//  Copyright (C) 2005 BMPx development team.
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
//
//  --
//
//  The BMPx project hereby grants permission for non-GPL compatible GStreamer
//  plugins to be used and distributed together with GStreamer and BMPx. This
//  permission is above and beyond the permissions granted by the GPL license
//  BMPx is covered by.

#include <bmp/vfs.hpp>
#include <ne_basic.h>
#include <ne_compress.h>
#include <ne_socket.h>
#include <ne_utils.h>
#include <ne_props.h>
#include <ne_session.h>
#include <ne_request.h>

#include <bmp/util.h>
#include <bmp/uri++.hpp>

#include <glibmm.h>

#include <iostream>
#include <sstream>

namespace
{

  struct ReadHandle
  {
    Bmp::URI	 uri;
    GMutex      *handle_lock;
    GMutex      *thread_lock;
    GCond       *cond;
    ne_session  *sess;
    char        *memory;
    size_t       size;
  };

  int
  read_block (void *data, const char *buf, size_t len)
  {
    ReadHandle *rhandle = reinterpret_cast<ReadHandle*>(data);

    if (!len)
    {
      g_mutex_unlock (rhandle->handle_lock);
      return 0;
    }

    rhandle->memory = static_cast<char*>(realloc (rhandle->memory, rhandle->size+len));
    memcpy  (rhandle->memory+rhandle->size, buf, len);
    rhandle->size += len;
    return 0;
  }

  void*
  neon_read_thread (void *data)
  {
    ne_session                       *sess;
    ne_request                       *req;
    char                             *path;
    ReadHandle                       *rhandle = reinterpret_cast<ReadHandle*>(data);

    if (!rhandle->uri.port) rhandle->uri.port = 80;

    if (!rhandle->uri.query.empty())
    {
      path = g_strconcat (rhandle->uri.path.c_str(), "?", rhandle->uri.query.c_str(), NULL);
    }
    else
    {
      path = g_strdup (rhandle->uri.path.c_str());
    }

    sess = ne_session_create (rhandle->uri.scheme.c_str(), rhandle->uri.hostname.c_str(), rhandle->uri.port);
    ne_set_read_timeout (sess, 30);
    rhandle->sess = sess;

    req = ne_request_create (sess, "GET", path);
    ne_add_response_body_reader (req, ne_accept_always, read_block, rhandle);
    g_mutex_lock (rhandle->handle_lock);

    ne_request_dispatch (req);

    /* wait while we busy fetching the data and make sure signals are passed */
    while (!g_mutex_trylock(rhandle->handle_lock))
      {
        while (g_main_context_pending (NULL)) g_main_context_iteration (NULL, TRUE);
      }

    g_mutex_unlock (rhandle->handle_lock);
    g_mutex_free (rhandle->handle_lock);

    free (path);

    ne_request_destroy (req);
    ne_session_destroy (sess);

    g_mutex_lock (rhandle->thread_lock);
    g_cond_signal (rhandle->cond);
    g_mutex_unlock (rhandle->thread_lock);

    g_thread_exit (0);
    return 0;
  }
}

namespace Bmp
{
  namespace VFS
  {
      class PluginTransportHTTP
	  : public Bmp::VFS::PluginTransportBase
      {

	public:

	  virtual bool	
	  can_process (const std::string& uri)
	  {
	      return (!g_ascii_strncasecmp("http://", uri.c_str(), 7));
	  }

	  virtual bool
	  handle_read (Bmp::VFS::Handle& handle)	  
	  {
	    GThread                          *thread;
	    ReadHandle                        rhandle;
	    GTimeVal                          _tv;

	    rhandle.memory = NULL;
	    rhandle.size = 0;
	    rhandle.handle_lock = g_mutex_new ();
	    rhandle.thread_lock = g_mutex_new ();
	    rhandle.uri = Bmp::URI (handle.get_uri()); 
	    rhandle.cond = g_cond_new ();

	    g_mutex_lock (rhandle.thread_lock);
	    thread = g_thread_create (neon_read_thread,
				      &rhandle,
				      FALSE,
				      NULL);

	    while (42)
	      {
		while (g_main_context_pending (NULL)) g_main_context_iteration (NULL, TRUE);
		g_get_current_time (&_tv);
		g_time_val_add (&_tv, 10000);
		if (g_cond_timed_wait(rhandle.cond, rhandle.thread_lock, &_tv)) break;
	      }

	    g_mutex_unlock (rhandle.thread_lock);
	    g_mutex_free (rhandle.thread_lock);
	    g_cond_free (rhandle.cond);

	    handle.set_buffer (reinterpret_cast<const unsigned char *>(rhandle.memory), rhandle.size);
	    free (rhandle.memory);
            return true;
	  }

	  virtual bool
	  handle_write  (const Bmp::VFS::Handle& handle)
	  {
	    return false;
	  }

      };

    }
}
  
extern "C" Bmp::VFS::PluginTransportBase* plugin_create ()
{
  return new Bmp::VFS::PluginTransportHTTP;
}

extern "C" void plugin_delete (Bmp::VFS::PluginTransportHTTP* p)
{
  delete p;
}
