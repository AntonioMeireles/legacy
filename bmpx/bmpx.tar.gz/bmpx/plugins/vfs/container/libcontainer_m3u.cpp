//  BMPx - The Dumb Music Player
//  Copyright (C) 2005 BMPx development team.
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
//
//  --
//
//  The BMPx project hereby grants permission for non-GPL compatible GStreamer
//  plugins to be used and distributed together with GStreamer and BMPx. This
//  permission is above and beyond the permissions granted by the GPL license
//  BMPx is covered by.

#include <bmp/util.h>
#include <bmp/uri++.hpp>
#include <bmp/file_utils.hpp>
#include <bmp/vfs.hpp>
#include <bmp/database.hpp>
#include <bmp/library.hpp>

#define BMP_PLUGIN_COMPILATION 1

#include "src/main.hpp"

#include <glibmm.h>

namespace Bmp
{
  namespace VFS
  {
      class PluginContainerM3U
	  : public Bmp::VFS::PluginContainerBase
      {
	  public:

	    virtual bool
	    can_process (const std::string& uri)
	    {
		return str_has_suffix_nocase (uri.c_str(), "m3u"); 
	    }

            virtual bool 
	    handle_read	(Bmp::VFS::Handle  &handle,
			 Util::FileList    &list)
	    {
		char **uris;
		int    n = 0;

		if (!handle.get_buffer()) throw Bmp::VFS::UNABLE_TO_PROCESS;

		uris = g_strsplit ((const char*)handle.get_buffer (), "\n", 0);
		 
		while (uris[n])
		{
			char *uri = uris[n];
			char *aux;

			//Strip leading spaces/tabs
			while ((uri[0] == ' ') || (uri[0] == '\t')) uri++;

			//Skip comments, extended information or null lenght uris
			if ((uri[0] == '#') || (uri[0] == '\0'))
			    {
				n++;
				continue;
			    }
	      
			if (uri[0] == '/')
			  {
				  aux = g_strconcat ("file://", uri, NULL);
				  list.push_back (aux);
				  free (aux);
			  }
			else		
			  {
				  list.push_back (uri);
			  }
			n++;
		}

		g_strfreev (uris);
		return true;
	    }

	    virtual bool
	    can_write ()
	    {
	      return true;
	    }

	    virtual bool
	    handle_write  (Bmp::VFS::Handle& handle, const Util::FileList& uri_list)
	    {
		std::stringstream out;
		std::string	  outstr;
	
		out << "#EXTM3U\n";

		for (Util::FileList::const_iterator iter = uri_list . begin (); iter != uri_list . end (); ++iter)
		{
		      Bmp::DB::DataRow row = library->get_metadata (*iter);
		      Bmp::DB::ValueVariant v_artist,
					    v_title,
					    v_duration;
		
		      v_artist   = row[library->get_metadatum_id (Bmp::Library::DATUM_ARTIST)];
		      v_title    = row[library->get_metadatum_id (Bmp::Library::DATUM_TITLE)];
		      v_duration = row[library->get_metadatum_id (Bmp::Library::DATUM_TIME)];

		      out << "#EXTINF:" << boost::get<int>(v_duration) << "," << boost::get<std::string>(v_artist) << " - " << boost::get<std::string>(v_title) << "\n";

		      Bmp::URI uri (*iter);

		      if (uri.get_protocol() != Bmp::URI::PROTOCOL_FILE)
			{ 		  
			  out << (*iter) << "\n";
			}
		      else	    
			{		      
			  uri.unescape ();
			  out << uri.path << "\n";
			}
		}
	       
		outstr = out.str(); 
		handle.set_buffer((const unsigned char *)strdup(outstr. c_str ()), strlen(outstr.c_str())+1);
		return true;
	    }

	    virtual Bmp::VFS::ExportData
	    get_export_data ()
	    {
	      static Bmp::VFS::ExportData export_data ("M3U Playlist", "m3u"); 
	      return export_data;
	    }
      };
  }
}
  
extern "C" Bmp::VFS::PluginContainerBase* plugin_create ()
{
  return new Bmp::VFS::PluginContainerM3U;
}

extern "C" void plugin_delete (Bmp::VFS::PluginContainerM3U* p)
{
  delete p;
}
