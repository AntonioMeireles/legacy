//  BMPx - The Dumb Music Player
//  Copyright (C) 2005 BMPx development team.
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
//
//  --
//
//  The BMPx project hereby grants permission for non-GPL compatible GStreamer
//  plugins to be used and distributed together with GStreamer and BMPx. This
//  permission is above and beyond the permissions granted by the GPL license
//  BMPx is covered by.

#include <bmp/util.h>
#include <bmp/uri++.hpp>
#include <bmp/file_utils.hpp>
#include <bmp/vfs.hpp>

#include <libxml/tree.h>
#include <libxml/parser.h>
#include <libxml/xmlreader.h>
#include <libxml/xpath.h>
#include <libxml/xpathInternals.h>

#define BMP_PLUGIN_COMPILATION 1

#include "src/main.hpp"
#include "src/xml.h"

#include <glibmm.h>

namespace Bmp
{
  namespace VFS
  {
      class PluginContainerXSPF
	  : public Bmp::VFS::PluginContainerBase
      {
	  public:

	    virtual bool
	    can_process (const std::string& uri)
	    {
		return str_has_suffix_nocase (uri.c_str(), "xspf"); 
	    }

            virtual bool 
	    handle_read	(Bmp::VFS::Handle   &handle,
			 Util::FileList	    &list)
	    {
		xmlXPathObjectPtr   xpathObj;
		xmlNodeSetPtr	    nv;
		xmlDocPtr	    doc;
		int		    n;

		if (!handle.get_buffer())
		    throw Bmp::VFS::UNABLE_TO_PROCESS;

		doc = xmlParseDoc (BAD_CAST handle.get_buffer());
		if (!doc)
		  {
		    g_log (G_LOG_DOMAIN, G_LOG_LEVEL_WARNING, "%s: No document", G_STRLOC);
		    throw Bmp::VFS::UNABLE_TO_PROCESS;
		  }

		xpathObj = xml_execute_xpath_expression(doc, BAD_CAST "//xspf:location", BAD_CAST "xspf=http://xspf.org/ns/0/"); 
		if (!xpathObj) 
		  {
		    g_log (G_LOG_DOMAIN, G_LOG_LEVEL_WARNING, "%s: XPath expression yields no result", G_STRLOC);
		    throw Bmp::VFS::UNABLE_TO_PROCESS;
		  }

		nv = xpathObj->nodesetval;
		if (!nv)
		  {
		    g_log (G_LOG_DOMAIN, G_LOG_LEVEL_WARNING, "%s: XPath expression result contains no nodes", G_STRLOC);
		    throw Bmp::VFS::UNABLE_TO_PROCESS;
		  }

		for (n = 0; n < nv->nodeNr; n++)
		{
		    char *aux = (char*)XML_GET_CONTENT(nv->nodeTab[n]->children);
		    Bmp::URI uri (aux);
		    uri.unescape ();
		    list.push_back (std::string(uri));
		    free (aux);
		}

		xmlXPathFreeObject (xpathObj);
		return true;
	    }

	    virtual bool
	    can_write ()
	    {
	      return true;
	    }

	    virtual bool
	    handle_write  (Bmp::VFS::Handle& handle, const Util::FileList& uri_list)
	    {

#define XSPF_ROOT_NODE_NAME "playlist"
#define XSPF_XMLNS "http://xspf.org/ns/0/"

		xmlDocPtr  doc;
		xmlNodePtr node_playlist,
			   node_tracklist,
			   node_track,
			   node_location,
			   node;
		int	   size;

		doc = xmlNewDoc(BAD_CAST "1.0"); 
		node_playlist = xmlNewNode (NULL, BAD_CAST XSPF_ROOT_NODE_NAME);
		xmlSetProp (node_playlist, BAD_CAST "version", BAD_CAST "1");
		xmlSetProp (node_playlist, BAD_CAST "xmlns", BAD_CAST "http://xspf.org/ns/0/");
		xmlDocSetRootElement (doc, node_playlist);
		node = xmlNewNode (NULL, BAD_CAST "creator");
		xmlAddChild (node, xmlNewText(BAD_CAST "BMP2"));
		xmlAddChild (node_playlist, node);

		node_tracklist = xmlNewNode (NULL, BAD_CAST "trackList");
		xmlAddChild (node_playlist, node_tracklist);

		for (Util::FileList::const_iterator iter = uri_list.begin (); iter != uri_list.end (); ++iter)
		{
		    Bmp::URI uri (*iter);
		    uri.escape ();

		    node_track = xmlNewNode (NULL, BAD_CAST "track");
		    node_location = xmlNewNode (NULL, BAD_CAST "location");
		    xmlAddChild (node_location, xmlNewText(BAD_CAST std::string(uri).c_str()) );
		    xmlAddChild (node_track, node_location); 
		    xmlAddChild (node_tracklist, node_track);

	    #if 0
		    tuple = bmp_metadata_cache_get_metadata (bmp_metadata_cache, iter_list->data);

		    if (tuple)
		      {
			elem = h_tuple_get (tuple, bmp_metadata_get_id_static (BMP_DATUM_ARTIST));
			node = 
			  xmlNewNode (NULL, UC("creator")); 
			xmlAddChild (node, xmlNewText(UC(elem->value)));
			xmlAddChild (node_track, node);

			elem = h_tuple_get (tuple, bmp_metadata_get_id_static (BMP_DATUM_ALBUM));
			node = 
			  xmlNewNode (NULL, UC("album"));
			xmlAddChild (node, xmlNewText(UC(elem->value)));
			xmlAddChild (node_track, node);

			elem = h_tuple_get (tuple, bmp_metadata_get_id_static (BMP_DATUM_TITLE));
			node = 
			  xmlNewNode (NULL, UC("title"));
			xmlAddChild (node, xmlNewText(UC(elem->value)));
			xmlAddChild (node_track, node);
		      }
	    #endif

		}

		xmlKeepBlanksDefault(0);
		xmlChar *data;
		xmlDocDumpFormatMemoryEnc (doc, &data, &size, "UTF-8", 1);
		handle.set_buffer((const unsigned char*)data, strlen((const char*)data)+1);
		return true;
	    }

	    virtual Bmp::VFS::ExportData
	    get_export_data ()
	    {
	      static Bmp::VFS::ExportData export_data ("XSPF Playlist", "xspf"); 
	      return export_data;
	    }
      };
  }
}
  
extern "C" Bmp::VFS::PluginContainerBase* plugin_create ()
{
  return new Bmp::VFS::PluginContainerXSPF;
}

extern "C" void plugin_delete (Bmp::VFS::PluginContainerXSPF* p)
{
  delete p;
}


