//  BMPx - The Dumb Music Player
//  Copyright (C) 2005 BMPx development team.
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
//
//  --
//
//  The BMPx project hereby grants permission for non-GPL compatible GStreamer
//  plugins to be used and distributed together with GStreamer and BMPx. This
//  permission is above and beyond the permissions granted by the GPL license
//  BMPx is covered by.

#include <bmp/util.h>
#include <bmp/uri++.hpp>
#include <bmp/file_utils.hpp>
#include <bmp/vfs.hpp>

#include <glibmm.h>

namespace Bmp
{
  namespace VFS
  {
      class PluginContainerPLS
	  : public Bmp::VFS::PluginContainerBase
      {
	  public:

	    virtual bool
	    can_process (const std::string& uri)
	    {
		return str_has_suffix_nocase (uri.c_str(), "pls"); 
	    }

            virtual bool 
	    handle_read	(Bmp::VFS::Handle  &handle,
			 Util::FileList    &list)
	    {
		int	    num_entries_i;
		std::string num_entries;

		if (!handle.get_buffer()) 
		    throw Bmp::VFS::UNABLE_TO_PROCESS;

		num_entries = read_ini_string_buffer ((const char*)handle.get_buffer(), "playlist", "numberofentries");
		if (!num_entries.length())
		    throw Bmp::VFS::UNABLE_TO_PROCESS;

		num_entries_i = strtol (num_entries.c_str(), NULL, 10);
		for (int n = 0; n < num_entries_i; n++)
		{
		    std::string	      key, value;
		    std::stringstream stream;

		    stream << "File" << (n+1);
		    key = stream.str();
		    value = read_ini_string_buffer ((const char*)handle.get_buffer (), "playlist", key);
		    list.push_back (value);
		}
		return true;
	    }

	    virtual bool
	    can_write ()
	    {
	      return true;
	    }

	    virtual bool
	    handle_write  (Bmp::VFS::Handle& handle, const Util::FileList& uri_list)
	    {
	      std::stringstream out;
	      int n = 1;

	      out << "[playlist]\n";
	      out << "numberofentries=" << uri_list.size () << "\n";

	      for (Util::FileList::const_iterator iter = uri_list.begin (); iter != uri_list.end (); ++iter)
	      {
		    Bmp::URI uri (*iter);
		    uri.unescape ();
		    out << "File" << n << "=" << std::string(uri) << "\n";
		    out << "Title" << n << "=\n";
		    out << "Length" << n << "=-1\n";
		    n++;
	      }

	      out << "Version=2\n";
	      
	      handle.set_buffer((const unsigned char *)strdup(out.str().c_str()), strlen(out.str().c_str())+1);
	      return true;
	    }

	    virtual Bmp::VFS::ExportData
	    get_export_data ()
	    {
	      static Bmp::VFS::ExportData export_data ("PLS Playlist", "pls"); 
	      return export_data;
	    }
      };
  }
}
  
extern "C" Bmp::VFS::PluginContainerBase* plugin_create (void)
{
  return new Bmp::VFS::PluginContainerPLS;
}

extern "C" void plugin_delete (Bmp::VFS::PluginContainerPLS* p)
{
  delete p;
}
