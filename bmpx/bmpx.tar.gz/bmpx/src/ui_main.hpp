/*  BMPx - The Dumb Music Player
 *  Copyright (C) 2005 BMPx development team.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * The BMPx project hereby grant permission for non-gpl compatible GStreamer
 * plugins to be used and distributed together with GStreamer and BMPx. This
 * permission are above and beyond the permissions granted by the GPL license
 * BMPx is covered by.
 */


#ifndef BMP_UI_MAIN_HPP
#define BMP_UI_MAIN_HPP

#include <glib-object.h>

#define BMP_TYPE_WINDOW_MAIN		  (bmp_window_main_get_type ())
#define BMP_WINDOW_MAIN(obj)		  (G_TYPE_CHECK_INSTANCE_CAST ((obj), BMP_TYPE_WINDOW_MAIN, BmpWindowMain))
#define BMP_IS_WINDOW_MAIN(obj)		  (GTK_CHECK_TYPE ((obj), BMP_TYPE_WINDOW_MAIN))
#define BMP_WINDOW_MAIN_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj), BMP_TYPE_WINDOW_MAIN, BmpWindowMainClass))
#define BMP_WINDOW_MAIN_CLASS(klass)	  (G_TYPE_CHECK_CLASS_CAST ((klass), BMP_TYPE_WINDOW_MAIN, BmpWindowMainClass))
#define BMP_IS_WINDOW_MAIN_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass), BMP_TYPE_WINDOW_MAIN))

typedef struct _BmpWindowMain BmpWindowMain;
typedef struct _BmpWindowMainClass BmpWindowMainClass;
typedef struct _BmpWindowMainPrivate BmpWindowMainPrivate;

struct _BmpWindowMain {
	GObject parent;

        BmpWindowMainPrivate *priv;

	GtkWidget *window;
};

struct _BmpWindowMainClass {
	GObjectClass parent;
};

typedef enum {
	BMP_UI_MAIN_SLIDER_VOLUME,
	BMP_UI_MAIN_SLIDER_BALANCE,
	BMP_UI_MAIN_SLIDER_SEEK,

	BMP_UI_MAIN_N_SLIDERS
} BmpUIMainSliders;

GType
bmp_window_main_get_type (void);

BmpWindowMain*
bmp_window_main_new (void);

void
bmp_window_main_configure	  (BmpWindowMain *window);

void
bmp_window_main_iconify		  (BmpWindowMain *window);

#if 0
void
bmp_window_main_set_seek_request  (BmpWindowMain *window,
				   gint		  seek_request);
#endif

void
bmp_window_main_get_seek_time	  (BmpWindowMain *window,
				   gint		 *minutes,
				   gint		 *seconds);

#endif // BMP_UI_MAIN_HPP
