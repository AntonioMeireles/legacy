//-*- Mode: C; indent-tabs-mode: nil; -*-

#include <config.h>

#include <stdlib.h>
#include <string.h>

#include <sqlite3.h>

#include <glib.h>

#include <bmp/metadata.h>

#include "hrel_sqlite_connector.h"
#include "main.h"

G_DEFINE_TYPE (BmpHRelSQLiteConnector, bmp_hrel_sqlite_connector, G_TYPE_OBJECT)

struct _BmpHRelSQLiteConnectorPrivate {

      gboolean    dispose_has_run;

      HRelation	  *relation;
      sqlite3	  *sqlite3;
      gchar	  *sqlite3_filename;
      gchar	  *name;

      gulong	   handler_id_insert;
      gulong	   handler_id_delete;

};

static void
bmp_hrel_sqlite_connector_init_db	(BmpHRelSQLiteConnector *connector);

static gint
bmp_hrel_sqlite_connector_sql_exec	(BmpHRelSQLiteConnector *connector,
					 gchar			*SQL)
{
    gchar *error = NULL;
    gint   err;

    err = sqlite3_exec (connector->private->sqlite3, SQL, NULL, NULL, &error);

    if (err)
      {
	  g_message (error);
      }

    return err;
}

gboolean
bmp_hrel_sqlite_connector_open		(BmpHRelSQLiteConnector *connector)
{
    gboolean init = FALSE;
    gint     err;

    init = (!g_file_test (connector->private->sqlite3_filename, G_FILE_TEST_EXISTS));
    err = sqlite3_open (connector->private->sqlite3_filename, &connector->private->sqlite3);

    if (init)
     {
         bmp_hrel_sqlite_connector_init_db (connector);
     }

    return init;
}

gint
bmp_hrel_sqlite_connector_close		(BmpHRelSQLiteConnector *connector)
{
    return sqlite3_close (connector->private->sqlite3);
}

static void
bmp_hrel_sqlite_connector_init_db (BmpHRelSQLiteConnector *connector)
{
    gchar *SQL;

    SQL = sqlite3_mprintf
          ("CREATE TABLE 'files' ('%s' text NOT NULL, '%s' text, '%s'  text, '%s'  text, '%s'  integer, '%s'  integer, '%s'  text, '%s'  text, '%s'  integer, '%s'  integer, '%s'  integer, '%s'  integer, '%s'  integer, '%s' integer, '%s'  text, '%s'  text);",
				  bmp_metadata_get_id_static (BMP_DATUM_LOCATION),
				  bmp_metadata_get_id_static (BMP_DATUM_ARTIST),
				  bmp_metadata_get_id_static (BMP_DATUM_ALBUM),
				  bmp_metadata_get_id_static (BMP_DATUM_TITLE),

				  bmp_metadata_get_id_static (BMP_DATUM_TRACK),
				  bmp_metadata_get_id_static (BMP_DATUM_TIME),

				  bmp_metadata_get_id_static (BMP_DATUM_GENRE),
				  bmp_metadata_get_id_static (BMP_DATUM_COMMENT),

				  bmp_metadata_get_id_static (BMP_DATUM_RATING),
				  bmp_metadata_get_id_static (BMP_DATUM_DATE),
				  bmp_metadata_get_id_static (BMP_DATUM_MTIME),
				  bmp_metadata_get_id_static (BMP_DATUM_BITRATE),
				  bmp_metadata_get_id_static (BMP_DATUM_SAMPLERATE),
				  bmp_metadata_get_id_static (BMP_DATUM_COUNT),

				  bmp_metadata_get_id_static (BMP_DATUM_HAL_VOLUME_UDI),
				  bmp_metadata_get_id_static (BMP_DATUM_HAL_DEVICE_UDI));

    bmp_hrel_sqlite_connector_sql_exec (connector, SQL);
    g_free (SQL);

    bmp_hrel_sqlite_connector_sql_exec (connector,
                   "CREATE TABLE 'meta' ('key' text NOT NULL, 'value' text NOT NULL);");
    bmp_hrel_sqlite_connector_sql_exec (connector,
                   "INSERT INTO  'meta' (key, value) VALUES ('id','bmpx_db');");


    SQL = g_strdup_printf ("INSERT INTO 'meta' (key, value) VALUES ('db_version','%f');", 0.1);
    bmp_hrel_sqlite_connector_sql_exec (connector, SQL);
    g_free (SQL);
}

static void
insert_tuple (HRelation		      *relation,
	      HTuple		      *tuple,
	      BmpHRelSQLiteConnector  *self)
{
     gchar	*SQL;

     SQL = sqlite3_mprintf
          ("INSERT INTO 'files'  ('%s', "
				" '%s', "
				" '%s', "
				" '%s', "
				" '%s', "
				" '%s', "
				" '%s', "
				" '%s', "
				" '%s', "
				" '%s', "
				" '%s', "
				" '%s', "
				" '%s', "
				" '%s', "
				" '%s', "
				" '%s') VALUES ('%s', '%q', '%q', '%q', "
					      " '%d', '%d', "
					      " '%q', '%q', "
					      " '%d', '%d', '%d', '%d', '%d', '%d', "
					      " '%s', '%s');",

				  bmp_metadata_get_id_static (BMP_DATUM_LOCATION),
				  bmp_metadata_get_id_static (BMP_DATUM_ARTIST),
				  bmp_metadata_get_id_static (BMP_DATUM_ALBUM),
				  bmp_metadata_get_id_static (BMP_DATUM_TITLE),

				  bmp_metadata_get_id_static (BMP_DATUM_TRACK),
				  bmp_metadata_get_id_static (BMP_DATUM_TIME),

				  bmp_metadata_get_id_static (BMP_DATUM_GENRE),
				  bmp_metadata_get_id_static (BMP_DATUM_COMMENT),

				  bmp_metadata_get_id_static (BMP_DATUM_RATING),
				  bmp_metadata_get_id_static (BMP_DATUM_DATE),
				  bmp_metadata_get_id_static (BMP_DATUM_MTIME),
				  bmp_metadata_get_id_static (BMP_DATUM_BITRATE),
				  bmp_metadata_get_id_static (BMP_DATUM_SAMPLERATE),
				  bmp_metadata_get_id_static (BMP_DATUM_COUNT),

				  bmp_metadata_get_id_static (BMP_DATUM_HAL_VOLUME_UDI),
				  bmp_metadata_get_id_static (BMP_DATUM_HAL_DEVICE_UDI),

				  h_tuple_get (tuple, bmp_metadata_get_id_static (BMP_DATUM_LOCATION))->value,
				  h_tuple_get (tuple, bmp_metadata_get_id_static (BMP_DATUM_ARTIST))->value,
				  h_tuple_get (tuple, bmp_metadata_get_id_static (BMP_DATUM_ALBUM))->value,
				  h_tuple_get (tuple, bmp_metadata_get_id_static (BMP_DATUM_TITLE))->value,

				  GPOINTER_TO_INT(h_tuple_get (tuple, bmp_metadata_get_id_static (BMP_DATUM_TRACK))->value),
				  GPOINTER_TO_INT(h_tuple_get (tuple, bmp_metadata_get_id_static (BMP_DATUM_TIME))->value),

				  h_tuple_get (tuple, bmp_metadata_get_id_static (BMP_DATUM_GENRE))->value,
				  h_tuple_get (tuple, bmp_metadata_get_id_static (BMP_DATUM_COMMENT))->value,

				  GPOINTER_TO_INT(h_tuple_get (tuple, bmp_metadata_get_id_static (BMP_DATUM_RATING))->value),
				  GPOINTER_TO_INT(h_tuple_get (tuple, bmp_metadata_get_id_static (BMP_DATUM_DATE))->value),
				  GPOINTER_TO_INT(h_tuple_get (tuple, bmp_metadata_get_id_static (BMP_DATUM_MTIME))->value),
				  GPOINTER_TO_INT(h_tuple_get (tuple, bmp_metadata_get_id_static (BMP_DATUM_BITRATE))->value),
				  GPOINTER_TO_INT(h_tuple_get (tuple, bmp_metadata_get_id_static (BMP_DATUM_SAMPLERATE))->value),
				  GPOINTER_TO_INT(h_tuple_get (tuple, bmp_metadata_get_id_static (BMP_DATUM_COUNT))->value),

				  h_tuple_get (tuple, bmp_metadata_get_id_static (BMP_DATUM_HAL_VOLUME_UDI))->value,
				  h_tuple_get (tuple, bmp_metadata_get_id_static (BMP_DATUM_HAL_DEVICE_UDI))->value);

    bmp_hrel_sqlite_connector_sql_exec	(self,
					 SQL);
}

static void
delete_tuple (HRelation		      *relation,
	      HTuple		      *tuple,
	      BmpHRelSQLiteConnector  *self)
{
     gchar	*SQL;

     return;

     SQL = g_strdup_printf
          ("DELETE FROM 'files' where '%s' = '%s';", bmp_metadata_get_id_static (BMP_METADATA_PKEY),
						     h_tuple_get (tuple, bmp_metadata_get_id_static (BMP_METADATA_PKEY))->value);
     bmp_hrel_sqlite_connector_sql_exec	(self,
					 SQL);
}

typedef struct _ConnectorQTuple ConnectorQTuple;
struct _ConnectorQTuple {

    sqlite3   *sqlite3;
    gchar     *error;
    gchar    **result;
    gint       nrow,
	       ncolumn,
	       k,
	       n;
    GMutex    *lock;
};

static gpointer
run_all_query (ConnectorQTuple *qtuple)
{
    sqlite3_get_table (qtuple->sqlite3, "SELECT * FROM files;", &(qtuple->result), &(qtuple->nrow), &(qtuple->ncolumn), &(qtuple->error));
    g_mutex_unlock (qtuple->lock);
    g_thread_exit (NULL);
    return NULL; //GCC
}

void
bmp_hrel_sqlite_connector_read_all  (BmpHRelSQLiteConnector *connector)
{
    ConnectorQTuple *qtuple;
    HTuple	    *tuple;
    GThread	    *thread;
    gint	     k,
		     n;

    qtuple = g_new0 (ConnectorQTuple, 1);
    qtuple->sqlite3 = connector->private->sqlite3;
    qtuple->lock = g_mutex_new ();

    g_mutex_lock (qtuple->lock);
    thread = g_thread_create ((GThreadFunc) run_all_query, qtuple, TRUE, NULL);

    while (!g_mutex_trylock (qtuple->lock))
      {
	  while (g_main_context_pending(NULL)) g_main_context_iteration (NULL, TRUE);
      }

    g_mutex_unlock (qtuple->lock);
    g_thread_join (thread);

    if (qtuple->nrow < 2) return;
    for (k = 0; k < qtuple->nrow; k++)
      {
	  tuple = h_tuple_new ();
	  for (n = 0; n < BMP_DATUM_NONE; n++)
	    {
		switch (bmp_metadata_get_type (n))
		  {
		    case G_TYPE_STRING:
		      {
		      	h_tuple_insert (tuple,
					bmp_metadata_get_id_static (n),
					G_TYPE_STRING,
					qtuple->result[(k*qtuple->ncolumn)+qtuple->ncolumn+n]);
			break;
		      }

		    case G_TYPE_INT:
		      {
		      	h_tuple_insert (tuple,
					bmp_metadata_get_id_static (n),
					G_TYPE_INT,
					GINT_TO_POINTER(atoi(qtuple->result[(k*qtuple->ncolumn)+qtuple->ncolumn+n])));
			break;
		      }

		    case G_TYPE_LONG:
		      {
			glong l_val;

			l_val = strtol (qtuple->result[(k*qtuple->ncolumn)+qtuple->ncolumn+n], NULL, 10);

		      	h_tuple_insert (tuple,
					bmp_metadata_get_id_static (n),
					G_TYPE_LONG,
					(gpointer)l_val);
			break;
		      }
		  }
	    }

        h_relation_base_insert_tuple (H_RELATION_BASE(connector->private->relation), tuple);
	h_tuple_free (tuple);
	while (g_main_context_pending(NULL)) g_main_context_iteration (NULL, TRUE);
      }

    sqlite3_free_table (qtuple->result);
    g_mutex_free (qtuple->lock);
    g_free (qtuple);
}


HTuple*
bmp_hrel_sqlite_connector_read  (BmpHRelSQLiteConnector *connector,
			         const gchar		*uri)
{
    HTuple   *tuple;
    gchar    *SQL,
	     *error;
    gchar   **result;
    gint      nrow,
	      ncolumn,
	      n;

    tuple = h_relation_base_get_tuplev (H_RELATION_BASE(connector->private->relation),
					bmp_metadata_get_id_static (BMP_METADATA_PKEY),
				        (gpointer)uri);

    if (tuple) return tuple;

    SQL = sqlite3_mprintf ("SELECT * FROM files WHERE '%s' = '%s';", bmp_metadata_get_id_static (BMP_METADATA_PKEY), uri);
    sqlite3_get_table (connector->private->sqlite3, SQL, &result, &nrow, &ncolumn, &error);
    if (nrow < 2) return NULL;

    tuple = h_tuple_new ();
    for (n = 0; n < BMP_DATUM_NONE; n++)
      {
	  switch (bmp_metadata_get_type (n))
	      {
		    case G_TYPE_STRING:
		      {
		      	h_tuple_insert (tuple,
					bmp_metadata_get_id_static (n),
					G_TYPE_STRING,
					result[ncolumn+n]);
			break;
		      }

		    case G_TYPE_INT:
		      {
		      	h_tuple_insert (tuple,
					bmp_metadata_get_id_static (n),
					G_TYPE_INT,
					GINT_TO_POINTER(atoi(result[ncolumn+n])));
			break;
		      }

		    case G_TYPE_LONG:
		      {
			glong l_val;

			l_val = strtol (result[ncolumn+n], NULL, 10);

		      	h_tuple_insert (tuple,
					bmp_metadata_get_id_static (n),
					G_TYPE_LONG,
					(gpointer)l_val);
			break;
		      }
	      }
      }

    sqlite3_free_table (result);

    return tuple;
}

BmpHRelSQLiteConnector*
bmp_hrel_sqlite_connector_new	(HRelation		*relation,
				 const gchar		*name)
{
    BmpHRelSQLiteConnector *self;

    self = g_object_new (BMP_TYPE_HREL_SQLITE_CONNECTOR, NULL);
    self->private->sqlite3_filename = g_strconcat (BMP_PATH_USER_DIR, "/", name, ".hsql", NULL);
    self->private->name		    = g_strdup (name);
    self->private->relation	    = relation;

    self->private->handler_id_insert = g_signal_connect (G_OBJECT(relation),
						"insert-tuple",
						G_CALLBACK(insert_tuple),
						self);

    self->private->handler_id_delete = g_signal_connect (G_OBJECT(relation),
						"delete-tuple",
						G_CALLBACK(delete_tuple),
						self);

    return self;
}

/*
 * GObject stuff
 */
static void
bmp_hrel_sqlite_connector_init	(BmpHRelSQLiteConnector *connector)
{
    connector->private =
        g_new0 (BmpHRelSQLiteConnectorPrivate, 1);

    connector->private->dispose_has_run =
        FALSE;

    connector->private->sqlite3_filename =
        NULL;

    connector->private->sqlite3 =
        NULL;
}

static GObject *
bmp_hrel_sqlite_connector_constructor (GType type,
                  guint n_construct_properties,
                  GObjectConstructParam * construct_properties)
{
    GObject *obj;

    {
        BmpHRelSQLiteConnectorClass	*klass;
        GObjectClass	*parent_class;

        klass = BMP_HREL_SQLITE_CONNECTOR_CLASS (g_type_class_peek (BMP_TYPE_HREL_SQLITE_CONNECTOR));
        parent_class = G_OBJECT_CLASS (g_type_class_peek_parent (klass));

        obj = parent_class->constructor (type,
                                         n_construct_properties,
                                         construct_properties);
    }

    return obj;
}

static void
bmp_hrel_sqlite_connector_dispose (GObject * obj)
{
    BmpHRelSQLiteConnector *connector = (BmpHRelSQLiteConnector *) obj;

    if (connector->private->dispose_has_run) return;
    connector->private->dispose_has_run = TRUE;
}

static void
bmp_hrel_sqlite_connector_finalize (GObject * obj)
{
    BmpHRelSQLiteConnector *connector = (BmpHRelSQLiteConnector *) obj;

    g_free (connector->private);
}

static void
bmp_hrel_sqlite_connector_class_init (BmpHRelSQLiteConnectorClass * klass)
{

    GObjectClass *gobject_class = G_OBJECT_CLASS (klass);

    gobject_class->dispose	= bmp_hrel_sqlite_connector_dispose;
    gobject_class->finalize	= bmp_hrel_sqlite_connector_finalize;
    gobject_class->constructor	= bmp_hrel_sqlite_connector_constructor;

}
