/*  BMPx - Cross-platform multimedia player
 *  Copyright (C) 2003-2004  Edward Brocklesby, Chong Kai Xiong,
 *            Milosz Derezynski, David Lau, Michiel Sikkes
 *
 *  ui.c/bmp_ui.h
 *  bmp_button.c/bmp_button.h
 *  bmp_button_toggle.c/bmp_button_toggle.h
 *  bmp_slider.c/bmp_slider.h
 *
 *  M.Derezynski
 *  Tim-Philipp Mueller
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * The BMPx project hereby grant permission for non-gpl compatible GStreamer
 * plugins to be used and distributed together with GStreamer and BMPx. This
 * permission are above and beyond the permissions granted by the GPL license
 * BMPx is covered by.
 */

#include <gtk/gtk.h>
#include <glib/gi18n.h>

#include <cstring>

#include <bmp/widgets/bmp_button.h>
#include <bmp/widgets/bmp_button_toggle.h>
#include <bmp/widgets/bmp_slider.h>
#include <bmp/widgets/bmp_window.h>
#include <chroma/chroma-list.h>

#include <bmp/util.h>
#include <goa/libgoa.h>

#include "error.hpp"
#include "resource_manager.hpp"
#include "wm.hpp"

#include "ui.hpp"
#include "ui_playlist.hpp"
#include "ui_main.hpp"
#include "ui_dialog_about.hpp"

#include "library_ui.hpp"

//C++ objects
#include "trackinfo.hpp"
#include "streams.hpp"
#include "preferences.hpp"

//Utility/auxilliary stuff
#include "ui_util.hpp"
#include "ui_callbacks.hpp"

#include "bmp_status_icon.h"

G_DEFINE_TYPE (BmpUI, bmp_ui, G_TYPE_OBJECT)

#include "main.hpp"
#include "paths.hpp"

using namespace Bmp;

enum {
    BMP_UI_PROP_TRAYICON_EMBEDDED = 1,
    BMP_PLAY_N_PROPS
};

struct _BmpUIPrivate {

    gboolean dispose_has_run;

#if 0
    gboolean               trayicon_embedded;
#endif

    BmpWindowMain         *window_main;
    BmpWindowPlaylist     *window_playlist;

#if 0
    BmpLibrary            *library;
    BmpJumpToTrack	  *jtt;
#endif

    Bmp::LibraryUI	  *library;
    Bmp::AboutDialog      *about_dialog;
    Bmp::TrackInfo	  *trackinfo;
    Bmp::Streams::Dialog  *streams;
    Bmp::Preferences	  *preferences;

    GdkBitmap             *window_main_mask;

    BmpStatusIcon         *status_icon;
    GdkPixbuf             *status_icon_image_default;
    GdkPixbuf             *status_icon_image_paused;
    GdkPixbuf             *status_icon_image_playing;

    gint                   x_main;
    gint                   y_main;
    gint                   x_pl;
    gint                   y_pl;
    gint                   w_pl;
    gint                   h_pl;
};

static gchar* bmp_skin_files[] = {
        "main.bmp",
        "shufrep.bmp",
        "cbuttons.bmp",
        "posbar.bmp",
        "volume.bmp",
        "titlebar.bmp",
        "balance.bmp",
        "pledit.bmp",
        "monoster.bmp",
        NULL,
        "playpaus.bmp"
};

static BmpSkinComponent bmp_skin_files_sequential[] = {
        SKIN_COMPONENT_MAIN,
        SKIN_COMPONENT_SHUFREP,
        SKIN_COMPONENT_CBUTTONS,
        SKIN_COMPONENT_TITLEBAR,
        SKIN_COMPONENT_PLEDIT,
        SKIN_COMPONENT_MONOSTER,
        SKIN_COMPONENT_PLAYPAUSE
};

static void
on_action_show_ui_toggled         (GtkToggleAction *action, BmpUI *self);

static void
on_action_keep_above_toggled      (GtkToggleAction *action, BmpUI *self);

static GtkToggleActionEntry bmp_toggle_actions_UI[] = {

  { BMP_TOGGLE_ACTION_MUTE,
        NULL,
        N_("Mute Volume"),
        NULL,
        N_("Mute Volume"),
        G_CALLBACK (bmp_ui_callback_mute),
        FALSE },

  { BMP_TOGGLE_ACTION_SHOW_UI,
        NULL,
        N_("Show UI"),
        NULL,
        N_("Toggle BMP UI Visiblity"),
        G_CALLBACK (on_action_show_ui_toggled),
        TRUE },

  { BMP_TOGGLE_ACTION_KEEP_ABOVE,
        NULL,
        N_("Keep BMP on top"),
        NULL,
        N_("Keep BMP on top"),
        G_CALLBACK (on_action_keep_above_toggled),
        FALSE },
};

/* 'extern' referenced */
GtkUIManager	  *bmp_ui_manager = NULL;
BmpPosbarT	  *bmp_posbar;
BmpVolumeT	  *bmp_volume;
BmpVolumeT	  *bmp_balance;
BmpSkinComponentT *bmp_skin_component[N_SKIN_COMPONENTS];
GtkWidget	  *c_tracklist;
GtkWidget	  *c_tracklist_scrollbar;

/* Action groups */
GtkActionGroup *bmp_actions = NULL;
GtkActionGroup *bmp_toggle_actions = NULL;

static void
set_ui_title      (BmpUI         *self,
                   const gchar   *title);

static void
set_ui_playstatus (BmpUI         *self,
                   Bmp::Playstatus  playstatus);


static void
skin_components_free (BmpUI *self)
{
  gint n;

 /* Free memory */
  for (n = 0; n < N_SKIN_COMPONENTS; n++)
  {
     if (bmp_skin_component[n] != NULL)
     {
        g_object_unref (bmp_skin_component[n]->pixbuf);
        g_free (bmp_skin_component[n]);
        bmp_skin_component[n] = NULL;
     }
  }

  if (bmp_posbar)
        {
                g_object_unref (bmp_posbar->pixbuf);
                g_free (bmp_posbar);
                bmp_posbar = NULL;
        }

  if (bmp_volume)
        {
                g_object_unref (bmp_volume->pixbuf);
                g_free (bmp_volume);
                bmp_volume = NULL;
        }

  if (bmp_balance)
        {
                g_object_unref (bmp_balance->pixbuf);
                g_free (bmp_balance);
                bmp_balance = NULL;
        }
}

static void
load_skin_components (BmpUI             *self,
                      const std::string &archive_filename,
                      gint               type,
                      BmpSkinComponentT *(*skin_components)[N_SKIN_COMPONENTS])
{
  GdkPixbuf *pixbuf;

  std::string filename, archive_dirname;

  /* Free memory */
  skin_components_free (self);
  bmp_cursors_free ();

  /* LOAD COMPONENTS */
  if (type == BMP_SKIN_ARCHIVE)
    {
        archive_dirname = Util::archive_decompress (archive_filename);
    }
  else
    {
        archive_dirname = archive_filename;
    }

  bmp_cursors_set (archive_dirname.c_str());

  /* Buttons, Titlebars */
  for (unsigned int n = 0; n < G_N_ELEMENTS(bmp_skin_files_sequential); n++)
    {
      if (!Util::find_file (archive_dirname, bmp_skin_files[bmp_skin_files_sequential[n]], filename, 1))
        {
                g_message("%s not found", bmp_skin_files[bmp_skin_files_sequential[n]]);
        }
      else
        {
              pixbuf = gdk_pixbuf_new_from_file (filename.c_str(), NULL);

              (*skin_components)[bmp_skin_files_sequential[n]] = new BmpSkinComponentT;
              (*skin_components)[bmp_skin_files_sequential[n]]->identifier = bmp_skin_files_sequential[n];
              (*skin_components)[bmp_skin_files_sequential[n]]->pixbuf = pixbuf;
        }
    }

  /* Numbers */
  (*skin_components)[SKIN_COMPONENT_NUMBERS] = new BmpSkinComponentT;

  Util::find_file (archive_dirname, "numbers.bmp", filename, 1);

  if (filename.empty ())
    {
        Util::find_file (archive_dirname, "nums_ex.bmp", filename, 1);
    }

  if (filename.empty ())
    {
        g_message("%s: Numbers not found", G_STRFUNC);
        g_free ((*skin_components)[SKIN_COMPONENT_NUMBERS]);
    }
  else
    {
        pixbuf = gdk_pixbuf_new_from_file (filename.c_str(), NULL);
        (*skin_components)[SKIN_COMPONENT_NUMBERS]->identifier = SKIN_COMPONENT_NUMBERS;
        (*skin_components)[SKIN_COMPONENT_NUMBERS]->pixbuf = pixbuf;

        if (gdk_pixbuf_get_width(pixbuf) >= 108)
	  {
	      (*skin_components)[SKIN_COMPONENT_NUMBERS]->user_data = GINT_TO_POINTER (12);
	  }
        else
	  {
	      (*skin_components)[SKIN_COMPONENT_NUMBERS]->user_data = GINT_TO_POINTER (10);
	  }
    }

  /* Volume, Balance and Seek slider*/
  Util::find_file (archive_dirname, bmp_skin_files[SKIN_COMPONENT_POSBAR], filename, 1);
  if (filename.empty ())
    {
        g_message("%s not found", bmp_skin_files[SKIN_COMPONENT_POSBAR]);
    }
  else
   {
        pixbuf = gdk_pixbuf_new_from_file(filename.c_str(), NULL);
        bmp_posbar = new BmpPosbarT;
        bmp_posbar->pixbuf = pixbuf;
   }

  Util::find_file (archive_dirname, bmp_skin_files[SKIN_COMPONENT_VOLUME], filename, 1);
  if (filename.empty ())
    {
        g_message("%s not found", bmp_skin_files[SKIN_COMPONENT_VOLUME]);
    }
  else
    {
        pixbuf = gdk_pixbuf_new_from_file(filename.c_str(), NULL);
        bmp_volume = new BmpVolumeT;
        bmp_volume->pixbuf = pixbuf;
        bmp_volume->height = gdk_pixbuf_get_height(pixbuf) - 422;

        if (gdk_pixbuf_get_height(pixbuf) > 422)
            bmp_volume->has_button = TRUE;
        else
            bmp_volume->has_button = FALSE;
    }

  Util::find_file (archive_dirname, bmp_skin_files[SKIN_COMPONENT_BALANCE], filename, 1);
  if (filename.empty ())
    {
        g_message ("%s not found", bmp_skin_files[SKIN_COMPONENT_BALANCE]);
    }
  else
    {
        pixbuf = gdk_pixbuf_new_from_file(filename.c_str(), NULL);
        bmp_balance = new BmpVolumeT;

        bmp_balance->pixbuf = pixbuf;
        bmp_balance->height = gdk_pixbuf_get_height(pixbuf) - 421;

        if (gdk_pixbuf_get_height(pixbuf) > 421)
            bmp_balance->has_button = TRUE;
        else
            bmp_balance->has_button = FALSE;
    }

  bmp_colors_init (archive_dirname.c_str());

  /* FIXME: Move this into ui_main.c */
  self->priv->window_main_mask = bmp_get_mask_window_main (archive_dirname);

  if (type == BMP_SKIN_ARCHIVE)
    {
        Util::del_directory (archive_dirname);
    }
}


GdkBitmap*
bmp_ui_get_mask_window_main (BmpUI *self)
{
    g_return_val_if_fail (BMP_IS_UI (self), NULL);

    return self->priv->window_main_mask;
}

static void
display_windows (BmpUI *self)
{
    gint x,y,w,h;
    gboolean visible;

    w = mcs->key_get<int>("playlist-window", "width");
    h = mcs->key_get<int>("playlist-window", "height");
    x = mcs->key_get<int>("playlist-window", "pos_x");
    y = mcs->key_get<int>("playlist-window", "pos_y");

    if ((x > -1) && (y > -1))
      {
        gtk_window_move (GTK_WINDOW(self->priv->window_playlist->window), x, y);
        BMP_WINDOW (self->priv->window_playlist->window)->x = x;
        BMP_WINDOW (self->priv->window_playlist->window)->y = y;
      }
    else
      {
        x = gdk_screen_get_width (gdk_screen_get_default());
        y = gdk_screen_get_height (gdk_screen_get_default());

        x /= 2;
        y /= 2;

        x -= BMP_WINDOW_MAIN_WIDTH;
        y -= BMP_WINDOW_MAIN_HEIGHT;

        gtk_window_move (GTK_WINDOW(self->priv->window_playlist->window), x, y);
        BMP_WINDOW (self->priv->window_playlist->window)->x = x;
        BMP_WINDOW (self->priv->window_playlist->window)->y = y;
      }

    visible = mcs->key_get<bool>("playlist-window", "visible");

    if (visible)
      {
        gtk_toggle_action_set_active (GTK_TOGGLE_ACTION(gtk_action_group_get_action(bmp_toggle_actions,BMP_TOGGLE_ACTION_PL)), TRUE);
        gtk_window_resize (GTK_WINDOW(self->priv->window_playlist->window), w, h);
      }

    x = mcs->key_get<int>("main-window", "pos_x");
    y = mcs->key_get<int>("main-window", "pos_y");

    if ((x > -1) && (y > -1))
    {
        gtk_window_move (GTK_WINDOW(self->priv->window_main->window), x, y);
        BMP_WINDOW (self->priv->window_main->window)->x = x;
        BMP_WINDOW (self->priv->window_main->window)->y = y;
    }
    else
    {
        x = gdk_screen_get_width (gdk_screen_get_default());
        y = gdk_screen_get_height (gdk_screen_get_default());

        x /= 2;
        y /= 2;

        x -= BMP_WINDOW_MAIN_WIDTH/2;
        y -= BMP_WINDOW_MAIN_HEIGHT/2;

        gtk_window_move (GTK_WINDOW(self->priv->window_main->window), x, y);
        BMP_WINDOW (self->priv->window_main->window)->x = x;
        BMP_WINDOW (self->priv->window_main->window)->y = y;
      }
    gtk_widget_show_all (BMP_WINDOW_MAIN(self->priv->window_main)->window);


}

static int
load_skin (BmpUI             *self,
           const std::string &filename,
           BmpSkinComponentT *(*skin_components)[N_SKIN_COMPONENTS])
{
    gint error_status;

    if (!Glib::file_test(filename, Glib::FILE_TEST_EXISTS)) {
        error_status = BMP_ERROR_FAILURE;
        return error_status;
    }

    bmp_colors_free();

    if (Glib::file_test(filename, Glib::FILE_TEST_IS_DIR)) {
        load_skin_components (self, filename, BMP_SKIN_DIR, skin_components);
        error_status = BMP_ERROR_SUCCESS;
    }
    else
    if (Glib::file_test(filename, Glib::FILE_TEST_IS_REGULAR)) {
        load_skin_components(self, filename, BMP_SKIN_ARCHIVE, skin_components);
        error_status = BMP_ERROR_SUCCESS;
    }
    else
    {
        error_status = BMP_ERROR_FAILURE;
        return error_status;
    }

    if (self->priv->window_main)
        bmp_window_main_configure (BMP_WINDOW_MAIN (self->priv->window_main));

    if (self->priv->window_playlist)
        bmp_window_playlist_configure (BMP_WINDOW_PLAYLIST (self->priv->window_playlist));

    return error_status;
}

static void
on_bmp_skin_changed (MCS_CB_DEFAULT_SIGNATURE, BmpUI *ui)
{
    std::string path = boost::get<std::string> (value);
    if (load_skin (ui, path, &bmp_skin_component) != BMP_ERROR_SUCCESS)
      {
	mcs->key_unset ("bmp", "skin");
      }
}

static void
on_system_control_set_title (BmpSystemControl *control,
			     char	      *title,
                             BmpUI            *self)
{
    set_ui_title (self, title);
}

static void
on_tray_icon_click (BmpStatusIcon *icon, gpointer data)
{
    GtkToggleAction *action;
    gboolean active;

    action = GTK_TOGGLE_ACTION(gtk_action_group_get_action (bmp_toggle_actions, BMP_TOGGLE_ACTION_SHOW_UI));
    active = gtk_toggle_action_get_active (action);

    gtk_toggle_action_set_active (GTK_TOGGLE_ACTION(action), !active);
}

static void
on_tray_icon_scroll_up (BmpStatusIcon *icon, gpointer data)
{
    gint volume;

    volume = g_object_get_int (bmp_system_control, "volume");
    volume += 4;
    volume = (volume > 100) ? 100 : volume;
    bmp_system_control_volume_set (bmp_system_control, volume, NULL);
}

static void
on_tray_icon_scroll_down (BmpStatusIcon *icon, gpointer data)
{
    gint volume;

    volume = g_object_get_int (bmp_system_control, "volume");
    volume -= 4;
    volume = (volume < 0) ? 0 : volume;
    bmp_system_control_volume_set (bmp_system_control, volume, NULL);
}


static void
on_tray_icon_popup_menu (BmpStatusIcon *icon, guint arg1, guint arg2, gpointer data)
{
    GtkWidget *menu;

    menu = ui_manager_get_popup (bmp_ui_manager, "/popup-tray/menu-tray");
    gtk_widget_realize (menu);
    gtk_menu_popup (GTK_MENU(menu), NULL, NULL, NULL, NULL, arg1, arg2);
}

static void
set_ui_playstatus (BmpUI          *self,
                   Bmp::Playstatus   playstatus)
{
  const gchar *stock_id;

  if (playstatus == PLAYSTATUS_PLAYING)
      {
            bmp_status_icon_set_from_pixbuf (self->priv->status_icon,
                                             self->priv->status_icon_image_playing);
      }
  else
  if (playstatus == PLAYSTATUS_PAUSED)
      {
            bmp_status_icon_set_from_pixbuf (self->priv->status_icon,
                                             self->priv->status_icon_image_paused);
      }
  else
      {
            bmp_status_icon_set_from_pixbuf (self->priv->status_icon,
                                             self->priv->status_icon_image_default);
      }

    switch (playstatus)
      {
        case PLAYSTATUS_STOPPED: stock_id = GTK_STOCK_MEDIA_STOP; break;
        case PLAYSTATUS_PAUSED:  stock_id = GTK_STOCK_MEDIA_PAUSE; break;
        case PLAYSTATUS_PLAYING: stock_id = GTK_STOCK_MEDIA_PLAY; break;
        default: stock_id = GTK_STOCK_MEDIA_STOP; break;
      }

    bmp_status_icon_set_icon (self->priv->status_icon, stock_id);

    if (playstatus == PLAYSTATUS_STOPPED)
      {
        bmp_status_icon_set_text (self->priv->status_icon, "");
      }
}

static void
set_ui_title    (BmpUI        *self,
                 const gchar  *title)
{
    gchar       *window_title;

    g_return_if_fail (BMP_IS_UI(self));

    if (!title)
      {
        window_title = g_strdup_printf ("BMP");
      }
    else
      {
        window_title = g_strdup_printf ("BMP: %s", title);
      }
    gtk_window_set_title (GTK_WINDOW(self->priv->window_main->window), window_title);

}

static void
on_system_control_set_playstatus (BmpSystemControl *system_control,
                                  Bmp::Playstatus   status,
                                  BmpUI            *self)
{
    set_ui_playstatus (self, status);
}

static void
on_action_keep_above_toggled      (GtkToggleAction *action, BmpUI *self)
{
    wm_set_keep_above (gtk_toggle_action_get_active (action));
}

static void
on_action_show_ui_toggled       (GtkToggleAction      *action,
                                 BmpUI                *self)
{
    static gboolean playlist_visible = FALSE;
    gboolean        active;

    active = gtk_toggle_action_get_active (action);
    if (active)
      {
        if (self->priv->x_main > 0) gtk_window_move (GTK_WINDOW(bmp_ui->priv->window_main->window), self->priv->x_main, self->priv->y_main);
        gtk_window_present (GTK_WINDOW(bmp_ui->priv->window_main->window));

        if (playlist_visible)
          {
            if (self->priv->x_pl > 0) gtk_window_move (GTK_WINDOW(bmp_ui->priv->window_playlist->window), self->priv->x_pl, self->priv->y_pl);
            gtk_window_present (GTK_WINDOW(bmp_ui->priv->window_playlist->window));
          }

        gtk_window_set_skip_taskbar_hint
                                        (GTK_WINDOW(bmp_ui->priv->window_main->window),
                                             FALSE);
        gtk_window_set_skip_pager_hint  (GTK_WINDOW(bmp_ui->priv->window_main->window),
                                             FALSE);

        gtk_window_set_skip_taskbar_hint
                                        (GTK_WINDOW(bmp_ui->priv->window_playlist->window),
                                             FALSE);
        gtk_window_set_skip_pager_hint  (GTK_WINDOW(bmp_ui->priv->window_playlist->window),
                                             FALSE);

        wm_set_keep_above (gtk_toggle_action_get_active
                           (GTK_TOGGLE_ACTION(gtk_action_group_get_action (bmp_toggle_actions, BMP_TOGGLE_ACTION_KEEP_ABOVE))));
      }
    else
      {
        gtk_window_get_position (GTK_WINDOW(bmp_ui->priv->window_main->window), &(self->priv->x_main), &(self->priv->y_main));
        gtk_window_get_position (GTK_WINDOW(bmp_ui->priv->window_playlist->window), &(self->priv->x_pl), &(self->priv->y_pl));

        gtk_widget_hide (GTK_WIDGET(bmp_ui->priv->window_main->window));

        playlist_visible = GTK_WIDGET_VISIBLE(bmp_ui->priv->window_playlist->window);

        if (playlist_visible)
          {
            gtk_widget_hide (bmp_ui->priv->window_playlist->window);
          }

        gtk_window_set_skip_taskbar_hint
                                        (GTK_WINDOW(bmp_ui->priv->window_main->window),
                                             TRUE);
        gtk_window_set_skip_pager_hint  (GTK_WINDOW(bmp_ui->priv->window_main->window),
                                             TRUE);

        gtk_window_set_skip_taskbar_hint
                                        (GTK_WINDOW(bmp_ui->priv->window_playlist->window),
                                             TRUE);
        gtk_window_set_skip_pager_hint  (GTK_WINDOW(bmp_ui->priv->window_playlist->window),
                                             TRUE);
      }
}

static void
on_system_control_track_change (BmpSystemControl    *control,
                                BmpUI               *self)
{
    GError      *error = 0;
    char	*uri;

    if (!bmp_system_control_get_current_uri  (bmp_system_control,
                                              &uri,
                                              &error)) {
      g_message ("%s", error->message);
      g_error_free (error);
      return;
    }
  
    Bmp::DB::DataRow row = library->get_metadata (std::string(uri));
    free (uri);

    if (!row.empty ())
    {
      Bmp::Library::Datum fields[] = {

              Bmp::Library::DATUM_ARTIST,
              Bmp::Library::DATUM_ALBUM,
	      Bmp::Library::DATUM_TITLE
      };

      enum
      {
	S_ARTIST,
        S_ALBUM,
	S_TITLE,
      };

      std::string str[3];

      for (int n = 0; n < 3; n++)
      {
	  Bmp::DB::DataRow::iterator iter = row.find (library->get_metadatum_id (fields[n]));
	  if (iter != row.end())
	  {
	    str[n] = Glib::Markup::escape_text (boost::get<std::string>(iter->second));
	  }
      }

      std::stringstream status_icon_text;

      status_icon_text << "<b>" << str[S_ARTIST] << "</b>\n<i>" << str[S_ALBUM] << "</i>\n" << str[S_TITLE];
      bmp_status_icon_set_text (self->priv->status_icon, status_icon_text . str () . c_str ());
    }
}

static void
on_system_control_app_busy (BmpSystemControl *control,
                            BmpUI            *self)
{
    bmp_window_set_busy (self->priv->window_playlist->window);
    bmp_window_set_busy (self->priv->window_main->window);
}

static void
on_system_control_app_idle (BmpSystemControl *control,
                            BmpUI            *self)
{
    bmp_window_set_idle (self->priv->window_playlist->window);
    bmp_window_set_idle (self->priv->window_main->window);
}

static gint
ui_initialize (BmpUI *self)
{
    GError	      *error = NULL;
    char	      *title;
    Glib::ustring      trayicon_ui;

    for (unsigned int n = 0; n < N_SKIN_COMPONENTS; bmp_skin_component[n++] = NULL);

    bmp_cursors_init ();

    mcs->subscribe ("Ui", "bmp", "skin", sigc::bind (sigc::ptr_fun (&on_bmp_skin_changed), self));

    bmp_ui_manager = gtk_ui_manager_new ();

    bmp_resource_manager_create_path (bmp_rm, 0, "dialogs");
    bmp_resource_manager_create_path (bmp_rm, 0, "windows");
    bmp_resource_manager_create_path (bmp_rm, 0, "tooltips");

    bmp_actions = gtk_action_group_new (BMP_MAIN_ACTION_GROUP);
    bmp_toggle_actions = gtk_action_group_new (BMP_MAIN_ACTION_GROUP_TOGGLE);

    gtk_action_group_set_translate_func (bmp_actions,
                bmp_menu_translate,
                NULL,
                NULL);
    gtk_action_group_set_translate_func (bmp_toggle_actions,
                bmp_menu_translate,
                NULL,
                NULL);

    gtk_ui_manager_insert_action_group (bmp_ui_manager, bmp_actions, 0);
    gtk_ui_manager_insert_action_group (bmp_ui_manager, bmp_toggle_actions, 0);
    gtk_action_group_set_sensitive (bmp_actions, TRUE);
    gtk_action_group_set_sensitive (bmp_toggle_actions, TRUE);

    gtk_action_group_add_toggle_actions (bmp_toggle_actions, bmp_toggle_actions_UI, G_N_ELEMENTS (bmp_toggle_actions_UI), self);

    //Winamp2.x skin windows
    self->priv->window_main = bmp_window_main_new ();
    RM_ITEM_NEW("windows",
                "window-main",
                self->priv->window_main,
                NULL);

    self->priv->window_playlist = bmp_window_playlist_new ();
    RM_ITEM_NEW("windows",
                "window-playlist",
                self->priv->window_playlist,
                NULL);

#if 0
    //Dialogs
    self->priv->jtt = bmp_jtt_new ();
    RM_ITEM_NEW("dialogs",
                "dialog-jtt",
                 self->priv->jtt,
                 NULL);
#endif

    self->priv->library = Bmp::LibraryUI::create ();
    RM_ITEM_NEW("dialogs",
                "dialog-library",
                 self->priv->library,
                 NULL);


    self->priv->preferences = Bmp::Preferences::create ();
    RM_ITEM_NEW("dialogs",
                "dialog-preferences",
                 self->priv->preferences,
                 NULL);

    self->priv->trackinfo = Bmp::TrackInfo::create ();
    RM_ITEM_NEW("dialogs",
                "dialog-trackinfo",
                 self->priv->trackinfo,
                 NULL);

    self->priv->streams = Bmp::Streams::Dialog::create ();
    RM_ITEM_NEW("dialogs",
                "dialog-streams",
                 self->priv->streams,
                 NULL);

    /* Set up configuration bindings */
    Glib::RefPtr<Gtk::ToggleAction> action;
    action = Glib::wrap (GTK_TOGGLE_ACTION(gtk_action_group_get_action (bmp_toggle_actions, BMP_TOGGLE_ACTION_PL)));
    mcs_bind->bind_toggle_action (action, "playlist-window", "visible");

    action = Glib::wrap (GTK_TOGGLE_ACTION(gtk_action_group_get_action (bmp_toggle_actions, BMP_TOGGLE_ACTION_KEEP_ABOVE)));
    mcs_bind->bind_toggle_action (action, "bmp", BMP_TOGGLE_ACTION_KEEP_ABOVE);

    bmp_system_control_repeat_set  (bmp_system_control,
                                    mcs->key_get<bool>("bmp", "repeat"),
                                    NULL);

    bmp_system_control_shuffle_set (bmp_system_control,
                                    mcs->key_get<bool>("bmp", "shuffle"),
                                    NULL);

    /* Init Tray Icon */
    self->priv->status_icon_image_default =
        gdk_pixbuf_new_from_file (DATA_DIR G_DIR_SEPARATOR_S "icons/tray-icons/tray-icon-default.png",
                                  NULL);
    self->priv->status_icon_image_paused =
        gdk_pixbuf_new_from_file (DATA_DIR G_DIR_SEPARATOR_S "icons/tray-icons/tray-icon-paused.png",
                                  NULL);
    self->priv->status_icon_image_playing =
        gdk_pixbuf_new_from_file (DATA_DIR G_DIR_SEPARATOR_S "icons/tray-icons/tray-icon-playing.png",
                                  NULL);
    self->priv->status_icon =
        bmp_status_icon_new_from_pixbuf (self->priv->status_icon_image_default);
    bmp_status_icon_set_tooltip (self->priv->status_icon, "", GTK_STOCK_MEDIA_STOP);
    bmp_status_icon_set_visible (self->priv->status_icon, TRUE);

    g_object_connect (G_OBJECT (self->priv->status_icon),
                    "signal::click",
                    G_CALLBACK(on_tray_icon_click),
                    self,
                    "signal::popup-menu",
                    G_CALLBACK(on_tray_icon_popup_menu),
                    self,
                    "signal::scroll-up",
                    G_CALLBACK(on_tray_icon_scroll_up),
                    self,
                    "signal::scroll-down",
                    G_CALLBACK(on_tray_icon_scroll_down),
                    self,
                    NULL);

    trayicon_ui = Glib::build_filename (DATA_DIR, BMP_UI_BASENAME) + "/trayicon.ui";

    if (!gtk_ui_manager_add_ui_from_file (bmp_ui_manager, trayicon_ui.c_str(), &error))
    {
	g_message ("%s: Building menus %s failed: %s", G_STRLOC, trayicon_ui.c_str (), error->message);
	g_error_free (error);
	error = NULL;
    }

    title = g_object_get_string (bmp_system_control, "current_title");
    set_ui_playstatus (self, Bmp::Playstatus (bmp_play_engine->property_status().get_value()));
    set_ui_title (self, title);
    g_free (title);

    g_object_connect (bmp_system_control,
                                        "signal::set-playstatus",
                                        G_CALLBACK (on_system_control_set_playstatus),
                                        self,
					NULL); 

    g_object_connect (bmp_system_control,
                                        "signal::set-title",
                                        G_CALLBACK (on_system_control_set_title),
                                        self,
					NULL); 

    g_object_connect (bmp_system_control,
                                        "signal::track-change",
                                        G_CALLBACK (on_system_control_track_change),
                                        self,
                                        NULL); 

    g_object_connect (bmp_system_control,
                                        "signal::app-busy",
                                        G_CALLBACK (on_system_control_app_busy),
                                        self,
                                        NULL); 

    g_object_connect (bmp_system_control,
                                        "signal::app-idle",
                                        G_CALLBACK (on_system_control_app_idle),
                                        self,
                                        NULL); 

    self->priv->about_dialog = new AboutDialog;

    display_windows (self);

#if 0
  self->priv->trayicon_embedded = bmp_status_icon_is_embedded (self->priv->status_icon);
#endif

    return BMP_ERROR_SUCCESS;
}

/* GObject stuff */
static void
bmp_ui_dispose (GObject *obj)
{
    BmpUI *self = BMP_UI (obj);
    gint w, h;

    if (self->priv->dispose_has_run) return;

    self->priv->dispose_has_run = TRUE;

#if 0
    lv_bmp_stop ();
#endif

    gtk_window_get_position (GTK_WINDOW(bmp_ui->priv->window_main->window), &(self->priv->x_main), &(self->priv->y_main));

    mcs->key_set<int>("main-window", "pos_x", self->priv->x_main);
    mcs->key_set<int>("main-window", "pos_y", self->priv->y_main);

    gtk_window_get_position (GTK_WINDOW(bmp_ui->priv->window_playlist->window), &(self->priv->x_pl), &(self->priv->y_pl));
    mcs->key_set<int>("playlist-window", "pos_x", self->priv->x_pl);
    mcs->key_set<int>("playlist-window", "pos_y", self->priv->y_pl);

    if (g_object_get_data (reinterpret_cast<GObject*>(self->priv->window_playlist), "shown"))
      {
	gtk_window_get_size (GTK_WINDOW(self->priv->window_playlist->window), &w, &h);
	mcs->key_set<int>("playlist-window", "width", w);
	mcs->key_set<int>("playlist-window", "height", h);
      }

    skin_components_free (self);

    g_object_unref (self->priv->window_main);
    g_object_unref (self->priv->window_playlist);
    //g_object_unref (self->priv->preferences);
    //g_object_unref (self->priv->jtt);
    //g_object_unref (self->priv->library);
    g_object_unref (self->priv->status_icon);
    g_object_unref (bmp_ui_manager);

    //Delete C++ objects
    delete self->priv->about_dialog;
    delete self->priv->trackinfo;
    delete self->priv->streams;
    delete self->priv->library;

/*    gdk_display_close (gdk_display_get_default()); */

    g_message("stopped: %s", G_OBJECT_TYPE_NAME(self));
}

static void
bmp_ui_finalize (GObject *obj)
{
}

#if 0
static void
bmp_ui_get_property (GObject    *object,
                     guint       property_id,
                     GValue     *value,
                     GParamSpec *pspec)
{
  BmpUI *self = (BmpUI*) object;

  switch (property_id)
    {
        case BMP_UI_PROP_TRAYICON_EMBEDDED:
              g_value_set_boolean (value, self->priv->trayicon_embedded);
              break;

        default:
              g_assert (FALSE);
    }
}
#endif

static void
bmp_ui_class_init (BmpUIClass * klass)
{
    GObjectClass *gobject_class = G_OBJECT_CLASS (klass);

#if 0
    gobject_class->get_property = bmp_ui_get_property;
    gobject_class->set_property = bmp_play_set_property;
    gobject_class->constructor = bmp_play_constructor;

    g_object_class_install_property (gobject_class,
                                     BMP_UI_PROP_TRAYICON_EMBEDDED,
                                     g_param_spec_boolean ("trayicon-embedded",
                                                           "trayicon-embedded",
                                                           "Whether tray icon is embedded or not", FALSE,
                                                            G_PARAM_READABLE));
#endif

    gobject_class->dispose  = bmp_ui_dispose;
    gobject_class->finalize = bmp_ui_finalize;
}

static void
bmp_ui_init (BmpUI *self)
{
    self->priv = g_new0 (BmpUIPrivate, 1);

    self->priv->window_main = NULL;
    self->priv->window_playlist = NULL;

    self->priv->preferences = NULL;
    self->priv->trackinfo = NULL;

    self->priv->window_main_mask = NULL;

    self->priv->x_main = -1;
    self->priv->y_main = -1;
    self->priv->x_pl   = -1;
    self->priv->y_pl   = -1;
    self->priv->w_pl   = -1;
    self->priv->h_pl   = -1;
}


BmpUI*
bmp_ui_new (void)
{
    BmpUI *self;

    GtkSettings *settings;
    const gchar *name;

    self = BMP_UI (g_object_new (BMP_TYPE_UI, NULL));

    /* Hack-around for no xsettings manager available that would set the cursor theme */
    settings = gtk_settings_get_for_screen (gdk_screen_get_default());
    name = g_object_get_string (settings, "gtk-cursor-theme-name");
    if (!name)
      {
          name = g_getenv("XCURSOR_THEME");
          g_object_set (settings, "gtk-cursor-theme-name", name, NULL);
      }

    return self;
}


int
bmp_ui_finalize_init (BmpUI *self)
{
    gint rv;

    rv = ui_initialize(self);

    if (rv == BMP_ERROR_SUCCESS)
            g_message("running: %s", G_OBJECT_TYPE_NAME(self));
    else
            g_message("%s Not initalized: Skin couldn't be loaded", __FILE__);

    return rv;
}


void
bmp_ui_jtt_show (BmpUI *self)
{
//    bmp_jtt_show (self->priv->jtt);
}


void
bmp_ui_library_show (BmpUI *self)
{
    self->priv->library->present ();
}


void
bmp_ui_streams_show (BmpUI *self)
{
    self->priv->streams->present ();
}

void
bmp_ui_about_show (BmpUI *self)
{
    self->priv->about_dialog->present ();
}

void
bmp_ui_preferences_show (BmpUI *self)
{
    self->priv->preferences->present ();
}

void
bmp_ui_raise_windows (BmpUI *self)
{
    GtkToggleAction *action;

    if (!self) return;

    g_return_if_fail (BMP_IS_UI(self));

    action = GTK_TOGGLE_ACTION(gtk_action_group_get_action (bmp_toggle_actions, BMP_TOGGLE_ACTION_SHOW_UI));
    gtk_toggle_action_set_active (GTK_TOGGLE_ACTION(action), TRUE);

    gtk_window_present (GTK_WINDOW(self->priv->window_playlist->window));
    gtk_window_present (GTK_WINDOW(self->priv->window_main->window));
}
