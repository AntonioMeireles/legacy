#ifndef BMP_AMAZON_HPP
#define BMP_AMAZON_HPP

#include <gtkmm.h>

namespace Bmp
{
  Glib::RefPtr<Gdk::Pixbuf>
  get_cover (const std::string &uri);
}

#endif
