//  BMPx - The Dumb Music Player
//  Copyright (C) 2005-2006 BMPx development team.
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
//
//  --
//
//  The BMPx project hereby grants permission for non GPL-compatible GStreamer
//  plugins to be used and distributed together with GStreamer and BMPx. This
//  permission is above and beyond the permissions granted by the GPL license
//  BMPx is covered by.

#include <config.h>

#ifdef HAVE_GUI
#include <gtk/gtk.h>
#endif

#include <glibmm.h>
#include <glib/gstdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <time.h>

#include <bmp/util.h>
#include <bmp/plugin.h>
#include <bmp/plugin_interfaces.h>
#include <bmp/playlist.hpp>
#include <bmp/database.hpp>
#include <bmp/library.hpp>
#include <bmp/vfs.hpp>
#include <bmp/file_utils.hpp>
#include <bmp/uri++.hpp>

#include <goa/libgoa.h>
#include "bmp-marshalers.h"

namespace 
{
  void     bmp_playlist_init       (BmpPlaylist      *self);
  void     bmp_playlist_class_init (BmpPlaylistClass *klass);
  gpointer bmp_playlist_parent_class = NULL;
  void     bmp_playlist_class_intern_init (gpointer klass)
  {
    bmp_playlist_parent_class = g_type_class_peek_parent (klass);
    bmp_playlist_class_init ((BmpPlaylistClass*) klass);
  }
}

#include "loader.hpp"
#include "main.hpp"
#include "paths.hpp"

#define  NONE (-1)

typedef enum {
        BMP_PLAYLIST_SIGNAL_TRACKLIST_LIST_SORTED,
        BMP_PLAYLIST_SIGNAL_TRACKLIST_ITEMS_REMOVED,
        BMP_PLAYLIST_SIGNAL_TRACKLIST_ITEMS_ADDED,

        BMP_PLAYLIST_N_SIGNALS
} BmpPlaylistSignals;

namespace { guint signals[BMP_PLAYLIST_N_SIGNALS] = { 0, 0, 0 }; }

enum BmpPlaylistProperties
{
        BMP_PLAYLIST_PROP_0,

        BMP_PLAYLIST_N_PROPERTIES
};

struct _BmpPlaylistPrivate
{
        bool      dispose_has_run;
        GtkListStore *playlist;
};

namespace {
  Bmp::Library::Datum vcolumns[] =
  {
    Bmp::Library::DATUM_ARTIST,
    Bmp::Library::DATUM_ALBUM,
    Bmp::Library::DATUM_TRACK,
    Bmp::Library::DATUM_TITLE,
    Bmp::Library::DATUM_GENRE,
    Bmp::Library::DATUM_DATE,
    Bmp::Library::DATUM_TIME
  };
}

static void
save_playlist (BmpPlaylist *self);

static void
load_playlist (BmpPlaylist *self);

unsigned int
vcolumns_get_n_items (void)
{
  return G_N_ELEMENTS (vcolumns);
}

Bmp::Library::Datum
vcolumns_get_item_nth (unsigned int n)
{
  return vcolumns[n];
}

/* History system */

#define PLAYBACK_HISTORY_LIMIT 1000

static void
history_free (BmpPlaybackHistory *history)
{
    g_queue_foreach (history->history, GFunc (gtk_tree_row_reference_free), NULL);
    g_queue_free (history->history);

    delete history;
}


BmpPlaybackHistory*
bmp_playback_history_new (void)
{
    BmpPlaybackHistory *history;

    history = new BmpPlaybackHistory;
    history->history = g_queue_new ();
    history->mark = 0;
    history->dirty = false;

    return history;
}


void
bmp_playback_history_free (BmpPlaybackHistory *history)
{
    if (!history) return;

    history_free (history);
}

static bool
history_item_prepend (BmpPlaybackHistory     *history,
                      BmpPluginFlowInterface *flow_plugin)
{
    RowGUID               *guid;
    GtkTreeModel          *model;
    GtkTreeRowReference   *reference;
    GtkTreePath           *path;
    GtkTreeIter            iter;

    g_return_val_if_fail (history != NULL, FALSE);

    model = GTK_TREE_MODEL(bmp_playlist_get_playlist (bmp_playlist));

    if (!bmp_plugin_flow_item_prev ((BmpPluginFlowInterface*)flow_plugin, GTK_LIST_STORE(model), &iter))
      {
        return FALSE;
      }

    if (history->history->length+1 > PLAYBACK_HISTORY_LIMIT)
      {
        g_queue_pop_tail (history->history);
      }

    path = gtk_tree_model_get_path (model, &iter);

    reference = gtk_tree_row_reference_new (model, path);
    gtk_tree_path_free (path);

    g_queue_push_head (history->history, reference);

    gtk_tree_model_get (model,
                        &iter,
                        COLUMN_GUID, &guid,
                        -1);

    history->mark = 1;

    return TRUE;
}

static bool
history_item_append (BmpPlaybackHistory     *history,
                     BmpPluginFlowInterface *flow_plugin)
{
    RowGUID               *guid;
    GtkTreeModel          *model;
    GtkTreeRowReference   *reference;
    GtkTreePath           *path;
    GtkTreeIter            iter;

    g_return_val_if_fail (history != NULL, FALSE);

    model = GTK_TREE_MODEL(bmp_playlist_get_playlist (bmp_playlist));

    if (!bmp_plugin_flow_item_next ((BmpPluginFlowInterface*)flow_plugin, GTK_LIST_STORE(model), &iter))
    {
      return FALSE;
    }


    if (history->history->length+1 > PLAYBACK_HISTORY_LIMIT)
    {
      g_queue_pop_head (history->history);
    }

    path = gtk_tree_model_get_path (model, &iter);
    reference = gtk_tree_row_reference_new (model, path);
    gtk_tree_path_free (path);

    g_queue_push_tail (history->history, reference);

    gtk_tree_model_get (model, &iter, COLUMN_GUID, &guid, -1);
    history->mark++;
    return TRUE;
}

int
bmp_playback_history_rewind (BmpPlaybackHistory *history)
{

    GtkTreeRowReference *reference;
    GtkTreePath *path;
    int row;

    g_return_val_if_fail (history != NULL, NONE);

    Glib::Mutex::Lock (history->lock);

    history->mark = 1;
    row = 0;

    if (history->dirty && (history->history->length > 0))
      {
        reference = static_cast<GtkTreeRowReference *> (g_queue_peek_nth (history->history, history->mark-1));
        path = gtk_tree_row_reference_get_path (reference);
        row = gtk_tree_path_get_indices (path)[0];
        gtk_tree_path_free (path);
      }
    return row;
}


void
bmp_playback_history_set (BmpPlaybackHistory *history,
                          int                position)

{
    GtkTreeModel          *model;
    GtkTreeRowReference   *reference;
    GtkTreePath           *path;

    g_return_if_fail (history != NULL);

    Glib::Mutex::Lock (history->lock);
    history->dirty = true;

    model = GTK_TREE_MODEL(bmp_playlist_get_playlist (bmp_playlist));
    path = gtk_tree_path_new_from_indices (position, -1);
    reference = gtk_tree_row_reference_new (model, path);
    g_assert (reference);
    gtk_tree_path_free (path);

    if (int(history->mark) < int(history->history->length))
      {
          for (unsigned int n = 0; n < (history->history->length - history->mark); n++)
            {
                g_queue_pop_tail (history->history);
            }
      }

    g_queue_push_tail (history->history, reference);
    history->mark++;
}


int
bmp_playback_history_prev (BmpPlaybackHistory     *history,
                           BmpPluginFlowInterface *flow_plugin)
{
    GtkTreePath           *path;
    GtkTreeRowReference   *reference;
    int row;

    g_return_val_if_fail (history != NULL, NONE);

    Glib::Mutex::Lock (history->lock);
    history->dirty = true;

    row = NONE;
    item_back_iteration:

    if (history->mark == 0)
      {
        if (history_item_prepend (history, flow_plugin))
          {
            reference = static_cast<GtkTreeRowReference *> (g_queue_peek_nth (history->history, history->mark-1));
            g_assert (reference);
            path = gtk_tree_row_reference_get_path (reference);
            g_assert (path);

            row = gtk_tree_path_get_indices (path)[0];
            gtk_tree_path_free (path);
          }
      }
    else
      {
        history->mark--;

        if (history->mark == 0)
          {
            goto item_back_iteration;
          }
        else
          {
            reference = static_cast<GtkTreeRowReference *> (g_queue_peek_nth (history->history, history->mark-1));
            path = gtk_tree_row_reference_get_path (reference);
            if (!path)
              {
                g_queue_pop_nth (history->history, history->mark);

                if (gtk_tree_row_reference_valid (reference)) gtk_tree_row_reference_free (reference);

                if (int(history->mark) > int(history->history->length))
                    history->mark = history->history->length;

                goto item_back_iteration;
              }

            row = gtk_tree_path_get_indices (path)[0];
            gtk_tree_path_free (path);
          }
      }

    return row;
}


int
bmp_playback_history_next (BmpPlaybackHistory       *history,
                           BmpPluginFlowInterface   *flow_plugin)
{
    GtkTreePath           *path;
    GtkTreeRowReference   *reference;
    int row;

    g_return_val_if_fail (history != NULL, NONE);

    Glib::Mutex::Lock (history->lock);
    history->dirty = true;

    row = NONE;
    item_forward_iteration:

    if (int(history->mark) == int(history->history->length))
      {
        if (history_item_append (history, flow_plugin))
          {
            reference = static_cast<GtkTreeRowReference *> (g_queue_peek_nth (history->history, history->mark-1));
            if (!reference)
              {
                abort ();
              }

            path = gtk_tree_row_reference_get_path (reference);
            if (!path)
              {
                abort ();
              }

            row = gtk_tree_path_get_indices (path)[0];
            gtk_tree_path_free (path);
          }
      }
    else
      {
        history->mark++;

        reference = static_cast<GtkTreeRowReference *> (g_queue_peek_nth (history->history, history->mark-1));
        g_assert (reference);

        path = gtk_tree_row_reference_get_path (reference);
        if (!path)
          {
            g_queue_pop_nth (history->history, history->mark-1);

            if (gtk_tree_row_reference_valid (reference)) gtk_tree_row_reference_free (reference);

            if (int(history->mark) > int(history->history->length))
                history->mark = history->history->length;

            goto item_forward_iteration;
          }

        row = gtk_tree_path_get_indices (path)[0];
        gtk_tree_path_free (path);
      }

    return row;
}

namespace
{

void
on_playlist_sort_column_changed   (GtkTreeSortable *treesortable,
                                   gpointer         data)
{
    GtkSortType  order;
    int         column;

    gtk_tree_sortable_get_sort_column_id (treesortable, &column, &order);

#if 0
        g_signal_emit (G_OBJECT (data),
                   signals[BMP_PLAYLIST_SIGNAL_TRACKLIST_LIST_SORTED], 0, column);
#endif
}

void
bmp_playlist_init (BmpPlaylist  *self)
{
        self->priv = g_new0(BmpPlaylistPrivate, 1);

        self->priv->dispose_has_run = FALSE;
        self->priv->playlist = gtk_list_store_new (9,
                                                   G_TYPE_STRING,
                                                   G_TYPE_STRING,
                                                   G_TYPE_INT,
                                                   G_TYPE_STRING,
                                                   G_TYPE_STRING,
                                                   G_TYPE_INT,
                                                   G_TYPE_INT,
                                                   BMP_TYPE_ROW_GUID, //GUID
                                                   G_TYPE_STRING); //URI
                                    

        g_object_set_data (G_OBJECT(self->priv->playlist), "current", NULL);

#if 0
        g_object_connect (G_OBJECT(self->priv->playlist),
                          "signal::row-deleted",
                          G_CALLBACK(update_row_guid_mappings),
                          self,
                          NULL);
#endif

        g_object_connect (G_OBJECT(self->priv->playlist),
                          "signal::sort-column-changed",
                          G_CALLBACK(on_playlist_sort_column_changed),
                          self,
                          NULL);


        g_message("running: %s", G_OBJECT_TYPE_NAME(self));
}

GObject *
bmp_playlist_constructor (GType                  type,
                       guint                  n_construct_properties,
                       GObjectConstructParam *construct_properties)
{
        GObject *obj;

        {
                /* Invoke parent constructor. */
                BmpPlaylistClass *klass;
                GObjectClass *parent_class;
                klass = BMP_PLAYLIST_CLASS (g_type_class_peek (BMP_TYPE_PLAYLIST));
                parent_class = G_OBJECT_CLASS (g_type_class_peek_parent (klass));
                obj = parent_class->constructor (type,
                                                 n_construct_properties,
                                                 construct_properties);
        }

        /* do stuff. */

        return obj;
}

void
bmp_playlist_dispose (GObject *obj)
{
    BmpPlaylist *self = (BmpPlaylist*) obj;

    if (self->priv->dispose_has_run) return;

    self->priv->dispose_has_run = TRUE;
    save_playlist (self);

    g_message("stopped: %s", G_OBJECT_TYPE_NAME(obj));
}

void
bmp_playlist_finalize (GObject *object)
{
    BmpPlaylist *self = (BmpPlaylist*)object;
    g_free (self->priv);
}

void
bmp_playlist_class_init (BmpPlaylistClass *g_class)

{
    GObjectClass *gobject_class = G_OBJECT_CLASS (g_class);

    gobject_class->dispose      = bmp_playlist_dispose;
    gobject_class->finalize     = bmp_playlist_finalize;
    gobject_class->constructor  = bmp_playlist_constructor;

    signals[BMP_PLAYLIST_SIGNAL_TRACKLIST_LIST_SORTED] =
        g_signal_new ("tracklist-list-sorted",
                      G_OBJECT_CLASS_TYPE (gobject_class),
                      GSignalFlags (0),
                      G_STRUCT_OFFSET (BmpPlaylistClass, tracklist_list_sorted),
                      NULL, NULL, g_cclosure_marshal_VOID__INT, G_TYPE_NONE,
                      1, G_TYPE_INT);

    signals[BMP_PLAYLIST_SIGNAL_TRACKLIST_ITEMS_REMOVED] =
        g_signal_new ("tracklist-items-removed",
                      G_OBJECT_CLASS_TYPE (gobject_class),
                      GSignalFlags (0),
                      G_STRUCT_OFFSET (BmpPlaylistClass, tracklist_items_removed),
                      NULL, NULL, bmpx_VOID__POINTER_INT, G_TYPE_NONE,
                      2, G_TYPE_POINTER, G_TYPE_INT);

    signals[BMP_PLAYLIST_SIGNAL_TRACKLIST_ITEMS_ADDED] =
        g_signal_new ("tracklist-items-added",
                      G_OBJECT_CLASS_TYPE (gobject_class),
                      GSignalFlags (0),
                      G_STRUCT_OFFSET (BmpPlaylistClass, tracklist_items_added),
                      NULL, NULL, bmpx_VOID__POINTER_INT, G_TYPE_NONE,
                      2, G_TYPE_POINTER, G_TYPE_INT);
}

static int
insert_items (BmpPlaylist        *self,
              const char         *uri,
              int                 index)
{
    using namespace Bmp::DB;

    Bmp::URI u (uri);

    if (bmp_play_engine->is_audio_file(uri) || (u.get_protocol () == Bmp::URI::PROTOCOL_CDDA))
      {
        DataRow row = library->get_metadata (std::string(uri));
	DataRow::iterator end = row.end ();

        GtkTreeIter iter;
        gtk_list_store_insert (GTK_LIST_STORE(self->priv->playlist), &iter, index);

        for (unsigned int n = 0; n < G_N_ELEMENTS(vcolumns); n++)
        {
	  DataRow::iterator row_iter = row.find(library->get_metadatum_id (vcolumns[n]));
	  if (row_iter == end) 
	  {
	    continue;
	  }
	  else
	  {
	    if (row_iter->second.which() == VALUE_TYPE_STRING)
	    {
                gtk_list_store_set (GTK_LIST_STORE(self->priv->playlist), &iter,
                                    n, (boost::get<std::string>(row_iter->second).c_str()), -1);
	    }
	    else if (row_iter->second.which() == VALUE_TYPE_INT)
	    {
                gtk_list_store_set (GTK_LIST_STORE(self->priv->playlist), &iter,
                                    n, boost::get<int>(row_iter->second), -1);
	    }
	  }
        }

        RowGUID *guid = bmp_row_guid_new (uri);
        gtk_list_store_set (GTK_LIST_STORE(self->priv->playlist), &iter,
                            COLUMN_GUID,   guid,
                            COLUMN_URI,    uri, 
                            -1);
        free (guid);
        index++;
      }
    else
      {
	Bmp::VFS::Handle    handle = Bmp::VFS::Handle::create (std::string(uri));
	Bmp::Util::FileList list;
	Bmp::URI u (uri);
	u.unescape ();

	if ((u.get_protocol() == Bmp::URI::PROTOCOL_FILE) && (Glib::file_test (u.path, Glib::FILE_TEST_IS_DIR)))
	{
	  Bmp::Util::collect_path (u.path, list);
	}
	else
	{
	  try { vfs->read (handle, list); } catch (...) { return index; }
	}

	for (Bmp::Util::FileList::const_iterator i = list.begin ();
	    i != list.end (); 
	    ++i)
	{
		Bmp::URI uri (*i);

		DataRow row = library->get_metadata (*i);
		DataRow::iterator end = row.end ();

		GtkTreeIter iter;
		gtk_list_store_insert (GTK_LIST_STORE(self->priv->playlist), &iter, index);

		for (unsigned int n = 0; n < G_N_ELEMENTS(vcolumns); n++)
		{
		  DataRow::iterator row_iter = row.find(library->get_metadatum_id (vcolumns[n]));
		  if (row_iter == end)
		  {
		    continue;
		  }
		  else
		  {
		    if (row_iter->second.which() == VALUE_TYPE_STRING)
		    {
		      gtk_list_store_set (GTK_LIST_STORE(self->priv->playlist), &iter,
                                    n, (boost::get<std::string>(row_iter->second).c_str()), -1);
		    }
		    else if (row_iter->second.which() == VALUE_TYPE_INT)
		    {
		      gtk_list_store_set (GTK_LIST_STORE(self->priv->playlist), &iter,
                                    n, boost::get<int>(row_iter->second), -1);
		    }
		  }
		}

		RowGUID *guid = bmp_row_guid_new (std::string(uri).c_str());
		gtk_list_store_set (GTK_LIST_STORE(self->priv->playlist), &iter,
				    COLUMN_GUID,   guid,
				    COLUMN_URI,    (*i).c_str(), 
				    -1);
		free (guid);
		index++;
            }
      }
      return index;
}

}

BmpPlaylist*
bmp_playlist_new (void)
{
  BmpPlaylist *self;

  self = static_cast<BmpPlaylist *> (g_object_new (bmp_playlist_get_type (), NULL));

  return self;
}

GtkListStore*
bmp_playlist_get_playlist (BmpPlaylist *self)
{
  return self->priv->playlist;
}

int
bmp_playlist_get_row_by_guid (BmpPlaylist *self, RowGUID *guid)
{
    GtkTreeIter  iter;
    bool     found = FALSE;
    bool     run = TRUE;
    int         n = 0;

    g_return_val_if_fail (BMP_IS_PLAYLIST (self), -1);

    run = gtk_tree_model_get_iter_first (GTK_TREE_MODEL(self->priv->playlist), &iter);

    while (run)
      {
        RowGUID *guid2;
        gtk_tree_model_get (GTK_TREE_MODEL(self->priv->playlist),
                            &iter,
                            COLUMN_GUID, &guid2,
                            -1);

        if (row_guid_equal_func (guid, guid2))
         {
            found = TRUE;
            break;
         }

        n++;

        run = gtk_tree_model_iter_next (GTK_TREE_MODEL(self->priv->playlist), &iter);
      }

    return found ? n : -1;
}

bool
bmp_playlist_get_row_by_index (BmpPlaylist        *self,
                               int                 index,
                               GtkTreeIter        *iter)
{
    if (!gtk_tree_model_iter_nth_child (GTK_TREE_MODEL(self->priv->playlist), iter, NULL, index))
    {
      return FALSE;
    }

    return TRUE;
}

char*
bmp_playlist_get_uri_by_index (BmpPlaylist        *self,
                               int                 index)

{
    GtkTreeIter  iter;
    char        *uri;

    if (!gtk_tree_model_iter_nth_child (GTK_TREE_MODEL(self->priv->playlist), &iter, NULL, index))
    {
      return NULL;
    }

    gtk_tree_model_get (GTK_TREE_MODEL(self->priv->playlist), &iter, COLUMN_URI, &uri, -1);
    return uri;
}

int
bmp_playlist_insert_tracklist_items_position (BmpPlaylist *self, const char **uri_list, int idx)
{
    int	    n_added_rows = 0,
	    idx_original = idx;
    GArray *added_rows;
  
    int n = 0;
    while (uri_list[n])
      {
        idx = insert_items (self, uri_list[n], idx);
        n++;
      }

    added_rows = g_array_new (FALSE, FALSE, sizeof(int));
    n_added_rows = (idx - idx_original);

    for (int n = 0; n < n_added_rows; ++n)
    {
        int val = n + idx_original;
        g_array_append_val (added_rows, val);
    }

    g_signal_emit (G_OBJECT (self),
                   signals[BMP_PLAYLIST_SIGNAL_TRACKLIST_ITEMS_ADDED],
                   0, added_rows, n_added_rows);

    return idx;
}

int
bmp_playlist_insert_tracklist_items (BmpPlaylist *self, const gchar **uri_list)
{
   return bmp_playlist_insert_tracklist_items_position (self, uri_list, gtk_tree_model_iter_n_children (GTK_TREE_MODEL(self->priv->playlist), NULL));
}


void
bmp_playlist_tracklist_remove_rows_all (BmpPlaylist *self)
{
    GArray                  *removed_rows;
    int                     n_removed_rows = -1;

    gtk_tree_row_reference_free (static_cast<GtkTreeRowReference *> (g_object_get_data (G_OBJECT(self->priv->playlist), "current")));
    g_object_set_data (G_OBJECT(self->priv->playlist), "current", NULL);
    gtk_list_store_clear (self->priv->playlist);

    removed_rows = g_array_new (FALSE,FALSE,sizeof(int));

    g_signal_emit (G_OBJECT (self),
                   signals[BMP_PLAYLIST_SIGNAL_TRACKLIST_ITEMS_REMOVED],
                   0, removed_rows, n_removed_rows);
}

void
bmp_playlist_tracklist_remove_selected (BmpPlaylist *self, GList *paths)
{
        GArray *removed_rows;
        int    n_removed_rows;

        removed_rows = g_array_new (FALSE, FALSE, sizeof(int));
        n_removed_rows = g_list_length (paths);

        for ( ; paths ; paths = paths->next)
          {
              GtkTreeIter  iter;
              GtkTreePath *path = static_cast<GtkTreePath *> (paths->data);
              int         row = gtk_tree_path_get_indices (path)[0];

              if (gtk_tree_model_get_iter (GTK_TREE_MODEL(self->priv->playlist), &iter, path))
                {
                  gtk_list_store_remove (GTK_LIST_STORE(self->priv->playlist), &iter);
                  g_array_append_val (removed_rows, row);
                }
          }

        g_signal_emit (G_OBJECT (self),
                   signals[BMP_PLAYLIST_SIGNAL_TRACKLIST_ITEMS_REMOVED],
                   0, removed_rows, n_removed_rows);
}

static void
load_playlist (BmpPlaylist *self)
{
        gchar    **uri_strv;
        int       new_count = 0;

        uri_strv = g_new0 (gchar*,2);
        uri_strv[0] = g_strconcat ("file://", BMP_PATH_USER_DIR, "/tracklist.xspf", NULL);
        uri_strv[1] = NULL;

        bmp_system_control_add_uri_list (bmp_system_control,
                                        (const gchar**)uri_strv,
                                        -1,
                                        FALSE,
                                        FALSE,
                                        0,
                                        &new_count,
                                        NULL);
        g_strfreev (uri_strv);
}

static void
save_playlist (BmpPlaylist *self)
{
	Bmp::Util::FileList list;
        GtkTreeIter	    iter;
        bool	    proceed;

        proceed = gtk_tree_model_get_iter_first (GTK_TREE_MODEL(self->priv->playlist), &iter);
        while (proceed)
        {
            char        *uri_str;
            std::string  filename;
                        
            gtk_tree_model_get (GTK_TREE_MODEL(self->priv->playlist), &iter, COLUMN_URI, &uri_str, -1);

	    Bmp::URI uri (uri_str);
	    uri.escape ();
            filename = Glib::filename_from_uri (std::string(uri));

            if ((uri.get_protocol() != Bmp::URI::PROTOCOL_FILE) || ((!filename.empty()) && Glib::file_test(filename, Glib::FILE_TEST_EXISTS)))
	    {
		list.push_back (std::string(uri_str));
	    }

            free (uri_str);
            proceed = gtk_tree_model_iter_next (GTK_TREE_MODEL(self->priv->playlist), &iter);
        }

	std::string tracklist = Glib::build_filename (BMP_PATH_USER_DIR, "tracklist.xspf");
	vfs->write (list, tracklist, std::string("xspf"));
}


int
bmp_playlist_get_length (BmpPlaylist *self)
{
    return gtk_tree_model_iter_n_children (GTK_TREE_MODEL(self->priv->playlist), NULL);
}


char*
bmp_playlist_get_uri_nth (BmpPlaylist       *self,
                          int                index)
{
    GtkTreeIter  iter;
    char        *uri;

    gtk_tree_model_iter_nth_child (GTK_TREE_MODEL(self->priv->playlist), &iter, NULL, index);
    gtk_tree_model_get (GTK_TREE_MODEL(self->priv->playlist), &iter, COLUMN_URI, &uri, -1);
    return uri;
}

char*
bmp_playlist_get_current_uri (BmpPlaylist *self)
{
    GtkTreeRowReference     *reference;
    GtkTreePath             *path;
    GtkTreeIter              iter;
    char                    *uri;

    reference = static_cast<GtkTreeRowReference *> (g_object_get_data (G_OBJECT(self->priv->playlist), "current"));
    if (!reference) return NULL;

    path = gtk_tree_row_reference_get_path (reference);
    gtk_tree_model_get_iter (GTK_TREE_MODEL(self->priv->playlist), &iter, path);
    gtk_tree_path_free (path);
    gtk_tree_model_get (GTK_TREE_MODEL(self->priv->playlist), &iter, COLUMN_URI, &uri, -1);
    return uri;
}

char*
bmp_playlist_get_title_nth (BmpPlaylist         *self,
                            int                  index)
{
    GtkTreeIter              iter;
    char                    *uri;

    gtk_tree_model_iter_nth_child (GTK_TREE_MODEL(self->priv->playlist), &iter, NULL, index);
    gtk_tree_model_get (GTK_TREE_MODEL(self->priv->playlist), &iter, COLUMN_URI, &uri, -1);

    Bmp::DB::DataRow row = library->get_metadata (uri); 
    Bmp::DB::ValueVariant v_artist,
			  v_album,
			  v_title;

    std::stringstream titlestring;
    v_artist = row[library->get_metadatum_id (Bmp::Library::DATUM_ARTIST)];
    v_album  = row[library->get_metadatum_id (Bmp::Library::DATUM_ALBUM)];
    v_title  = row[library->get_metadatum_id (Bmp::Library::DATUM_TITLE)];

    titlestring << v_artist << " - " << v_album << " - " << v_title; 

    free (uri);
    return strdup (titlestring.str().c_str());
}


char*
bmp_playlist_get_current_title (BmpPlaylist *self)
{
    GtkTreeRowReference     *reference;
    GtkTreePath             *path;
    GtkTreeIter              iter;
    char                    *uri;

    reference = static_cast<GtkTreeRowReference *> (g_object_get_data (G_OBJECT(self->priv->playlist), "current"));
    if (!reference) return NULL;

    path = gtk_tree_row_reference_get_path (reference);
    if (!path) return NULL;

    gtk_tree_model_get_iter (GTK_TREE_MODEL(self->priv->playlist), &iter, path);
    gtk_tree_path_free (path);
    gtk_tree_model_get (GTK_TREE_MODEL(self->priv->playlist), &iter, COLUMN_URI, &uri, -1);

    Bmp::DB::DataRow row = library->get_metadata (uri); 
    Bmp::DB::ValueVariant v_artist,
			  v_album,
			  v_title;

    std::stringstream titlestring;
    v_artist = row[library->get_metadatum_id (Bmp::Library::DATUM_ARTIST)];
    v_album  = row[library->get_metadatum_id (Bmp::Library::DATUM_ALBUM)];
    v_title  = row[library->get_metadatum_id (Bmp::Library::DATUM_TITLE)];

    titlestring << v_artist << " - " << v_album << " - " << v_title; 

    free (uri);
    return strdup (titlestring.str().c_str());
}

void
bmp_playlist_load_playlist (BmpPlaylist *self)
{
    g_return_if_fail (self != NULL);
    g_return_if_fail (BMP_IS_PLAYLIST(self));
    load_playlist (self);
}

GType
bmp_playlist_get_type (void)
{
  static GType g_define_type_id = 0; 
  if (G_UNLIKELY (g_define_type_id == 0)) 
    { 
      static const GTypeInfo g_define_type_info = { 
        sizeof (BmpPlaylistClass), 
        (GBaseInitFunc) NULL, 
        (GBaseFinalizeFunc) NULL, 
        (GClassInitFunc) bmp_playlist_class_intern_init, 
        (GClassFinalizeFunc) NULL, 
        NULL,   /* class_data */ 
        sizeof (BmpPlaylist), 
        0,      /* n_preallocs */ 
        (GInstanceInitFunc) bmp_playlist_init, 
      }; 
      g_define_type_id = g_type_register_static (G_TYPE_OBJECT, "BmpPlaylist", &g_define_type_info, GTypeFlags(0)); 
    } 
  return g_define_type_id; 
}
