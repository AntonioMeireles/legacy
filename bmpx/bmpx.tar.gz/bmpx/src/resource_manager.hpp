//-*- Mode: C++; indent-tabs-mode: nil; -*-

/*  BMPx - The Dumb Music Player
 *  Copyright (C) 2005 BMPx development team.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 *  $Id$
 *
 * The BMPx project hereby grant permission for non-gpl compatible GStreamer
 * plugins to be used and distributed together with GStreamer and BMPx. This
 * permission are above and beyond the permissions granted by the GPL license
 * BMPx is covered by.
 *
 */

#ifndef BMP_RESOURCE_MANAGER_HPP
#define BMP_RESOURCE_MANAGER_HPP

/*
 * Potentially, include other headers on which this header depends.
 */
#include <glib-object.h>

#define BMP_TYPE_RESOURCE_MANAGER		    (bmp_resource_manager_get_type ())
#define BMP_RESOURCE_MANAGER(obj)		    (G_TYPE_CHECK_INSTANCE_CAST ((obj), BMP_TYPE_RESOURCE_MANAGER, BmpResourceManager))
#define BMP_RESOURCE_MANAGER_CLASS(klass)	    (G_TYPE_CHECK_CLASS_CAST ((klass), BMP_TYPE_RESOURCE_MANAGER, BmpResourceManagerClass))
#define BMP_IS_RESOURCE_MANAGER(obj)	  	  (G_TYPE_CHECK_INSTANCE_TYPE ((obj), BMP_TYPE_RESOURCE_MANAGER))
#define BMP_IS_RESOURCE_MANAGER_CLASS(klass)	    (G_TYPE_CHECK_CLASS_TYPE ((klass), BMP_TYPE_RESOURCE_MANAGER))
#define BMP_RESOURCE_MANAGER_GET_CLASS(obj)	    (G_TYPE_INSTANCE_GET_CLASS ((obj), BMP_TYPE_RESOURCE_MANAGER, BmpResourceManagerClass))

typedef struct _BmpResourceManager BmpResourceManager;
typedef struct _BmpResourceManagerClass BmpResourceManagerClass;
typedef struct _BmpResourceManagerPrivate BmpResourceManagerPrivate;

struct _BmpResourceManager
{
    GObject parent;

    BmpResourceManagerPrivate *priv;
};

struct _BmpResourceManagerClass {
	GObjectClass parent;
};


typedef enum {
    BMP_RESOURCE_DATA,
    BMP_RESOURCE_BRANCH,

    N_BMP_RESOURCE_TYPES
} ResourceType;

typedef struct {
	ResourceType     type;

	gchar	        *name;
	gpointer	 value;
	GDestroyNotify   destroy;

	GMutex	        *lock;
} BmpResource;

#define RM_PATH_DELIMITER_S ":"

#define NOLOCK FALSE
#define LOCK TRUE

GType bmp_resource_manager_get_type (void);

BmpResourceManager*
bmp_resource_manager_new (void);

gboolean
bmp_resource_manager_create_path (BmpResourceManager *self, const gchar *parent_path, const gchar *path);

gboolean
bmp_resource_manager_append_item (BmpResourceManager *self, const gchar *path, const gchar *name, gpointer item_value, GDestroyNotify item_value_destroy);

gpointer
bmp_resource_manager_get_item (BmpResourceManager *self, const gchar *path, const gchar *name);

/* You should use *this* fucntion if you will be modifying the item ('R/W access')...*/
gpointer
bmp_resource_manager_get_item_locked (BmpResourceManager *self, const gchar *path, const gchar *name);

/*...and then unlock it when you're done with it */
void
bmp_resource_manager_unlock_item (BmpResourceManager *self, const gchar *path, const gchar *name);

#define RM_GET_ITEM(path, name, lock) \
	  lock ? bmp_resource_manager_get_item_locked (bmp_rm, path, name) : bmp_resource_manager_get_item (bmp_rm, path, name)

#define RM_ITEM_UNLOCK(path, name) \
	bmp_resource_manager_unlock_item (bmp_rm, path, name)

#define RM_ITEM_NEW(path, name, pointer, destroy) \
	    bmp_resource_manager_append_item (bmp_rm, path, name, pointer, destroy)

#endif // BMP_RESOURCE_MANAGER_HPP
