//-*- Mode: C++; indent-tabs-mode: nil; -*-

/*  BMPx - The Dumb Music Player
 *  Copyright (C) 2005 BMPx development team.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 *  $Id$
 *
 * The BMPx project hereby grant permission for non-gpl compatible GStreamer
 * plugins to be used and distributed together with GStreamer and BMPx. This
 * permission are above and beyond the permissions granted by the GPL license
 * BMPx is covered by.
 */

#ifdef HAVE_GUI
#  include <gtkmm.h>
#else
#  include <glibmm.h>
#endif

#include "resource_manager.hpp"

G_DEFINE_TYPE(BmpResourceManager, bmp_resource_manager, G_TYPE_OBJECT)

#if 0
typedef enum {
	BMP_RESOURCE_MANAGER_N_SIGNALS
} BmpResourceManagerSignals;
static guint bmp_resource_manager_signals[BMP_RESOURCE_MANAGER_N_SIGNALS] = {};
#endif

typedef enum {
	BMP_RESOURCE_MANAGER_N_PROPERTIES
} BmpResourceManagerProperties;

struct _BmpResourceManagerPrivate
{
        gboolean dispose_has_run;

	GHashTable *root;
};

static void
free_resource_item (BmpResource *item)
{
}

static GHashTable*
get_path (BmpResourceManager *self, const gchar *path)
{
    BmpResource *resource;
    GHashTable *ht_path;
    gchar **path_elements, **_path_elements;

    g_return_val_if_fail (BMP_IS_RESOURCE_MANAGER(self), NULL);

    ht_path = self->priv->root;
    if (! path) return ht_path;

    path_elements = g_strsplit (path, RM_PATH_DELIMITER_S, -1);
    if (! path_elements) return NULL;

    _path_elements = path_elements;
    while (*path_elements)
    {
	resource = static_cast<BmpResource *> (g_hash_table_lookup (ht_path, *path_elements));

	if (! resource)
	{
	    g_strfreev(_path_elements);
	    return NULL;
	}
	else
	{
	    ht_path = static_cast<GHashTable *> (resource->value);
	    path_elements++;
	}
    }

    g_strfreev(_path_elements);

    return ht_path;
}

static BmpResource*
get_item (BmpResourceManager *self, const gchar *path, const gchar *item_name)
{
    GHashTable *ht_path;

    ht_path = get_path (self, path);

    return static_cast<BmpResource *> (ht_path ? g_hash_table_lookup (ht_path, item_name) : NULL);
}

static void
create_new_node_path (BmpResourceManager *self, const gchar *path, const gchar *name)
{
    GHashTable *ht, *ht_path;
    BmpResource *item;

    item = g_new0(BmpResource,1);

    ht = g_hash_table_new_full (g_str_hash, g_str_equal,
                                (GDestroyNotify) g_free,
                                (GDestroyNotify) free_resource_item);

    item->type = BMP_RESOURCE_BRANCH;
    item->name = g_strdup(name);
    item->destroy = NULL;
    item->lock = NULL;
    item->value = ht;

    ht_path = get_path (self, path);

    if (! ht_path) {

	free_resource_item (item);
	return;
    }

    g_hash_table_replace (ht_path, g_strdup(name), item);
}

static void
create_new_node_item (BmpResourceManager *self, const gchar *path, const gchar *name, gpointer value, GDestroyNotify destroy)
{
    GHashTable *ht_path;
    BmpResource *item;

    item = g_new0(BmpResource,1);

    item->type = BMP_RESOURCE_DATA;
    item->name = g_strdup(name);
    item->destroy = destroy;
    item->lock = g_mutex_new();
    item->value = value;

    ht_path = get_path (self, path);

    if (!ht_path)
    {
	free_resource_item (item);
	return;
    }

    g_hash_table_replace (ht_path, (gchar*)name, item);
}

/* Public API */

gboolean
bmp_resource_manager_create_path (BmpResourceManager *self, const gchar *parent_path, const gchar *path)
{
    create_new_node_path (self, parent_path, path);

    return TRUE;
}


gboolean
bmp_resource_manager_append_item (BmpResourceManager *self, const gchar *path, const gchar *name, gpointer item_value, GDestroyNotify item_value_destroy)
{
    create_new_node_item (self, path, name, item_value, item_value_destroy);

    return TRUE;
}


gpointer
bmp_resource_manager_get_item (BmpResourceManager *self, const gchar *path, const gchar *name)
{
    BmpResource *item;

    item = get_item (self, path, name);

    if (! item) return NULL;

    return item->value;
}


gpointer
bmp_resource_manager_get_item_locked (BmpResourceManager *self, const gchar *path, const gchar *name)
{
    BmpResource *item;

    item = get_item (self, path, name);

    if (! item) return NULL;

    g_mutex_lock (item->lock);

    return item->value;
}


void
bmp_resource_manager_unlock_item (BmpResourceManager *self, const gchar *path, const gchar *name)
{
    BmpResource *item;

    item = get_item (self, path, name);

    if (!item)
         return;


    g_mutex_unlock (item->lock);
}

/* GObject */
static void
bmp_resource_manager_init (BmpResourceManager *self)
{
    self->priv = g_new (BmpResourceManagerPrivate, 1);
    self->priv->dispose_has_run = FALSE;

    self->priv->root = g_hash_table_new_full (g_str_hash, g_str_equal, g_free, NULL);
}

static void
bmp_resource_manager_set_property (GObject      *object,
                        guint         property_id,
                        const GValue *value,
                        GParamSpec   *pspec)
{
        switch (property_id) {

        default:
                /* We don't have any other property... */
                g_assert (FALSE);
                break;
        }
}

static void
bmp_resource_manager_get_property (GObject      *object,
                        guint         property_id,
                        GValue       *value,
                        GParamSpec   *pspec)
{


        switch (property_id) {

        default:
                /* We don't have any other property... */
                g_assert (FALSE);
                break;
        }
}

static GObject *
bmp_resource_manager_constructor (GType                  type,
                       guint                  n_construct_properties,
                       GObjectConstructParam *construct_properties)
{
        GObject *obj;

        {
                /* Invoke parent constructor. */
                BmpResourceManagerClass *klass;
                GObjectClass *parent_class;
                klass = BMP_RESOURCE_MANAGER_CLASS (g_type_class_peek (BMP_TYPE_RESOURCE_MANAGER));
                parent_class = G_OBJECT_CLASS (g_type_class_peek_parent (klass));
                obj = parent_class->constructor (type,
                                                 n_construct_properties,
                                                 construct_properties);
        }

        /* do stuff. */

        return obj;
}

static void
bmp_resource_manager_dispose (GObject *obj)
{
        BmpResourceManager *self = (BmpResourceManager *)obj;

        if (self->priv->dispose_has_run) {
                /* If dispose did already run, return. */
                return;
        }
        /* Make sure dispose does not run twice. */
        self->priv->dispose_has_run = TRUE;

        /*
         * In dispose, you are supposed to free all types referenced from this
         * object which might themselves hold a reference to self. Generally,
         * the most simple solution is to unref all members on which you own a
         * reference.
         */
}

static void
bmp_resource_manager_finalize (GObject *obj)
{
        BmpResourceManager *self = (BmpResourceManager *)obj;

        /*
         * Here, complete object destruction.
         * You might not need to do much...
         */
        g_free (self->priv);
}


BmpResourceManager*
bmp_resource_manager_new (void)
{
  BmpResourceManager *rm;
  rm = static_cast<BmpResourceManager *> (g_object_new (bmp_resource_manager_get_type (), NULL));

  return rm;
}

static void
bmp_resource_manager_class_init (BmpResourceManagerClass *g_class)
{
        GObjectClass *gobject_class = G_OBJECT_CLASS (g_class);

        gobject_class->set_property = bmp_resource_manager_set_property;
        gobject_class->get_property = bmp_resource_manager_get_property;
        gobject_class->dispose = bmp_resource_manager_dispose;
        gobject_class->finalize = bmp_resource_manager_finalize;
        gobject_class->constructor = bmp_resource_manager_constructor;
}
