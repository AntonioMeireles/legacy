/*  BMPx - The Dumb Music Player
 *  Copyright (C) 2005 BMPx development team.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 *  $Id$
 *
 * The BMPx project hereby grant permission for non-gpl compatible GStreamer
 * plugins to be used and distributed together with GStreamer and BMPx. This
 * permission are above and beyond the permissions granted by the GPL license
 * BMPx is covered by.
 */

#ifndef BMP_PLAY_HPP
#define BMP_PLAY_HPP

#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <cstring>
#include <glibmm.h>

#include <gst/gst.h>
#include <gst/gstelement.h>
#include <gst/interfaces/mixer.h>
#include <gst/interfaces/mixertrack.h>
#include <gst/interfaces/mixeroptions.h>

#include <bmp/uri++.hpp>
#include <bmp/util.h>

#include <goa/libgoa.h>

namespace Bmp {

  enum Playstatus
  {
	PLAYSTATUS_STOPPED = 1 << 1,
	PLAYSTATUS_PLAYING = 1 << 2,
	PLAYSTATUS_PAUSED  = 1 << 3,
	PLAYSTATUS_SEEKING = 1 << 4,
	PLAYSTATUS_WAITING = 1 << 5
  };

};

namespace Bmp {

    /** Playback Engine
     *
     * Bmp::Play is the playback engine of BMP. It is based on GStreamer 0.10
     * using a rather simple design. (http://www.gstreamer.net)
     *
     */
    class Play
      : public Glib::Object
    {

      public:

	Play ();
	~Play ();

	/** Resets the playback engine, used when the audio preferences are changed
	 *
	 */
	void
	reset ();

	/** Determine whether a stream/file specified by uri is a playable file or not 
	 *
	 * @param uri The URI to determine whether a stream is an audio file or not 
	 *
	 */
	bool
	is_audio_file (const Glib::ustring& uri);

	/** Stream URI 
	 *
	 */
	Glib::PropertyProxy<Glib::ustring> property_stream();

	/** Volume, Range 0-100
	 *
	 */
	Glib::PropertyProxy<int> property_volume();

	/** Stream Position in seconds 
	 *
	 */
	Glib::PropertyProxy<int> property_position();

	/** Playback Status, see @link Bmp::Playstatus@endlink
	 *
	 */
	Glib::PropertyProxy<int> property_status();

	/** Returns the sanity of the playback engine 
	 *
	 */
	Glib::PropertyProxy<bool> property_sane();

	/** Allows to set and retrieve the stream length
	 *
	 */
	Glib::PropertyProxy<int>  property_length();

	/** Determines whether the playback engine currently has CDDA playback capability 
	 *
	 */
	Glib::PropertyProxy<bool> property_has_cdda();

	/** Determines whether the playback engine currently has HTTP stream playback capability 
	 *
	 */
	Glib::PropertyProxy<bool> property_has_http();

	Glib::PropertyProxy<bool> property_mute();

	typedef sigc::signal<void, char*>	  SignalTitle;
	typedef sigc::signal<void>		  SignalEos;
	typedef sigc::signal<void, int>		  SignalSeek;
	typedef sigc::signal<void, int>		  SignalPosition;
	typedef sigc::signal<void, unsigned int>  SignalBitrate;
	typedef sigc::signal<void, unsigned int>  SignalSamplerate;

 	/** Signal emitted when we receive new samplerate metadata
	 *
	 */
	SignalBitrate& signal_bitrate();

 	/** Signal emitted when we receive new samplerate metadata
	 *
	 */
	SignalSamplerate& signal_samplerate();

 	/** Signal emitted when a stream title is incoming 
	 *
	 */
	SignalTitle& signal_title();

	/** Signal emitted on end of stream
	 *
	 */
	SignalEos& signal_eos();

	/** Signal emitted on a successful seek event, used by @link Bmp::Scrobbler@endlink
	 *
	 */
	SignalSeek& signal_seek();

	/** Signal emitted on stream position change
	 *
	 */
	SignalPosition& signal_position();

      private:
    
	SignalSamplerate   signal_samplerate_;
	SignalBitrate      signal_bitrate_;
	SignalTitle	   signal_title_;
	SignalEos	   signal_eos_;
	SignalSeek	   signal_seek_;
	SignalPosition	   signal_position_;

	static void
	link_pad  (GstElement *element,
		   GstPad     *pad,
		   gboolean    last,
		   gpointer    data);

	static gboolean
	bus_watch (GstBus     *bus,
                   GstMessage *message,
                   gpointer    data);

	static gboolean
	foreach_structure (GQuark	 field_id,
			   const GValue	*value,
			   gpointer	 data);

	//Properties
	Glib::Property<Glib::ustring> property_stream_;
	Glib::Property<int>  property_volume_;
	Glib::Property<int>  property_position_;
	Glib::Property<int>  property_status_;
	Glib::Property<bool> property_mute_;

	Glib::Property<bool> property_sane_;
	Glib::Property<int>  property_length_;
	Glib::Property<bool> property_has_cdda_;
	Glib::Property<bool> property_has_http_;

	enum Pipeline
	{
	    P_FILE,
	    P_HTTP,
	    P_CDDA,
	    N_PIPELINES
	};

	enum Element
	{
	    PIPELINE,
	    SRC,
	    DECODER,
	    CONVERT,
	    SINK,
	    VOLUME,
	    TEE,
	    QUEUE,
	    N_ELEMENTS
	};

        GstElement	     *elements[N_PIPELINES][N_ELEMENTS];
	Pipeline	      current_pipe;
	sigc::connection      source;
	int		      message_domain_id;
	bool		      sane;
	std::map<std::string, bool> extensions;

	void
	pipelines_destroy ();

	void
	pipeline_create (Pipeline pipeline);

	void
        stop_stream ();

	void
	play_stream ();

	void
	pause_stream ();

	void
	on_playstatus_changed ();

        void
        on_position_changed ();

	void
	on_stream_changed ();

	void
	on_volume_changed ();

	bool
	timeout_handler ();

    };

}

#endif // BMP_PLAY_HPP
