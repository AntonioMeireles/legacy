//  BMPx - The Dumb Music Player
//  Copyright (C) 2005-2006 BMPx development team.
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
//
//  --
//
//  The BMPx project hereby grants permission for non GPL-compatible GStreamer
//  plugins to be used and distributed together with GStreamer and BMPx. This
//  permission is above and beyond the permissions granted by the GPL license
//  BMPx is covered by.

#include <config.h>

#include <glib.h>
#include <glib/gi18n.h>
#include <gtk/gtk.h>
#include <gdk/gdkkeysyms.h>
#include <glade/glade.h>

#include <cstring>
#include <climits>
#include <cstdio>
#include <cstring>

#include <sys/time.h>
#include <sys/types.h>
#include <unistd.h>

#include <bmp/playlist.hpp>
#include <bmp/util.h>
#include <bmp/uri++.hpp>

#include <libhrel/types.h>
#include <libhrel/tuple.h>

#include "glade.hpp"
#include "ui_util.hpp"
#include "ui_dialog_jtt.hpp"

#include "main.hpp"

static BmpMetadatumId jtt_columns[] = {
	BMP_DATUM_ARTIST,
	BMP_DATUM_ALBUM,
	BMP_DATUM_TITLE,
	BMP_DATUM_GENRE,
};

/* GObject stuff */
G_DEFINE_TYPE (BmpJumpToTrack, bmp_jtt, G_TYPE_OBJECT)

struct _BmpJumpToTrackPrivate {

    gboolean		 dispose_has_run;

    GladeXML		*xml;

    GtkTreeModel	*jtt_model_filter;
    GtkTreeView		*jtt_tree_view;
    GtkTreeSelection	*jtt_tree_selection;
};


void
window_jtt_create (BmpJumpToTrack *self);


BmpJumpToTrack*
bmp_jtt_new (void)
{
    BmpJumpToTrack *self;

    self = BMP_JTT (g_object_new (BMP_TYPE_JTT, NULL));
    return self;
}

static GObject *
bmp_jtt_constructor (GType type,
	                   guint n_construct_properties,
         	           GObjectConstructParam * construct_properties)
{
    GObject *obj;

    {
        BmpJumpToTrackClass *klass;
        GObjectClass	    *parent_class;

        klass = BMP_JTT_CLASS (g_type_class_peek (BMP_TYPE_JTT));
        parent_class = G_OBJECT_CLASS (g_type_class_peek_parent (klass));

        obj = parent_class->constructor (type,
                                         n_construct_properties,
                                         construct_properties);
    }

    return obj;
}

static void
bmp_jtt_dispose (GObject *object)
{
    BmpJumpToTrack *self = (BmpJumpToTrack *)object;

    g_object_unref (self->priv->jtt_model_filter);
    g_object_unref (self->priv->xml);
    gtk_widget_destroy (self->window);
}

static void
bmp_jtt_class_init (BmpJumpToTrackClass * klass)
{
    GObjectClass *gobject_class = G_OBJECT_CLASS (klass);

#if 0
    gobject_class->set_property = bmp_play_set_property;
    gobject_class->get_property = bmp_play_get_property;
    gobject_class->finalize	= bmp_play_finalize;
#endif
    gobject_class->dispose     = bmp_jtt_dispose;
    gobject_class->constructor = bmp_jtt_constructor;

}

static void
bmp_jtt_init	    (BmpJumpToTrack *self)
{
    self->priv = g_new (BmpJumpToTrackPrivate, 1);
    self->priv->dispose_has_run = FALSE;
    window_jtt_create (self);
}

#if 0
static void
jtt_cell_data_func  (GtkTreeViewColumn	*tree_column,
                     GtkCellRenderer	*cell,
                     GtkTreeModel	*tree_model,
                     GtkTreeIter	*iter,
                     gpointer		 data)
{
    BmpFileItem	    *item;
    HTuple	    *tuple;
    HTupleElem	    *tuple_elem;
    BmpMetadatumId   metadatum_id = BmpMetadatumId (GPOINTER_TO_INT (data));

    gtk_tree_model_get (tree_model, iter, TUPLE_COLUMN, &item, -1);
    if (!item)
      {
	g_object_set (G_OBJECT(cell), "text", "", NULL);
      }

    tuple = bmp_metadata_cache_metadata_get (bmp_metadata_cache, item);
    if (!tuple)
      {
	g_object_set (G_OBJECT(cell), "text", "", NULL);
	return;
      }

    tuple_elem = h_tuple_get (tuple, bmp_metadata_get_id_static (metadatum_id));

    if (tuple_elem->value)
      g_object_set (G_OBJECT(cell), "text", tuple_elem->value, NULL);
    else
      g_object_set (G_OBJECT(cell), "text", "", NULL);

    h_tuple_free (tuple);
}
#endif

static void
jtt_index_data_func  (GtkTreeViewColumn	*tree_column,
                      GtkCellRenderer	*cell,
                      GtkTreeModel	*tree_model,
                      GtkTreeIter	*iter,
                      gpointer		 data)
{
    GtkTreeModel    *child;
    GtkTreeIter	     iter_child;
    GtkTreePath	    *path;
    gchar	    *string;

    child = gtk_tree_model_filter_get_model (GTK_TREE_MODEL_FILTER(tree_model));
    gtk_tree_model_filter_convert_iter_to_child_iter (GTK_TREE_MODEL_FILTER(tree_model), &iter_child, iter);

    path = gtk_tree_model_get_path (child, &iter_child);
    string = g_strdup_printf ("%d", gtk_tree_path_get_indices (path)[0]+1);
    g_object_set (G_OBJECT(cell), "text", string, NULL);
    g_free (string);
    gtk_tree_path_free (path);
}

static gboolean
jtt_filter_visible_func (GtkTreeModel *model,
                         GtkTreeIter  *iter,
                         gpointer      data)
{
    HTuple	   *tuple;
    HTupleElem	   *tuple_elem;
    GladeXML	   *xml = BMP_JTT (data)->priv->xml;
    const gchar	   *needle;
    gboolean	    match;
    char	   *uri;

    needle = gtk_entry_get_text (GTK_ENTRY(glade_xml_get_widget_warn (xml, "jump_filter_text")));

    if ((!needle) || (!std::strlen(needle))) return TRUE;

    match = FALSE;
    gtk_tree_model_get (GTK_TREE_MODEL(model), iter, COLUMN_URI, &uri, -1);
    if (!uri) return FALSE;

    tuple = bmp_metadata_cache_metadata_get (bmp_metadata_cache, uri);
    if (!tuple) return FALSE; //FIXME: What to do here?
    g_free (uri);

    for (unsigned int n = 0; n < G_N_ELEMENTS (jtt_columns); n ++)
      {
	  tuple_elem = h_tuple_get (tuple, bmp_metadata_get_id_static (jtt_columns[n]));

	  if (match_keys (static_cast<const char *> (tuple_elem->value), needle))
	    {
		match = TRUE;
		break;
	    }
      }

    h_tuple_free (tuple);

    return match;
}

static gboolean
jtt_key_press_event (GtkWidget	  *widget,
		     GdkEventKey  *event,
		     gpointer	   data)
{
    BmpJumpToTrack  *self   = BMP_JTT (data);
    GtkWidget	    *entry;

    g_return_val_if_fail (GTK_IS_WIDGET (widget), FALSE);

    if (event->keyval == GDK_Escape) gtk_widget_hide (widget);

    entry = glade_xml_get_widget_warn (self->priv->xml, "jump_filter_text");
    if (GTK_WIDGET_HAS_FOCUS(entry) && (event->keyval == GDK_Down))
      {
	  gtk_widget_grab_focus (GTK_WIDGET(self->priv->jtt_tree_view));
	  return TRUE;
      }

    return FALSE;
}

static void
on_jump_to_clicked    (GtkWidget	  *widget,
		       gpointer		   data)
{
    GtkTreeModel  *model;
    GtkTreePath	  *path;
    GtkTreeIter	   iter,
		   iter_child;
    gint	   index;

    model = gtk_tree_model_filter_get_model (GTK_TREE_MODEL_FILTER(BMP_JTT (data)->priv->jtt_model_filter));
    if (!gtk_tree_selection_get_selected (BMP_JTT (data)->priv->jtt_tree_selection, NULL, &iter))
      {
	  if (!gtk_tree_model_get_iter_first (BMP_JTT (data)->priv->jtt_model_filter, &iter)) return;
      }

    gtk_tree_model_filter_convert_iter_to_child_iter (GTK_TREE_MODEL_FILTER(BMP_JTT (data)->priv->jtt_model_filter), &iter_child, &iter);
    path = gtk_tree_model_get_path (model, &iter_child);
    if (!path) return;
    index = gtk_tree_path_get_indices (path)[0];
    gtk_tree_path_free (path);

    gtk_widget_hide(glade_xml_get_widget_warn (BMP_JTT (data)->priv->xml, "jump_to_track"));
    bmp_system_control_play_track (bmp_system_control, index, NULL);
}

static void
on_jtt_tree_view_row_activated   (GtkTreeView       *tree_view,
                                  GtkTreePath       *path_origin,
                                  GtkTreeViewColumn *column,
                                  gpointer           data)
{
    BmpJumpToTrack  *self;
    GtkTreeModel    *model;
    GtkTreePath	  *path;
    GtkTreeIter	   iter,
		   iter_child;
    gint	   index;

    self = BMP_JTT (data);
    model = gtk_tree_model_filter_get_model (GTK_TREE_MODEL_FILTER(BMP_JTT (data)->priv->jtt_model_filter));

    gtk_tree_model_get_iter (BMP_JTT (data)->priv->jtt_model_filter, &iter, path_origin);
    gtk_tree_model_filter_convert_iter_to_child_iter (GTK_TREE_MODEL_FILTER(BMP_JTT (data)->priv->jtt_model_filter), &iter_child, &iter);
    path = gtk_tree_model_get_path (model, &iter_child);
    index = gtk_tree_path_get_indices (path)[0];
    gtk_tree_path_free (path);

    gtk_widget_hide(glade_xml_get_widget_warn (self->priv->xml, "jump_to_track"));
    bmp_system_control_play_track (bmp_system_control, index, NULL);
}


void
window_jtt_create   (BmpJumpToTrack *self)
{
    GtkTreeViewColumn	  *column;
    GtkCellRenderer	  *cell;
    const gchar		  *glade_file = DATA_DIR "/glade/dialog_jump_to_track.glade";
    gint		   n;

    self->priv->xml = glade_xml_new_or_die ("Jump To Track Dialog", glade_file, NULL, NULL);
    glade_xml_signal_autoconnect (self->priv->xml);

    //Setup window and connect ESC key
    self->window = glade_xml_get_widget_warn (self->priv->xml, "jump_to_track");
    g_object_connect (G_OBJECT(self->window),
		      "signal::key-press-event",
		      G_CALLBACK (jtt_key_press_event),
		      self,
		      NULL);

    //Set icon to window
    bmp_window_set_icon_list (GTK_WIDGET(self->window), "player");

    //Setup jump-to button
    g_object_connect (G_OBJECT(glade_xml_get_widget_warn (self->priv->xml, "jump_to")),
		      "signal::clicked",
		      G_CALLBACK (on_jump_to_clicked),
		      self,
		      NULL);

    //Setup TreeView
    self->priv->jtt_tree_view = GTK_TREE_VIEW(glade_xml_get_widget_warn (self->priv->xml, "jump_tree_browse"));
    g_object_connect (G_OBJECT(self->priv->jtt_tree_view),
		      "signal::row-activated",
		      G_CALLBACK (on_jtt_tree_view_row_activated),
		      self,
		      NULL);


    //Index column
    column = gtk_tree_view_column_new ();
    gtk_tree_view_column_set_title (column, "#");
    gtk_tree_view_column_set_expand
		(column,
		 TRUE);

    cell = gtk_cell_renderer_text_new ();
    gtk_tree_view_column_pack_start
		(column,
		 cell,
		 TRUE);
    g_object_set (G_OBJECT(cell), "xalign", 1.0, NULL);

    gtk_tree_view_column_set_cell_data_func
		(column,
		 cell,
		 (GtkTreeCellDataFunc) jtt_index_data_func,
                 NULL,
                 NULL);

    gtk_tree_view_append_column
		(GTK_TREE_VIEW (self->priv->jtt_tree_view),
		 GTK_TREE_VIEW_COLUMN (column));

    for (n = 0; n < G_N_ELEMENTS(jtt_columns); n++)
      {
	column = gtk_tree_view_column_new ();
	gtk_tree_view_column_set_title (column, bmp_metadata_get_title_static (jtt_columns[n]));

	cell = gtk_cell_renderer_text_new ();
	gtk_tree_view_column_pack_start
		(column,
		 cell,
		 TRUE);

#if 0
	gtk_tree_view_column_set_cell_data_func
		(column,
		 cell,
		 (GtkTreeCellDataFunc) jtt_cell_data_func,
                 GINT_TO_POINTER(jtt_columns[n]),
                 NULL);
#endif

	gtk_tree_view_column_set_sizing (column, GTK_TREE_VIEW_COLUMN_GROW_ONLY);
	gtk_tree_view_column_set_min_width (column, 80);
	gtk_tree_view_column_set_max_width (column, 250);

	gtk_tree_view_append_column
		(GTK_TREE_VIEW (self->priv->jtt_tree_view),
		 GTK_TREE_VIEW_COLUMN (column));
      }

    self->priv->jtt_model_filter = gtk_tree_model_filter_new (GTK_TREE_MODEL(bmp_playlist_get_playlist (bmp_playlist)), NULL);
    gtk_tree_view_set_model (GTK_TREE_VIEW(self->priv->jtt_tree_view), self->priv->jtt_model_filter);
    gtk_tree_model_filter_set_visible_func (GTK_TREE_MODEL_FILTER(self->priv->jtt_model_filter),
                                            (GtkTreeModelFilterVisibleFunc) jtt_filter_visible_func,
                                            self,
                                            NULL);

    self->priv->jtt_tree_selection = gtk_tree_view_get_selection (GTK_TREE_VIEW(self->priv->jtt_tree_view));

    g_object_connect (G_OBJECT(glade_xml_get_widget_warn (self->priv->xml, "jump_filter_text")),
		      "swapped-signal::changed",
		      G_CALLBACK(gtk_tree_model_filter_refilter),
		      self->priv->jtt_model_filter,
		      NULL);
}


void
bmp_jtt_show (BmpJumpToTrack *self)
{
    gtk_window_present (GTK_WINDOW(self->window));
    gtk_widget_grab_focus (glade_xml_get_widget_warn (self->priv->xml, "jump_filter_text"));
}
