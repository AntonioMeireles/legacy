namespace Bmp
{
    namespace Service
    {

	Queue::Queue ();
	Queue::~Queue ();

	Bmp::Service::Message::Base	  
	Queue::pop ()
	{
	      Glib::Mutex::Lock lock (this->lock);

	      if (list.empty ())
                  throw Bmp::Service::Queue::QUEUE_EMPTY;

	      Bmp::Service::Message::Base message = queue.front (); 
	      list.pop_front ();
	      return message;
	}

	void
	Queue::push (Bmp::Service::Message::Base& message)
	{
	      Glib::Mutex::Lock lock (this->lock);
	      queue.push_back (message);
	}
  
  } // Service

} // Bmp
