/*  BMPx - Cross-platform multimedia player
 *  Copyright (C) 2003-2004  Edward Brocklesby, Chong Kai Xiong,
 *            Milosz Derezynski, David Lau, Michiel Sikkes
 *
 *  ui.c/bmp_ui.h
 *  bmp_button.c/bmp_button.h
 *  bmp_button_toggle.c/bmp_button_toggle.h
 *  bmp_slider.c/bmp_slider.h
 *
 *  M.Derezynski
 *  Tim-Philipp Mueller
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * The BMPx project hereby grant permission for non-gpl compatible GStreamer
 * plugins to be used and distributed together with GStreamer and BMPx. This
 * permission are above and beyond the permissions granted by the GPL license
 * BMPx is covered by.
 */

#include <gtk/gtk.h>
#include <gdk/gdkx.h>
#include <gdk/gdkkeysyms.h>
#include <X11/Xlib.h>

#include "main.h"
#include "error.h"
#include "resource_manager.h"
#include "ui_equalizer.h"
#include "ui_util.h"
#include "ui_dialog_about.h"


#include <libskinned/bmp_button.h>
#include <libskinned/bmp_button_toggle.h>
#include <libskinned/bmp_slider.h>
#include <libskinned/bmp_slider.h>
#include <libskinned/bmp_window.h>

#include <goa/libgoa.h>
#include <bmp/util.h>

static void
window_equalizer_create(BmpWindowEqualizer *self);

/* GObject stuff */
G_DEFINE_TYPE (BmpWindowEqualizer, bmp_window_equalizer, G_TYPE_OBJECT)

/* Our stuff */
#if 0
static GtkActionEntry bmp_actions_EQUALIZER[] = { {NULL} };
static GtkToggleActionEntry bmp_toggle_actions_EQUALIZER[] = { {NULL} };
#endif

static GPtrArray *array_buttons;
static GPtrArray *array_buttons_toggle;

static bmp_button_toggle_t bmp_window_equalizer_buttons_toggle[] = { {NULL} };
static gint nbuttons_window_equalizer_toggle = G_N_ELEMENTS(bmp_window_equalizer_buttons_toggle);

static bmp_button_normal_t bmp_window_equalizer_buttons[] = { {NULL} };
static gint nbuttons_window_equalizer = G_N_ELEMENTS(bmp_window_equalizer_buttons);

struct _BmpWindowEqualizerPrivate {

    gboolean dispose_has_run;

    /* Sliders */
    GtkWidget *sliders[BMP_UI_EQUALIZER_N_SLIDERS];
};

static gboolean
on_window_equalizer_state_event (GtkWidget *widget, GdkEventWindowState *event, gpointer data)
{
    g_return_val_if_fail (GTK_IS_WIDGET (widget), FALSE);

    return TRUE;
}

static gboolean
on_window_equalizer_focus_in (GtkWidget *widget, GdkEventFocus *event, gpointer data)
{
    BmpWindowPlaylist    *window_playlist;
    BmpWindowEqualizer        *window_equalizer;
    BmpWindowPreferences *window_preferences;

    g_return_val_if_fail (GTK_IS_WIDGET (widget), FALSE);
    g_return_val_if_fail (GTK_IS_WIDGET (data), FALSE);

    gtk_widget_show (GTK_WIDGET(g_ptr_array_index (array_buttons, 6)));
    gtk_widget_show (GTK_WIDGET(g_ptr_array_index (array_buttons, 7)));

    gtk_widget_queue_draw_area (GTK_WIDGET(data), 0, 0, 275, 14);

    window_playlist = RM_GET_ITEM("windows", "window-playlist", NOLOCK);
    window_equalizer = RM_GET_ITEM("windows", "window-equalizer", NOLOCK);
    window_preferences = RM_GET_ITEM("windows", "window-preferences", NOLOCK);

    if (!bmp_preferences_window_raise(window_preferences))
	{
	    gdk_window_raise (window_playlist->window->window);
	    gdk_window_raise (window_equalizer->window->window);
	}

    gtk_widget_queue_draw (window_playlist->window);

    return FALSE;
}

static gboolean
on_window_equalizer_focus_out (GtkWidget *widget, GdkEventFocus *event, gpointer data)
{
	g_return_val_if_fail (GTK_IS_WIDGET (widget), FALSE);
	g_return_val_if_fail (GTK_IS_WIDGET (data), FALSE);

	gtk_widget_hide (GTK_WIDGET(g_ptr_array_index (array_buttons, 6)));
	gtk_widget_hide (GTK_WIDGET(g_ptr_array_index (array_buttons, 7)));

	gtk_widget_queue_draw_area (GTK_WIDGET(data), 0, 0, 275, 14);

	return FALSE;
}

static gboolean
on_window_equalizer_button_release (GtkWidget *widget,
		    GdkEventButton *event,
		    BmpWindowEqualizer *self)
{
    g_return_val_if_fail (GTK_IS_WIDGET (widget), FALSE);

    return FALSE;
}

static gboolean
on_window_equalizer_scroll_event (GtkWidget *widget,
		    GdkEventScroll *event,
		    BmpWindowEqualizer *self)
{
    g_return_val_if_fail (GTK_IS_WIDGET(widget), FALSE);

    return TRUE;
}

static gboolean
on_window_equalizer_key_press (GtkWidget *widget,
		    GdkEventKey *event,
		    BmpWindowEqualizer *self)
{
    g_return_val_if_fail (GTK_IS_WIDGET (widget), FALSE);

    return FALSE;
}

static gboolean
on_window_equalizer_button_press (GtkWidget *widget,
		    GdkEventButton *event,
		    BmpWindowEqualizer *self)
{
    gint x, y, w_width, w_height;
    gboolean grab = TRUE;

    g_return_val_if_fail (GTK_IS_WIDGET (widget), FALSE);

    gtk_window_get_size (GTK_WINDOW(self->window), &w_width, &w_height);

    x = event->x;
    y = event->y;

    if (event->type != GDK_BUTTON_PRESS) return FALSE;

    if (event->button == 1 && ((y < 14) && (x < 240)))
    {
	//FIXME: replace from dock move
    }

    if (grab)
        gdk_pointer_grab(widget->window, FALSE,
                         GDK_BUTTON_MOTION_MASK |
                         GDK_BUTTON_RELEASE_MASK,
                         GDK_WINDOW(GDK_NONE), NULL, GDK_CURRENT_TIME);


    return FALSE;
}

static gboolean
on_window_equalizer_motion_notify (GtkWidget *widget, GdkEventMotion *event, BmpWindowEqualizer *self)
{
    return TRUE;
}

static gboolean
on_window_equalizer_canvas_expose (GtkWidget *widget,
                     GdkEventExpose *event,
                     BmpWindowEqualizer *self)
{

	return FALSE;
}

static void
create_actions(BmpWindowEqualizer *self)
{
#if 0
  BmpWindow *window = BMP_WINDOW(self->window);
  GError *error = NULL;
  gchar *filename;

  bmp_actions_eq = gtk_action_group_new(BMP_ACTION_GROUP_EQUALIZER);
  gtk_action_group_add_actions (bmp_actions, bmp_actions_EQUALIZER, G_N_ELEMENTS (bmp_actions_EQUALIZER), NULL);
  gtk_action_group_set_sensitive (bmp_actions, TRUE);

  bmp_toggle_actions_eq = gtk_action_group_new(BMP_ACTION_GROUP_EQUALIZER_TOGGLE);
  gtk_action_group_add_toggle_actions (bmp_toggle_actions, bmp_toggle_actions_EQUALIZER, G_N_ELEMENTS (bmp_toggle_actions_EQUALIZER), window);
  gtk_action_group_set_sensitive (bmp_toggle_actions, TRUE);

  gtk_ui_manager_insert_action_group (bmp_ui_manager, bmp_actions_eq, 0);
  gtk_ui_manager_insert_action_group (bmp_ui_manager, bmp_toggle_actions_eq, 0);

  filename = g_build_filename (DATA_DIR, BMP_UI_BASENAME,"equalizer.ui",NULL);

  if (!gtk_ui_manager_add_ui_from_file (bmp_ui_manager, filename, &error))
	{
		g_message ("building menus failed: %s", error->message);
		g_error_free (error);
	}

  g_free (filename);
#endif
}

static void
allocate_widgets(BmpWindowEqualizer *self)
{
  BmpWindow *window = BMP_WINDOW(self->window);
  BmpButton *button;
  BmpButtonToggle *button_toggle;
  GtkAction *action;
  gint i;

  array_buttons = g_ptr_array_new();
  array_buttons_toggle = g_ptr_array_new();

  /* Normal buttons */
  for (i = 0; i < nbuttons_window_equalizer; ++i) {

      button = bmp_button_new((bmp_window_equalizer_buttons[i].action_id != NULL) ? FALSE : TRUE);

      if (bmp_window_equalizer_buttons[i].action_id != NULL) {
             action = gtk_action_group_get_action(bmp_actions, bmp_window_equalizer_buttons[i].action_id);
             if (action != NULL) {
                     gtk_action_connect_proxy (GTK_ACTION (action), GTK_WIDGET (button));
             }
        }
     else
        {
	    gtk_widget_set_sensitive(GTK_WIDGET(button), FALSE);
	}


      /* FIXME: Make this an appropriate method of BmpWindow */
      gtk_fixed_put(GTK_FIXED (BMP_WINDOW(window)->canvas), GTK_WIDGET (button), bmp_window_equalizer_buttons[i].pos_x, bmp_window_equalizer_buttons[i].pos_y);
      g_ptr_array_add(array_buttons,button);
  }

  /* Toggle buttons */
  for (i = 0; i < nbuttons_window_equalizer_toggle; ++i) {

      button_toggle = bmp_button_toggle_new();

      if (bmp_window_equalizer_buttons_toggle[i].action_id != NULL) {
            action = gtk_action_group_get_action(bmp_toggle_actions, bmp_window_equalizer_buttons_toggle[i].action_id);
            if (action != NULL) {
                     gtk_action_connect_proxy(GTK_ACTION (action), GTK_WIDGET (button_toggle));
            } else {
	    }
        }
      else
        {
	    gtk_widget_set_sensitive(GTK_WIDGET(button_toggle), FALSE);
	}

      gtk_fixed_put(GTK_FIXED (BMP_WINDOW(window)->canvas), GTK_WIDGET (button_toggle), bmp_window_equalizer_buttons_toggle[i].pos_x, bmp_window_equalizer_buttons_toggle[i].pos_y);
      g_ptr_array_add(array_buttons_toggle, button_toggle);

  }
}

void
bmp_window_equalizer_iconify (BmpWindowEqualizer *self)
{
	GtkAction *action;

	action = gtk_action_group_get_action (bmp_actions, BMP_ACTION_ICONIFY);
	gtk_action_activate (action);
}

static void
window_equalizer_create(BmpWindowEqualizer *self)
{
  BmpWindow *window;

  self->window = GTK_WIDGET(bmp_window_new(GTK_WINDOW_TOPLEVEL));
  window = BMP_WINDOW(self->window);

  gtk_widget_set_size_request (GTK_WIDGET(BMP_WINDOW(window)->canvas), BMP_WINDOW_MAIN_WIDTH, BMP_WINDOW_MAIN_HEIGHT);

  create_actions (self);
  allocate_widgets (self);

  bmp_window_set_icon_list (GTK_WIDGET(window), "player");
  gtk_window_set_title (GTK_WINDOW(window), "BMPx");

  g_object_set_data (G_OBJECT(window), "id", g_strdup("equalizer"));

  g_object_connect (G_OBJECT (BMP_WINDOW(window)),
			"signal::focus-in-event",
			G_CALLBACK(on_window_equalizer_focus_in),
		        BMP_WINDOW(window)->canvas,
 			"signal::focus-out-event",
			G_CALLBACK(on_window_equalizer_focus_out),
			BMP_WINDOW(window)->canvas,
  			"signal::button-press-event",
			G_CALLBACK(on_window_equalizer_button_press),
			self,
			"signal::button-release-event",
			G_CALLBACK(on_window_equalizer_button_release),
			self,
			"signal::motion-notify-event",
			G_CALLBACK(on_window_equalizer_motion_notify),
			self,
			"signal::key-press-event",
			G_CALLBACK(on_window_equalizer_key_press),
			self,
			"signal::scroll-event",
			G_CALLBACK(on_window_equalizer_scroll_event),
			self,
			"signal::window-state-event",
			G_CALLBACK(on_window_equalizer_state_event),
			NULL,
			NULL);

  g_object_connect (G_OBJECT(BMP_WINDOW(window)->canvas),
			"signal::expose-event",
			G_CALLBACK(on_window_equalizer_canvas_expose),
			self,
			NULL);

  gtk_window_add_accel_group (GTK_WINDOW(window), gtk_ui_manager_get_accel_group(bmp_ui_manager));
}

void
bmp_window_equalizer_configure(BmpWindowEqualizer *self)
{
  BmpWindow *window = BMP_WINDOW(self->window);
  BmpButton *button;
  BmpButtonToggle *button_toggle;
  gint i;

  /* Normal buttons */
  for (i = 0; i < nbuttons_window_equalizer; ++i) {
      button = g_ptr_array_index(array_buttons, i);
      bmp_button_set_from_table(BMP_BUTTON (button),
				bmp_skin_component[bmp_window_equalizer_buttons[i].pixmap_id]->pixbuf,
				bmp_window_equalizer_buttons[i].width,
				bmp_window_equalizer_buttons[i].height,
				bmp_window_equalizer_buttons[i].img_x,
				bmp_window_equalizer_buttons[i].img_y,
				bmp_window_equalizer_buttons[i].img_x_pressed,
				bmp_window_equalizer_buttons[i].img_y_pressed);
      gtk_widget_set_size_request (GTK_WIDGET (button),
	    bmp_window_equalizer_buttons[i].width,
	    bmp_window_equalizer_buttons[i].height);
  }
  BMP_BUTTON(g_ptr_array_index(array_buttons, 6))->passtrough = FALSE;
  BMP_BUTTON(g_ptr_array_index(array_buttons, 7))->passtrough = FALSE;

  /* Toggle buttons */
  for (i = 0; i < nbuttons_window_equalizer_toggle; ++i) {
      button_toggle =
	    g_ptr_array_index(array_buttons_toggle, i);

      bmp_button_toggle_set_from_table (BMP_BUTTON_TOGGLE (button_toggle),
					bmp_skin_component[bmp_window_equalizer_buttons_toggle[i].pixmap_id]->pixbuf,
					bmp_window_equalizer_buttons_toggle[i].width,
					bmp_window_equalizer_buttons_toggle[i].height,
					bmp_window_equalizer_buttons_toggle[i].img_x,
					bmp_window_equalizer_buttons_toggle[i].img_y,
					bmp_window_equalizer_buttons_toggle[i].img_x_pressed,
					bmp_window_equalizer_buttons_toggle[i].img_y_pressed,
					bmp_window_equalizer_buttons_toggle[i].img_x_active,
					bmp_window_equalizer_buttons_toggle[i].img_y_active );
      gtk_widget_set_size_request (GTK_WIDGET (button_toggle) ,
	    bmp_window_equalizer_buttons_toggle[i].width,
	    bmp_window_equalizer_buttons_toggle[i].height);
  }

 SET_CURSOR_FOR_WIDGET(CURSOR_NORMAL,BMP_WINDOW(window)->canvas);
 SET_CURSOR_FOR_WIDGET(CURSOR_NORMAL,window);

 gtk_widget_modify_bg (GTK_WIDGET(BMP_WINDOW(window)->canvas), GTK_STATE_NORMAL, bmp_colors_get_color(BMP_SKINCOLOR_PL_BG_NORMAL));
 gtk_widget_modify_base (GTK_WIDGET(BMP_WINDOW(window)->canvas), GTK_STATE_NORMAL, bmp_colors_get_color(BMP_SKINCOLOR_PL_BG_NORMAL));

 gtk_widget_modify_fg (GTK_WIDGET(BMP_WINDOW(window)->canvas), GTK_STATE_NORMAL, bmp_colors_get_color(BMP_SKINCOLOR_PL_FG_CURRENT));
 gtk_widget_modify_text (GTK_WIDGET(BMP_WINDOW(window)->canvas), GTK_STATE_NORMAL, bmp_colors_get_color(BMP_SKINCOLOR_PL_FG_CURRENT));

 gtk_widget_queue_draw (GTK_WIDGET (window));
 gdk_flush();

#if 0
 gdk_window_shape_combine_mask (GTK_WIDGET(window)->window, bmp_ui_get_mask_window_equalizer(bmp_ui), 0, 0);
#endif
 gdk_flush();
}

/* GObject */
BmpWindowEqualizer*
bmp_window_equalizer_new (void)
{
    BmpWindowEqualizer *self;

    self =
        g_object_new (BMP_TYPE_WINDOW_EQUALIZER, NULL);

    return self;
}

static GObject *
bmp_window_equalizer_constructor (GType type,
	                     guint n_construct_properties,
         	             GObjectConstructParam * construct_properties)
{
    GObject *obj;

    {
        /*
         * Invoke parent constructor.
         */
        BmpWindowEqualizerClass *klass;
        GObjectClass *parent_class;
        klass = BMP_WINDOW_EQUALIZER_CLASS (g_type_class_peek (BMP_TYPE_WINDOW_EQUALIZER));
        parent_class = G_OBJECT_CLASS (g_type_class_peek_parent (klass));
        obj =
            parent_class->constructor (type,
                                       n_construct_properties,
                                       construct_properties);
    }

    /*
     * do stuff.
     */
    return obj;
}

static void
bmp_window_equalizer_dispose (GObject *object)
{
    BmpWindowEqualizer *self = (BmpWindowEqualizer *) object;

    if (self->private->dispose_has_run)
         return;

    self->private->dispose_has_run = TRUE;
}

static void
bmp_window_equalizer_finalize (GObject *object)
{

}

static void
bmp_window_equalizer_class_init (BmpWindowEqualizerClass * klass)
{
    GObjectClass *gobject_class = G_OBJECT_CLASS (klass);

#if 0
    gobject_class->set_property = bmp_play_set_property;
    gobject_class->get_property = bmp_play_get_property;
#endif
    gobject_class->finalize = bmp_window_equalizer_finalize;
    gobject_class->dispose = bmp_window_equalizer_dispose;
    gobject_class->constructor = bmp_window_equalizer_constructor;

}

static void
bmp_window_equalizer_init (BmpWindowEqualizer *self)
{
    self->private = g_new (BmpWindowEqualizerPrivate, 1);

    self->private->dispose_has_run = FALSE;

    window_equalizer_create(self);
}
