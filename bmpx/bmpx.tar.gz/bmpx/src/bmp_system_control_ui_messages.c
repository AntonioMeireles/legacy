	case BMP_SYSTEM_MESSAGE_UI_START:
		{
		    GdkDisplay *display;

		    if (!ui_initialized)
		    {
		      gtk_init (0, NULL);
		      Gdk::wrap_init();
		      Gtk::wrap_init(); 
		      ui_initialized = TRUE;
		    }

		    if (message->data)
		      {
			display = gdk_display_open ((gchar*)message->data);
			if (display)
			  {
			    gdk_display_manager_set_default_display (gdk_display_manager_get (), display);
			  }
			else
			  gdk_display_open_default_libgtk_only();
		      }
		    else
			gdk_display_open_default_libgtk_only();

		    g_message ("Starting UI...");

		    bmp_ui = bmp_ui_new ();
		    if (bmp_ui_finalize_init (bmp_ui) != BMP_ERROR_SUCCESS)
			{
			    g_object_unref (bmp_ui);
			    bmp_ui = NULL;
			    gtk_main_quit ();
			}

		    bmp_system_control_update_title (control);
		    control->priv->dispose_objects = g_list_prepend (control->priv->dispose_objects, (gpointer)bmp_ui);
		}
	    break;

	case BMP_SYSTEM_MESSAGE_UI_STOP:
		{
		    if (bmp_ui)
		      {
			control->priv->dispose_objects = g_list_remove (control->priv->dispose_objects, bmp_ui);
			g_object_unref (bmp_ui);
			bmp_ui = NULL;
		      }
		}
	    break;

