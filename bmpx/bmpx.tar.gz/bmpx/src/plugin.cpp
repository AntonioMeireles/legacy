/*  BMPx - The Dumb Music Player
 *  Copyright (C) 2005 BMPx development team.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 *  $Id$
 *
 * The BMPx project hereby grant permission for non-gpl compatible GStreamer
 * plugins to be used and distributed together with GStreamer and BMPx. This
 * permission are above and beyond the permissions granted by the GPL license
 * BMPx is covered by.
 *
 */


#include <config.h>
#include <stdio.h>
#include <stdlib.h>
#include <gmodule.h>

#include <bmp/plugin.h>

typedef struct _BmpPluginClass BmpPluginClass;

struct _BmpPlugin
{
  GTypeModule parent_instance;

  GModule *library;

  void	   (*init)            (GTypeModule *);
  void	   (*exit)            (void);
  GObject* (*create_instance) (void);

  gchar *path;
};

struct _BmpPluginClass
{
  GTypeModuleClass parent_class;
};

static gboolean
bmp_plugin_load (GTypeModule *module)
{
  BmpPlugin *plugin = BMP_PLUGIN(module);
  gpointer   plugin_version_sym;
  guint	    *plugin_version;

  plugin->library = g_module_open (plugin->path, G_MODULE_BIND_LOCAL);
  if (!plugin->library)
    {
      g_warning (g_module_error());
      return FALSE;
    }

  if (!g_module_symbol (plugin->library, "plugin_version", &plugin_version_sym))
      {
	g_module_close (plugin->library);
	plugin->library = NULL;
	g_log (G_LOG_DOMAIN, G_LOG_LEVEL_WARNING, "Plugin has no version information, not loading.");
	return FALSE;
      }

  plugin_version = static_cast<guint *> (plugin_version_sym);

  if (*plugin_version != PLUGIN_VERSION)
      {
	g_module_close (plugin->library);
	plugin->library = NULL;
	g_log (G_LOG_DOMAIN, G_LOG_LEVEL_WARNING, "Plugin version mismatch, not loading.");
	return FALSE;
      }

  /* extract symbols from the lib */
  if (!g_module_symbol (plugin->library, "plugin_init",
			(gpointer *) &plugin->init) ||
      !g_module_symbol (plugin->library, "plugin_exit",
			(gpointer *) &plugin->exit) ||
      !g_module_symbol (plugin->library, "create_instance",
			(gpointer *) &plugin->create_instance))
    {
      g_warning (g_module_error());
      g_module_close (plugin->library);

      return FALSE;
    }
  else
    {
      //g_log (G_LOG_DOMAIN, G_LOG_LEVEL_INFO, "Success loading plugin.");
    }

  plugin->init (module);

  return TRUE;
}

static void
bmp_plugin_unload (GTypeModule *module)
{
  BmpPlugin *plugin = BMP_PLUGIN (module);

  plugin->exit();

  g_module_close (plugin->library);

  plugin->library = NULL;
  plugin->init = NULL;
  plugin->exit = NULL;
  plugin->create_instance = NULL;
}

static void
bmp_plugin_class_init (BmpPluginClass *klass)
{
  GTypeModuleClass *module_class = G_TYPE_MODULE_CLASS (klass);

  module_class->load   = bmp_plugin_load;
  module_class->unload = bmp_plugin_unload;
}


GType
bmp_plugin_get_type (void)
{
  static GType plugin_type = 0;

  if (!plugin_type)
    {
      static const GTypeInfo plugin_info = {
        sizeof (BmpPluginClass),
        NULL,           /* base_init */
        NULL,           /* base_finalize */
        (GClassInitFunc) bmp_plugin_class_init,
        NULL,           /* class_finalize */
        NULL,           /* class_data */
        sizeof (BmpPlugin),
        0,              /* n_preallocs */
        NULL,           /* instance_init */
      };

      plugin_type =
	g_type_register_static (G_TYPE_TYPE_MODULE, "BmpPlugin",
				&plugin_info, GTypeFlags (0));
    }

  return plugin_type;
}


BmpPlugin*
bmp_plugin_new (const gchar *path)
{
    BmpPlugin *plugin;

    plugin = static_cast<BmpPlugin *> (g_object_new (BMP_TYPE_PLUGIN, NULL));
    plugin->path = g_strdup(path);

    return plugin;
}


gboolean
bmp_plugin_valid (BmpPlugin *plugin)
{
    return (plugin->library != NULL);
}


GObject*
bmp_plugin_create_instance (BmpPlugin *plugin)
{
    g_assert (plugin != NULL);

    return plugin->create_instance();
}
