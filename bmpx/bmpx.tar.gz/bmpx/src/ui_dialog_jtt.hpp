//  BMPx - The Dumb Music Player
//  Copyright (C) 2005-2006 BMPx development team.
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
//
//  --
//
//  The BMPx project hereby grants permission for non GPL-compatible GStreamer
//  plugins to be used and distributed together with GStreamer and BMPx. This
//  permission is above and beyond the permissions granted by the GPL license
//  BMPx is covered by.

#ifndef BMP_UI_DIALOG_JTT_HPP
#define BMP_UI_DIALOG_JTT_HPP

#include <glib-object.h>

#define BMP_TYPE_JTT		  (bmp_jtt_get_type ())
#define BMP_JTT(obj)		  (G_TYPE_CHECK_INSTANCE_CAST ((obj), BMP_TYPE_JTT, BmpJumpToTrack))
#define BMP_JTT_CLASS(klass)	  (G_TYPE_CHECK_CLASS_CAST ((klass), BMP_TYPE_JTT, BmpJumpToTrackClass))
#define BMP_IS_JTT(obj)		  (GTK_CHECK_TYPE ((obj), BMP_TYPE_JTT))
#define BMP_IS_JTT_CLASS(klass)	  (G_TYPE_CHECK_CLASS_TYPE ((klass), BMP_TYPE_JTT))
#define BMP_JTT_GET_CLASS(obj)	  (G_TYPE_INSTANCE_GET_CLASS ((obj), BMP_TYPE_JTT, BmpJumpToTrackClass))

typedef struct _BmpJumpToTrack BmpJumpToTrack;
typedef struct _BmpJumpToTrackClass BmpJumpToTrackClass;
typedef struct _BmpJumpToTrackPrivate BmpJumpToTrackPrivate;

struct _BmpJumpToTrack {
	GObject parent;

        BmpJumpToTrackPrivate *priv;

    	GtkWidget *window;
};

struct _BmpJumpToTrackClass {
	GObjectClass parent;
};

GType
bmp_jtt_get_type      (void);

BmpJumpToTrack*
bmp_jtt_new	      (void);

void
bmp_jtt_show	      (BmpJumpToTrack *jtt);

#endif // BMP_UI_DIALOG_JTT_HPP
