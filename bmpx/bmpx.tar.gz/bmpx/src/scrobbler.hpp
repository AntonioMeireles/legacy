//-*- Mode: C++; indent-tabs-mode: nil; -*-

/*  BMPx - The Dumb Music Player
 *  Copyright (C) 2005 BMPx development team.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 *  $Id$
 *
 * The BMPx project hereby grant permission for non-gpl compatible GStreamer
 * plugins to be used and distributed together with GStreamer and BMPx. This
 * permission are above and beyond the permissions granted by the GPL license
 * BMPx is covered by.
 *
 */

#ifndef LASTFM_CLASS_HPP
#define LASTFM_CLASS_HPP

#include <glibmm.h>
#include <system_control.hpp>
#include <mcs/mcs.h>

namespace Bmp
{
    /** Client code for Last.FM
     *
     * Bmp::Scrobbler is a client implementation of Audioscrobbler Protocol 1.1,
     * (http://www.audioscrobbler.com), used by Last.FM (http://last.fm), a public,
     * free service that tracks your listening habits and provides you with statistics
     * and friends. 
     *
     */
    class Scrobbler : public Glib::Object
    {
      public:

	Scrobbler ();
	~Scrobbler ();

	//Signals
	typedef sigc::signal<void, unsigned int> SignalQueueSize;
	SignalQueueSize& signal_queue_size(); 

	typedef sigc::signal<void> SignalSubmitStart;
	SignalSubmitStart& signal_submit_start(); 

	typedef sigc::signal<void> SignalSubmitEnd;
	SignalSubmitEnd& signal_submit_end();

	void
	emit_queue_size ();

      private:

	SignalQueueSize signal_queue_size_; 
	SignalSubmitStart signal_submit_start_; 
	SignalSubmitEnd signal_submit_end_;

	struct QueueItem
	{
	    std::string md5_pre;
	    std::string md5_post;
	};

	struct HandshakeInfo
	{
	    /** Whether the server signalized that we're up to date 
	     */
	    bool uptodate;

	    /** URI for track submissions 
	     */
	    std::string uri;

	    /** MD5 challenge string from the server 
	     */
	    std::string md5;

	    /** Initial interval received from the server 
	     */
	    int interval;

	    /** Used for FAILED reason and UPDATE url
	     */
	    std::string info;
	};

	enum HandshakeStatus
	{
          SCROBBLER_HANDSHAKE_UPTODATE,
	  SCROBBLER_HANDSHAKE_UPDATE,
	  SCROBBLER_HANDSHAKE_BADUSER,
	  SCROBBLER_HANDSHAKE_FAILED,
	  SCROBBLER_HANDSHAKE_NETWORK_ERROR,
	  SCROBBLER_HANDSHAKE_STATE_UNDEFINED
	};

	enum SignalHandlers
	{
	  H_TRACK_CHANGE,
	  H_SET_STREAM_POS,
	  H_SEEK_EVENT,
	  H_LASTFM_ENABLE,
	  H_LASTFM_ENABLE_GENERAL,

	  N_HANDLERS
	};
     
	Glib::Mutex	  lock_green_light;
	Glib::Mutex	  lock_queue;
   
	HandshakeInfo	  info;
	std::string	  md5_response;
	bool		  handshaked;
	bool		  enabled;
	bool		  sent;

	bool		  green_light;
	sigc::connection  green_light_conn;
     
	std::list<QueueItem> queue;
	sigc::connection queue_conn;

	int		  duration;
	int		  position;

	gulong		  handler[N_HANDLERS];
	int		  message_domain_id;

        HandshakeStatus
	handshake ();

	void
	run_handshake ();

	bool
	process_queue ();

	void
	restart_green_light_timeout (int seconds);

	bool
	set_green_light ();

	void
	send_song_information (int position);
   
	//MCS callbacks 
	void
	general_enable (const std::string&	    domain,
			const std::string&	    key,
			const Mcs::KeyVariant&	    value);

        void
	enable_changed (const std::string&	    domain,
			const std::string&	    key,
			const Mcs::KeyVariant&	    value);

	//C GObject callbacks
	static void
	track_change  (BmpSystemControl    *system_control,
		       gpointer		    data);


	static void
	seek_event (BmpSystemControl  *control,
		    gint	       position,
		    gpointer           data);

	static void
	set_stream_pos	(BmpSystemControl   *system_control,
			 gint		     position,
			 gpointer	     data);

    };

};

#endif // LASTFM_CLASS_HPP

