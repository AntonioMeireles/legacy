#include <config.h>

#include <gtk/gtk.h>
#include <gtkmm.h>

#include <glibmm.h>
#include <glib/gi18n.h>
#include <glib/gstdio.h>

#include <cstdio>
#include <cstdlib>
#include <cstring>

#include <unistd.h>
#include <sys/stat.h>

#include <bmp/util.h>
#include <bmp/uri++.hpp>
#include <bmp/file_utils.hpp>
#include <bmp/vfs.hpp>

#include <libxml/tree.h>
#include <libxml/parser.h>
#include <libxml/xmlreader.h>
#include <libxml/xpath.h>
#include <libxml/xpathInternals.h>

#include <boost/format.hpp>

#include "xml.h"
#include "main.hpp"
#include "paths.hpp"

namespace
{
  void
  area_prepared (gint *done)
  {
    g_atomic_int_inc (done);
  }
}

#define AMAZON_FORMAT_STRING_URI "http://webservices.amazon.com/onca/xml?Service=AWSECommerceService&SubscriptionId=1E90RVC80K4MVNTCHG02&Operation=ItemSearch&Artist=%s&Title=%s&SearchIndex=Music&ResponseGroup=Images&Version=2004-11-10"

namespace Bmp
{
  Glib::RefPtr<Gdk::Pixbuf> 
  get_cover (const std::string& _uri) 
  {
    Glib::RefPtr<Gdk::PixbufLoader> loader;
    sigc::connection		    area_done_conn;
    char		  *uri_img;
    int			   done;
    xmlDocPtr		   doc;
    xmlXPathObjectPtr	   xpathObj;
    xmlNodeSetPtr	   nv;
    xmlNodePtr		   node;

    Glib::RefPtr<Gdk::Pixbuf> cover;

    Bmp::DB::DataRow		row = library->get_metadata (_uri);
    Bmp::DB::DataRow::iterator	i;

    i = row.find (library->get_metadatum_id (Bmp::Library::DATUM_ARTIST));
    if (i == row.end()) throw false;
    Glib::ustring artist = Glib::ustring(boost::get<std::string>(i->second)); 

    i = row.find (library->get_metadatum_id (Bmp::Library::DATUM_ALBUM));
    if (i == row.end()) throw false;
    Glib::ustring album	= Glib::ustring(boost::get<std::string>(i->second)); 

    i = row.find (library->get_metadatum_id (Bmp::Library::DATUM_LOCATION));
    if (i == row.end()) throw false;
    Glib::ustring location = Glib::ustring(boost::get<std::string>(i->second)); 

    Bmp::URI uri (boost::get<std::string>(i->second));

    if ((album.length () > 0) && (uri.get_protocol() != Bmp::URI::PROTOCOL_HTTP)) 
    {
	std::string basename = (boost::format ("%1%_%2%.png") % artist.lowercase () % album.lowercase ()).str ();
	std::string thumb_path = Glib::build_filename (BMP_PATH_COVER_THUMB_DIR, basename);

	if (Glib::file_test (thumb_path, Glib::FILE_TEST_EXISTS))
	{
	    cover = Gdk::Pixbuf::create_from_file (thumb_path); 
	    return cover;
	}
	else
	{
	  Bmp::URI uri ((boost::format (AMAZON_FORMAT_STRING_URI) % artist % album).str());
	  uri.escape ();
	  Bmp::VFS::Handle handle = Bmp::VFS::Handle::create (std::string(uri));
	  vfs->read_no_container (handle);

	  doc = xmlParseMemory ((const char*)handle.get_buffer(), handle.get_buffer_size());
	  if (!doc) throw false;
	  xpathObj = xml_execute_xpath_expression (doc, BAD_CAST "//amazon:MediumImage/amazon:URL", BAD_CAST "amazon=http://webservices.amazon.com/AWSECommerceService/2004-11-10");
	  nv = xpathObj->nodesetval;
	  if (!nv)
	  {
	    xmlXPathFreeObject (xpathObj);
	    throw false;
	  }

	  if (!nv->nodeNr)
	  {
	    xmlXPathFreeObject (xpathObj);
	    throw false;
	  }

	  node = nv->nodeTab[0];
	  if (!node->children)
	  {
	    xmlXPathFreeObject (xpathObj);
	    throw false;
	  }

	  uri_img = (char*)XML_GET_CONTENT (node->children);
	  xmlXPathFreeObject (xpathObj);
	  handle = Bmp::VFS::Handle::create (std::string(uri_img));
	  vfs->read_no_container (handle);

	  if (!handle.get_buffer())
	  {
	    throw false;
	  }

	  loader = Gdk::PixbufLoader::create ("jpeg"); 
	  done = 0;
	  area_done_conn = loader->signal_area_prepared().connect (sigc::bind (&area_prepared, &done));
	  loader->write (reinterpret_cast<const guint8*>(handle.get_buffer()), handle.get_buffer_size());
	  loader->close ();
	  cover = loader->get_pixbuf (); 

	  //FIXME: Use Mutex and GCond
	  while (!g_atomic_int_get(&done))
	  {
	    while (gtk_events_pending()) gtk_main_iteration ();
	  }

	  area_done_conn. disconnect ();

	  Glib::RefPtr<Gdk::Pixbuf> scaled = cover->scale_simple ( 128, 128, Gdk::INTERP_HYPER );
	  scaled->save (thumb_path, "png");
	  return scaled;
	}
    }
    throw false;
  }
}
