#include <iostream>
#include <sstream>

#include <sqlite3.h>
#include <glibmm.h>
#include <boost/variant.hpp>
#include <boost/tuple/tuple.hpp>
#include <bmp/database.hpp>

namespace {

  static const char* sql_valuenames[] =
  {
      "INTEGER",    //SQLite doesn't know a boolean type so we have to convert hence and forth
      "INTEGER",
      "REAL",
      "TEXT"
  };

};

namespace Bmp {

      namespace DB {

	  void
	  DB::sqlite_exec_simple (std::string sql)
	  {
	    //compile the sql statement
	    int		   status;
	    sqlite3_stmt  *pStmt = NULL;
	    const char    *tail;

	    status = sqlite3_prepare (sqlite,
				sql.c_str(),
				sql.length(),
				&pStmt,
				&tail);		 

	    if (status != SQLITE_OK)
	    {
	      g_message ("SQL Error: '%s', SQL Statement: '%s'", sqlite3_errmsg (sqlite), sql.c_str ());
	      throw Bmp::DB::SQL_EXEC_ERROR;
	    }

	    for (status = -1; status != SQLITE_DONE; )
	    {
	      status = sqlite3_step (pStmt);

	      if (status == SQLITE_ERROR)
	      {
		g_message ("SQL Error: '%s', SQL Statement: '%s'", sqlite3_errmsg (sqlite), sql.c_str ());
		break;
	      }
	    }
	    sqlite3_finalize (pStmt);

	  }


	  DB::DB (std::string name, std::string path, bool truncate) : name (name), path (path)
	  {
	      std::string db_filename (Glib::build_filename (path, name) + ".mlib");	    

	      if (Glib::file_test (db_filename, Glib::FILE_TEST_EXISTS) && truncate)
		{
		  unlink (db_filename.c_str());
		}

	      if (sqlite3_open (db_filename.c_str(), &sqlite) != SQLITE_OK)
		{
		  throw IO_ERROR;
		}
	  };

	  DB::~DB ()
	  {
	      sqlite3_close (sqlite);
	  };
    
	  void
	  DB::add  (std::string		     name,
		    const Bmp::DB::DataRow&  row,
		    const ValueMap&	     map)
	  {
	      using namespace std;

		stringstream sql_keys,
			     sql_values;
		bool	     had_value; 

		had_value  =  false;
		sql_keys   << "(";
		sql_values << "("; 

		for (ValueMap::const_iterator iter = map.begin (); iter != map.end (); iter++)
		{
		  const ValueMapPair &pair = (*iter);
		  const Bmp::DB::DataRow::const_iterator data_iter = row.find (pair.first);

		  if (data_iter != row. end ())
		  {
		    const ValueVariant &value = (*data_iter).second;

		    if (had_value)
		    {
		      sql_keys    << " , ";
		      sql_values  << " , ";
		    }

		    //add key
		    sql_keys   << pair.first;

		    //add it's value
		    sql_values << "'"; 
		    switch (pair.second)
		    {
			case VALUE_TYPE_STRING:
			{
			  char  *attribute_value_escaped = sqlite3_mprintf ("%q", boost::get<std::string>(value).c_str()); 
			  sql_values << attribute_value_escaped; 
			  g_free (attribute_value_escaped);
			  break;
			}
  
			case VALUE_TYPE_INT:
			{
			  sql_values << value; 
			  break;
			}

			case VALUE_TYPE_BOOL:
			{
			  sql_values << value; 
			  break;
			}

			case VALUE_TYPE_REAL:
			{
			  sql_values << value; 
			  break;
			}

		    }
		    sql_values << "'"; 
		    had_value = true;
		  }
		}
		sql_keys    << ")";
		sql_values  << ")";

		stringstream statement;
		statement << "INSERT INTO '" << name << "' " << sql_keys.str() << " VALUES " << sql_values.str() << ";";
		try {
		  sqlite_exec_simple (statement.str ());
		} catch (Bmp::DB::Exception e) {}

	  }

	  void
	  DB::del 	(std::string		name,
			 const ValueMap&	map,
			 const AttributeList&	attributes)
	  {
	      using namespace std;

		stringstream sql;
		sql << "DELETE FROM '" << name << "' WHERE ";

		AttributeList::const_iterator attributesLast (attributes.end ());
		attributesLast--;
		for (AttributeList::const_iterator attributeIter  = attributes.begin  (),
						   attributesEnd  = attributes.end    ();
						   attributeIter != attributesEnd ; ++attributeIter)
		  {
		    const Bmp::DB::Attribute& Attr	= (*attributeIter);
		    const bool exact			= boost::get<0>(Attr);
		    const std::string& attribute_name	= boost::get<1>(Attr);
		    const ValueVariant& attribute_value	= boost::get<2>(Attr);
    
		    if (!exact)
		    {
		      if (attribute_value.which() == VALUE_TYPE_STRING)
		      {
			char *attribute_value_escaped = sqlite3_mprintf ("%q", boost::get<std::string>(attribute_value).c_str()); 
			sql << attribute_name << " LIKE '" << attribute_value_escaped << "%' ";
			g_free (attribute_value_escaped);
		      }
		      else
		      {
			sql << attribute_name << " LIKE '" << attribute_value << "%' ";
		      }
		    } 
		    else
		    {
		      if (attribute_value.which() == VALUE_TYPE_STRING)
		      {
			char *attribute_value_escaped = sqlite3_mprintf ("%q", boost::get<std::string>(attribute_value).c_str()); 
			sql << attribute_name << "='" << attribute_value_escaped << "' ";
			g_free (attribute_value_escaped);
		      }
		      else
		      {
			sql << attribute_name << "='" << attribute_value << "' ";
		      }
		    }

		    if (attributeIter != attributesLast) sql << " AND ";
		  }
		  sql << ";";

                //compile the sql statement
                int	      status;
                sqlite3_stmt  *pStmt;
                const char    *tail;
                status = sqlite3_prepare (sqlite,
                                          sql.str().c_str(),
                                          sql.str().length(),
                                          &pStmt,
                                          &tail);		 
  
                if (status != SQLITE_OK)
                {
                    g_message ("SQL Error: '%s', SQL Statement: '%s'", sqlite3_errmsg (sqlite), sql.str().c_str ());
                    throw Bmp::DB::SQL_EXEC_ERROR;
                };
  
  
                for (status = -1; status != SQLITE_DONE; )
                {
                    status = sqlite3_step (pStmt);
  
                    switch (status)
                    {
                        case SQLITE_DONE: break;
                        case SQLITE_ERROR: break;
                    } 
  
                } 
                sqlite3_finalize (pStmt);

	  }

	  Bmp::DB::DataRowVector
	  DB::project     (std::string		    name,
			   std::string		    p_column, 
			   const ValueMap&	    map,
			   const AttributeList&	    attributes)
	  {
	      using namespace std;

		Bmp::DB::DataRowVector vector;
		stringstream sql;

	        ValueMap::const_iterator valueMapLast (map.end());	
		valueMapLast--;

		if (!attributes.empty ())
		{
		  sql << "SELECT DISTINCT " << p_column << " FROM '" << name << "' WHERE "; 

		  AttributeList::const_iterator attributesLast (attributes.end ());
		  attributesLast--;
		  for (AttributeList::const_iterator attributeIter  = attributes.begin  (),
						 attributesEnd  = attributes.end    ();
						 attributeIter != attributesEnd ; ++attributeIter)
		  {
		    const Bmp::DB::Attribute& Attr	= (*attributeIter);
		    const bool exact			= boost::get<0>(Attr);
		    const std::string& attribute_name	= boost::get<1>(Attr);
		    const ValueVariant& attribute_value = boost::get<2>(Attr);
    
		    if (!exact)
		    {
		      if (attribute_value.which() == VALUE_TYPE_STRING)
		      {
			char *attribute_value_escaped = sqlite3_mprintf ("%q", boost::get<std::string>(attribute_value).c_str()); 
			sql << attribute_name << " LIKE '" << attribute_value_escaped << "%' ";
			g_free (attribute_value_escaped);
		      }
		      else
		      {
			sql << attribute_name << " LIKE '" << attribute_value << "%' ";
		      }
		    }
		    else
		    {
		      if (attribute_value.which() == VALUE_TYPE_STRING)
		      {
			char *attribute_value_escaped = sqlite3_mprintf ("%q", boost::get<std::string>(attribute_value).c_str()); 
			sql << attribute_name << "='" << attribute_value_escaped << "' ";
			g_free (attribute_value_escaped);
		      }
		      else
		      {
			sql << attribute_name << "='" << attribute_value << "' ";
		      }
		    }

		    if (attributeIter != attributesLast) sql << " AND ";
		  } 
		  sql << ";";
		}
		else
		{
		  sql << "SELECT DISTINCT " << p_column << " FROM '" << name << "';";
		}

		//compile the sql statement
		sqlite3_stmt  *pStmt;
		const char    *tail;
		int	       status;

		status = sqlite3_prepare (sqlite,
					  sql.str().c_str(),
					  sql.str().length(),
					  &pStmt,
					  &tail);		 

		if (status != SQLITE_OK)
		{
		  g_message ("SQL Error: '%s', SQL Statement: '%s'", sqlite3_errmsg (sqlite), sql.str().c_str ());
		  throw Bmp::DB::SQL_EXEC_ERROR;
		};

		for (status = -1; status != SQLITE_DONE; )
		{
		  status = sqlite3_step (pStmt);
		  switch (status)
		  {
		      case SQLITE_ROW:		    
		      {
			Bmp::DB::DataRow row;
			Bmp::DB::ValueType type = (*(map.find (p_column))).second;

			switch (type)
			{
			      case VALUE_TYPE_BOOL:
			      {
				int value = sqlite3_column_int (pStmt, 0); 
				row.insert (DataRowPair (p_column, bool(value)));
				break;
			      }

			      case VALUE_TYPE_INT:
			      {
				int value = sqlite3_column_int (pStmt, 0); 
				row.insert (DataRowPair (p_column, int(value))); 
				break;
			      }

			      case VALUE_TYPE_REAL:
			      {
				double value = sqlite3_column_double (pStmt, 0); 
				row.insert (DataRowPair (p_column, double(value)));
				break;
			      }

			      case VALUE_TYPE_STRING:
			      {
				const char* value = (const char*)sqlite3_column_text (pStmt, 0); 
				if (value)
				  row.insert (DataRowPair (p_column, std::string(value)));
				else
				  row.insert (DataRowPair (p_column, std::string("")));
				break;
			      }

			      default: break;
			}

			vector.push_back (row);
			break;
		      }

		      case SQLITE_DONE: break;
		      case SQLITE_ERROR: break;
		  } 
		} 

	      sqlite3_finalize (pStmt);

	      return vector;
	  }

	  Bmp::DB::DataRowVector
	  DB::get         (std::string		  name,
			   const ValueMap&	  map,
			   const AttributeList&   attributes)
	  {
	      using namespace std;

		Bmp::DB::DataRowVector vector;
		stringstream sql;

	        ValueMap::const_iterator valueMapLast (map.end());	
		valueMapLast--;

		sql << "SELECT ";
		for (ValueMap::const_iterator valueMapIter = map.begin	  (),
					      valueMapEnd  = map.end	  ();
					      valueMapIter != valueMapEnd ; ++valueMapIter)
		{
		  const ValueMapPair &pair = (*valueMapIter);
    
		  sql << pair.first;
		  if (valueMapIter != valueMapLast) sql << ",";
		}

		if (!attributes.empty ())
		{
		  sql << " FROM '" << name << "' WHERE ";

		  AttributeList::const_iterator attributesLast (attributes.end ());
		  attributesLast--;
		  for (AttributeList::const_iterator attributeIter  = attributes.begin  (),
						 attributesEnd  = attributes.end    ();
						 attributeIter != attributesEnd ; ++attributeIter)
		  {
		    const Bmp::DB::Attribute& Attr	= (*attributeIter);
		    const bool exact			= boost::get<0>(Attr);
		    const std::string& attribute_name	= boost::get<1>(Attr);
		    const ValueVariant& attribute_value	= boost::get<2>(Attr);
    
		    if (!exact)
		    {
		      if (attribute_value.which() == VALUE_TYPE_STRING)
		      {
			char *attribute_value_escaped = sqlite3_mprintf ("%q", boost::get<std::string>(attribute_value).c_str()); 
			sql << attribute_name << " LIKE '" << attribute_value_escaped << "%' ";
			g_free (attribute_value_escaped);
		      }
		      else
		      {
			sql << attribute_name << " LIKE '" << attribute_value << "%' ";
		      }
		    } 
		    else
		    {
		      if (attribute_value.which() == VALUE_TYPE_STRING)
		      {
			char *attribute_value_escaped = sqlite3_mprintf ("%q", boost::get<std::string>(attribute_value).c_str()); 
			sql << attribute_name << "='" << attribute_value_escaped << "' ";
			g_free (attribute_value_escaped);
		      }
		      else
		      {
			sql << attribute_name << "='" << attribute_value << "' ";
		      }
		    }

		    if (attributeIter != attributesLast) sql << " AND ";
		  }
		  sql << ";";
		}
		else
		{
		  sql << "FROM '" << name << "';";
		}

                //compile the sql statement
                int	     status;
                sqlite3_stmt  *pStmt;
                const char    *tail;
                status = sqlite3_prepare (sqlite,
                                          sql.str().c_str(),
                                          sql.str().length(),
                                          &pStmt,
                                          &tail);		 
  
                if (status != SQLITE_OK)
                {
                    g_message ("SQL Error: '%s', SQL Statement: '%s'", sqlite3_errmsg (sqlite), sql.str().c_str ());
                    throw Bmp::DB::SQL_EXEC_ERROR;
                };
  
  
                for (status = -1; status != SQLITE_DONE; )
                {
                    status = sqlite3_step (pStmt);
  
                    switch (status)
                    {
                        case SQLITE_ROW:		    
                        {
                          Bmp::DB::DataRow row;
                          unsigned int counter = 0;
                          for (ValueMap::const_iterator iter = map.begin (); iter != map.end (); iter++)
                          {
                            const ValueMapPair &pair = (*iter);
                            switch (pair.second)
                            {
                                case VALUE_TYPE_BOOL:
                                {
                                  int value = sqlite3_column_int (pStmt, counter++);	      
                                  row.insert (DataRowPair (pair.first, bool(value))); 
                                  break;
                                }
  
                                case VALUE_TYPE_INT:
                                {
                                  int value = sqlite3_column_int (pStmt, counter++);	      
                                  row.insert (DataRowPair (pair.first, int(value))); 
                                  break;
                                }
  
                                case VALUE_TYPE_STRING:
                                {
				  const char* value = (const char*)sqlite3_column_text (pStmt, counter++);	      

				  if (value)
				  {
				    row.insert (DataRowPair (pair.first, std::string(value)));
				  }
				  else
				  {
				    row.insert (DataRowPair (pair.first, std::string("")));
				  }

				  break;
                                }
  
                                case VALUE_TYPE_REAL:
                                {
                                  double value = sqlite3_column_double (pStmt, counter++);	      
                                  row.insert (DataRowPair (pair.first, double(value))); 
                                  break;
                                }
  
                              default: break;
                            }
                          }
                          vector.push_back (row);
                          break;
                        }
  
                        case SQLITE_DONE: break;
                        case SQLITE_ERROR: break;
                    } 
  
                } 
                sqlite3_finalize (pStmt);

                return vector;
	  }

	  void
	  DB::create_table (std::string name, std::string pkey, const ValueMap& map)
	  {
		using namespace std;

		ValueMap::const_iterator  last;
		stringstream		  sql;

		sql << "CREATE TABLE IF NOT EXISTS '" << name << "' (";
		last = map.end ();
		last--;

		for (ValueMap::const_iterator iter = map.begin (); iter != map.end (); iter++)
		{
		  const ValueMapPair &pair = (*iter);

		  if (!pkey.compare (pair.first))
		  {
		    sql << "'" << pair.first << "' " << sql_valuenames[pair.second] << " NOT NULL PRIMARY KEY";
		  }
		  else
		  {
		    sql << "'" << pair.first << "' " << sql_valuenames[pair.second] << " "; 
		  }

		  if (iter != last) sql << ",";
		}

		sql << ");";

		try {
		  sqlite_exec_simple (sql.str ());
		} catch (Bmp::DB::Exception e) {} //FIXME: Propagate and check whether the table exists

	  }

	  void
	  DB::drop_table (std::string name)
	  {
		using namespace std;

		ValueMap::iterator  last;
		stringstream	    sql;

		sql << "DROP TABLE '" << name << "';";

		try {
		  sqlite_exec_simple (sql.str ());
		} catch (Bmp::DB::Exception e) {}

	  };


      } // DB

}; // Bmp
