//  BMPx - The Dumb Music Player
//  Copyright (C) 2005 BMPx development team.
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
//
//  --
//
//  The BMPx project hereby grants permission for non-GPL compatible GStreamer
//  plugins to be used and distributed together with GStreamer and BMPx. This
//  permission is above and beyond the permissions granted by the GPL license
//  BMPx is covered by.

#ifndef BMP_AUDIO_HPP
#define BMP_AUDIO_HPP

#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <cstring>
#include <glibmm.h>
#include <boost/variant.hpp>

#include <gst/gst.h>
#include <gst/gstelement.h>
#include <gst/interfaces/mixer.h>
#include <gst/interfaces/mixertrack.h>
#include <gst/interfaces/mixeroptions.h>

#include <bmp/uri++.hpp>
#include <bmp/util.h>

#include <goa/libgoa.h>

namespace Bmp
{
  namespace Audio
  {
    /** Elements enum
     */
    enum Elements
    {
	SOURCE,	
	DECODER,
	TEE,
	QUEUE,
	CONVERT,
	VOLUME,
	SINK,
      
	N_ELEMENTS
    };

    /** Names of the elements, corresponding to @link Bmp::Audio::Elements@endlink 
     */
    namespace Element  
    {
      namespace Variant
      {
	  /** boost::variant type for bool, int, double and string values
	   */
	  typedef boost::variant<bool, int, double, std::string> Variant;

	  /** Enum specifying the type of the variant 
	   *  FIXME: This might not be needed
	   */
	  enum Type 
	  {
	    BOOL,
	    INTEGER,
	    DOUBLE,
	    STRING,
	  };
      }

      /** An attribute holds a @link Bmp::Audio::Element::Variant::Variant@endlink,  
       *  a @link Bmp::Audio::Element::Variant::Type@endlink and a name (std::string)
       *
       */
      struct Attribute
      {
	Variant::Variant  value;
	Variant::Type	  type;
	std::string	  name;

	/** Default ctor
	 */
	Attribute () {};

	/** Ctor taking the value, type and the name 
	 */
	Attribute (std::string name, Variant::Variant value) : value (value), name (name) { type = Bmp::Audio::Element::Variant::Type(value.which ()); }; 
      };

      /** std::vector typedef of an Attribute
       */
      typedef std::vector<Attribute> Attributes;

      /** An element consists of a a 'name' (std::string) and a list of attributes (@link Bmp::Audio::Element::Attributes@endlink)
       */
      struct Element
      {
	std::string	    name;
	Attributes	    attributes;

	/** Default ctor
	 */
	Element () {};

        /** Ctor that takes the name of the element
	 */
	Element (std::string name) : name (name) {};

	/** Ctor that takes the name and a reference to a vector of @link Bmp::Audio::Element::Attributes@endlink
	 */
	Element (std::string name, const Attributes& attributes) : name (name), attributes (attributes) {};

        /** Adds an attribute to the list of element attributes
	 * @param attribute An @link Bmp::Audio::Element::Attribute@endlink
	 * @returns void
	 */
	void
	add (const Attribute& attribute)
	{
	  attributes.push_back (attribute);
	}

      };

    }//Element

  }//Audio

}//Bmp

namespace Bmp
{ 
  namespace Audio
  {
    enum Exceptions
    {
	ENOELEMENT,
    };
 
    /** Current state of the audio processing unit
     */ 
    enum ProcessorState
    {
	STATE_STOPPED,
	STATE_PAUSED,
	STATE_RUNNING,
    };

    /** Stream audioproperties 
      *
      */
    struct StreamProperties
    {
	unsigned int bitrate;
	unsigned int samplerate;
	std::string  title;

	StreamProperties () : bitrate (0), samplerate (0), title ("") {}
    };

    /** sigc signal typedef for the stream position
     */
    typedef sigc::signal<void, int>
	    SignalPosition;

    /** sigc signal typedef signalizing end-of-stream 
     */
    typedef sigc::signal<void>
	    SignalEos;

    /** sigc signal typedef for stream properties
     */
    typedef sigc::signal<void, StreamProperties>
	    SignalStreamProperties;

    /** This is the base class for the audio processors
      *
      */
    class ProcessorBase
      : public Glib::Object
    {
      public:

	ProcessorBase ();
	virtual ~ProcessorBase ();

	/** PropertyProxy to get or set the stream time.
	 *  Setting the stream time equals to a seek.
	 */ 
	virtual Glib::PropertyProxy<unsigned int>
	prop_stream_time ();

	/** PropertyProxy to get or set the time interval in millisecond at which to report the current stream time via SignalPosition
	 */
	virtual Glib::PropertyProxy<unsigned int>
	prop_stream_time_report_interval ();

	/** ProcessorState PropertyProxy. Allows to read the current processor state, or set it which equals to one of ::stop (), ::run (), or ::pause ()
	 */
	virtual Glib::PropertyProxy<ProcessorState>
	prop_state ();

	virtual Glib::PropertyProxy<unsigned int>
	prop_length();

	SignalPosition&
	signal_position();

	SignalEos&
	signal_eos();

	SignalStreamProperties&
	signal_stream_properties ();

	/** Starts the processor
	 */
	virtual GstStateChangeReturn
	run   ();

      	/** Stops the processor
	 */
	virtual GstStateChangeReturn 
	stop  ();

	/** Puts the processor into pause mode
	 */
	virtual GstStateChangeReturn 
	pause (); 

	/** Taps into the processor's pipeline
	 * 
	 * @returns The 'tee' element of the pipeline to connect a Processor_Source_* to 
	 *
	 */
	GstElement*
	tap ();

      protected:

	GstElement	  *pipeline;

	Glib::Property<unsigned int>	prop_stream_time_;
	Glib::Property<unsigned int>	prop_stream_time_report_interval_;
	Glib::Property<unsigned int>	prop_length_;
	Glib::Property<ProcessorState>	prop_state_;

	SignalPosition		signal_position_;
	SignalEos		signal_eos_;
	SignalStreamProperties	signal_stream_properties_;

	sigc::connection   conn_position; 

	Element::Element   source;	
	Element::Element   sink;

	StreamProperties   stream_properties;

	/** Creates a pipeline as specified by the current source and sink elements
	 */
	virtual void
	create_pipeline ();

	/** Preforms a position query on the current pipeline and emits the current stream position via @link SignalPosition@endlink
	 */
	virtual bool
	emit_stream_position ();

	/** Stops emission of the current stream position 
	 */
	virtual void
	position_send_stop ();

	/** Starts emission of the current stream position in intervals specified by prop_stream_time_report_interval()
	 */
	void
	position_send_start ();

	/** Handler of state changes of the processor's state property 
	 */
	void
	prop_state_changed ();

	/** Handler of changes to the interval for sending the stream's position 
	 */
	void
	position_send_interval_change ();

	static void
	link_pad  (GstElement *element,
		   GstPad     *pad,
		   gboolean    last,
		   gpointer    data);

	static gboolean
	bus_watch (GstBus     *bus,
                   GstMessage *message,
                   gpointer    data);

	static gboolean
	foreach_structure (GQuark	 field_id,
			   const GValue	*value,
			   gpointer	 data);
    };


    /** This class can be used to play a stream file
     *
     */
    class ProcessorURISink
      : public ProcessorBase 
    {
      public:

	ProcessorURISink ();
	virtual ~ProcessorURISink ();

	/** Will set the uri to the ProcessorURISink
	 * @param uri The uri to use. The processor will automatically adapt to the protocol of the URI to construct an appropriate pipeline
	 * @param sink The @link Bmp::Audio::Element::Element@endlink to specify the sink
	 */
	void
	set_uri (Glib::ustring			     uri,
		 const Bmp::Audio::Element::Element& sink);

      private:

	Bmp::URI::Protocol current_protocol;
        std::string	   stream;
	
    };

#if 0
    class ProcessorURISink_Convert
      : public ProcessorBase 
    {
      public:

	ProcessorURISink_Convert ();
	virtual ~ProcessorURISink_Convert ();

	void
	set_uri (Glib::ustring uri,
		 const Bmp::Audio::Element::Element& sink);

      private:

	BmpURIProtocol current_protocol;
        std::string    uri;
	
    };
#endif

  }
}

namespace Bmp
{
  namespace Audio
  {
      enum ProcessorType
      {
	PROCESSOR_URI_SINK,
      };

      class Hub
      {
	public:
	  Hub	();
	  ~Hub	();

	private:
	  typedef std::map<std::string, Bmp::Audio::ProcessorBase*> Processors;  
	  Processors processors;
      };
  }
}



#endif //BMP_AUDIO_HPP

