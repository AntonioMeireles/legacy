//  BMPx - The Dumb Music Player
//  Copyright (C) 2005-2006 BMPx development team.
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
//
//  --
//
//  The BMPx project hereby grants permission for non GPL-compatible GStreamer
//  plugins to be used and distributed together with GStreamer and BMPx. This
//  permission is above and beyond the permissions granted by the GPL license
//  BMPx is covered by.

#include <config.h>

#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <boost/format.hpp>

#include <unistd.h>
#include <errno.h>

#include <bmp/util.h>
#include <bmp/uri++.hpp>
#include <bmp/file_utils.hpp>

#ifndef __USE_BSD
# define __USE_BSD      /* Needed for mkdtemp () */
#endif

#include "main.hpp"

//////////////// Archive handling functions
namespace Bmp
{
  namespace Util
  {
    namespace
    {
      enum ArchiveType
      {
          ARCHIVE_UNKNOWN = 0,
          ARCHIVE_DIR,
          ARCHIVE_TAR,
          ARCHIVE_TGZ,
          ARCHIVE_ZIP,
          ARCHIVE_TBZ2
      };

      struct ArchiveExtensionType
      {
          ArchiveType type;
          const gchar *ext;
      };

      typedef std::string (*ArchiveExtractFunc) (const std::string &,
                                                 const std::string &);

      ArchiveExtensionType archive_extensions[] =
      {
          {ARCHIVE_TAR, "tar"},
          {ARCHIVE_ZIP, "wsz"},
          {ARCHIVE_ZIP, "zip"},
          {ARCHIVE_TGZ, "tar.gz"},
          {ARCHIVE_TGZ, "tgz"},
          {ARCHIVE_TBZ2, "tar.bz2"},
          {ARCHIVE_TBZ2, "bz2"},
          {ARCHIVE_UNKNOWN, NULL}
      };

      std::string archive_extract_tar (const std::string &archive,
                                       const std::string &dest);

      std::string archive_extract_zip  (const std::string &archive,
                                        const std::string &dest);

      std::string archive_extract_tgz  (const std::string &archive,
                                        const std::string &dest);

      std::string archive_extract_tbz2 (const std::string &archive,
                                        const std::string &dest);

      ArchiveExtractFunc archive_extract_funcs[] =
      {
          0,
          0,
          archive_extract_tar,
          archive_extract_tgz,
          archive_extract_zip,
          archive_extract_tbz2
      };

      std::string
      escape_shell_chars (const std::string &string)
      {
	  char *out_c = g_shell_quote (string.c_str());
	  std::string out (out_c);
	  free (out_c);
	  return out;
      }

      std::string
      archive_extract_tar (const std::string &archive,
                           const std::string &dest)
      {
          static boost::format format ("%s >/dev/null xf %s -C %s");

          return (format % "tar" % archive % dest).str ();
      }

      std::string
      archive_extract_zip (const std::string &archive,
                           const std::string &dest)
      {
          static boost::format format ("%s >/dev/null -o -j %s -d %s");

          return (format % "unzip" % archive % dest).str ();
      }

      std::string
      archive_extract_tgz (const std::string &archive,
                           const std::string &dest)
      {
          static boost::format format ("%s >/dev/null xzf %s -C %s");

          return (format % "tar" % archive % dest).str ();
      }

      std::string
      archive_extract_tbz2 (const std::string &archive,
                            const std::string &dest)
      {
          static boost::format format ("bzip2 -dc %s | %s >/dev/null xf - -C %s");

          return (format % archive % "tar" % dest).str ();
      }

      ArchiveType
      archive_get_type (const std::string &filename)
      {
          gint i = 0;

          if (Glib::file_test (filename, Glib::FILE_TEST_IS_DIR))
              return ARCHIVE_DIR;

          while (archive_extensions[i].ext)
          {
              if (g_str_has_suffix (filename.c_str (), archive_extensions[i].ext))
              {
                  return archive_extensions[i].type;
              }
              i++;
          }

          return ARCHIVE_UNKNOWN;
      }

      bool
      find_file_actual (const std::string &dir_path,
                        const std::string &filename,
                        std::string       &found_path,
                        int                max_depth,
                        int                depth)
      {
          if (max_depth != -1 && depth > max_depth)
              return false;

          Glib::Dir dir (dir_path);

          for (Glib::Dir::const_iterator iter = dir.begin (), end = dir.end ();
               iter != dir.end ();
               ++iter)
          {
              if (*iter != "." && *iter != "..")
              {
                  std::string full_path = Glib::build_filename (dir_path, *iter);

                  if (full_path.length () > FILENAME_MAX)
                  {
                      g_warning (G_STRLOC ": ignoring path: name too long (%s)",
                                 Glib::filename_to_utf8 (full_path).c_str ());
                      return false;
                  }

                  if (Glib::file_test (full_path, Glib::FILE_TEST_IS_REGULAR))
                  {
                      if (Glib::filename_to_utf8 (*iter).lowercase () ==
                          Glib::filename_to_utf8 (filename).lowercase ())
                      {
                          found_path = full_path;
                          return true;
                      }
                  }
                  else if (Glib::file_test (full_path, Glib::FILE_TEST_IS_DIR))
                  {
                      return find_file_actual (dir_path, filename, found_path, max_depth, depth + 1);
                  }
              }
          }

          return false;
      }

    } // <anonymous> namespace

    // FIXME: Return a std::string
    char *
    create_glob (const std::string &suffix)
    {
        GString *out;
        gint n = 0;

        out = g_string_new ("");

        while (suffix[n])
        {
            g_string_append_printf (out, "[%c%c]", g_ascii_tolower (suffix[n]), g_ascii_toupper (suffix[n]));
            n++;
        }

        return g_string_free (out, FALSE);
    }

    bool
    file_is_archive (const std::string &filename)
    {
        return (archive_get_type (filename) > ARCHIVE_DIR);
    }

    std::string
    archive_basename (const std::string &str_std)
    {
        gint i = 0;
        char *str = g_strdup (str_std.c_str ());

        while (archive_extensions[i].ext)
        {
            if (str_has_suffix_nocase (str, archive_extensions[i].ext))
            {
                const gchar *end = g_strrstr (str, archive_extensions[i].ext);
                if (end)
                {
                    /* The -1 is for the '.' in the extension */

                    //FIXME: Don't use C string copying here
                    char *result = g_strndup (str, end - str - 1);
                    std::string result_std (result);

                    g_free (result);
                    g_free (str);

                    return result_std;
                }
            }
            i++;
        }

        g_free (str);
        return std::string ("");
    }

    std::string
    archive_decompress (const std::string &filename)
    {
        std::string escaped_filename, command;

        ArchiveType type;
        if ((type = archive_get_type (filename)) <= ARCHIVE_DIR)
            return std::string ("");

        char *c_tmp_dir = g_strdup (Glib::build_filename (g_get_tmp_dir (), "bmp.XXXXXXXX").c_str ());

        if (!mkdtemp (c_tmp_dir))
        {
            g_message ("Unable to decompress archive '%s': could not create temporary directory: %s",
                       Glib::filename_to_utf8 (filename).c_str (), g_strerror (errno));

            return std::string ("");
        }

        std::string tmp_dir (c_tmp_dir);
        g_free (c_tmp_dir);

        escaped_filename = escape_shell_chars (filename);
        command = archive_extract_funcs[type] (escaped_filename, tmp_dir);

        if (!command.length ())
            return std::string ("");

        if (system (command.c_str ()))
        {
            g_message ("Unable to decompress archive '%s'", Glib::filename_to_utf8 (filename).c_str ());
            return std::string ("");
        }

        return tmp_dir;
    }

    bool
    find_file (const std::string &dir_path,
               const std::string &filename,
               std::string       &found_path,
               int                max_depth)
    {
        found_path = "";
        return find_file_actual (dir_path, filename, found_path, max_depth, 0);
    }

    // Deletes a directory recursively
    void
    del_directory (const std::string &dir_path)
    {
        Glib::Dir dir (dir_path);

        for (Glib::Dir::const_iterator iter = dir.begin (), end = dir.end ();
             iter != end;
             ++iter)
        {
            if (*iter != "." && *iter != "..")
            {
                std::string full_path = Glib::build_filename (dir_path, *iter);

                if (Glib::file_test (full_path, Glib::FILE_TEST_IS_DIR))
                    del_directory (full_path);
                else
                    unlink (full_path.c_str ());
            }
        }

        rmdir (dir_path.c_str ());
    }

    // "Collects" a path of audio files recursively
    void
    collect_path (const std::string &dir_path,
                  FileList          &collection,
                  bool               clear)
    {
        if (clear)
        {
            collection.clear ();
        }

        Glib::Dir dir (dir_path);

        for (Glib::Dir::const_iterator iter = dir.begin (), end = dir.end ();
             iter != end;
             ++iter)
        {
            if (*iter != "." && *iter != "..")
            {
                std::string full_path = Glib::build_filename (dir_path, *iter);

                if (Glib::file_test (full_path, Glib::FILE_TEST_IS_REGULAR))
                {
                    if (bmp_play_engine->is_audio_file (*iter))
		    {
			g_message ("Adding path: %s", full_path.c_str());
                        collection.push_back (full_path);
		    }
                }
                else if (Glib::file_test (full_path, Glib::FILE_TEST_IS_DIR))
                {
                    collect_path (full_path, collection, false);
                }
            }
        }
    }

    void
    dir_for_each_entry (const Glib::ustring &path,
                        DirForeachSlot	     slot)
    {
        Glib::Dir dir (path);
        for (Glib::Dir::const_iterator iter = dir.begin(), end = dir.end(); iter != end; ++iter)
        {
            Glib::ustring full_path = Glib::build_filename (path, *iter);
            if (slot (full_path)) break;
        }
    }

  } // namespace Util

} // namespace Bmp

/////////////////////////////////////////////////////////////////////

#if 0
void
copy_file (const gchar  *source,
           const gchar  *dest)
{

#define CHUNK_SIZE 524288 /* 512k */

    FILE        *FH_SRC, *FH_DEST;
    size_t       size_r, size_w;
    gboolean     proceed = TRUE;

    FH_SRC  = fopen (source, "r");
    FH_DEST = fopen (dest,   "w");

    while (proceed)
    {
        gchar*mem;

        mem = static_cast<char *> (g_malloc0 (CHUNK_SIZE));
        size_r = fread (mem, 1, CHUNK_SIZE, FH_SRC);
        while (gtk_events_pending ()) gtk_main_iteration();

        if ((size_r < CHUNK_SIZE) && (feof (FH_SRC) || ferror (FH_SRC)))
        {
            proceed = FALSE;
        }

        size_w = fwrite (mem, 1, size_r, FH_DEST);
        while (gtk_events_pending ()) gtk_main_iteration();

        g_free (mem);
    }

    fclose (FH_SRC);
    fclose (FH_DEST);
}
#endif
