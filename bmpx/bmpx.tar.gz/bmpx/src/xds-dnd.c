#include "config.h"
#include <string.h>
#include <gtk/gtk.h>

#include "dnd.h"

#define MAX_URI_LEN 4096

void
bmp_dnd_xds_source_set (GdkDragContext *context,
                        Query          *query)
{
  GdkAtom  property;
  g_return_if_fail (GDK_IS_DRAG_CONTEXT (context));
  g_return_if_fail (image == NULL || BMP_IS_IMAGE (image));
  
  property = gdk_atom_intern ("XdndDirectSave0", FALSE);
  
  if (query)
    {
      GdkAtom  type     = gdk_atom_intern ("text/plain", FALSE);
      gchar   *basename;

      basename = g_strdup("Album"); 

      gdk_property_change (context->source_window,
                           property, type, 8, GDK_PROP_MODE_REPLACE,
                           (const guchar *) basename,
                           basename ? strlen (basename) : 0);

      g_free (basename);
      g_free (filename);
    }
  else
    {
      gdk_property_delete (context->source_window, property);
    }
}

void
bmp_dnd_xds_save_image (GdkDragContext   *context,
                        Query            *query,
                        GtkSelectionData *selection)
{
  PlugInProcDef *proc;
  GdkAtom        property = gdk_atom_intern ("XdndDirectSave0", FALSE);
  GdkAtom        type     = gdk_atom_intern ("text/plain", FALSE);
  gint           length;
  guchar        *data;
  gchar         *uri, *filename;
  GError        *error = NULL;

  g_return_if_fail (GDK_IS_DRAG_CONTEXT (context));

  if (! gdk_property_get (context->source_window, property, type,
                          0, MAX_URI_LEN, FALSE,
                          NULL, NULL, &length, &data))
    return;

  uri = g_strndup ((const gchar *) data, length);
  g_free (data);
  filename = g_filename_from_uri (uri, NULL, NULL);
  
  if (g_mkdir(filename))
            {
              gtk_selection_data_set (selection, selection->target, 8,
                                      (const guchar *) "S", 1);
            }
          else
            {
              gtk_selection_data_set (selection, selection->target, 8,
                                      (const guchar *) "E", 1);
	    }

  g_free (filename);
  g_free (uri);
}

/******************************/
/* Direct Save Protocol (XDS) */
/******************************/

// Code based on current GIMP 2.3 CVS (C) 1998-2005 GIMP Coders

static void
bmp_dnd_get_xds_data (GtkWidget        *widget,
                      GdkDragContext   *context,
                      GCallback         get_image_func,
                      gpointer          get_image_data,
                      GtkSelectionData *selection)
{
#if 0
  BmpImage *image;

  image = (BmpImage *)
    (* (BmpDndDragViewableFunc) get_image_func) (widget, get_image_data);

  if (image)
    bmp_dnd_xds_save_image (context, image, selection);
#endif
}

static void
bmp_dnd_xds_drag_begin (GtkWidget      *widget,
                        GdkDragContext *context)
{
  // bmp_dnd_xds_source_set (context, image);
}

static void
bmp_dnd_xds_drag_end (GtkWidget      *widget,
                       GdkDragContext *context)
{
//  bmp_dnd_xds_source_set (context, NULL);
}

void
bmp_dnd_xds_source_add (GtkWidget               *widget,
                        gpointer                 data)
{
  gulong handler;

  g_return_if_fail (GTK_IS_WIDGET (widget));

#if 0
  bmp_dnd_data_source_add (BMP_DND_TYPE_XDS, widget,
                          // G_CALLBACK (get_image_func),
                           data);
#endif

  handler = GPOINTER_TO_UINT (g_object_get_data (G_OBJECT (widget),
                                                 "bmp-dnd-xds-drag-begin"));

  if (! handler)
    {
      handler = g_signal_connect (widget, "drag-begin",
                                  G_CALLBACK (bmp_dnd_xds_drag_begin),
                                  NULL);
      g_object_set_data (G_OBJECT (widget), "bmp-dnd-xds-drag-begin",
                         GUINT_TO_POINTER (handler));
    }

  handler = GPOINTER_TO_UINT (g_object_get_data (G_OBJECT (widget),
                                                 "bmp-dnd-xds-drag-end"));

  if (! handler)
    {
      handler = g_signal_connect (widget, "drag-end",
                                  G_CALLBACK (bmp_dnd_xds_drag_end),
                                  NULL);
      g_object_set_data (G_OBJECT (widget), "bmp-dnd-xds-drag-end",
                         GUINT_TO_POINTER (handler));
    }
}

void
bmp_dnd_xds_source_remove (GtkWidget *widget)
{
  gulong handler;

  g_return_if_fail (GTK_IS_WIDGET (widget));

  handler = GPOINTER_TO_UINT (g_object_get_data (G_OBJECT (widget),
                                                 "bmp-dnd-xds-drag-begin"));
  if (handler)
    {
      g_signal_handler_disconnect (widget, handler);
      g_object_set_data (G_OBJECT (widget), "bmp-dnd-xds-drag-begin", NULL);
    }

  handler = GPOINTER_TO_UINT (g_object_get_data (G_OBJECT (widget),
                                                 "bmp-dnd-xds-drag-end"));
  if (handler)
    {
      g_signal_handler_disconnect (widget, handler);
      g_object_set_data (G_OBJECT (widget), "bmp-dnd-xds-drag-end", NULL);
    }

#if 0
  bmp_dnd_data_source_remove (BMP_DND_TYPE_XDS, widget);
#endif
}
