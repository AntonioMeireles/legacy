/*  BMPx - The Dumb Music Player
 *  Copyright (C) 2005 BMPx development team.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * The BMPx project hereby grant permission for non-gpl compatible GStreamer
 * plugins to be used and distributed together with GStreamer and BMPx. This
 * permission are above and beyond the permissions granted by the GPL license
 * BMPx is covered by.
 */

#ifndef UI_EQUALIZER_H
#define UI_EQUALIZER_H

#include "bmp_window.h"
#include <glib-object.h>

#define BMP_TYPE_WINDOW_EQUALIZER		  (bmp_window_equalizer_get_type ())
#define BMP_WINDOW_EQUALIZER(obj)		  (G_TYPE_CHECK_INSTANCE_CAST ((obj), BMP_TYPE_WINDOW_EQUALIZER, BmpWindowEqualizer))
#define BMP_WINDOW_EQUALIZER_CLASS(klass)	  (G_TYPE_CHECK_CLASS_CAST ((klass), BMP_TYPE_WINDOW_EQUALIZER, BmpWindowEqualizerClass))
#define BMP_IS_WINDOW_EQUALIZER(obj)	  (GTK_CHECK_TYPE ((obj), BMP_TYPE_WINDOW_EQUALIZER))
#define BMP_IS_WINDOW_EQUALIZER_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass), BMP_TYPE_WINDOW_EQUALIZER))
#define BMP_WINDOW_EQUALIZER_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj), BMP_TYPE_WINDOW_EQUALIZER, BmpWindowEqualizerClass))

typedef struct _BmpWindowEqualizer BmpWindowEqualizer;
typedef struct _BmpWindowEqualizerClass BmpWindowEqualizerClass;
typedef struct _BmpWindowEqualizerPrivate BmpWindowEqualizerPrivate;

struct _BmpWindowEqualizer {
	GObject parent;

        BmpWindowEqualizerPrivate *private;

	GtkWidget *window;
};

struct _BmpWindowEqualizerClass {
	GObjectClass parent;
};

#define BMP_UI_EQUALIZER_N_SLIDERS 10

GType
bmp_window_equalizer_get_type (void);

BmpWindowEqualizer*
bmp_window_equalizer_new (void);
 
void 
bmp_window_equalizer_configure(BmpWindowEqualizer *window_equalizer);

void
bmp_window_equalizer_iconify (BmpWindowEqualizer *self);

#endif /* UI_EQUALIZER_H */
