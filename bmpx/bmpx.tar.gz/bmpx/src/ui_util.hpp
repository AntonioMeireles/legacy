#ifndef UI_UTIL_HPP
#define UI_UTIL_HPP

#include <config.h>
#include <gtk/gtk.h>
#include <gdk/gdk.h>
#include <gtkmm.h>
#include "ui.hpp"

enum BmpSkinColor
{
    BMP_SKINCOLOR_PL_BG_NORMAL,
    BMP_SKINCOLOR_PL_FG_NORMAL,
    BMP_SKINCOLOR_PL_BG_SELECTED,
    BMP_SKINCOLOR_PL_FG_CURRENT,
    BMP_N_SKINCOLORS
};

enum CursorId
{
    CURSOR_NORMAL,
    CURSOR_POSBAR,
    CURSOR_VOLBAR,
    CURSOR_PLAYLIST,
    CURSOR_PLAYLIST_SIZE,
    CURSOR_MAINMENU,
    CURSOR_N_CURSORS
};

enum SkinColorId
{
    SKIN_PLEDIT_NORMAL = 0,
    SKIN_PLEDIT_CURRENT,
    SKIN_PLEDIT_NORMALBG,
    SKIN_PLEDIT_SELECTEDBG,
    SKIN_TEXTBG,
    SKIN_TEXTFG,
    SKIN_N_COLORS
};

GdkPixbuf*
bmp_pixbuf_new_simple (guint width, guint height);

void
bmp_pixbuf_copy_area_simple(GdkPixbuf *dest, guint x, guint y, guint width, guint height);

void
bmp_draw_pixbuf_simple (cairo_t *cr, GdkPixbuf *buf, guint x, guint y);

void
bmp_cursors_init ();

void
bmp_cursors_free ();

void
bmp_cursors_set (const std::string& archive_dirname);

void
bmp_cursor_add (const std::string& archive_dirname,
	        int		   cursor_enum);

GdkCursor*
bmp_cursor_get (::CursorId cursor_enum);

GdkBitmap*
bmp_get_mask_window_main (const std::string& path);

std::string
bmp_skin_get_color (const std::string&	path,
		    const std::string&  key);

GdkColor*
bmp_skin_convert_color (const std::string& value_arg);

void
bmp_colors_set_color (BmpSkinColor color, const std::string& color_hex);

void
bmp_colors_init (const std::string& archive_dirname);

void
bmp_colors_free ();

void
bmp_color_allocate (BmpSkinColor color, GtkWidget *widget);

GdkColor*
bmp_colors_get_color(BmpSkinColor color);

void
gdk_color_to_rgba (GdkColor *color, double *r, double *g, double *b, double *a);

void
bmp_window_set_icon_list (GtkWidget *window, const gchar *icon_name);

gdouble
screen_get_resolution (GdkScreen *screen);

gdouble
screen_get_x_resolution (GdkScreen *screen);

gdouble
screen_get_y_resolution (GdkScreen *screen);

GtkWidget *
ui_manager_get_popup (GtkUIManager * self,
		      const gchar * path);

void
bmp_menu_popup (GtkMenu * menu,
		gint x,
		gint y,
		guint button,
		guint time);

void
util_menu_position (GtkMenu * menu,
		    gint * x,
		    gint * y,
		    gboolean * push_in,
		    gpointer data);

#ifdef ENABLE_NLS
gchar *
bmp_menu_translate (const gchar *message,
                    gpointer     data);
#else
#define bmp_menu_translate NULL
#endif

void
bmp_window_set_busy (GtkWidget *widget);

void
bmp_window_set_idle (GtkWidget *widget);

namespace Bmp
{
  namespace Util
  {
    void
    window_set_busy (Gtk::Window &window);

    void
    window_set_idle (Gtk::Window &window);

    // NOTE: gtkmm has no binding for gdk_screen_get_rgba_visual()
    Glib::RefPtr<Gdk::Visual>
    screen_get_rgba_visual (const Glib::RefPtr<Gdk::Screen> &screen);

    // NOTE: gtkmm has no binding for gdk_screen_get_rgba_colormap()
    Glib::RefPtr<Gdk::Colormap>
    screen_get_rgba_colormap (const Glib::RefPtr<Gdk::Screen> &screen);

  } // namespace Util

} // namespace Bmp

#endif
