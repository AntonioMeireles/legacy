#ifndef BMP_TRACKLIST_CLASS_HPP
#define BMP_TRACKLIST_CLASS_HPP

#include <bmp/database.hpp>
#include <list>
#include <vector>
#include <map>
#include <string>
#include <glibmm.h>
#include <gtkmm.h>

namespace Bmp
{
  // TODO: we need a Uri class
  typedef Glib::ustring Uri;

  /** List of URIs (needed in @link Bmp::Playback::insert_rows()@endlink
   */
  typedef std::vector<Uri> UriList;

  /** Row GUID
   */
  typedef unsigned long TrackGuid;

  /** Map mapping a GUID <-> RowReference
   */
  typedef std::map<TrackGuid, Gtk::TreeModel::RowReference> TrackGuidRowMap;


  class PlaybackHistory
  {
  public:

      PlaybackHistory ();
      ~PlaybackHistory ();

      /** Rewinds the history to the beginning.
       *
       */
      void
      rewind ();

      /** Truncates the end of the history and appends TrackGuid guid
       *
       * @param guid The TrackGuid to append
       *
       */
      void
      set (TrackGuid guid);

      /** Prepends TrackGuid guid to the history
       *
       * @param guid The TrackGuid to prepend
       *
       */
      void
      prepend (TrackGuid guid);


      /** Appends TrackGuid guid to the history
       *
       * @param guid The TrackGuid to prepend
       *
       */
      void
      append (TrackGuid guid);

      /** Goes one step back in the history
       *
       */
      void
      back ();

      /** Goes one step forward in the history
       *
       */
      void
      forward ();

      /** Clears the history
       *
       */
      void
      clear ();

      /** Removes the given TrackGuid from the history
       *
       * @param guid The TrackGuid to remove
       *
       */
      void
      remove (TrackGuid guid);

      /** Returns the GUID of the current track
       */
      TrackGuid
      get_mark () const
      {
          return (*mark);
      }

      /** Returns true if the history size is > 0
       */
      operator bool ()
      {
          return history.size ();
      }

  private:

      typedef std::list<TrackGuid> History;

      Glib::Mutex       lock;
      History           history;
      History::iterator mark;
  };

  class TracklistColumns
      : public Gtk::TreeModel::ColumnRecord
  {
  public:

      Gtk::TreeModelColumn<Glib::ustring> artist;
      Gtk::TreeModelColumn<Glib::ustring> album;
      Gtk::TreeModelColumn<int>           track;
      Gtk::TreeModelColumn<Glib::ustring> title;
      Gtk::TreeModelColumn<Glib::ustring> genre;
      Gtk::TreeModelColumn<int>           date;
      Gtk::TreeModelColumn<int>           time;
      Gtk::TreeModelColumn<TrackGuid>     guid;
      Gtk::TreeModelColumn<Uri>           uri;

      TracklistColumns ()
      {
          add (artist);
          add (album);
          add (track);
          add (title);
          add (genre);
          add (date);
          add (time);
          add (guid);
          add (uri);
      }
  };

  class Tracklist
  {

    public:

      Tracklist ();
      ~Tracklist ();

      TracklistColumns tracklist_columns;

      /** Insert rows at the given index into the playlist
       *
       * @param uris list of URIs to insert into the playlist
       * @param index The index at which to insert the items
       * @returns The new end of the list
       *
       */
      unsigned int
      insert_rows (const UriList      &uris,
                   const unsigned int  index);

    private:

      void
      row_inserted (const Gtk::TreeModel::Path     &path,
                    const Gtk::TreeModel::iterator &iter);

      Glib::RefPtr<Gtk::ListStore> playlist;

      PlaybackHistory              history;
      TrackGuid                    current;
      bool                         current_valid;

      TrackGuidRowMap              guid_row_map;
      static unsigned long         guid_base;

      DB::ValueMap                 map;
  };

} // Bmp namespace

#endif // BMP_TRACKLIST_CLASS_HPP
