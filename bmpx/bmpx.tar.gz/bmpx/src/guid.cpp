#include <glibmm.h>
#include <glib.h>
#include <bmp/guid.hpp>

bool
row_guid_equal_func (RowGUID *guid_a, RowGUID *guid_b)
{
    g_return_val_if_fail (guid_a != NULL, FALSE);
    g_return_val_if_fail (guid_b != NULL, FALSE);

    if ((guid_a->counter == guid_b->counter) &&
        (guid_a->hash    == guid_b->hash))
      {
        return true;
      }
    else
      {
        return false;
      }
}

unsigned int
row_guid_hash_func (RowGUID *guid)
{
    guint  hash;
    gchar *hash_str;

    g_return_val_if_fail (guid != NULL, FALSE);

    hash_str = g_strdup_printf ("%u %u", guid->counter, guid->hash);
    hash = g_str_hash (hash_str);
    g_free (hash_str);

    return hash;
}

RowGUID*
bmp_row_guid_copy (RowGUID *guid)
{
  RowGUID *copy = g_new0 (RowGUID,1);

  copy->counter = guid->counter;
  copy->hash    = guid->hash;

  return copy;
}

void
bmp_row_guid_free (RowGUID *guid)
{
  g_free (guid);
}

GType
bmp_row_guid_get_type (void)
{
    static GType our_type = 0;

    if (our_type == 0)
        our_type = g_boxed_type_register_static ("BmpRowGUID",
                                                 (GBoxedCopyFunc)
                                                 bmp_row_guid_copy,
                                                 (GBoxedFreeFunc)
                                                 bmp_row_guid_free);
    return our_type;
}

namespace { unsigned int guid_counter = 0; }

RowGUID*
bmp_row_guid_new (const char *uri)
{
    RowGUID *guid;

    guid = g_new0 (RowGUID,1);
    guid->counter = guid_counter++;
    guid->hash    = g_str_hash (uri);
    return guid;
}
