/*  BMPx - The Dumb Music Player
 *  Copyright (C) 2005 BMPx development team.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 *  $Id$
 *
 * The BMPx project hereby grant permission for non-gpl compatible GStreamer
 * plugins to be used and distributed together with GStreamer and BMPx. This
 * permission are above and beyond the permissions granted by the GPL license
 * BMPx is covered by.
 */

#ifndef BMP_UI_CALLBACKS_HPP
#define BMP_UI_CALLBACKS_HPP

#include <glade/glade.h>
#include <bmp/playlist.hpp>

/* GtkAction callbacks */
void
bmp_ui_callback_mute			    (GtkAction *action, gpointer data);

void
bmp_ui_callback_about			    (GtkAction *action, gpointer data);

void
bmp_ui_callback_preferences		    (GtkAction *action, gpointer data);

void
bmp_ui_callback_library			    (GtkAction *action, gpointer data);

void
bmp_ui_callback_streams			    (GtkAction *action, gpointer data);

void
bmp_ui_callback_jtt			    (GtkAction *action, gpointer data);

void
bmp_ui_callback_quit			    (GtkAction *action, gpointer data);

void
bmp_ui_callback_quit_title		    (GtkAction *action, gpointer data);


void
bmp_ui_callback_iconify			    (GtkAction *action, gpointer data);

void
bmp_ui_callback_prev			    (GtkAction *action, gpointer data);

void
bmp_ui_callback_play			    (GtkAction *action, gpointer data);

void
bmp_ui_callback_pause			    (GtkAction *action, gpointer data);

void
bmp_ui_callback_stop			    (GtkAction *action, gpointer data);

void
bmp_ui_callback_next			    (GtkAction *action, gpointer data);

void
bmp_ui_callback_toggle_shuffle		    (GtkAction *action, gpointer data);

void
bmp_ui_callback_toggle_repeat		    (GtkAction *action, gpointer data);

void
bmp_ui_callback_toggle_pl		    (GtkAction *action, gpointer data);

void
bmp_ui_callback_tracklist_new		    (GtkAction *action, gpointer data);

void
bmp_ui_callback_tracklist_remove	    (GtkAction *action, gpointer data);

void
bmp_ui_callback_tracklists_remove_all	    (GtkAction *action, gpointer data);

void
bmp_ui_callback_tracklist_rename	    (GtkAction *action, gpointer data);

void
bmp_ui_callback_set_playlist_filename	    (GtkAction *action, gpointer data);

void
bmp_ui_callback_add_files		    (GtkAction *action, gpointer data);

void
bmp_ui_callback_add_cd			    (GtkAction *action, gpointer data);

void
bmp_ui_callback_open_files		    (GtkAction *action, gpointer data);

void
bmp_ui_callback_del_files		    (GtkAction *action, gpointer data);

void
bmp_ui_callback_crop_files		    (GtkAction *action, gpointer data);

/* Predicated removals/crops */
void
bmp_ui_callback_remove_artist		    (GtkAction *action, gpointer data);

void
bmp_ui_callback_keep_artist		    (GtkAction *action, gpointer data);

void
bmp_ui_callback_remove_album		    (GtkAction *action, gpointer data);

void
bmp_ui_callback_keep_album		    (GtkAction *action, gpointer data);



void
bmp_ui_callback_del_files_all		    (GtkAction *action, gpointer data);

void
bmp_ui_callback_select_all_files	    (GtkAction *action, gpointer data);

void
bmp_ui_callback_unselect_all_files	    (GtkAction *action, gpointer data);

void
bmp_ui_callback_invert_selection	    (GtkAction *action, gpointer data);

void
bmp_ui_callback_sort_current_list	    (GtkAction *action, gpointer data);

void
bmp_ui_callback_sort_current_list_artist    (GtkAction *action, gpointer data);

void
bmp_ui_callback_sort_current_list_album	    (GtkAction *action, gpointer data);

void
bmp_ui_callback_sort_current_list_title	    (GtkAction *action, gpointer data);

void
bmp_ui_callback_sort_current_list_genre	    (GtkAction *action, gpointer data);

void
bmp_ui_callback_sort_current_list_track	    (GtkAction *action, gpointer data);

void
bmp_ui_callback_sort_current_list_location  (GtkAction *action, gpointer data);

/* TrackInfo */
void
bmp_ui_trackinfo_clear	  (void);

void
bmp_ui_callback_trackinfo (GtkAction *action, gpointer data);


void
bmp_ui_callback_export_tracklist	  (GtkAction *action, gpointer data);

void
bmp_ui_callback_clear_playback_history	  (GtkAction *action, gpointer data);

void
bmp_ui_callback_stop_after_current_track  (GtkAction *action, gpointer data);

/* Our own callbacks */
void
bmp_ui_callback_seek_moved		  (GtkWidget *widget, gpointer data);

void
bmp_ui_callback_volume_moved		  (GtkWidget *widget, gpointer data);

void
bmp_ui_callback_balance_moved		  (GtkWidget *widget, gpointer data);

#endif // BMP_UI_CALLBACKS_HPP
