#ifndef BMP_UI_SPLASH_HPP
#define BMP_UI_SPLASH_HPP

#include <gtkmm.h>

namespace Bmp
{

  class SplashWindow
      : public Gtk::Window
  {
  public:

      SplashWindow ();

  protected:

      virtual void
      on_realize ();

      virtual bool
      on_expose_event (GdkEventExpose *event);

  private:

      Glib::RefPtr<Gdk::Pixbuf> image;

      bool has_alpha;
  };

} // namespace Bmp

#endif // BMP_UI_SPLASH_HPP
