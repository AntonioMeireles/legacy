/*  BMPx - The Dumb Music Player
 *  Copyright (C) 2005 BMPx development team.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 *  $Id$
 *
 * The BMPx project hereby grant permission for non-gpl compatible GStreamer
 * plugins to be used and distributed together with GStreamer and BMPx. This
 * permission are above and beyond the permissions granted by the GPL license
 * BMPx is covered by.
 */

#include <gtk/gtkmain.h>
#include <glib-object.h>
#include <glib/gmacros.h>
#include <gtk/gtkmarshal.h>

#include <bmp/widgets/bmp_button_toggle.h>

/* Forward declarations */

static void bmp_button_toggle_class_init               (BmpButtonToggleClass    *klass);
static void bmp_button_toggle_init                    (BmpButtonToggle         *button_toggle);
static void bmp_button_toggle_destroy                  (GtkObject        *object);
static void bmp_button_toggle_realize                  (GtkWidget        *widget);
static gboolean bmp_button_toggle_expose                   (GtkWidget        *widget,
						GdkEventExpose   *event);
static gboolean bmp_button_toggle_button_press             (GtkWidget        *widget,
						GdkEventButton   *event);

static gboolean bmp_button_toggle_button_release           (GtkWidget        *widget,
						GdkEventButton   *event);
static gboolean bmp_button_toggle_enter_notify		(GtkWidget	 *widget,
						GdkEventCrossing *event);
static gboolean bmp_button_toggle_leave_notify		(GtkWidget	 *widget,
						GdkEventCrossing *event);
static void bmp_button_toggle_size_allocate (GtkWidget           *widget,
					    GtkAllocation       *allocation);
static void bmp_button_toggle_send_configure (BmpButtonToggle     *button_toggle);

enum {
	PROP_0,
	PROP_ACTIVE
};

/* Local data */

static GtkToggleButtonClass *parent_class = NULL;

GType
bmp_button_toggle_get_type ()
{
  static GType button_type = 0;

  if (!button_type)
    {
      static const GTypeInfo button_info =
      {
        sizeof (BmpButtonToggleClass),
        NULL,           /* base_init */
        NULL,           /* base_finalize */
        (GClassInitFunc) bmp_button_toggle_class_init,
        NULL,           /* class_finalize */
        NULL,           /* class_data */
        sizeof (BmpButtonToggle),
        0,              /* n_preallocs */
        (GInstanceInitFunc) bmp_button_toggle_init
      };

      button_type =
        g_type_register_static (GTK_TYPE_TOGGLE_BUTTON, "BmpButtonToggle",
                                &button_info, 0);
    }

  return button_type;
}

static void
bmp_button_toggle_class_init (BmpButtonToggleClass *class)
{
  GtkObjectClass *object_class;
  GtkWidgetClass *widget_class;

  object_class = (GtkObjectClass*) class;
  widget_class = (GtkWidgetClass*) class;

  parent_class = gtk_type_class (gtk_widget_get_type ());

  object_class->destroy = bmp_button_toggle_destroy;

  widget_class->realize = bmp_button_toggle_realize;
  widget_class->expose_event = bmp_button_toggle_expose;
  widget_class->enter_notify_event = bmp_button_toggle_enter_notify;
  widget_class->leave_notify_event = bmp_button_toggle_leave_notify;
  widget_class->button_press_event = bmp_button_toggle_button_press;
  widget_class->button_release_event = bmp_button_toggle_button_release;
  widget_class->size_allocate = bmp_button_toggle_size_allocate;
}

static void
bmp_button_toggle_init (BmpButtonToggle *button_toggle)
{
        gint n;

        GTK_WIDGET_UNSET_FLAGS (button_toggle, GTK_NO_WINDOW);

	button_toggle->width = 0;
	button_toggle->height = 0;
	button_toggle->constructed = 0;
	button_toggle->in_button = 0;
	button_toggle->state = BMP_BUTTON_TOGGLE_STATE_IDLE;
	GTK_TOGGLE_BUTTON(button_toggle)->active = 0;

 	for (n = 0; n < BMP_BUTTON_TOGGLE_N_STATES; button_toggle->state_pb[n++] = NULL);

}

BmpButtonToggle*
bmp_button_toggle_new (void)
{
  BmpButtonToggle *button;

  button = gtk_type_new (bmp_button_toggle_get_type ());
  return button; 
}


GtkWidget*
bmp_button_toggle_new_with_pixbufs(GdkPixbuf *normal, GdkPixbuf *pressed, GdkPixbuf *active)
{
  BmpButtonToggle *button;
  button = gtk_type_new (bmp_button_toggle_get_type ());

  button->state_pb[BMP_BUTTON_TOGGLE_NORMAL] = normal;
  g_object_ref(normal);

  button->state_pb[BMP_BUTTON_TOGGLE_PRESSED] = pressed;
  g_object_ref(pressed);

  button->gc = gdk_gc_new (GTK_WIDGET(button)->window);

  return GTK_WIDGET (button);
}

void
bmp_button_toggle_set_pixbufs(BmpButtonToggle *button, GdkPixbuf *normal, GdkPixbuf *pressed, GdkPixbuf *active)
{

  button->state_pb[BMP_BUTTON_TOGGLE_NORMAL] = normal;
  g_object_ref(normal);

  button->state_pb[BMP_BUTTON_TOGGLE_PRESSED] = pressed;
  g_object_ref(pressed);

  button->state_pb[BMP_BUTTON_TOGGLE_ACTIVE] = active;
  g_object_ref(active);

}

void
bmp_button_toggle_set_from_table (BmpButtonToggle* arg_button, const GdkPixbuf *src, 
                guint            width, 
                guint            height,
                guint            x_normal,
                guint            y_normal,
                guint            x_pressed,
                guint            y_pressed,
		guint		 x_active,
		guint		 y_active)

{
  BmpButtonToggle *button;
  gint n;
 
  g_return_if_fail (GDK_IS_PIXBUF (src));
 
  button = (BmpButtonToggle*) arg_button;

  for (n = 0; n < BMP_BUTTON_TOGGLE_N_STATES; n++)
  {
      if (button->state_pb[n] != NULL) g_object_unref (button->state_pb[n]);
  }
 
  button->state_pb[BMP_BUTTON_TOGGLE_NORMAL] = gdk_pixbuf_new (gdk_pixbuf_get_colorspace(src),
                                            gdk_pixbuf_get_has_alpha(src),
                                            gdk_pixbuf_get_bits_per_sample(src),
                                            width, height);
 
  button->state_pb[BMP_BUTTON_TOGGLE_PRESSED] = gdk_pixbuf_new (gdk_pixbuf_get_colorspace(src),
                                             gdk_pixbuf_get_has_alpha(src),
                                             gdk_pixbuf_get_bits_per_sample(src),
                                             width, height);
 
  button->state_pb[BMP_BUTTON_TOGGLE_ACTIVE] = gdk_pixbuf_new (gdk_pixbuf_get_colorspace(src),
                                             gdk_pixbuf_get_has_alpha(src),
                                             gdk_pixbuf_get_bits_per_sample(src),
                                             width, height);
 
  gdk_pixbuf_copy_area (src, x_normal, y_normal, width, height, 
                        button->state_pb[BMP_BUTTON_TOGGLE_NORMAL], 0, 0);

  gdk_pixbuf_copy_area (src, x_pressed, y_pressed, width, height, 
                        button->state_pb[BMP_BUTTON_TOGGLE_PRESSED], 0, 0);
 
  gdk_pixbuf_copy_area (src, x_active, y_active, width, height, 
                        button->state_pb[BMP_BUTTON_TOGGLE_ACTIVE], 0, 0);
  
  button->gc = gdk_gc_new (GTK_WIDGET(button)->window);
    
  gtk_widget_set_size_request(GTK_WIDGET (button), width, height);
 
}




static void
bmp_button_toggle_destroy (GtkObject *object)
{
  BmpButtonToggle *button_toggle;

  g_return_if_fail (object != NULL);
  g_return_if_fail (BMP_IS_BUTTON_TOGGLE (object));

  button_toggle = BMP_BUTTON_TOGGLE(object);

  if (GTK_OBJECT_CLASS (parent_class)->destroy)
    (* GTK_OBJECT_CLASS (parent_class)->destroy) (object);
}

static void
bmp_button_toggle_realize (GtkWidget *widget)
{
  BmpButtonToggle *button_toggle;
  GdkWindowAttr attributes;
  gint attributes_mask;

  g_return_if_fail (widget != NULL);
  g_return_if_fail (BMP_IS_BUTTON_TOGGLE (widget));

  GTK_WIDGET_SET_FLAGS (widget, GTK_REALIZED);
  button_toggle = BMP_BUTTON_TOGGLE (widget);

  attributes.x = widget->allocation.x;
  attributes.y = widget->allocation.y;
  attributes.width = widget->allocation.width;
  attributes.height = widget->allocation.height;
  attributes.wclass = GDK_INPUT_OUTPUT;
  attributes.window_type = GDK_WINDOW_CHILD;
  attributes.event_mask = gtk_widget_get_events (widget) | 
    GDK_EXPOSURE_MASK | GDK_BUTTON_PRESS_MASK | 
    GDK_BUTTON_RELEASE_MASK | GDK_LEAVE_NOTIFY_MASK | GDK_ENTER_NOTIFY_MASK;
  attributes.visual = gtk_widget_get_visual (widget);
  attributes.colormap = gtk_widget_get_colormap (widget);

  attributes_mask = GDK_WA_X | GDK_WA_Y | GDK_WA_VISUAL | GDK_WA_COLORMAP;
  widget->window = gdk_window_new (widget->parent->window, &attributes, attributes_mask);

  widget->style = gtk_style_attach (widget->style, widget->window);

  gdk_window_set_user_data (widget->window, widget);

  gtk_style_set_background (widget->style, widget->window, GTK_STATE_ACTIVE);
  bmp_button_toggle_send_configure (BMP_BUTTON_TOGGLE(widget));

  
}


static void
bmp_button_toggle_send_configure (BmpButtonToggle *button_toggle)
{
  GtkWidget *widget;
  GdkEvent *event = gdk_event_new (GDK_CONFIGURE);

  widget = GTK_WIDGET (button_toggle);

  event->configure.window = g_object_ref (widget->window);
  event->configure.send_event = TRUE;
  event->configure.x = widget->allocation.x;
  event->configure.y = widget->allocation.y;
  event->configure.width = widget->allocation.width;
  event->configure.height = widget->allocation.height;
  
  gtk_widget_event (widget, event);
  gdk_event_free (event);
}

static void
bmp_button_toggle_size_allocate (GtkWidget     *widget,
				GtkAllocation *allocation)
{
  g_return_if_fail (BMP_IS_BUTTON_TOGGLE (widget));
  g_return_if_fail (allocation != NULL);

  widget->allocation = *allocation;

  if (GTK_WIDGET_REALIZED (widget))
    {
      gdk_window_move_resize (widget->window,
			      allocation->x, allocation->y,
			      allocation->width, allocation->height);

      bmp_button_toggle_send_configure (BMP_BUTTON_TOGGLE (widget));
    }
}

static gboolean
bmp_button_toggle_expose (GtkWidget      *widget,
		 GdkEventExpose *event)
{
  BmpButtonToggle *button;
  GdkPixbuf *buf;
 
  g_return_val_if_fail (widget != NULL, FALSE);
  g_return_val_if_fail (BMP_IS_BUTTON_TOGGLE (widget), FALSE);
  g_return_val_if_fail (event != NULL, FALSE);

  if (event->count > 0)
    return FALSE;
  
  button = BMP_BUTTON_TOGGLE (widget);
  
  buf = button->state_pb[BMP_BUTTON_TOGGLE_NORMAL]; 
 
  if ( (button->state == BMP_BUTTON_TOGGLE_STATE_ACTIVE) 
			&&
	        (button->in_button) ) {
	buf = button->state_pb[BMP_BUTTON_TOGGLE_PRESSED];
  } else if (GTK_TOGGLE_BUTTON(button)->active) {
	buf = button->state_pb[BMP_BUTTON_TOGGLE_ACTIVE];	
  };
	gdk_draw_pixbuf(GTK_WIDGET(button)->window,
			button->gc,
			buf,
			0,
			0,
			0,
			0,
			-1,
			-1,
			GDK_RGB_DITHER_NONE,
			0,
			0);
			
  return FALSE;
}

static gboolean
bmp_button_toggle_button_press (GtkWidget      *widget,
		       GdkEventButton *event)
{
  BmpButtonToggle *button;

  g_return_val_if_fail (widget != NULL, FALSE);
  g_return_val_if_fail (BMP_IS_BUTTON_TOGGLE (widget), FALSE);
  g_return_val_if_fail (event != NULL, FALSE);

  if (event->button != 1) return FALSE;

  button = BMP_BUTTON_TOGGLE (widget);

  button->state = BMP_BUTTON_TOGGLE_STATE_ACTIVE;

  gtk_widget_queue_draw(widget);

  return TRUE;
}

static gboolean
bmp_button_toggle_button_release (GtkWidget      *widget,
			  GdkEventButton *event)
{
  BmpButtonToggle *button_toggle;

  g_return_val_if_fail (widget != NULL, FALSE);
  g_return_val_if_fail (BMP_IS_BUTTON_TOGGLE (widget), FALSE);
  g_return_val_if_fail (event != NULL, FALSE);

  button_toggle = BMP_BUTTON_TOGGLE (widget);

  button_toggle->state = BMP_BUTTON_TOGGLE_STATE_IDLE;

  if (button_toggle->in_button) {
	g_signal_emit(button_toggle, g_signal_lookup("clicked",GTK_TYPE_TOGGLE_BUTTON), 0);
  }
 
  gtk_widget_queue_draw(widget);

  return TRUE;
}

void
bmp_button_toggle_toggled(BmpButtonToggle *button)
{
	g_signal_emit(button, g_signal_lookup("toggled",GTK_TYPE_TOGGLE_BUTTON), 0);
}

static gboolean
bmp_button_toggle_enter_notify(GtkWidget *widget, GdkEventCrossing *event) {

  BmpButtonToggle *button;

  button = BMP_BUTTON_TOGGLE(widget);
  button->in_button = TRUE;

  gtk_widget_queue_draw(widget);

  return TRUE; 
}

static gboolean
bmp_button_toggle_leave_notify(GtkWidget *widget, GdkEventCrossing *event) {

  BmpButtonToggle *button;

  button = BMP_BUTTON_TOGGLE(widget);
  button->in_button = FALSE;

  gtk_widget_queue_draw(widget);

  return TRUE;
}

void
bmp_button_toggle_set_active (BmpButtonToggle *button_toggle,
                              gboolean         is_active)
{
  g_return_if_fail (BMP_IS_BUTTON_TOGGLE (button_toggle));

  is_active = is_active != FALSE;

}

gboolean
bmp_button_toggle_get_active (BmpButtonToggle *button_toggle)
{
  g_return_val_if_fail (BMP_IS_BUTTON_TOGGLE (button_toggle), FALSE);

  return (GTK_TOGGLE_BUTTON(button_toggle)->active) ? TRUE : FALSE;
}

#if 0
static void
bmp_button_toggle_set_property (GObject      *object,
                                guint         prop_id,
                                const GValue *value,
                                GParamSpec   *pspec)
{
  BmpButtonToggle *tb;

  tb = BMP_BUTTON_TOGGLE (object);

  switch (prop_id)
    {
    case PROP_ACTIVE:
      bmp_button_toggle_set_active (tb, g_value_get_boolean (value));
      break;
    default:
      break;
    }
}
#endif

#if 0
static void
bmp_button_toggle_get_property (GObject      *object,
                                guint         prop_id,
                                GValue       *value,
                                GParamSpec   *pspec)
{
  BmpButtonToggle *tb;

  tb = BMP_BUTTON_TOGGLE (object);

  switch (prop_id)
    {
    case PROP_ACTIVE:
      g_value_set_boolean (value, tb->active);
      break;
    default:
      G_OBJECT_WARN_INVALID_PROPERTY_ID (object, prop_id, pspec);
      break;
    }
}
#endif

#if 0
static void
bmp_button_toggle_button_press (GtkWidget      *widget,
		       GdkEventButton *event)
{
  BmpButtonToggle *button;

  g_return_val_if_fail (widget != NULL, FALSE);
  g_return_val_if_fail (BMP_IS_BUTTON_TOGGLE (widget), FALSE);
  g_return_val_if_fail (event != NULL, FALSE);

  button = BMP_BUTTON_TOGGLE (widget);

  button->state = BMP_BUTTON_TOGGLE_STATE_ACTIVE;

  gtk_widget_draw(widget, NULL);
  return FALSE;
}

static void
bmp_button_toggle_button_release (GtkWidget      *widget,
			  GdkEventButton *event)
{
  BmpButtonToggle *button;

  g_return_val_if_fail (widget != NULL, FALSE);
  g_return_val_if_fail (BMP_IS_BUTTON_TOGGLE (widget), FALSE);
  g_return_val_if_fail (event != NULL, FALSE);

  button = BMP_BUTTON_TOGGLE (widget);

  button->state = BMP_BUTTON_TOGGLE_STATE_IDLE;

  if (button->in_button) {
	g_signal_emit(button, button_signals[TOGGLED], 0);
	button->active = button->active ? FALSE : TRUE;
  }
 
  gtk_widget_draw(widget, NULL);
  return FALSE;
}
#endif
