//  BMPx - The Dumb Music Player
//  Copyright (C) 2005-2006 BMPx development team.
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
//
//  --
//
//  The BMPx project hereby grants permission for non GPL-compatible GStreamer
//  plugins to be used and distributed together with GStreamer and BMPx. This
//  permission is above and beyond the permissions granted by the GPL license
//  BMPx is covered by.

#include <config.h>
#include <revision.h>
#include <build.h>

#include "main.hpp"

#ifdef HAVE_GUI
#  include <gtk/gtk.h>
#  include <gtkmm.h>
#  include <gdkmm/wrap_init.h>
#  include <gtkmm/wrap_init.h>
#else
#  include <locale.h>
#endif // HAVE_GUI

#include <glibmm.h>
#include <glib.h>
#include <glib-object.h>
#include <glib/gi18n.h>
#include <glib/gprintf.h>
#include <glib/gstdio.h>

#include <cstdlib>
#include <cstring>

#include <errno.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>

#include "error.hpp"
#include "logger.hpp"

#ifdef HAVE_GUI
#  include "ui.hpp"
#  include "ui_splash.hpp"
#  include "sm.hpp"
#  include "xdb.hpp"
#  ifdef HAVE_STARTUP_NOTIFICATION
#    define SN_API_NOT_YET_FROZEN
#    include <libsn/sn-launchee.h>
#    include <gdk/gdkx.h>
namespace
{
  SnLauncheeContext *sn_context = 0;
  SnDisplay *sn_display = 0;
}
#  endif // HAVE_STARTUP_NOTIFICATION
#endif // HAVE_GUI

#include "play.hpp"
#include "resource_manager.hpp"
#include "scrobbler.hpp"
#include "signals.hpp"
#include "file_monitor.hpp"

#ifdef HAVE_HAL
# include <bmp/hal.h>
#endif

#include <bmp/sanity.h>
#include <bmp/plugin.h>
#include <bmp/vfs.hpp>
#include <bmp/util.h>

#include <bmp/playlist.hpp>
#include <bmp/library.hpp>

#include <mcs/mcs.h>

#ifdef HAVE_GUI
#  include <mcs/gtk-bind.h>
#endif

#include <goa/libgoa.h>
#include <gst/gst.h>

#include "paths.hpp"
#include "loader.hpp"

#include "debug.hpp"
#include "audio.hpp"

#include <dbus/dbus-gtype-specialized.h>

BmpResourceManager *bmp_rm = 0;
BmpPlaylist        *bmp_playlist = 0;
BmpSystemControl   *bmp_system_control = 0;

//C++ objects go here
Bmp::FileMonitor::Monitor   *bmp_file_monitor = 0;
Bmp::Play		    *bmp_play_engine = 0;
Bmp::Logger		    *bmp_logger = 0;
Bmp::Scrobbler		    *bmp_scrobbler = 0;
Bmp::Library::Library	    *library = 0;
Bmp::VFS::VFS		    *vfs = 0;
Mcs::Mcs		    *mcs = 0;

#ifdef HAVE_GUI
Mcs::Bind	   *mcs_bind = 0;
BmpUI              *bmp_ui = 0;
gboolean            use_xdb = FALSE;
gboolean            progress_running = FALSE;
#endif // HAVE_GUI

gchar              *bmp_paths[BMP_N_PATHS] = { 0 };

#ifndef HAVE_GUI
GMainLoop          *mainloop;
#endif // !HAVE_GUI

#ifdef HAVE_HAL
BmpHal             *bmp_hal;
#endif // HAVE_HAL

#ifdef HAVE_SM
namespace { gchar *session_id = 0; }
#endif // HAVE_SM

namespace { gboolean show_version  = FALSE; }

#ifdef HAVE_GUI
gboolean run_headless = FALSE;
gboolean ui_initialized = FALSE;
namespace {  gboolean forced_headless = FALSE; };
#endif // HAVE_GUI

namespace
{

  gboolean detach = FALSE;
  gboolean log_stdout = FALSE;
  gboolean no_resume = FALSE;
  gboolean no_remote = FALSE;

  GOptionEntry bmp_options[] =
    {
      {"version", 'v', 0, G_OPTION_ARG_NONE, &show_version,
       N_("Display version"), 0},
      {"no-log", 0, 0, G_OPTION_ARG_NONE, &log_stdout,
       N_("Disable logfile, log messages to shell"), 0},
#ifdef HAVE_GUI
      {"use-xdb", 0, 0, G_OPTION_ARG_NONE, &use_xdb,
       N_("Use XDB (X Debugger), verbose X events logging"), 0},
      {"no-ui", 0, 0, G_OPTION_ARG_NONE, &run_headless,
       N_("Disable UI"), 0},
      {"no-resume", 0, 0, G_OPTION_ARG_NONE, &no_resume,
       N_("Disable resume playback at startup"), 0},
      {"detach", 0, 0, G_OPTION_ARG_NONE, &detach,
       N_("Detach from the tty"), 0},
#else
      {"detach", 0, 0, G_OPTION_ARG_NONE, &detach,
       N_("Detach from the tty"), 0},
#endif // HAVE_GUI
      {"no-remote", 0, 0, G_OPTION_ARG_NONE, &no_remote,
       N_("Disable DBUS remote interface"), 0},
#ifdef HAVE_SM
      {"sm-client-id", 0, 0, G_OPTION_ARG_STRING, &session_id,
       N_("Specify session management ID"), N_("ID")},
#endif // HAVE_SM
      { 0 }
    };

  static const char *features[] =
    {
#ifdef HAVE_SM
      N_("X11 Session Management"),
#endif // HAVE_SM
      N_("D-BUS support"),
#ifdef HAVE_HAL
      N_("HAL support"),
#endif // USE_HAL
      N_("Audio backend: GStreamer"),
#ifdef USE_AMAZON
      N_("Amazon album cover support"),
#endif // USE_AMAZON
#ifdef HAVE_GUI
      N_("Core GUI (Winamp 2.x skinning engine)"),
#endif // HAVE_GUI
#ifdef HAVE_ALSA
      N_("ALSA Support (Linux)"),
#endif
#ifdef HAVE_SUN
      N_("SUN Audio support")
#endif
    };

  void
  print_version ()
  {
    g_print ("%s %s",
             PACKAGE,
             VERSION);

    if (std::strlen (RV_REVISION))
      g_print (" (%s-R%s)",
               RV_LAST_CHANGED_DATE,
               RV_REVISION);

    g_print (_("\nCopyright (c) 2005-2006 BMP Project <http://www.beep-media-player.org>\n\n"));

    g_print (_("Built the %s on %s with:\n"),
             BUILD_DATE,
             BUILD_ARCH);

    for (unsigned int i = 0; i < G_N_ELEMENTS (features); i++)
      g_print ("* %s\n", _(features[i]));

    g_print ("\n");
  }

  int
  make_user_dir (const gchar *name)
  {
    const mode_t mode755 = S_IRWXU | S_IRGRP | S_IXGRP | S_IROTH | S_IXOTH;
    int mkdir_rv;
    if (g_file_test (name, G_FILE_TEST_IS_DIR)) return 0;
    mkdir_rv = g_mkdir_with_parents (name, mode755);
    if (mkdir_rv)
      {
	int errsv = errno;
	g_critical ("%s: Unable to create %s: %s", G_STRFUNC, name, strerror(errsv));
      }
    return mkdir_rv;
  }

  void
  make_user_dirs ()
  {
    const mode_t mode755 = S_IRWXU | S_IRGRP | S_IXGRP | S_IROTH | S_IXOTH;
    int sanity = 0;

    std::string cache_dir = Glib::build_filename (g_get_user_cache_dir (), BMP_XDG_CACHE_BASEDIR);

    if (!g_file_test (cache_dir.c_str (), G_FILE_TEST_IS_DIR))
      {
	sanity |= g_mkdir_with_parents (cache_dir.c_str (), mode755);
	if (sanity != 0)
	  {
	    int errsv = errno;
	    g_critical ("%s: Unable to create %s: %s", G_STRFUNC, cache_dir.c_str (), strerror(errsv));
	  }
      }

    sanity |= make_user_dir (BMP_PATH_USER_DIR);
    sanity |= make_user_dir (BMP_PATH_LOGS_DIR);
    sanity |= make_user_dir (BMP_PATH_USER_SKIN_DIR);
    sanity |= make_user_dir (BMP_PATH_SKIN_THUMB_DIR);
    sanity |= make_user_dir (BMP_PATH_COVER_THUMB_DIR);
    sanity |= make_user_dir (BMP_PATH_PLAYLISTS);

    if (sanity)
      {
	g_error (_("%s: Unable to create one or more user directories used by BMP (please see log above). Aborting startup; please check permissions in your home directory"), G_STRFUNC);
	exit (EXIT_FAILURE);
      }
  }

  void
  free_paths ()
  {
    for (int i = 0; i < BMP_N_PATHS; i++)
      {
        g_free (bmp_paths[i]);
        bmp_paths[i] = 0;
      }
  }

#define USER_PATH(path)                                 \
  g_build_filename (BMP_PATH_USER_DIR, path, NULL);

#define XDG_CACHE_PATH(path)                                            \
  g_build_filename (g_get_user_cache_dir(), BMP_XDG_CACHE_BASEDIR, path, NULL);

  void
  init_paths ()
  {
    BMP_PATH_USER_DIR = g_build_filename(g_get_home_dir(), BMP_RCPATH, NULL);

    BMP_PATH_LOGS_DIR =
      USER_PATH(BMP_LOGS_BASENAME);
    BMP_PATH_USER_SKIN_DIR =
      USER_PATH(BMP_SKIN_DIR_BASENAME);
    BMP_PATH_PLAYLISTS =
      USER_PATH(BMP_PLAYLISTS_DIR_BASENAME);

    BMP_PATH_SKIN_THUMB_DIR =
      XDG_CACHE_PATH(BMP_SKIN_THUMB_DIR_BASENAME);
    BMP_PATH_COVER_THUMB_DIR =
      XDG_CACHE_PATH(BMP_COVER_THUMB_DIR_BASENAME);

#if 0
    BMP_PATH_CONFIG_FILE =
      USER_PATH(BMP_CONFIG_BASENAME);
    BMP_PATH_ACCEL_FILE =
      USER_PATH(BMP_ACCEL_BASENAME);
#endif

    make_user_dirs ();
  }

  void
  setup_i18n ()
  {
#ifdef HAVE_GUI
    gtk_set_locale ();
#else
    setlocale (LC_ALL, "");
#endif // HAVE_GUI

    bindtextdomain (PACKAGE, LOCALE_DIR);
    bind_textdomain_codeset (PACKAGE, "UTF-8");
    textdomain (PACKAGE);
  }

#ifdef HAVE_STARTUP_NOTIFICATION
  void
  sn_error_trap_push(SnDisplay *display, Display *xdisplay)
  {
    gdk_error_trap_push();
  }

  void
  sn_error_trap_pop(SnDisplay *display, Display *xdisplay)
  {
    gdk_error_trap_pop();
  }

  void
  startup_notification_complete()
  {
    Display *xdisplay;

    xdisplay = GDK_DISPLAY();
    sn_display = sn_display_new(xdisplay,
                                sn_error_trap_push,
                                sn_error_trap_pop);
    sn_context =
      sn_launchee_context_new_from_environment(sn_display,
                                               DefaultScreen(xdisplay));

    if (sn_context != 0)
      {
        sn_launchee_context_complete(sn_context);
        sn_launchee_context_unref(sn_context);

        sn_display_unref(sn_display);
      }
  }
#endif // HAVE_STARTUP_NOTIFICATION

#ifdef HAVE_GUI
  void
  shutdown_func_gtk (gpointer data)
  {
    gtk_main_quit ();
  }

  void
  startup_func_gtk (gpointer data)
  {
    gtk_main ();
  }
#endif

  void
  shutdown_func_glib (gpointer data)
  {
    g_main_loop_quit (static_cast<GMainLoop *> (data));
  }

  void
  startup_func_glib (gpointer data)
  {
    g_main_loop_run (static_cast<GMainLoop *> (data));
  }

  void
  register_keys (void)
  {
    using namespace Mcs;

    mcs->register_domain ("bmp");
    mcs->register_domain ("audio");
    mcs->register_domain ("tracklist");
    mcs->register_domain ("lastfm");

#ifdef HAVE_GUI
    mcs->register_domain ("playlist-window");
    mcs->register_key ("playlist-window", "visible", KeyVariant (bool(false)), KEY_TYPE_BOOL);
    mcs->register_key ("playlist-window", "width", KeyVariant (int(0)), KEY_TYPE_INT); //FIXME:
    mcs->register_key ("playlist-window", "height", KeyVariant (int(0)), KEY_TYPE_INT); //FIXME:
    mcs->register_key ("playlist-window", "pos_x", KeyVariant (int(0)), KEY_TYPE_INT);
    mcs->register_key ("playlist-window", "pos_y", KeyVariant (int(0)), KEY_TYPE_INT);

    mcs->register_domain ("main-window");
    mcs->register_key ("main-window", "width", KeyVariant (int(0)), KEY_TYPE_INT); //FIXME:
    mcs->register_key ("main-window", "height", KeyVariant (int(0)), KEY_TYPE_INT); //FIXME:
    mcs->register_key ("main-window", "pos_x", KeyVariant (int(0)), KEY_TYPE_INT);
    mcs->register_key ("main-window", "pos_y", KeyVariant (int(0)), KEY_TYPE_INT);
#endif // HAVE_GUI

    mcs->register_key ("bmp", "no-ui", KeyVariant (bool(false)), KEY_TYPE_BOOL);
    mcs->register_key ("bmp", "no-remote", KeyVariant (bool(false)), KEY_TYPE_BOOL);

    mcs->register_key ("bmp", "time-remaining", KeyVariant (bool(false)), KEY_TYPE_BOOL);
    mcs->register_key ("bmp", "volume", KeyVariant (int(50)), KEY_TYPE_INT);
    mcs->register_key ("bmp", "ui-esc-trayconify", KeyVariant (bool(false)), KEY_TYPE_BOOL);
    mcs->register_key ("bmp", "library-add-automatically", KeyVariant (bool(false)), KEY_TYPE_BOOL);
    mcs->register_key ("bmp", "library-no-incomplete-add", KeyVariant (bool(true)), KEY_TYPE_BOOL);
    mcs->register_key ("bmp", "keep-above", KeyVariant (bool(false)), KEY_TYPE_BOOL);
    mcs->register_key ("bmp", "file-chooser-close-on-open", KeyVariant (bool(true)), KEY_TYPE_BOOL);
    mcs->register_key ("bmp", "file-chooser-close-on-add", KeyVariant (bool(false)), KEY_TYPE_BOOL);
    mcs->register_key ("bmp", "file-chooser-path", KeyVariant (std::string(g_get_home_dir())), KEY_TYPE_STRING);
    mcs->register_key ("bmp", "follow-current-track", KeyVariant (bool(false)), KEY_TYPE_BOOL);
    mcs->register_key ("bmp", "playlists-path", KeyVariant (std::string(BMP_PATH_PLAYLISTS)), KEY_TYPE_STRING);
    mcs->register_key ("bmp", "resume-on-startup", KeyVariant (bool(false)), KEY_TYPE_BOOL);
    mcs->register_key ("bmp", "resume-on-startup-track", KeyVariant (int(0)), KEY_TYPE_INT);
    mcs->register_key ("bmp", "resume-on-startup-time", KeyVariant (int(0)), KEY_TYPE_INT);
    mcs->register_key ("bmp", "font", KeyVariant (std::string(BMP_DEFAULT_FONT)), KEY_TYPE_STRING);
    mcs->register_key ("bmp", "icon-theme", KeyVariant (std::string("red")), KEY_TYPE_STRING);
    mcs->register_key ("bmp", "skin", KeyVariant (std::string(DATA_DIR G_DIR_SEPARATOR_S BMP_SKIN_DIR_BASENAME G_DIR_SEPARATOR_S BMP_DEFAULT_SKIN)), KEY_TYPE_STRING);
    mcs->register_key ("bmp", "use-custom-cursors", KeyVariant (bool(true)), KEY_TYPE_BOOL);
    mcs->register_key ("bmp", "display-tooltips", KeyVariant (bool(true)), KEY_TYPE_BOOL);
    mcs->register_key ("bmp", "display-tracklist-numbers", KeyVariant (bool(true)), KEY_TYPE_BOOL);
    mcs->register_key ("bmp", "shuffle", KeyVariant (bool(false)), KEY_TYPE_BOOL);
    mcs->register_key ("bmp", "repeat", KeyVariant (bool(false)), KEY_TYPE_BOOL);


    mcs->register_key  ("tracklist","column_0_visible", KeyVariant(bool(true)), KEY_TYPE_BOOL);
    mcs->register_key  ("tracklist","column_1_visible", KeyVariant(bool(true)), KEY_TYPE_BOOL);
    mcs->register_key  ("tracklist","column_2_visible", KeyVariant(bool(true)), KEY_TYPE_BOOL);
    mcs->register_key  ("tracklist","column_3_visible", KeyVariant(bool(true)), KEY_TYPE_BOOL);
    mcs->register_key  ("tracklist","column_4_visible", KeyVariant(bool(false)), KEY_TYPE_BOOL);
    mcs->register_key  ("tracklist","column_5_visible", KeyVariant(bool(false)), KEY_TYPE_BOOL);
    mcs->register_key  ("tracklist","column_6_visible", KeyVariant(bool(true)), KEY_TYPE_BOOL);

    mcs->register_key  ("tracklist","column_0_width", KeyVariant(double(0.2)), KEY_TYPE_FLOAT);
    mcs->register_key  ("tracklist","column_1_width", KeyVariant(double(0.2)), KEY_TYPE_FLOAT);
    mcs->register_key  ("tracklist","column_2_width", KeyVariant(double(0.2)), KEY_TYPE_FLOAT);
    mcs->register_key  ("tracklist","column_3_width", KeyVariant(double(0.2)), KEY_TYPE_FLOAT);
    mcs->register_key  ("tracklist","column_4_width", KeyVariant(double(0.0)), KEY_TYPE_FLOAT);
    mcs->register_key  ("tracklist","column_5_width", KeyVariant(double(0.0)), KEY_TYPE_FLOAT);
    mcs->register_key  ("tracklist","column_6_width", KeyVariant(double(0.2)), KEY_TYPE_FLOAT);

    mcs->register_key ("audio", "sink", KeyVariant(std::string(DEFAULT_SINK)), KEY_TYPE_STRING);

#ifdef HAVE_ALSA
    mcs->register_key ("audio", "alsa-buffer-time", KeyVariant(int(200000)), KEY_TYPE_INT);
    mcs->register_key ("audio", "device-alsa", KeyVariant(std::string(DEFAULT_DEVICE_ALSA)), KEY_TYPE_STRING);
#endif

#ifdef HAVE_SUN
    mcs->register_key ("audio", "sun-buffer-time",  KeyVariant(int(200000)), KEY_TYPE_INT);
    mcs->register_key ("audio", "device-sun", KeyVariant(std::string(DEFAULT_DEVICE_SUN)), KEY_TYPE_STRING);
#endif

    mcs->register_key ("audio", "oss-buffer-time",  KeyVariant(int(200000)), KEY_TYPE_INT);
    mcs->register_key ("audio", "device-oss", KeyVariant(std::string(DEFAULT_DEVICE_OSS)), KEY_TYPE_STRING);

    mcs->register_key ("audio", "esd-buffer-time",  KeyVariant(int(200000)), KEY_TYPE_INT);
    mcs->register_key ("audio", "device-esd", KeyVariant(std::string(DEFAULT_DEVICE_ESD)), KEY_TYPE_STRING);

    mcs->register_key ("lastfm", "general-enable", KeyVariant (bool(false)), KEY_TYPE_BOOL);
    mcs->register_key ("lastfm", "enable", KeyVariant (bool(false)), KEY_TYPE_BOOL);
    mcs->register_key ("lastfm", "username", KeyVariant (std::string("")), KEY_TYPE_STRING);
    mcs->register_key ("lastfm", "password", KeyVariant (std::string("")), KEY_TYPE_STRING);

  }

} // anonymous namespace

int
main (int    argc,
      char** argv)
{
  GError              *error = 0;
  gchar               *sanity_error = 0;
  GOptionContext      *ocbmp;

  g_type_init ();

  Glib::thread_init (0);
  Glib::init ();

  setup_i18n ();
  Bmp::debug_init ();

  sanity_error = sanity_check_libs ();
  if (sanity_error)
    {
      g_printerr ("%s\n", sanity_error);
      g_free (sanity_error);

      std::exit (EXIT_FAILURE);
    }

  /* Attempt to run X11-less if we are --daemon or --no-ui */
  ocbmp = g_option_context_new (_(" - Run BMPx"));
  g_option_context_add_main_entries (ocbmp, bmp_options, PACKAGE);

#ifdef HAVE_GUI
  g_option_context_add_group (ocbmp, gtk_get_option_group (FALSE));
#endif // HAVE_GUI

  g_option_context_add_group (ocbmp, gst_init_get_option_group ());

  if (!g_option_context_parse (ocbmp, &argc, &argv, &error))
    {
      g_printerr (_("Invalid argument: %s\n"), error->message);
      g_error_free (error);
      std::exit (EXIT_FAILURE);
    }

  if (detach)
    {
      if (!bmp_detach ())
        g_warning (_("Unable to detach, proceeding with normal startup."));
    }

  init_paths ();

  if ((!run_headless) && (!g_getenv("DISPLAY")))
    {
      run_headless = TRUE;
      forced_headless = TRUE;
    }

  if (show_version)
    {
      print_version ();
      goto main_early_exit;
    }

  if (!log_stdout)
    {
      bmp_logger = new Bmp::Logger;
    }

#ifdef HAVE_GUI
  if (!run_headless)
  {
    gtk_init (&argc, &argv);
    Gdk::wrap_init();
    Gtk::wrap_init();
  }
#endif

  vfs = new Bmp::VFS::VFS;
  bmp_rm = bmp_resource_manager_new ();

  try
  {
      std::string config_file_path = Glib::build_filename (BMP_PATH_USER_DIR , "config.xml");
      mcs = new Mcs::Mcs (config_file_path, "bmp-2", 0.14);
      register_keys ();
      mcs->load (Mcs::Mcs::VERSION_IGNORE);
  }
  catch (...)
  {}

#ifdef HAVE_GUI
  mcs_bind = new Mcs::Bind (mcs);
#endif

  if (no_resume)
    {
      mcs->key_set<bool>( "bmp","resume-on-startup", false);
    }

  /* Initialize Plugins */
  Bmp::Plugins::init ();

  progress_running = TRUE;

  /* Init signal handlers */
  Signals::handlers_init ();

  /* FIXME: gtk_init_with_args() (above) will remove all recognized
     arguments, so the session manager will run BMPx with incomplete
     options when it restarts. */

#ifdef HAVE_GUI
  if (mcs->key_get<bool>("bmp", "no-ui")) run_headless = TRUE;

  Bmp::SplashWindow *splash_window;

  if (!run_headless)
    {
      Session::start (argc, argv, session_id);

#ifdef HAVE_STARTUP_NOTIFICATION
      gtk_window_set_auto_startup_notification (FALSE);
#endif // HAVE_STARTUP_NOTIFICATION

      splash_window = new Bmp::SplashWindow;
      splash_window->show ();

      while (gtk_events_pending ())
        gtk_main_iteration ();
    }
  else
    {
      splash_window = 0;
    }
#endif // HAVE_GUI

#ifdef HAVE_GUI
  bmp_file_monitor = new Bmp::FileMonitor::Monitor;
#endif // HAVE_GUI

  if (mcs->key_get<bool>("bmp", "no-remote"))
    {
      no_remote = TRUE;
    }

  bmp_playlist = bmp_playlist_new ();

  if (!no_remote)
    {
      dbus_g_type_specialized_init ();
    }

#if 0
  Bmp::Audio::ProcessorURISink processor;  
  Bmp::Audio::Element::Element sink ("alsasink");
  processor.set_uri ("file:///tmp/test.mp3", sink); 
  processor.run ();
  gtk_main ();
  exit (0);
#endif

  bmp_system_control = bmp_system_control_new (no_remote);

  if (bmp_system_control)
    {
      bmp_play_engine = new Bmp::Play;
      bmp_system_control_init_finalize (bmp_system_control);

#ifdef HAVE_HAL
      bmp_hal = bmp_hal_new ();
#endif // HAVE_HAL

      library = new Bmp::Library::Library;
      bmp_playlist_load_playlist (bmp_playlist);

      bmp_scrobbler = new Bmp::Scrobbler;

#ifdef HAVE_GUI
      if (!run_headless)
        {
          bmp_system_control_ui_start (bmp_system_control, 0, 0);
        }
      else
        {
          if (!forced_headless)
            {
              g_log (G_LOG_DOMAIN, G_LOG_LEVEL_INFO, "Not starting UI on request.");
            }
          else
            {
              g_printerr (_("No X11 server found (DISPLAY environment variable not set): Not starting UI\n"));
            }
        }
#endif // HAVE_GUI

      //Register objects for disposal to BmpSystemControl
      bmp_system_control_register_dispose_object (bmp_system_control, G_OBJECT(bmp_playlist));

#ifdef HAVE_HAL
      bmp_system_control_register_dispose_object (bmp_system_control, G_OBJECT(bmp_hal));
#endif // HAVE_HAL

      //bmp_system_control_register_dispose_object (bmp_system_control, G_OBJECT(bmp_system_control));

#ifdef HAVE_GUI
      if (!run_headless)
        {
#ifdef HAVE_STARTUP_NOTIFICATION
          startup_notification_complete ();
#endif // HAVE_STARTUP_NOTIFICATION

          delete splash_window;
        }

      if (!no_remote)
        {
          bmp_system_control_initialize_dbus_connection (bmp_system_control);
        }

      //Initialize with GTK+2
      bmp_system_control_register_startup_func  (bmp_system_control,
                                                 (SystemStartupFunc)startup_func_gtk,
                                                 0);

      bmp_system_control_register_shutdown_func (bmp_system_control,
                                                 (SystemShutdownFunc)shutdown_func_gtk,
                                                 0);

#else // !HAVE_GUI

      //Initialize with GLib only
      g_log (G_LOG_DOMAIN, G_LOG_LEVEL_INFO, "Starting mainloop.");
      mainloop = g_main_loop_new (0, FALSE);

      bmp_system_control_register_startup_func  (bmp_system_control,
                                                 (SystemStartupFunc)startup_func_glib,
                                                 mainloop);

      bmp_system_control_register_shutdown_func (bmp_system_control,
                                                 (SystemShutdownFunc)shutdown_func_glib,
                                                 mainloop);

#endif // HAVE_GUI

      progress_running = FALSE;
      bmp_system_control_application_run (bmp_system_control);
    }
  else
    {
      g_log (G_LOG_DOMAIN, G_LOG_LEVEL_INFO, "BmpSystemControl not present, cannot proceed with startup sequence.");
    }

#ifdef HAVE_GUI
  if (!run_headless)
    {
      Session::end ();
    }
#endif // HAVE_GUI

  /* Shutdown Plugins */
  Bmp::Plugins::shutdown ();

  delete bmp_file_monitor;
  delete bmp_play_engine;
  delete bmp_scrobbler;
  delete bmp_logger;
  delete mcs;
#ifdef HAVE_GUI
  delete mcs_bind;
#endif

  g_object_unref (bmp_system_control);

 main_early_exit:

  free_paths ();

  std::exit (EXIT_SUCCESS);
}
