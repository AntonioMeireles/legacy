/*  BMPx - The Dumb Music Player
 *  Copyright (C) 2005 BMPx development team.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 *  $Id$
 *
 * The BMPx project hereby grant permission for non-gpl compatible GStreamer
 * plugins to be used and distributed together with GStreamer and BMPx. This
 * permission are above and beyond the permissions granted by the GPL license
 * BMPx is covered by.
 */

#include <config.h>
#include <string.h>

#include <glibmm.h>
#include <glib/gi18n.h>
#include <dbus/dbus.h>
#include <dbus/dbus-glib.h>

#include <bmp/uri++.hpp>
#include <bmp/util.h>
#include <bmp/dbus.h>

#include <goa/libgoa.h>

#include <libhrel/types.h>
#include <libhrel/tuple.h>
#include <libhrel/relation.h>
#include <libhrel/relation_base.h>

#ifdef HAVE_GUI
#  include <gtk/gtk.h>
#  include <chroma/chroma-list.h>
#  include <chroma/chroma-list-selection.h>
#  include <ui.hpp>
#  include <ui_util.hpp>
#endif

#include <main.hpp>
#include <loader.hpp>
#include <service_core.hpp>

namespace Bmp {

struct CServiceCoreClass
{
    GObjectClass parent;
};

static GType	c_service_core_type;
static void     c_service_core_init (CServiceCoreClass *klass);
static void*	c_service_core_parent_class = NULL;
static void     c_service_core_intern_init (gpointer klass)
{
  c_service_core_parent_class = g_type_class_peek_parent (klass);
  c_service_core_init ((CServiceCoreClass*) klass);
}

static const GTypeInfo g_define_type_info = { 

        sizeof (CServiceCoreClass), 
        (GBaseInitFunc)		NULL, 
        (GBaseFinalizeFunc)	NULL, 
        (GClassInitFunc)	c_service_core_intern_init, 
        (GClassFinalizeFunc)	NULL, 
        NULL,  
        sizeof (CServiceCore), 
        0,      
        (GInstanceInitFunc)	NULL, 
}; 

static GObject*
c_service_core_constructor (GType                  type,
			      guint                  n_construct_properties,
			      GObjectConstructParam *construct_properties)
{
	return  reinterpret_cast<GObjectClass*>(c_service_core_parent_class)->constructor (type,
											 n_construct_properties,
											 construct_properties);
}

static void
c_service_core_init (CServiceCoreClass *klass)
{
        GObjectClass *gobject_class = reinterpret_cast<GObjectClass*>(klass);
        gobject_class->constructor  = c_service_core_constructor;
}

#define MPRIS_IDENTITY "BMP2"

gboolean
c_service_core_identity (CServiceCore     *self,
			   gchar	     **identity,
			   GError	     **error)
{
    *identity = g_strdup (MPRIS_IDENTITY);
    return TRUE;
}

#if 0
gboolean
c_service_core_dummy      (CServiceCore *self, GError **error)
{
    self->control->send_message (Bmp::ServiceCore::PREV);
    return TRUE;
}
#endif

#include "service_core_glue.h"
static void initialize_dbus (CServiceCore *control)
{
    DBusGConnection *bus;
    DBusGProxy	    *bus_proxy;
    gboolean	     connected = FALSE;
    guint	     request_name_result;
    GError	    *error = NULL;

    bus = dbus_g_bus_get (DBUS_BUS_SESSION, &error);
    if (!bus)
        {
            g_message ("running: %s (DBUS Error: '%s')", G_OBJECT_TYPE_NAME(control), error->message);
            g_error_free (error);
            return;
        }

    bus_proxy = dbus_g_proxy_new_for_name (bus,
					   "org.freedesktop.DBus",
					   "/org/freedesktop/DBus",
					   "org.freedesktop.DBus");

    if (!dbus_g_proxy_call (bus_proxy, "RequestName", &error,
                            G_TYPE_STRING, BMP_DBUS_INTERFACE, 
                            G_TYPE_UINT, 0,
                            G_TYPE_INVALID,
                            G_TYPE_UINT, &request_name_result,
                            G_TYPE_INVALID))
        {
            g_error ("%s: Failed RequestName request: %s", G_STRFUNC, error->message);
            g_error_free (error);
            error = NULL;
        }

    switch (request_name_result)
        {
        case DBUS_REQUEST_NAME_REPLY_PRIMARY_OWNER:
                {
                    dbus_g_connection_register_g_object (bus, BMP_DBUS_PATH, G_OBJECT(control));
                    connected = TRUE;
                }
            break;

        case DBUS_REQUEST_NAME_REPLY_EXISTS:
                {
                    connected = FALSE;
                }
            break;
        }

    if (connected)
        {
            g_message ("%s (DBus:%s)", G_OBJECT_TYPE_NAME(control), BMP_DBUS_INTERFACE);
        }
}

CServiceCore*
c_service_core_new (Bmp::ServiceCore &control)
{
    CServiceCore *self;
  
    dbus_g_object_type_install_info (c_service_core_type, &dbus_glib_c_service_core_object_info); 
    self = G_TYPE_CHECK_INSTANCE_CAST(g_object_new (c_service_core_type, NULL), c_service_core_type, CServiceCore);
    self->control = &control;

    //Set up DBus connection
    initialize_dbus (self); 
    return self;
}

//Bmp::ServiceCore class

    //ctor
    ServiceCore::ServiceCore () 
		: Glib::ObjectBase (typeid(ServiceCore)),
    {
	c_service_core_type = g_type_register_static (G_TYPE_OBJECT, "CServiceCore", &g_define_type_info, GTypeFlags(0)); 
	c_service_core = reinterpret_cast<GObject*>(c_service_core_new (*this));
    
	queue	      = g_async_queue_new ();
    }

    //dtor
    ServiceCore::~ServiceCore ()
    {
	g_object_unref (c_service_core);
	g_async_queue_unref (queue);
    }

    bool
    ServiceCore::process_messages ()
    {
      Bmp::ServiceCore::Message *message;

      message = reinterpret_cast<Bmp::ServiceCore::Message *> (g_async_queue_try_pop (queue));
      if (!message) return false;
    
      switch (message->get_type())
        {
	  default:; // shuts GCC up about unhandled enum values
	}

      delete message;
      return (g_async_queue_length (queue) == 0);
    }

    void
    ServiceCore::send_message (MessageType type,
				 boost::any data)
    {
	Message *message;
	message = new Message (type, data); 

	g_async_queue_push (queue, message);
	if (!queue_conn.connected()) queue_conn = 
	      Glib::signal_idle().connect ( sigc::mem_fun (this, &Bmp::ServiceCore::process_messages) );  
    }
    void
    ServiceCore::send_message (MessageType type)
    {
	Message *message;
	message = new Message (type); 

	g_async_queue_push (queue, message);
	if (!queue_conn.connected()) queue_conn =
	      Glib::signal_idle().connect ( sigc::mem_fun (this, &Bmp::ServiceCore::process_messages) );  
    }

    //Bmp::ServiceCore::Message
    ServiceCore::Message::Message (MessageType type, boost::any data) : has_data (true)
    {
	this->type = type;
	this->data = data;
    }
    ServiceCore::Message::Message (MessageType type) : has_data (false)
    {
	this->type = type;
    }

    ServiceCore::Message::~Message ()
    {
    }

    boost::any 
    ServiceCore::Message::get_data ()
    {
	return data;	
    }

    Bmp::ServiceCore::MessageType 
    ServiceCore::Message::get_type ()
    {
	return type;	
    }
};
