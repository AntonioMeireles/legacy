#ifndef BMP_UI_PLAYLIST_HPP
#define BMP_UI_PLAYLIST_HPP

#include <glib-object.h>

#define BMP_TYPE_WINDOW_PLAYLIST		  (bmp_window_playlist_get_type ())
#define BMP_WINDOW_PLAYLIST(obj)		  (G_TYPE_CHECK_INSTANCE_CAST ((obj), BMP_TYPE_WINDOW_PLAYLIST, BmpWindowPlaylist))
#define BMP_WINDOW_PLAYLIST_CLASS(klass)	  (G_TYPE_CHECK_CLASS_CAST ((klass), BMP_TYPE_WINDOW_PLAYLIST, BmpWindowPlaylistClass))
#define BMP_IS_WINDOW_PLAYLIST(obj)	  (GTK_CHECK_TYPE ((obj), BMP_TYPE_WINDOW_PLAYLIST))
#define BMP_IS_WINDOW_PLAYLIST_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass), BMP_TYPE_WINDOW_PLAYLIST))
#define BMP_WINDOW_PLAYLIST_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj), BMP_TYPE_WINDOW_PLAYLIST, BmpWindowPlaylistClass))

typedef struct _BmpWindowPlaylist BmpWindowPlaylist;
typedef struct _BmpWindowPlaylistClass BmpWindowPlaylistClass;
typedef struct _BmpWindowPlaylistPrivate BmpWindowPlaylistPrivate;

struct _BmpWindowPlaylist {
	GObject parent;

        BmpWindowPlaylistPrivate *priv;

	GtkWidget *window;
};

struct _BmpWindowPlaylistClass {
	GObjectClass parent;
};

GType bmp_window_playlist_get_type (void);

BmpWindowPlaylist*
bmp_window_playlist_new (void);

void
bmp_window_playlist_configure		  (BmpWindowPlaylist *window_playlist);

void
bmp_window_playlist_set_cursors		  (BmpWindowPlaylist *window_playlist);

void
bmp_window_playlist_start_shade		  (BmpWindowPlaylist *window_playlist);

void
bmp_window_playlist_column_set_active	  (BmpWindowPlaylist *window_playlist, gint column, gboolean active);

void
bmp_window_playlist_show_trackinfo	  (BmpWindowPlaylist *window_playlist);

#endif // BMP_UI_PLAYLIST_HPP
