/*  BMPx - The Dumb Music Player
 *  Copyright (C) 2005 BMPx development team.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 *  $Id$
 *
 * The BMPx project hereby grant permission for non-gpl compatible GStreamer
 * plugins to be used and distributed together with GStreamer and BMPx. This
 * permission are above and beyond the permissions granted by the GPL license
 * BMPx is covered by.
 *
 */

#ifndef BMP_LOADER_HPP
#define BMP_LOADER_HPP

#include <string>
#include <list>
#include <bmp/plugin.h>

namespace Bmp
{
  namespace Plugins
  {
    enum Type
    {
      TYPE_FLOW,
      N_TYPES
    };

    extern GHashTable *table[N_TYPES];

    void
    init ();
    void
    shutdown ();

    std::string
    type_get_name (Type type);

    std::string
    type_get_desc (Type type);

  } // Plugins
} // Bmp


#endif // BMP_LOADER_HPP
