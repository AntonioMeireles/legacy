/*  BMPx - The Dumb Music Player
 *  Copyright (C) 2005 BMPx development team.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 *  $Id$
 *
 * The BMPx project hereby grant permission for non-gpl compatible GStreamer
 * plugins to be used and distributed together with GStreamer and BMPx. This
 * permission are above and beyond the permissions granted by the GPL license
 * BMPx is covered by.
 */


#include <config.h>
#include <stdlib.h>

#include <vector>
#include <boost/algorithm/string.hpp>

#include <glib.h>
#include <glib/gi18n.h>
#include <gmodule.h>
#include <glibmm.h>

#include <bmp/util.h>
#include <bmp/plugin.h>
#include <bmp/plugin_interfaces.h>

#include "loader.hpp"

enum
{
  LIB_BASENAME,
  LIB_PLUGNAME,
  LIB_SUFFIX
};

namespace
{
  bool
  is_module (const std::string &basename)
  {
    return str_has_suffix_nocase (basename.c_str (), G_MODULE_SUFFIX);
  }

  bool
  load_plugin (const std::string &dir_name,
               const std::string &basename,
               const std::string &type_name,
               int                type)
  {
    using boost::algorithm::split;
    using boost::algorithm::is_any_of;

    if (!is_module (basename))
      return false;

    g_message (G_STRLOC ": %s plugin: %s", type_name.c_str (), basename.c_str ());

    std::vector<std::string> subs;
    split (subs, basename, is_any_of ("_."));

    std::string dir   = Glib::build_filename (PLUGIN_DIR, type_name);
    std::string name  = type_name + "_" + subs[LIB_PLUGNAME];
    std::string mpath = Glib::Module::build_path (dir, name);

    BmpPlugin *plugin = bmp_plugin_new (mpath.c_str ());

    if (!plugin)
      return false;

    g_type_module_use (G_TYPE_MODULE (plugin));

    if (!bmp_plugin_valid (plugin))
      return false;

    GObject *plugin_instance = bmp_plugin_create_instance (plugin);
    g_hash_table_insert (Bmp::Plugins::table[type], g_strdup (subs[LIB_PLUGNAME].c_str ()), plugin_instance);

    return true;
  }

} // anonymous

namespace Bmp
{
  namespace Plugins
  {
    const std::string type_names[] = {
      "flow",
    };

    const std::string type_descs[] = {
      N_("Flow"),
    };

    GHashTable *table[N_TYPES];

    std::string
    type_get_name (Type type)
    {
      return type_names[type];
    }

    std::string
    type_get_desc (Type type)
    {
      return _(type_descs[type].c_str ());
    }

    void
    init ()
    {
      gint n;

      for (n = 0; n < N_TYPES; n++)
        {
          // FIXME: leak...
          table[n] = g_hash_table_new (g_str_hash, g_str_equal);
        }

      for (n = 0; n < N_TYPES; n++)
        {
          std::string dir_name = Glib::build_filename (PLUGIN_DIR, type_names[n]);

          Glib::Dir dir (dir_name);
          for (Glib::Dir::const_iterator iter = dir.begin (), end = dir.end ();
               iter != end;
               ++iter)
          {
              load_plugin (dir_name, *iter, type_names[n], n);
          }
        }
    }

    void
    shutdown ()
    {
#if 0
      GError *error = 0;

      for (unsigned int n = 0; n < N_TYPES; n++)
      {}
#endif
    }
  } // Plugins
} // Bmp
