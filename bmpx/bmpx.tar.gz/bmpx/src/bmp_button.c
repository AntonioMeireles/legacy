/*  BMPx - The Dumb Music Player
 *  Copyright (C) 2005 BMPx development team.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 *  $Id$
 *
 * The BMPx project hereby grant permission for non-gpl compatible GStreamer
 * plugins to be used and distributed together with GStreamer and BMPx. This
 * permission are above and beyond the permissions granted by the GPL license
 * BMPx is covered by.
 */

#include <gtk/gtkmain.h>
#include <glib-object.h>
#include <glib/gmacros.h>
#include <gtk/gtkmarshal.h>

#include <bmp/widgets/bmp_button.h>

/* Forward declarations */

static void bmp_button_class_init               (BmpButtonClass    *klass);
static void bmp_button_init                    (BmpButton         *button);
static void bmp_button_destroy                  (GtkObject        *object);
static void bmp_button_realize                  (GtkWidget        *widget);
static gint bmp_button_expose                   (GtkWidget        *widget,
						GdkEventExpose   *event);
static gint bmp_button_button_press             (GtkWidget        *widget,
						GdkEventButton   *event);
static gint bmp_button_button_release           (GtkWidget        *widget,
						GdkEventButton   *event);
static gint bmp_button_enter_notify		(GtkWidget	 *widget,
						GdkEventCrossing *event);
static gint bmp_button_leave_notify		(GtkWidget	 *widget,
						GdkEventCrossing *event);
static void bmp_button_size_allocate (GtkWidget           *widget,
					    GtkAllocation       *allocation);
static void bmp_button_send_configure (BmpButton     *button);

/* Local data */

static GtkButtonClass *parent_class = NULL;

G_DEFINE_TYPE (BmpButton, bmp_button, GTK_TYPE_BUTTON)

static void
bmp_button_class_init (BmpButtonClass *class)
{
  GtkObjectClass *object_class;
  GtkWidgetClass *widget_class;

  object_class = (GtkObjectClass*) class;
  widget_class = (GtkWidgetClass*) class;

  parent_class = gtk_type_class (gtk_widget_get_type ());

  object_class->destroy = bmp_button_destroy;

  widget_class->realize = bmp_button_realize;
  widget_class->expose_event = bmp_button_expose;
  widget_class->enter_notify_event = bmp_button_enter_notify;
  widget_class->leave_notify_event = bmp_button_leave_notify;
  widget_class->button_press_event = bmp_button_button_press;
  widget_class->button_release_event = bmp_button_button_release;
  widget_class->size_allocate = bmp_button_size_allocate;

}

static void
bmp_button_init (BmpButton *button)
{
        GTK_WIDGET_UNSET_FLAGS (button, GTK_NO_WINDOW);

	button->width = 0;
	button->height = 0;
	button->pb_normal = NULL;
	button->pb_pressed = NULL;
	button->constructed = 0;
	button->in_button = 0;
	button->state = BMP_BUTTON_STATE_IDLE;
}

BmpButton*
bmp_button_new (gboolean passtrough)
{
  BmpButton *button;

  button = gtk_type_new (bmp_button_get_type ());
  button->passtrough = passtrough;

  return button;
}

GtkWidget*
bmp_button_new_with_pixbufs(GdkPixbuf *normal, GdkPixbuf *pressed)
{
  BmpButton *button;
  button = gtk_type_new (bmp_button_get_type ());

  button->pb_normal = normal;
  g_object_ref(normal);

  button->pb_pressed = pressed;
  g_object_ref(pressed);

  button->gc = gdk_gc_new(GTK_WIDGET(button)->window);

  return GTK_WIDGET (button);
}

void
bmp_button_set_pixbufs(BmpButton *button, GdkPixbuf *normal, GdkPixbuf *pressed)
{

  button->pb_normal = normal;
  g_object_ref(normal);

  button->pb_pressed = pressed;
  g_object_ref(pressed);
}

void
bmp_button_set_from_table (BmpButton *arg_button, const GdkPixbuf *src, 
                guint            width, 
                guint            height,
                guint            x_normal,
                guint            y_normal,
                guint            x_pressed,
                guint            y_pressed)
{
  BmpButton *button;
 
  g_return_if_fail (GDK_IS_PIXBUF (src));
 
  button = (BmpButton*) arg_button;

  /* Check if our nominal values apply to real life ;) */

  if ( (x_normal+width) > gdk_pixbuf_get_width(src) ) {
	width = gdk_pixbuf_get_width(src) - x_normal; 
  }


  if (button->pb_normal) g_object_unref (button->pb_normal);
  button->pb_normal = gdk_pixbuf_new (gdk_pixbuf_get_colorspace(src),
                                            gdk_pixbuf_get_has_alpha(src),
                                            gdk_pixbuf_get_bits_per_sample(src),
                                            width, height);
 
  if (button->pb_pressed) g_object_unref (button->pb_pressed);
  button->pb_pressed = gdk_pixbuf_new (gdk_pixbuf_get_colorspace(src),
                                            gdk_pixbuf_get_has_alpha(src),
                                            gdk_pixbuf_get_bits_per_sample(src),
                                            width, height);
 
  gdk_pixbuf_copy_area (src, x_normal, y_normal, width, height, 
                        button->pb_normal, 0, 0);
 
  gdk_pixbuf_copy_area (src, x_pressed, y_pressed, width, height, 
                        button->pb_pressed, 0, 0);
 
  gtk_widget_set_size_request(GTK_WIDGET (button), width, height);
  button->gc = gdk_gc_new(GTK_WIDGET(button)->window);
}


static void
bmp_button_destroy (GtkObject *object)
{
  BmpButton *button;

  g_return_if_fail (object != NULL);
  g_return_if_fail (BMP_IS_BUTTON (object));

  button = BMP_BUTTON(object);

  if (GTK_OBJECT_CLASS (parent_class)->destroy)
    (* GTK_OBJECT_CLASS (parent_class)->destroy) (object);
}

static void
bmp_button_realize (GtkWidget *widget)
{
  BmpButton *button;
  GdkWindowAttr attributes;
  gint attributes_mask;

  g_return_if_fail (widget != NULL);
  g_return_if_fail (BMP_IS_BUTTON (widget));

  GTK_WIDGET_SET_FLAGS (widget, GTK_REALIZED);
  button = BMP_BUTTON (widget);

  attributes.x = widget->allocation.x;
  attributes.y = widget->allocation.y;
  attributes.width = widget->allocation.width;
  attributes.height = widget->allocation.height;
  attributes.wclass = GDK_INPUT_OUTPUT;
  attributes.window_type = GDK_WINDOW_CHILD;
  attributes.event_mask = gtk_widget_get_events (widget) | 
    GDK_EXPOSURE_MASK | GDK_BUTTON_PRESS_MASK | 
    GDK_BUTTON_RELEASE_MASK | GDK_LEAVE_NOTIFY_MASK | GDK_ENTER_NOTIFY_MASK;
  attributes.visual = gtk_widget_get_visual (widget);
  attributes.colormap = gtk_widget_get_colormap (widget);

  attributes_mask = GDK_WA_X | GDK_WA_Y | GDK_WA_VISUAL | GDK_WA_COLORMAP;
  widget->window = gdk_window_new (widget->parent->window, &attributes, attributes_mask);

  widget->style = gtk_style_attach (widget->style, widget->window);

  gdk_window_set_user_data (widget->window, widget);

  gtk_style_set_background (widget->style, widget->window, GTK_STATE_ACTIVE);
  bmp_button_send_configure (BMP_BUTTON(widget));
}

static gint
bmp_button_expose (GtkWidget      *widget,
		 GdkEventExpose *event)
{
  BmpButton *button;
  GdkPixbuf *buf;
 
  g_return_val_if_fail (widget != NULL, FALSE);
  g_return_val_if_fail (BMP_IS_BUTTON (widget), FALSE);
  g_return_val_if_fail (event != NULL, FALSE);

  if (event->count > 0)
    return FALSE;
  
  button = BMP_BUTTON (widget);
  
  buf = button->pb_normal; 
 
  if ( (button->state == BMP_BUTTON_STATE_ACTIVE) 
			&&
	        (button->in_button) ) {
	buf = button->pb_pressed;
  };	

	gdk_draw_pixbuf(GTK_WIDGET(button)->window,
			button->gc,
			buf,
			0,
			0,
			0,
			0,
			-1,
			-1,
			GDK_RGB_DITHER_NONE,
			0,
			0);
			
  return FALSE;
}

static gboolean
bmp_button_button_press (GtkWidget      *widget,
		       GdkEventButton *event)
{
  BmpButton *button;

  g_return_val_if_fail (widget != NULL, FALSE);
  g_return_val_if_fail (BMP_IS_BUTTON (widget), FALSE);
  g_return_val_if_fail (event != NULL, FALSE);

  if (event->button != 1) return TRUE;

  button = BMP_BUTTON (widget);

  button->state = BMP_BUTTON_STATE_ACTIVE;

  gtk_widget_queue_draw(widget);

  return button->passtrough ? FALSE : TRUE; 
}

static gboolean
bmp_button_button_release (GtkWidget      *widget,
			  GdkEventButton *event)
{
  BmpButton *button;

  g_return_val_if_fail (widget != NULL, FALSE);
  g_return_val_if_fail (BMP_IS_BUTTON (widget), FALSE);
  g_return_val_if_fail (event != NULL, FALSE);

  button = BMP_BUTTON (widget);

  button->state = BMP_BUTTON_STATE_IDLE;

  if (button->in_button) {
	g_signal_emit(button, g_signal_lookup("clicked",GTK_TYPE_BUTTON), 0);
  }
 
  gtk_widget_queue_draw(widget);

  return button->passtrough ? FALSE : TRUE;
}

static gboolean
bmp_button_enter_notify(GtkWidget *widget, GdkEventCrossing *event) {

  BmpButton *button;

  button = BMP_BUTTON(widget);

  button->in_button = TRUE;

  gtk_widget_queue_draw(widget);

  return TRUE;
}

static gboolean
bmp_button_leave_notify(GtkWidget *widget, GdkEventCrossing *event) {

  BmpButton *button;

  button = BMP_BUTTON(widget);

  button->in_button = FALSE;

  gtk_widget_queue_draw(widget);

  return TRUE;
}

static void
bmp_button_send_configure (BmpButton *button)
{
  GtkWidget *widget;
  GdkEvent *event = gdk_event_new (GDK_CONFIGURE);

  widget = GTK_WIDGET (button);

  event->configure.window = g_object_ref (widget->window);
  event->configure.send_event = TRUE;
  event->configure.x = widget->allocation.x;
  event->configure.y = widget->allocation.y;
  event->configure.width = widget->allocation.width;
  event->configure.height = widget->allocation.height;
  
  gtk_widget_event (widget, event);
  gdk_event_free (event);
}

static void
bmp_button_size_allocate (GtkWidget     *widget,
				GtkAllocation *allocation)
{
  g_return_if_fail (BMP_IS_BUTTON (widget));
  g_return_if_fail (allocation != NULL);

  widget->allocation = *allocation;

  if (GTK_WIDGET_REALIZED (widget))
    {
      gdk_window_move_resize (widget->window,
			      allocation->x, allocation->y,
			      allocation->width, allocation->height);

      bmp_button_send_configure (BMP_BUTTON (widget));
    }
}
