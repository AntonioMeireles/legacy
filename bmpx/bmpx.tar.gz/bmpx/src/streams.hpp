//  BMPx - The Dumb Music Player
//  Copyright (C) 2005 BMPx development team.
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
//
//  --
//
//  The BMPx project hereby grants permission for non-GPL compatible GStreamer
//  plugins to be used and distributed together with GStreamer and BMPx. This
//  permission is above and beyond the permissions granted by the GPL license
//  BMPx is covered by.

#ifndef STREAM_LISTER_HPP
#define STREAM_LISTER_HPP

#include <gtkmm.h>
#include <libglademm.h>
#include "bookmarks.hpp"

namespace Bmp {

  namespace Streams
  {

      class Dialog
	  : public Gtk::Window
      {

	public:

	  Dialog (BaseObjectType                       *cobject,
		        const Glib::RefPtr<Gnome::Glade::Xml> &xml);

	  static Dialog*
	  create ();

	private:

#ifndef DOXYGEN_SHOULD_SKIP_THIS
	  class ColumnsShoutcast
	    : public Gtk::TreeModel::ColumnRecord
	  {
	    public:
	      Gtk::TreeModelColumn<Glib::ustring> name;
	      Gtk::TreeModelColumn<unsigned int>  bitrate;
	      Gtk::TreeModelColumn<Glib::ustring> genre;
	      Gtk::TreeModelColumn<Glib::ustring> uri;
	      Gtk::TreeModelColumn<Glib::ustring> nowplaying;

	      ColumnsShoutcast()
	      {
		add (name);
		add (bitrate);
		add (genre);
		add (uri);
		add (nowplaying);
	      }
	  };
	  ColumnsShoutcast columns_shoutcast; 

	  //Shoutcast genres record
	  class ColumnsShoutcastGenres
	    : public Gtk::TreeModel::ColumnRecord
	  {
	    public:
	      Gtk::TreeModelColumn<Glib::ustring> name;

	      ColumnsShoutcastGenres()
	      {
		add (name);
	      }
	  };
	  ColumnsShoutcastGenres columns_shoutcast_genres; 

	  //Icecast columns record
	  class ColumnsIcecast
	    : public Gtk::TreeModel::ColumnRecord
	  {
	    public:
	      Gtk::TreeModelColumn<Glib::ustring> name;
	      Gtk::TreeModelColumn<unsigned int>  bitrate;
	      Gtk::TreeModelColumn<Glib::ustring> genre;
	      Gtk::TreeModelColumn<Glib::ustring> uri;
	      Gtk::TreeModelColumn<Glib::ustring> nowplaying;

	      ColumnsIcecast()
	      {
		add (name);
		add (bitrate);
		add (genre);
		add (nowplaying);
		add (uri);
	      }
	  };
	  ColumnsIcecast columns_icecast;
#endif
	  void
	  activate_default
	  (const Gtk::TreeModel::Path&	  path,
	   Gtk::TreeViewColumn		 *column);

	  void
	  switch_page
	  (GtkNotebookPage*page,
	   unsigned int    page_nr);

	  void
	  play ();
	
	  void
	  enqueue ();

	  void
	  bookmark_add (Glib::ustring& name,
			Glib::ustring& comment,
			Glib::ustring& uri);

	  void
	  bookmark_edit ();

	  void
	  bookmark_delete ();


	  //Shoutcast
	  void
	  shoutcast_build_genre_list ();
 
	  void
	  shoutcast_refresh ();
	  void
	  shoutcast_refresh_enter ();
	  void
	  shoutcast_refresh_exit  ();
	  void
	  shoutcast_bookmark ();
	  void
	  shoutcast_column_clicked (int column);
	  void
 	  shoutcast_selection_changed ();
	  bool
	  shoutcast_visible_func (const Gtk::TreeModel::iterator& iter);
	  void
	  shoutcast_filter_changed ();


	  //Icecast
	  void
	  icecast_refresh ();
	  void
	  icecast_refresh_exit  ();
	  void
	  icecast_refresh_enter ();
	  void
	  icecast_bookmark ();
	  void
	  icecast_column_clicked (int column);
	  void
	  icecast_selection_changed ();
	  bool
	  icecast_visible_func (const Gtk::TreeModel::iterator& iter);
	  void
	  icecast_filter_changed ();


	  Bmp::Streams::Bookmarks bookmarks;
	  void
	  bookmarks_column_clicked (int column);
	  void
	  bookmarks_selection_changed ();

	  Glib::RefPtr<Gnome::Glade::Xml> ref_xml;
	  bool clear;
	  bool start;
	  unsigned int track;

	  Gtk::Dialog	   *dialog_add_bookmark;
	  Gtk::Dialog	   *dialog_delete_bookmark;
	  Gtk::Entry	   *entry_bookmark_name;
	  Gtk::Notebook	   *notebook;
	  Gtk::Notebook	   *notebook_icecast_inner;
	  Gtk::Notebook	   *notebook_shoutcast_inner;
	  Gtk::Entry	   *icecast_filter;
	  Gtk::Entry	   *shoutcast_filter;
	  Glib::RefPtr<Gtk::ListStore>  list_store_icecast;
	  Glib::RefPtr<Gtk::ListStore>  list_store_shoutcast;
	  Glib::RefPtr<Gtk::ListStore>  list_store_shoutcast_genres;
	  Glib::RefPtr<Gtk::TreeModelFilter>  model_icecast_filter;
	  Glib::RefPtr<Gtk::TreeModelFilter>  model_shoutcast_filter;
	  Gtk::TreeView	   *tree_view_shoutcast;
	  Gtk::TreeView	   *tree_view_shoutcast_genres;
	  Gtk::TreeView	   *tree_view_icecast;
	  Gtk::TreeView	   *tree_view_bookmarks;
	  Gtk::Button	   *refresh_shoutcast;
	  Gtk::Button	   *refresh_icecast;
	  Gtk::Button	   *bookmark_shoutcast;
	  Gtk::Button	   *bookmark_icecast;
	  Gtk::Button	   *b_enqueue;
	  Gtk::Button	   *b_play;
	  Gtk::Button	   *b_close;
	  Gtk::Button	   *b_bookmark_icecast;
	  Gtk::Button	   *b_bookmark_shoutcast;
	  Gtk::Button	   *b_bookmark_add;
	  Gtk::Button	   *b_bookmark_edit;
	  Gtk::Button	   *b_bookmark_delete;
	  Gtk::VBox	   *vbox_shoutcast;
	  Gtk::VBox	   *vbox_icecast;

      }; // class Dialog

  }; //namespace Streams

}; //namespace Bmp

#endif // STREAM_LISTER_HPP
