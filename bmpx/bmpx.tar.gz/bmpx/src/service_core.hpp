/*  BMPx - The Dumb Music Player
 *  Copyright (C) 2005 BMPx development team.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 *  $Id$
 *
 * The BMPx project hereby grant permission for non-gpl compatible GStreamer
 * plugins to be used and distributed together with GStreamer and BMPx. This
 * permission are above and beyond the permissions granted by the GPL license
 * BMPx is covered by.
 */

#ifndef SERVICE_CORE_HPP 
#define SERVICE_CORE_HPP

#include <glibmm.h>
#include <glib.h>
#include <play.hpp>
#include <boost/any.hpp>
#include <main.hpp>

namespace Bmp {

#ifndef DOXYGEN_SHOULD_SKIP_THIS  
    struct CServiceCore;
#endif

    class ServiceCore
	: public Glib::Object
    {
      public:

	class Message
	{
	  public:

	    Message (MessageType type, boost::any value);
	    Message (MessageType type);
	    ~Message ();
  
	    boost::any
	    get_data ();

	    MessageType
	    get_type ();

	    bool
	    has_data ();

	  private:

	    MessageType type;
	    boost::any  data;
	    bool	has_data;
	};

	ServiceCore ();
	~ServiceCore ();

	void send_message (MessageType type, boost::any data);
	void send_message (MessageType type);

      private:

	//DBus C GObject
	GObject* c_service_core;
 	friend CServiceCore* c_service_core_new (Bmp::ServiceCore &control);

	//Message queue
	bool		  process_messages ();
	sigc::connection  queue_conn;
	GAsyncQueue	 *queue;
    };

#ifndef DOXYGEN_SHOULD_SKIP_THIS  
    struct CServiceCore
    {
      GObject parent;
      Bmp::ServiceCore *control;
    };
#endif

};

#endif // SERVICE_CORE_HPP
