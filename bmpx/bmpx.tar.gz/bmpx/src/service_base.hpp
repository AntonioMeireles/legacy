#ifndef SERVICE_BASE_HPP
#define SERVICE_BASE_HPP

#include <iostream>
#include <sstream>
#include <glibmm.h>

namespace Bmp
{
      namespace Service
      {

	namespace Message
	{
	  struct Base
	  { 
	    Base ();
	    virtual Base () {};
	  };
	}

	class Queue
	{
	  public:

	    enum Exception
	    {
	      QUEUE_EMPTY
	    };

	    Queue ();
	    ~Queue ();

	    Bmp::Service::Message::Base	  
	    pop ();

	    void
	    push (Bmp::Service::Message::Base& message);

	  private:
	    std::deque<Bmp::Message::Base>  queue;
	    Glib::Mutex			    lock;
	  
	};

	class Base
	{
	  public:

	    Base ();
	    virtual ~Base ();

	  private:

	    Bmp::Service::Queue messages;

	};

    } // Service

} // Bmp

#endif //SERVICE_BASE_HPP
