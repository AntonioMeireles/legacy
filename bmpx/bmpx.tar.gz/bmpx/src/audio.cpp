//  BMPx - The Dumb Music Player
//  Copyright (C) 2005 BMPx development team.
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
//
//  --
//
//  The BMPx project hereby grants permission for non-GPL compatible GStreamer
//  plugins to be used and distributed together with GStreamer and BMPx. This
//  permission is above and beyond the permissions granted by the GPL license
//  BMPx is covered by.

#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <cstring>
#include <glibmm.h>

#include <gst/gst.h>
#include <gst/gstelement.h>
#include <gst/interfaces/mixer.h>
#include <gst/interfaces/mixertrack.h>
#include <gst/interfaces/mixeroptions.h>

#include <bmp/uri++.hpp>
#include <bmp/util.h>

#include <goa/libgoa.h>

#include "debug.hpp"
#include "audio.hpp"

#define  AUDIO_DEBUG_NAME "bmp-audio"

namespace Bmp
{
  namespace Audio
  {
    std::string ElementNames[] =
    {
	"source",
	"decoder",  
	"tee",
	"queue",
	"convert",
	"volume",
	"sink"
    };

    void
    link_pad (GstElement *element,
	      GstPad     *pad,
	      gboolean    last,
	      GstPad	 *sinkpad) 
    {
	gst_pad_link (pad, sinkpad);
    }

    void
    outfit_element  (GstElement			  *element,
		     const Element::Attributes&    attributes)		     
    {
      using namespace Element;

      Bmp::debug (AUDIO_DEBUG_NAME,
		 "Creating properties for element '%s' of type '%s'",
		 gst_element_get_name (element), 
	         G_OBJECT_CLASS_NAME (element));		 

      for (Attributes::const_iterator iter = attributes.begin (); iter != attributes.end (); ++iter)
      {
	const Attribute& attr = (*iter);

	switch (attr.type)
	{
	  using namespace Variant;

	  case BOOL: 
	  {
	    Bmp::debug (AUDIO_DEBUG_NAME,
		 "Adding property of type 'bool' with value '%s' for element '%s'",
		 boost::get<bool>(attr.value) ? "true":"false",
		 gst_element_get_name (element)); 

	    g_object_set (G_OBJECT(element), attr.name.c_str(), boost::get<bool>(attr.value), NULL);
	    break;
	  }

	  case INTEGER: 
	  {
	    Bmp::debug (AUDIO_DEBUG_NAME,
		 "Adding property of type 'int' with value '%d' for element '%s'",
		 boost::get<int>(attr.value),
		 gst_element_get_name (element)); 

	    g_object_set (G_OBJECT(element), attr.name.c_str(), boost::get<int>(attr.value), NULL);
	    break;
	  }

	  case DOUBLE: 
	  {
	    Bmp::debug (AUDIO_DEBUG_NAME,
		 "Adding property of type 'double' with value '%lf' for element '%s'",
		 boost::get<double>(attr.value),
		 gst_element_get_name (element)); 

	    g_object_set (G_OBJECT(element), attr.name.c_str(), boost::get<double>(attr.value), NULL);
	    break;
	  }

	  case STRING: 
	  {
	    Bmp::debug (AUDIO_DEBUG_NAME,
		 "Adding property of type 'string' with value '%s' for element '%s'",
		 boost::get<std::string>(attr.value).c_str (),
		 gst_element_get_name (element)); 

	    g_object_set (G_OBJECT(element), attr.name.c_str(), boost::get<std::string>(attr.value).c_str (), NULL);
	    break;
	  }
	} 
      }
    }

    GstElement*
    create_pipeline (GstElement			         *src,
		     const Bmp::Audio::Element::Element&  sink)
    {
      GstElement *pipeline = 0;
      GstElement *e[N_ELEMENTS];

      e[SOURCE] = src;

      //create sink
      e[SINK] = gst_element_factory_make (sink. name. c_str (),
				  ElementNames[SINK].c_str ()); 
      if (!e[SINK]) throw Bmp::Audio::ENOELEMENT; 
      outfit_element (e[SINK],
		      sink.attributes); 

      e[DECODER] =
	    gst_element_factory_make ("decodebin",
				      ElementNames[DECODER].c_str()); 
      e[CONVERT] =
	    gst_element_factory_make ("audioconvert",
				      ElementNames[CONVERT].c_str()); 
      e[VOLUME] =
	    gst_element_factory_make ("volume",
				      ElementNames[VOLUME].c_str()); 
      e[TEE] =
	    gst_element_factory_make ("tee",
				      ElementNames[TEE].c_str()); 
      e[QUEUE] =
	    gst_element_factory_make ("queue",
				      ElementNames[QUEUE].c_str()); 
		
      pipeline = gst_pipeline_new ("pipeline_file");
		
      gst_bin_add_many (GST_BIN (pipeline),
				 e[SOURCE],
				 e[DECODER],
				 e[TEE],
				 e[QUEUE],
				 e[CONVERT],
				 e[VOLUME],
				 e[SINK],
				 NULL);
		
      gst_element_link_many (e[SOURCE],
			     e[DECODER],
			     NULL);
		
      gst_element_link_many (e[TEE],
			     e[QUEUE],
			     e[CONVERT],
			     e[VOLUME],
			     e[SINK],
			     NULL);
	
      g_signal_connect (G_OBJECT(e[DECODER]),
			"new-decoded-pad",
			G_CALLBACK (Bmp::Audio::link_pad),
			gst_element_get_pad (e[TEE], "sink"));

      return pipeline; 
    }

    GstElement*
    create_pipeline (const Bmp::Audio::Element::Element& source,
		     const Bmp::Audio::Element::Element& sink)
    {
      GstElement *e_source = 0;

      //create source
      e_source =
	gst_element_factory_make (source. name. c_str (),
			  ElementNames[SOURCE].c_str ());
      if (!e_source) throw Bmp::Audio::ENOELEMENT;  //FIXME: Perhaps the element name as well here, mr. derezynski
      outfit_element (e_source,
		      source.attributes); 

      return create_pipeline (e_source, sink);
    }

  }
}

//ProcessorBase
namespace Bmp
{ 
  namespace Audio
  {
      ProcessorBase::ProcessorBase ()
	  : Glib::ObjectBase (typeid(ProcessorBase)),
	    pipeline			      (0),
	    prop_stream_time_		      (*this, "stream-time", 0),
	    prop_stream_time_report_interval_ (*this, "stream-time-report-interval", 250),
	    prop_length_		      (*this, "stream-length", 0),
	    prop_state_			      (*this, "processor-state", Bmp::Audio::STATE_STOPPED)
      {
	  prop_stream_time_report_interval ().signal_changed ().connect (sigc::mem_fun (*this, &Bmp::Audio::ProcessorBase::position_send_interval_change));
	  prop_state ().signal_changed ().connect (sigc::mem_fun (*this, &Bmp::Audio::ProcessorBase::prop_state_changed));
      }

      void
      ProcessorBase::prop_state_changed ()
      {
	switch (prop_state_.get_value ())
	{
	    case Bmp::Audio::STATE_STOPPED:
		  stop ();
		  break;

	    case Bmp::Audio::STATE_PAUSED:
		  pause ();
		  break;

	    case Bmp::Audio::STATE_RUNNING:
		  run ();
		  break;
	}
      }

      ProcessorBase::~ProcessorBase ()
      {
      }

      void
      ProcessorBase::link_pad (GstElement *element,
			       GstPad     *srcpad,
			       gboolean    last,
			       gpointer	   data) 
      {
	GstPad *sinkpad;
	sinkpad = reinterpret_cast<GstPad*>(data);

	gst_pad_link (srcpad, sinkpad);
      }

      gboolean
      ProcessorBase::bus_watch (GstBus     *bus,
				GstMessage *message,
				gpointer    data)
      {
	Bmp::Audio::ProcessorBase *processor; 
	processor = reinterpret_cast<Bmp::Audio::ProcessorBase*>(data);
        
        switch (GST_MESSAGE_TYPE (message))
	{
	    case GST_MESSAGE_TAG:
	    {
#if 0
		GstTagList *tag_list;
		gst_message_parse_tag (message, &tag_list);
		if (tag_list)
		{
		  char *title = 0;
		  unsigned int bitrate = 0;

		  if (gst_tag_list_get_string (tag_list, GST_TAG_TITLE, &title));
		  {
		      if (title)
		      {
			play->signal_title_.emit (title);
		      }
		  }

		  if (gst_tag_list_get_uint (tag_list, GST_TAG_BITRATE, &bitrate));
		  {
		    if (bitrate)
		    {
			play->signal_bitrate_.emit (bitrate/1000);
		    }
		  }
		}
#endif
	    }
	    break;

            case GST_MESSAGE_STATE_CHANGED:
            {
		GstState old_state, new_state, pending_state;

                gst_message_parse_state_changed (message,
						 &old_state,
                                                 &new_state,
						 &pending_state);
       
                if (new_state == GST_STATE_PLAYING)
                {
		  processor->position_send_stop ();
		  processor->position_send_start ();
#if 0
		  if (message->src == GST_OBJECT(play->elements[play->current_pipe][PIPELINE]))
		  {
		    GstPad *pad = gst_element_get_pad (play->elements[play->current_pipe][SINK], "sink");
		    GstCaps *caps = gst_pad_get_negotiated_caps (pad);
		    gst_object_unref (pad);

		    for (unsigned int n = 0; n < gst_caps_get_size (caps); ++n)
		    {
		      GstStructure *structure = gst_caps_get_structure (caps, n);
		      gst_structure_foreach (structure, GstStructureForeachFunc (Bmp::Play::foreach_structure), play);
		    }

		  }
#endif
                }
		else if (new_state < GST_STATE_PAUSED)
		{
		  processor->position_send_stop ();
		}
            }
            break;

            case GST_MESSAGE_ERROR:
            {
                GstElement    *element;
                GError	      *error = 0;
                std::string    name,
			       location,
			       message_str;
		char	      *debug_string;
        
                element = GST_ELEMENT(GST_MESSAGE_SRC (message));
                name = gst_object_get_name (GST_OBJECT(element));
        
                message_str = "<b>ERROR [Element: <i>"+name+"</i>]</b>\n";

                gst_message_parse_error	(message,
                                        &error,
                                        &debug_string);
        
                if (error->domain == GST_CORE_ERROR)
                {
                            switch (error->code)
                                {
                                    case GST_CORE_ERROR_MISSING_PLUGIN:
                                    {
					message_str += "(E101) There is no plugin available to play this track\n";
                                        break;
                                    }
        
                                    case GST_CORE_ERROR_SEEK:
                                    {
                                        message_str += "(E102) An error occured during seeking\n";
                                        break;
                                    }
        
                                    case GST_CORE_ERROR_STATE_CHANGE:
                                    {
                                        typedef struct _StringPairs StringPairs;
                                        struct _StringPairs {
                                            std::string   state_pre;
                                            std::string   state_post;
                                        };
        
                                        static StringPairs string_pairs[] = {
                                            {"0",	  "READY"},
                                            {"READY",	  "PAUSED"},
                                            {"PAUSED",	  "PLAYING"},
                                            {"PLAYING",	  "PAUSED"},
                                            {"PAUSED",	  "READY"},
                                            {"READY",	  "0"},
                                        };
       
                                        message_str += "(E103) An error occured during changing the state from "+string_pairs[GST_STATE_PENDING(message->src)].state_pre+" to "+string_pairs[GST_STATE_PENDING(message->src)].state_post+" (note that these are internal states and don't neccesarily reflect what you might understand by e.g. 'play' or 'pause'\n";
                                        break;
                                    }
        
                                    case GST_CORE_ERROR_PAD:
                                    {
                                        message_str += "(E104) An error occured during pad linking/unlinking\n";
                                        break;
                                    }
        
                                    case GST_CORE_ERROR_NEGOTIATION:
                                    {
                                        message_str =+ "(E105) An error occured during element(s) negotiation\n";
                                        break;
                                    }
        
                                    default: break;
                                }
                }
                else if (error->domain == GST_RESOURCE_ERROR)
                {
                            switch (error->code)
                                {
        
                                    case GST_RESOURCE_ERROR_SEEK:
                                    {
                                        message_str += "(E201) An error occured during seeking\n";
                                        break;
                                    }
        
                                    case GST_RESOURCE_ERROR_NOT_FOUND:
                                    case GST_RESOURCE_ERROR_OPEN_READ:
                                    {
                                        message_str += "(E202) Couldn't open the stream/track\n";
                                        break;
                                    }
        
                                    default: break;
                                }
                    }
                else if (error->domain == GST_STREAM_ERROR)
                    {
                            switch (error->code)
                                {
                                    case GST_STREAM_ERROR_CODEC_NOT_FOUND:
                                    {
                                        message_str += "(E301) There is no codec installed to handle this stream\n";
                                        break;
                                    }
        
                                    case GST_STREAM_ERROR_DECODE:
                                    {
                                        message_str += "(E302) There was an error decoding the stream\n";
                                        break;
                                    }
        
                                    case GST_STREAM_ERROR_DEMUX:
                                    {
                                        message_str += "(E303) There was an error demultiplexing the stream\n";
                                        break;
                                    }
        
                                    case GST_STREAM_ERROR_FORMAT:
                                    {
                                        message_str += "(E304) There was an error parsing the format of the stream\n";
                                        break;
                                    }
        
                                    default: break;
                                }
                    }
        
		message_str += "\n<b>Current URI:</b>\n"+location+"\n\n<b>Detailed debugging information:</b>\n"+debug_string; 
		g_free (debug_string);
                g_error_free (error);

		//XXX: Dispatch message
      
		processor->stop ();

                break;
            }
        
            case GST_MESSAGE_WARNING:
            {
                GError  *error = 0;
                gchar   *debug;
        
                gst_message_parse_warning (message, &error, &debug);
                g_print ("%s WARNING: %s (%s)\n", G_STRLOC, error->message, debug);
                g_error_free (error);
            }
            break;
        
            case GST_MESSAGE_EOS:
                {
		    processor->signal_eos_.emit();
                }
                break;
        
            default: break;
	}
        
	return TRUE;

      }

      bool
      ProcessorBase::emit_stream_position ()
      {
	GstQuery       *query;
	GstFormat       format = GST_FORMAT_TIME;
	gint64          time_in_nanoseconds;
	gint            time_in_seconds;

	if ((GST_STATE (pipeline) != GST_STATE_PLAYING))
	{
	  return false;
	}

	query = gst_query_new_position (format);
	gst_element_query (pipeline, query);
	gst_query_parse_position (query, &format, &time_in_nanoseconds);
	time_in_seconds = time_in_nanoseconds / GST_SECOND;
	gst_query_unref (query);

	if ((time_in_seconds >= 0) && (GST_STATE(pipeline) >= GST_STATE_PLAYING))
	{
	  signal_position_.emit(time_in_seconds);
	  return true;
	}
	else
	{
	  signal_position_.emit(0);
	  return false;
	}
      }

      //Properties/Property proxies
      Glib::PropertyProxy<unsigned int>
      ProcessorBase::prop_stream_time ()
      {
	return prop_stream_time_.get_proxy ();
      }

      Glib::PropertyProxy<unsigned int>
      ProcessorBase::prop_stream_time_report_interval ()
      {
	return prop_stream_time_report_interval_.get_proxy ();
      }

      Glib::PropertyProxy<ProcessorState>
      ProcessorBase::prop_state ()
      {
	return prop_state_.get_proxy ();
      }

      Glib::PropertyProxy<unsigned int>
      ProcessorBase::prop_length()
      {
	  GstQuery       *query;
	  GstFormat       format = GST_FORMAT_TIME;
	  gint64          length_in_nanoseconds;
	  gint		  value = 0;

	  query = gst_query_new_duration (format);
	  gst_element_query (pipeline, query);
	  gst_query_parse_duration (query, &format, &length_in_nanoseconds);
	  value = length_in_nanoseconds / GST_SECOND;
	  gst_query_unref (query);

	  prop_length_ = value;
          return prop_length_.get_proxy();
      }

      void
      ProcessorBase::position_send_stop ()
      {
	if (conn_position.connected()) conn_position.disconnect ();
	signal_position_.emit(0);
      }

      void
      ProcessorBase::position_send_start ()
      {
	conn_position =
		Glib::signal_timeout().connect(sigc::mem_fun (*this, &Bmp::Audio::ProcessorBase::emit_stream_position),
					       prop_stream_time_report_interval_.get_value ());
      }

      void
      ProcessorBase::position_send_interval_change ()
      {
	position_send_stop ();
	if (prop_state_.get_value () == Bmp::Audio::STATE_RUNNING)
	{
	  position_send_start ();
	}
      }

      //Signals
      Bmp::Audio::SignalEos&
      ProcessorBase::signal_eos ()
      { 
	return signal_eos_;
      }

      Bmp::Audio::SignalPosition&
      ProcessorBase::signal_position ()
      {
	return signal_position_;
      }

      Bmp::Audio::SignalStreamProperties&
      ProcessorBase::signal_stream_properties ()
      {
	return signal_stream_properties_;
      }


      GstStateChangeReturn
      ProcessorBase::stop ()
      {
	if (!pipeline) return GST_STATE_CHANGE_FAILURE; //FIXME: Exception

	conn_position.disconnect ();
	prop_state_ = Bmp::Audio::STATE_STOPPED;
	return gst_element_set_state (pipeline, GST_STATE_READY);
      }

      GstStateChangeReturn
      ProcessorBase::pause ()
      {
	if (!pipeline) return GST_STATE_CHANGE_FAILURE; //FIXME: Exception

	prop_state_ = Bmp::Audio::STATE_PAUSED;
	return gst_element_set_state (pipeline, GST_STATE_PAUSED);
      }

      GstStateChangeReturn
      ProcessorBase::run ()
      {
	if (!pipeline) return GST_STATE_CHANGE_FAILURE; //FIXME: Exception

	conn_position.disconnect ();
	prop_state_ = Bmp::Audio::STATE_RUNNING;
	return gst_element_set_state (pipeline, GST_STATE_PLAYING);
      }

      GstElement*
      ProcessorBase::tap ()
      {
	return gst_bin_get_by_name (GST_BIN(pipeline), ElementNames[TEE].c_str());	
      }

      void
      ProcessorBase::create_pipeline ()
      {
	if (pipeline)	
	{
	  gst_element_set_state (GST_ELEMENT(pipeline), GST_STATE_NULL);
	  g_object_unref (pipeline);
	}

	pipeline = Bmp::Audio::create_pipeline (source, sink);
      }
  }
};

//ProcessorURISink
namespace Bmp
{ 
  namespace Audio
  {

      ProcessorURISink::ProcessorURISink  ()
      {
      }

      ProcessorURISink::~ProcessorURISink ()
      {
      }

      void
      ProcessorURISink::set_uri (Glib::ustring			    _uri,
				 const Bmp::Audio::Element::Element& sink)
      {
	Bmp::URI u (_uri);
	Bmp::URI::Protocol protocol = u.get_protocol(); 

	stop ();
	this->stream = _uri;

	if (protocol != current_protocol)
	{
	  switch (protocol)
	  {
	      case Bmp::URI::PROTOCOL_FILE:
	      {
		Bmp::debug (AUDIO_DEBUG_NAME,
		"Creating filesrc element");

		source = Element::Element ("filesrc");
		source.add (Element::Attribute ("location", Glib::filename_from_uri (_uri)));
		break;
	      }

	      case Bmp::URI::PROTOCOL_HTTP:
	      {
		Bmp::debug (AUDIO_DEBUG_NAME, "Creating neonhttpsrc element");

		source = Element::Element ("neonhttpsrc");
		source.add (Element::Attribute ("location", std::string (_uri)));
		source.add (Element::Attribute ("iradio-mode", true));
		break;
	      }

	      case Bmp::URI::PROTOCOL_CDDA:
	      {
		int track = atoi ((u.path.c_str())+1);
		Bmp::debug (AUDIO_DEBUG_NAME, "Creating cdparanoiasrc element");

		source = Element::Element ("cdparanoiasrc");
		source.add (Element::Attribute ("track", int(track)));
		break;
	      }

	      default: break; //FIXME: error condition
	    }

	    this->sink = sink;
	    create_pipeline ();
	}
	else
	{
	  switch (protocol)
	  {
	      case Bmp::URI::PROTOCOL_FILE:
	      {
		g_object_set (gst_bin_get_by_name (GST_BIN (pipeline), ElementNames[SOURCE].c_str()), "location", Glib::filename_from_uri (_uri).c_str (), NULL);
		break;
	      }

	      case Bmp::URI::PROTOCOL_HTTP:
	      {
		g_object_set (gst_bin_get_by_name (GST_BIN (pipeline), ElementNames[SOURCE].c_str()), "location", _uri.c_str (), NULL);
		break;
	      }

	      case Bmp::URI::PROTOCOL_CDDA:
	      {
		int track = atoi ((u.path.c_str())+1);
		g_object_set (gst_bin_get_by_name (GST_BIN (pipeline), ElementNames[SOURCE].c_str()), "track", track, NULL);
		break;
	      }
	      default: break; //FIXME: error condition
	  }
	} 
      }
  }
}
