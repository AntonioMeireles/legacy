#ifndef PATHS_HPP
#define PATHS_HPP

#define BMP_SKIN_THUMB_DIR_BASENAME   "thumbs"
#define BMP_COVER_THUMB_DIR_BASENAME  "covers"
#define BMP_XDG_CACHE_BASEDIR	       PACKAGE


#define BMP_SKIN_DIR_BASENAME         "skins"
#define BMP_LOGS_BASENAME             "logs"
#define BMP_PLAYLISTS_DIR_BASENAME    "playlists"
#define BMP_TAGS_DIR_BASENAME	      "tags"

#define BMP_UI_BASENAME		      "ui"
#define BMP_DATA_BASENAME	      "data"
#define BMP_IMAGES_BASENAME	      "images"
#define BMP_ICONS_BASENAME	      "icons/themes"

#define BMP_PATH_LOGS_DIR             bmp_paths[0]
#define BMP_PATH_USER_DIR             bmp_paths[1]
#define BMP_PATH_USER_PLUGIN_DIR      bmp_paths[2]
#define BMP_PATH_USER_SKIN_DIR        bmp_paths[3]
#define BMP_PATH_SKIN_THUMB_DIR       bmp_paths[4]
#define BMP_PATH_ACCEL_FILE           bmp_paths[5]
#define BMP_PATH_CONFIG_FILE          bmp_paths[6]
#define BMP_PATH_PLAYLISTS            bmp_paths[7]
#define BMP_PATH_METADATA_CACHE       bmp_paths[8]
#define BMP_PATH_COVER_THUMB_DIR      bmp_paths[9]
#define BMP_N_PATHS                   10

extern gchar *bmp_paths[BMP_N_PATHS];

#endif
