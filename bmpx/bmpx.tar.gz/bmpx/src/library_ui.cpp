#include <glibmm/i18n.h>
#include <gtkmm.h>
#include <cstdlib>
#include <cstring>
#include <bmp/file_utils.hpp>
#include "main.hpp"
#include "paths.hpp"
#include "library_ui.hpp"

namespace Bmp
{
      LibraryUI::LibraryUI (BaseObjectType                        *cobject,
			    const Glib::RefPtr<Gnome::Glade::Xml> &xml)
	: Gtk::Window (cobject),
	  ref_xml (xml)
      {
	Gtk::Image *image;

	ref_xml->get_widget ("i_header", image);
	image->set (Glib::build_filename (DATA_DIR, "images" G_DIR_SEPARATOR_S "library" G_DIR_SEPARATOR_S "header-logo.png"));

	ref_xml->get_widget ("i_add", image);
	image->set (Glib::build_filename (DATA_DIR, "images" G_DIR_SEPARATOR_S "library" G_DIR_SEPARATOR_S "add.png"));
	ref_xml->get_widget ("i_wait1", image);
	image->set (Glib::build_filename (DATA_DIR, "images" G_DIR_SEPARATOR_S "wait.gif"));


	ref_xml->get_widget ("i_remove_artist", image);
	image->set (Glib::build_filename (DATA_DIR, "images" G_DIR_SEPARATOR_S "library" G_DIR_SEPARATOR_S "remove.png"));
	ref_xml->get_widget ("i_remove_album", image);
	image->set (Glib::build_filename (DATA_DIR, "images" G_DIR_SEPARATOR_S "library" G_DIR_SEPARATOR_S "remove.png"));
	ref_xml->get_widget ("i_remove_tracks", image);
	image->set (Glib::build_filename (DATA_DIR, "images" G_DIR_SEPARATOR_S "library" G_DIR_SEPARATOR_S "remove.png"));


	ref_xml->get_widget ("b_add",
			      b_add);
	b_add->signal_clicked().connect			(sigc::mem_fun (*this,
							      &Bmp::LibraryUI::on_music_add));

	ref_xml->get_widget ("b_remove_tracks",
			      b_remove_tracks);
	b_remove_tracks->signal_clicked().connect       (sigc::mem_fun (*this,
							      &Bmp::LibraryUI::remove_tracks));

	ref_xml->get_widget ("b_remove_album",
			      b_remove_album);
	b_remove_album->signal_clicked().connect       (sigc::mem_fun (*this,
							      &Bmp::LibraryUI::remove_album));

	ref_xml->get_widget ("b_remove_artist",
			      b_remove_artist);
	b_remove_artist->signal_clicked().connect       (sigc::mem_fun (*this,
							      &Bmp::LibraryUI::remove_artist));

	ref_xml->get_widget ("b_close",
			      b_close);
	b_close->signal_clicked().connect		(sigc::mem_fun (*this,
							      &Gtk::Widget::hide));

	ref_xml->get_widget ("b_play",
			      b_play); 
	b_play->signal_clicked().connect		(sigc::mem_fun (*this,
							      &Bmp::LibraryUI::play));

	ref_xml->get_widget ("b_enqueue",
			      b_enqueue);
	b_enqueue->signal_clicked().connect		(sigc::mem_fun (*this,
							      &Bmp::LibraryUI::enqueue));
	ref_xml->get_widget ("b_select_all",
			      b_select_all);
	b_select_all->signal_clicked().connect		(sigc::mem_fun (*this,
							      &Bmp::LibraryUI::select_all));

	ref_xml->get_widget ("jump_to_current_a",
			      jump_to_current_a);
	jump_to_current_a->signal_clicked().connect	(sigc::bind (sigc::mem_fun (*this,
							      &Bmp::LibraryUI::jtc), VIEW_A));

	ref_xml->get_widget ("notebook_add", notebook_add);
	ref_xml->get_widget ("view_attr_a", view[VIEW_A]);
	ref_xml->get_widget ("view_attr_b", view[VIEW_B]);
	ref_xml->get_widget ("view_tracks", view_tracks);
	ref_xml->get_widget ("cbox_attr_a", cbox[VIEW_A]);
	ref_xml->get_widget ("cbox_attr_b", cbox[VIEW_B]);


	for (int n = 0; n < N_VIEWS; ++n)
	{
	  view[n]->get_selection()->set_mode (Gtk::SELECTION_SINGLE);
	  Gtk::CellRendererText *cell = Gtk::manage ( new Gtk::CellRendererText() );
	  cell->property_ellipsize () = Pango::ELLIPSIZE_END;
	  view[n]->append_column (_("View"), *cell);
	  view[n]->get_column (0)->add_attribute (*cell, "text", 0);
	  view[n]->get_column (0)->set_resizable (false);

	  store[n] = Gtk::ListStore::create (attribute_view);	
	  store[n]->set_sort_func (0, sigc::mem_fun (*this, &Bmp::LibraryUI::sort_attrs));
	  store[n]->set_sort_column (0, Gtk::SORT_ASCENDING);

	  view[n]->set_model (store[n]);
	}
	view[VIEW_A]->get_selection()->signal_changed().connect (sigc::mem_fun (*this, &Bmp::LibraryUI::attr_a_changed));
	view[VIEW_B]->get_selection()->signal_changed().connect (sigc::mem_fun (*this, &Bmp::LibraryUI::attr_b_changed));
	view[VIEW_A]->get_selection()->set_mode (Gtk::SELECTION_SINGLE);
	view[VIEW_B]->get_selection()->set_mode (Gtk::SELECTION_MULTIPLE);

	struct { 
	    char    *title;
	    double   xalign;
	    int	     width;
	} headers[] = {
	    { _("Track"),      1.0, 50  },
	    { _("Title"),      0.0, 250 },
	    { _("Genre"),      0.0, 100 },
	    { _("Bitrate"),    0.0, 80  },
	    { _("Samplerate"), 0.0, 80  },
	};

	view_tracks->get_selection()->set_mode (Gtk::SELECTION_MULTIPLE);
	for (unsigned int n = 0; n < G_N_ELEMENTS(headers); ++n)
	{
	  Gtk::CellRendererText *cell = Gtk::manage ( new Gtk::CellRendererText() );
	  cell->property_ellipsize () = Pango::ELLIPSIZE_END;
	  cell->property_xalign() = headers[n].xalign;
	  view_tracks->append_column (headers[n].title, *cell);
	  view_tracks->get_column (n)->add_attribute (*cell, "text", n);
	  view_tracks->get_column (n)->set_resizable (true);
	  view_tracks->get_column (n)->set_sort_column (n);
	  view_tracks->get_column (n)->set_expand (true);
	  view_tracks->get_column (n)->property_min_width() = headers[n].width;
	}
	store_tracks = Gtk::ListStore::create (tracks);
	view_tracks->set_model (store_tracks);
	view_tracks->get_selection()->signal_changed().connect (sigc::mem_fun (*this, &Bmp::LibraryUI::tracks_selection_changed));

	Bmp::Library::Datum attrs[] = { 	
	    Bmp::Library::DATUM_ARTIST,
	    Bmp::Library::DATUM_ALBUM,
	    Bmp::Library::DATUM_TITLE,
	    Bmp::Library::DATUM_GENRE,
	};

	for (unsigned int n = 0; n < N_VIEWS; ++n)
	{
	  store_attr[n] = Gtk::ListStore::create (attribute);
	  for (unsigned int k = 0; k < G_N_ELEMENTS(attrs); ++k)
	  {
	    Gtk::TreeModel::iterator iter = store_attr[n]->append ();	    
	    Bmp::Library::DatumDefine define = library->get_metadatum_define (attrs[k]); 
	    (*iter)[attribute.title] = define.title;
	    (*iter)[attribute.datum] = attrs[k];
	  }
	  cbox[n]->clear ();
	  Gtk::CellRendererText *cell = Gtk::manage ( new Gtk::CellRendererText() );
	  cbox[n]->pack_start (*cell);
	  cbox[n]->add_attribute (*cell, "text", 0); 
	  cbox[n]->set_model (store_attr[n]);
	}

	cbox[VIEW_A]->set_active (0);
	cbox[VIEW_B]->set_active (1);
	cbox[VIEW_A]->signal_changed().connect (sigc::mem_fun (*this, &Bmp::LibraryUI::attr_a_datum_changed));
	cbox[VIEW_B]->signal_changed().connect (sigc::mem_fun (*this, &Bmp::LibraryUI::attr_b_datum_changed));

	datum[VIEW_A] = Bmp::Library::DATUM_ARTIST;
	datum[VIEW_B] = Bmp::Library::DATUM_ALBUM;

	library->signal_processing_start().connect (sigc::bind (sigc::mem_fun (*this, &Gtk::Widget::set_sensitive), false));
	library->signal_processing_end().connect (sigc::bind (sigc::mem_fun (*this, &Gtk::Widget::set_sensitive), true));

	update_view ();
      }

      void
      LibraryUI::tracks_selection_changed ()
      {
	  bool selected = view_tracks->get_selection ()->count_selected_rows ();

	  b_play	  -> set_sensitive (selected);
	  b_enqueue	  -> set_sensitive (selected);
	  b_remove_tracks -> set_sensitive (selected);
      }

      void
      LibraryUI::select_all ()
      {
	view_tracks->get_selection()->select_all ();
      }

      void
      LibraryUI::remove_artist ()
      {
	  store_tracks->clear ();
	  del_current_artist ();	    
      }

      void
      LibraryUI::remove_album ()
      {
	  typedef std::vector<Gtk::TreeModel::iterator> VIters;
	  VIters iters;
      
	  Gtk::TreeSelection::ListHandle_Path paths = view[VIEW_B]->get_selection()->get_selected_rows();
	  for (Gtk::TreeSelection::ListHandle_Path::const_iterator i = paths.begin (); i != paths.end (); ++i)
	  {
	    Gtk::TreeModel::iterator m_iter_b = store[VIEW_B]->get_iter (*i);
	    iters.push_back (m_iter_b);
	  }

	  for (VIters::const_iterator i = iters.begin (); i != iters.end (); ++i)
	  {
	    Gtk::TreeModel::iterator m_iter_a = view[VIEW_A]->get_selection()->get_selected ();
	    Gtk::TreeModel::iterator m_iter_b = (*i); 
	    std::string key_a = (*m_iter_a)[attribute_view.key];
	    std::string key_b = (*m_iter_b)[attribute_view.key];

	    DB::AttributeList attrs;
	    attrs.push_back (DB::Attribute (true, library->get_metadatum_id (Bmp::Library::DATUM_ARTIST), key_a));
	    attrs.push_back (DB::Attribute (true, library->get_metadatum_id (Bmp::Library::DATUM_ALBUM),  key_b));
	    library->del (attrs);
	    store[VIEW_B]->erase (m_iter_b);
	  }

	  if (store[VIEW_B]->children ().empty ())
	  {
	    store_tracks->clear ();
	    del_current_artist ();	    
	  }
      }

      void
      LibraryUI::remove_tracks ()
      {
	  Gtk::TreeSelection::ListHandle_Path paths = view_tracks->get_selection()->get_selected_rows ();
	  for (Gtk::TreeSelection::ListHandle_Path::const_iterator iter = paths.begin (); iter != paths.end (); ++iter)
	  {
	      Gtk::TreeModel::iterator m_iter = store_tracks->get_iter (*iter);
	      Glib::ustring key = (*m_iter)[tracks.uri];
	      DB::AttributeList attrs;
	      attrs.push_back (DB::Attribute (true, library->get_metadatum_id (Bmp::Library::DATUM_LOCATION), std::string(key)));
	      library->del (attrs);
	  }

	  attr_b_changed ();

	  if (store_tracks->children ().empty())
	  {
	      del_current_album ();
	      if (store[VIEW_B]->children ().empty ())
	      {
		del_current_artist ();	    
	      }
	  }
      }

      void
      LibraryUI::del_current_album ()
      {
	  Gtk::TreeModel::iterator m_iter_a = view[VIEW_A]->get_selection ()->get_selected (); 
	  Gtk::TreeModel::iterator m_iter_b = view[VIEW_B]->get_selection ()->get_selected (); 

	  DB::AttributeList attrs;
	  std::string key_a = (*m_iter_a)[attribute_view.key];
	  std::string key_b = (*m_iter_b)[attribute_view.key];
	  attrs.push_back (DB::Attribute (true, library->get_metadatum_id (Bmp::Library::DATUM_ARTIST), key_a));
	  attrs.push_back (DB::Attribute (true, library->get_metadatum_id (Bmp::Library::DATUM_ALBUM),  key_b));
	  library->del (attrs);
	  store[VIEW_B]->erase (m_iter_b);
      }

      void
      LibraryUI::del_current_artist ()
      {
	  Gtk::TreeModel::iterator m_iter_a = view[VIEW_A]->get_selection ()->get_selected (); 
	  DB::AttributeList attrs;
	  std::string key = (*m_iter_a)[attribute_view.key];
	  attrs.push_back (DB::Attribute (true, library->get_metadatum_id (Bmp::Library::DATUM_ARTIST), key));
	  library->del (attrs);
	  store[VIEW_A]->erase (m_iter_a);
      }

      void
      LibraryUI::play ()
      {
	  Gtk::TreeSelection::ListHandle_Path paths = view_tracks->get_selection()->get_selected_rows ();
	  char **uri_list = (char**)calloc (paths.size()+1, sizeof(char*));
	  unsigned int counter = 0;
	  for (Gtk::TreeSelection::ListHandle_Path::const_iterator iter = paths.begin (); iter != paths.end (); ++iter)
	  {
	      Gtk::TreeModel::iterator m_iter = store_tracks->get_iter (*iter);
	      Glib::ustring str = (*m_iter)[tracks.uri];
	      uri_list[counter++] = strdup(str.c_str ());
	  }
	  uri_list[paths.size()] = 0;

	  int out;
	  bmp_system_control_add_uri_list (bmp_system_control,
					   (const gchar**)uri_list,
					   -1,
					   true, 
					   true, 
					   0, 
					   &out,
					   NULL);
	  g_strfreev (uri_list);
      }

      void
      LibraryUI::enqueue ()
      {
	  Gtk::TreeSelection::ListHandle_Path paths = view_tracks->get_selection()->get_selected_rows ();
	  char **uri_list = (char**)calloc (paths.size()+1, sizeof(char*));
	  unsigned int counter = 0;
	  for (Gtk::TreeSelection::ListHandle_Path::const_iterator iter = paths.begin (); iter != paths.end (); ++iter)
	  {
	      Gtk::TreeModel::iterator m_iter = store_tracks->get_iter (*iter);
	      Glib::ustring str = (*m_iter)[tracks.uri];
	      uri_list[counter++] = strdup(str.c_str ());
	  }
	  uri_list[paths.size()] = 0;

	  int out;
	  bmp_system_control_add_uri_list (bmp_system_control,
					   (const gchar**)uri_list,
					   -1,
					   false, 
					   false, 
					   -1, 
					   &out,
					   NULL);
	  g_strfreev (uri_list);
      }

      void
      LibraryUI::jtc (Bmp::LibraryUI::Views _view)
      {
	 Gtk::TreePath path (view[_view]->get_selection()->get_selected () );
	 view[_view]->scroll_to_row (path, 0.5);
      }

      void
      LibraryUI::attr_a_datum_changed ()
      {
	Gtk::TreeModel::iterator iter = cbox[VIEW_A]->get_active ();
	datum[VIEW_A] = (*iter)[attribute.datum];
	store[VIEW_A]->clear ();
	itermap[VIEW_A].clear ();

	std::string id = library->get_metadatum_id (datum[VIEW_A]);

	DB::AttributeList attrs;
	attrs.push_back (DB::Attribute (false, library->get_metadatum_id (Bmp::Library::DATUM_LOCATION), std::string("file")));
	DB::DataRowVector vector = library->project (id, attrs);

	for (DB::DataRowVector::iterator iter = vector.begin (); iter != vector.end (); ++iter)
	{	
	  std::string key = boost::get<std::string>((*iter)[id]);

	  if (key.length())
	  {
	    Gtk::TreeModel::iterator m_iter = store[VIEW_A]->append ();

	    (*m_iter)[attribute_view.name]  = key; 
	    (*m_iter)[attribute_view.key]   = key; 

	    itermap[VIEW_A].insert (std::make_pair (key, m_iter));
	  }
	}
	store[VIEW_B]->clear ();
	itermap[VIEW_B].clear ();
      }

      void
      LibraryUI::attr_b_datum_changed ()
      {
	Gtk::TreeModel::iterator iter = cbox[VIEW_B]->get_active ();
	datum[VIEW_B] = (*iter)[attribute.datum];
	attr_a_changed ();
      }

      void
      LibraryUI::attr_a_changed ()
      {
	  store_tracks->clear ();
	  itermap[VIEW_B].clear ();
	  store[VIEW_B]->clear ();

	  if (!view[VIEW_A]->get_selection ()->count_selected_rows ())
	  {
	      b_select_all->set_sensitive (false); 
	      b_remove_artist->set_sensitive (false); 
	      return;
	  }
	  else
	  {
	      b_remove_artist->set_sensitive (true); 
	  }

	  Gtk::TreeModel::iterator m_iter_a = view[VIEW_A]->get_selection ()->get_selected (); 

	  std::string key_a		    = (*m_iter_a)[attribute_view.key];
	  std::string id_a		    = library->get_metadatum_id (datum[VIEW_A]);
	  std::string id_b		    = library->get_metadatum_id (datum[VIEW_B]);

	  DB::AttributeList attrs;
	  attrs.push_back (DB::Attribute (true, id_a, key_a));
	  attrs.push_back (DB::Attribute (false, library->get_metadatum_id (Bmp::Library::DATUM_LOCATION), std::string("file")));

	  DB::DataRowVector vector = library->project (id_b, attrs);
	  for (DB::DataRowVector::iterator iter = vector.begin (); iter != vector.end (); ++iter)
	  {
	    std::string key = boost::get<std::string>((*iter)[id_b]);

	    if (key.length())
	    {
	      Gtk::TreeModel::iterator m_iter = store[VIEW_B]->append ();
	      (*m_iter)[attribute_view.name]  = key; 
	      (*m_iter)[attribute_view.key]   = key; 
	      itermap[VIEW_B].insert (std::make_pair (key, m_iter));
	    }
	  }
      }

      void
      LibraryUI::attr_b_changed ()
      {
	  store_tracks->clear ();

	  if (!view[VIEW_A]->get_selection ()->count_selected_rows ())
	  {
	      b_select_all->set_sensitive (false); 
	      b_remove_artist->set_sensitive (false); 
	      b_remove_album->set_sensitive (false); 
	      return; 
	  }
	  else
	  {
	      b_remove_artist->set_sensitive (true); 
	  }

	  if (!view[VIEW_B]->get_selection ()->count_selected_rows ())
	  {
	      b_select_all->set_sensitive (false); 
	      b_remove_album->set_sensitive (false); 
	      return; 
	  }
	  else
	  {
	      b_remove_album->set_sensitive (true); 
	  }

	  Gtk::TreeSelection::ListHandle_Path handle = view[VIEW_B]->get_selection ()->get_selected_rows ();

	  for (Gtk::TreeSelection::ListHandle_Path::iterator i = handle.begin (); i != handle.end (); ++i)
	  {
	    DB::AttributeList attrs;
	    Gtk::TreeModel::iterator m_iter_b = store[VIEW_B]->get_iter (*i);
	    std::string key_b = (*m_iter_b)[attribute_view.key];
	    attrs.push_back (DB::Attribute (true, library->get_metadatum_id (datum[VIEW_B]), key_b));
      
	    Gtk::TreeModel::iterator m_iter_a = view[VIEW_A]->get_selection ()->get_selected (); 
	    std::string key_a = (*m_iter_a)[attribute_view.key];
	    attrs.push_back (DB::Attribute (true, library->get_metadatum_id (datum[VIEW_A]), key_a));

	    DB::DataRowVector vector = library->query (attrs);

	    for (DB::DataRowVector::iterator iter = vector.begin ();
	       iter != vector.end ();
	       ++iter)
	    {
	      Gtk::TreeModel::iterator tracks_iter = store_tracks->append ();

	      (*tracks_iter)[tracks.title]      = boost::get<std::string>((*iter)[library->get_metadatum_id (Bmp::Library::DATUM_TITLE)]); 
	      (*tracks_iter)[tracks.track]      = boost::get<int>((*iter)[library->get_metadatum_id (Bmp::Library::DATUM_TRACK)]); 
	      (*tracks_iter)[tracks.genre]      = boost::get<std::string>((*iter)[library->get_metadatum_id (Bmp::Library::DATUM_GENRE)]); 
	      (*tracks_iter)[tracks.bitrate]    = boost::get<int>((*iter)[library->get_metadatum_id (Bmp::Library::DATUM_BITRATE)]); 
	      (*tracks_iter)[tracks.samplerate] = boost::get<int>((*iter)[library->get_metadatum_id (Bmp::Library::DATUM_SAMPLERATE)]); 
	      (*tracks_iter)[tracks.uri]	      = boost::get<std::string>((*iter)[library->get_metadatum_id (Bmp::Library::DATUM_LOCATION)]); 
	    }


	    if (!store_tracks->children ().empty ())
	    {
	      b_select_all->set_sensitive (true); 
	    }

	  }

	  view_tracks->columns_autosize ();
      }

      int
      LibraryUI::sort_attrs (const Gtk::TreeModel::iterator& iter_a,
			     const Gtk::TreeModel::iterator& iter_b)
      {
	  std::string str_a = (*iter_a)[attribute_view.key];
	  std::string str_b = (*iter_b)[attribute_view.key];

	  return str_a . compare (str_b); 
      }

      LibraryUI*
      LibraryUI::create ()
      {
	const std::string path = Glib::build_filename (DATA_DIR, "glade" G_DIR_SEPARATOR_S "library_ui.glade");
	Glib::RefPtr<Gnome::Glade::Xml> glade_xml = Gnome::Glade::Xml::create (path);
	LibraryUI *library_ui = 0;
	glade_xml->get_widget_derived ("library_ui", library_ui);
	return library_ui;
      }

      void
      LibraryUI::on_music_add ()
      {
	Gtk::FileChooserDialog dialog (*this,
                                       _("Select Path To Add"),
                                       Gtk::FILE_CHOOSER_ACTION_SELECT_FOLDER);

	dialog.add_button (Gtk::Stock::CANCEL, Gtk::RESPONSE_CANCEL);
	dialog.add_button (Gtk::Stock::ADD, Gtk::RESPONSE_OK);
	dialog.set_current_folder (mcs->key_get<std::string>("bmp", "file-chooser-path"));

	if (dialog.run () == Gtk::RESPONSE_CANCEL)
	{
	   return;
	}
	else
	{
	  notebook_add->set_current_page (1);
	  Glib::ustring folder = dialog.get_filename ();
	  dialog.hide ();

	  Util::FileList list;
	  Util::collect_path (folder, list);

	  for (Util::FileList::const_iterator iter = list.begin (), end = list.end ();
	       iter != end;
	       ++iter)
	  {
	    Glib::ustring uri = Glib::filename_to_uri (*iter);
	    library->cache_metadata (uri, folder);
	    while (gtk_events_pending ()) gtk_main_iteration ();
	  }

	  notebook_add->set_current_page (0);
	  update_view ();
      }
    }

    void
    LibraryUI::update_view ()
    {
      std::string id = library->get_metadatum_id (datum[VIEW_A]);

      DB::AttributeList attrs;
      attrs.push_back (DB::Attribute (false, library->get_metadatum_id (Bmp::Library::DATUM_LOCATION), std::string("file")));
      DB::DataRowVector vector = library->project (id, attrs);

      for (DB::DataRowVector::iterator iter = vector.begin (); iter != vector.end (); ++iter)
      {
	std::string key = boost::get<std::string>((*iter)[id]);

	if (key.length() && (itermap[VIEW_A].find (key) == itermap[VIEW_A].end()))
	{
	  Gtk::TreeModel::iterator m_iter = store[VIEW_A]->append ();

	  (*m_iter)[attribute_view.name]  = key; 
	  (*m_iter)[attribute_view.key]	  = key; 

	  itermap[VIEW_A].insert (std::make_pair (key, m_iter));
	}
      }
      attr_a_changed ();
    }
}
