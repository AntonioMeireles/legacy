//-*- Mode: C++; indent-tabs-mode: nil; -*-
//
//  BMPx - The Dumb Music Player
//  Copyright (C) 2005-2006 BMPx development team.
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
//
//  --
//
//  The BMPx project hereby grants permission for non GPL-compatible GStreamer
//  plugins to be used and distributed together with GStreamer and BMPx. This
//  permission is above and beyond the permissions granted by the GPL license
//  BMPx is covered by.


#include <glibmm.h>
#include <glib.h>
#include <fam.h>
#include <utility>

#include "file_monitor.hpp"

namespace Bmp
{
  namespace FileMonitor
  {
  Monitor::Watch::Watch (const std::string   monitor_name,
                                    const std::string   path_name,
                                    const FamFunc       &func_added,
                                    const FamFunc       &func_removed)
      : monitor_name  (monitor_name),
        path_name     (path_name),
        func_added    (func_added),
        func_removed  (func_removed)
  {
      FAMOpen (&fc);

      thread = Glib::Thread::create (sigc::mem_fun (this, &Watch::watch_thread), true);

      termination.lock ();
      terminate = false;
  }

  Monitor::Watch::~Watch ()
  {
      terminate_watch ();
      FAMClose (&fc);
  }

  void
  Monitor::Watch::terminate_watch ()
  {
      termination.unlock ();
      thread->join ();
      termination.unlock ();
  }

  void
  Monitor::Watch::watch_thread ()
  {
      FAMRequest fr;
      FAMMonitorDirectory (&fc, path_name.c_str(), &fr, 0);

      while (true)
      {
          Glib::Thread *collector = Glib::Thread::create (sigc::mem_fun (this, &Watch::monitor_thread), true);
          collector->join();

          for (EventList::const_iterator iter = events.begin (), end = events.end ();
               iter != end;
               ++iter)
          {
              switch (iter->second)
              {
              case FAMCreated:
                  {
                      func_added (iter->first);
                  }
                  break;

              case FAMDeleted:
                  {
                      func_removed (iter->first);
                  }
                  break;

              default:

                  break;
              }

          }

          events.clear();

          if (terminate)
          {
              FAMCancelMonitor (&fc, &fr);
              return;
          }
      }
  };

  void
  Monitor::Watch::monitor_thread ()
  {
      FAMEvent fe;
      bool     have_event;

      have_event = false;

      while (true)
      {
          Glib::usleep (50000);

          switch (FAMPending (&fc))
          {
          case 1:
              {
                  FAMNextEvent (&fc, &fe);

                  switch (fe.code)
                  {
                  case FAMCreated:
                  case FAMDeleted:
                  case FAMMoved:
                      {
                          events.push_back (std::make_pair (Glib::build_filename (path_name, fe.filename), fe.code));
                          have_event = true;
                      }
                      break;

                  default: break;

                  }
              }
              break;
          }

          terminate = termination.trylock();
          if (terminate || have_event)
          {
              break;
          }
      }
  }

  Monitor::Monitor ()
  {
      FAMConnection fc;

      if (FAMOpen (&fc) == -1)
      {
          monitor_running = false;
          g_message ("running: Monitor (FAM daemon not running: Not accepting watches!)");
      }
      else
      {
          monitor_running = true;
          g_message ("running: Monitor");
      }

      FAMClose (&fc);
  }

  Monitor::~Monitor ()
  {
      watches.clear();
      g_message ("stopped: Monitor");
  }

  bool
  Monitor::add_watch (const std::string   monitor_name,
                         const std::string   path_name,
                         const FamFunc       &func_added,
                         const FamFunc       &func_removed)
  {
      if (!monitor_running)
      {
          g_warning (G_STRLOC ": Not accepting monitor '%s' for path '%s': FAM daemon not running.",
                     monitor_name.c_str (), Glib::filename_to_utf8 (path_name).c_str ());
          return false;
      }

      watches[monitor_name] = new Bmp::FileMonitor::Monitor::Watch (monitor_name, path_name, func_added, func_removed);

      return true;
  }

  bool
  Monitor::stop_watch (const std::string monitor_name)
  {
      Bmp::FileMonitor::Monitor::Watch* watch;

      watch = watches. find (monitor_name)->second;
      if (!watch) return false;
      watch->terminate_watch();
      watches.erase (monitor_name);
      return true;
  }

 } //FileMonitor

} //Bmp
