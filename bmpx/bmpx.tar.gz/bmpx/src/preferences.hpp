//  BMPx - The Dumb Music Player
//  Copyright (C) 2005-2006 BMPx development team.
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
//
//  --
//
//  The BMPx project hereby grants permission for non GPL-compatible GStreamer
//  plugins to be used and distributed together with GStreamer and BMPx. This
//  permission is above and beyond the permissions granted by the GPL license
//  BMPx is covered by.

#ifndef BMP_UI_PREFERENCES_HPP
#define BMP_UI_PREFERENCES_HPP

#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <glibmm.h>
#include <gtkmm.h>
#include <libglademm.h>
#include <vector>
#include <map>
#include <mcs/mcs.h>

namespace Bmp
{
  class SkinView;

  /** Preferences dialog
   *
   * Bmp::Preferences is a complex dialog for adjusting run time parameters
   * of BMP trough the GUI instead of having to manipulate the configuration
   * file.
   */
  class Preferences
      : public Gtk::Window
  {

  public:

      Preferences (BaseObjectType                        *cobject,
                   const Glib::RefPtr<Gnome::Glade::Xml> &xml);

      static Preferences *
      create ();

      enum AudioSink
      {
          SINK_ALSA,
          SINK_OSS,
          SINK_SUNAUDIO,
          SINK_ESD
      };

  private:

      class CategoryView;
      class ListColumnView;

      enum LastFMNetworkState
      {
          LAST_FM_IDLE,
          LAST_FM_RX,
          LAST_FM_TX,

          LAST_FM_N_IMAGES
      };

#ifndef DOXYGEN_SHOULD_SKIP_THIS
      struct TitleFieldTag
      {
          const gchar *name;
          const gchar *tag;
      };
#endif

#ifndef DOXYGEN_SHOULD_SKIP_THIS
#ifdef HAVE_ALSA
      struct AlsaDevice
      {
	/** Description of the device
	*
	*/
	std::string   description;

	/** ALSA device string of this device
	*
	*/
	std::string   dev;
      
	/** ALSA card id of this device 
	*
	*/
	int	      card_id;

	/** ALSA device id of this device
	*
	*/
	int	      device_id;
      };
      typedef std::vector<AlsaDevice> AlsaDevices;

      struct AlsaCard
      {
	/** Description of the card
	 *
	 */
	std::string   description;

        /** ALSA device string of this card 
         *
         */
	std::string   dev;

        /** ALSA card id of this card 
         *
         */
        int	    card_id;

        /** List of devices on this card 
         *
	 */
        AlsaDevices   devices;  
    };
    typedef std::vector<AlsaCard> AlsaCards;

    /** Returns a list of all ALSA cards present on the system, each containing a list of devices
     *
     * @returns A list of ALSA cards
     *
     */
    AlsaCards
    get_alsa_cards ();

      // ALSA card columns record
      class AlsaCardColumnRecord
          : public Gtk::TreeModel::ColumnRecord
      {
      public:

          Gtk::TreeModelColumn<Glib::ustring> name;
          Gtk::TreeModelColumn<AlsaCard>      card;

          AlsaCardColumnRecord ()
          {
              add (name);
              add (card);
          }
      };

      // ALSA device columns record
      class AlsaDeviceColumnRecord
          : public Gtk::TreeModel::ColumnRecord
      {
      public:

          Gtk::TreeModelColumn<Glib::ustring> name;
          Gtk::TreeModelColumn<AlsaDevice>    device;

          AlsaDeviceColumnRecord ()
          {
              add (name);
              add (device);
          }
      };
#endif

      //Audio System column record
      class AudioSystemColumnRecord
          : public Gtk::TreeModel::ColumnRecord
      {
      public:
          Gtk::TreeModelColumn<Glib::ustring> description;
          Gtk::TreeModelColumn<Glib::ustring> sink_name;
          Gtk::TreeModelColumn<int>           tab_id;
          Gtk::TreeModelColumn<AudioSink>     sink_id;

          AudioSystemColumnRecord()
          {
              add (description);
              add (sink_name);
              add (tab_id);
              add (sink_id);
          }
      };

      AudioSystemColumnRecord  audio_system_columns;

#ifdef HAVE_ALSA
      AlsaCardColumnRecord     alsa_card_columns;
      AlsaDeviceColumnRecord   alsa_device_columns;
#endif

#endif

      void
      on_category_changed ();

      //audio
      void
      on_cbox_audio_system_changed ();

#ifdef HAVE_ALSA
      void
      on_cbox_alsa_card_changed ();
#endif
      void
      setup_audio ();

      void
      on_skin_changed ();

      //last.fm
      bool
      scrobbler_set_idle_image ();
      bool
      scrobbler_set_tx_image ();
      void
      on_scrobbler_queue_size (unsigned int queue_size);
      void
      on_scrobbler_submit_end ();
      void
      on_scrobbler_submit_start ();


      ////mcs subscriptions
      void
      mcs_display_tooltips_changed (MCS_CB_DEFAULT_SIGNATURE);
      void
      mcs_lastfm_enable_changed (MCS_CB_DEFAULT_SIGNATURE);
      void
      mcs_lastfm_general_enable_changed (MCS_CB_DEFAULT_SIGNATURE);

      Glib::RefPtr<Gnome::Glade::Xml>    ref_xml;

      Gtk::Button                       *close;
      Gtk::Window                       *window;

      Gtk::Label                        *l_queue_size,
                                        *l_version;

      Gtk::Image                        *last_fm_netstatus;
      Gtk::ToggleButton                 *last_fm_enable;

      CategoryView                      *category_view;
      SkinView                          *skin_view;
      ListColumnView                    *list_column_view;

      Gtk::Notebook                     *notebook_skins,
                                        *notebook_categories,
                                        *notebook_audio_system;

      // Audio general stuff
      std::map<Glib::ustring,bool>       available_sinks;
      Glib::RefPtr<Gtk::ListStore>       list_store_audio_systems;
      Gtk::ComboBox                     *cbox_audio_system;
      Gtk::Button                       *b_audio_system_apply;
      Gtk::HBox                         *hbox_warning;

      void
      set_apply_sensitive ();
      void
      on_b_audio_system_apply ();

#ifdef HAVE_ALSA
      // ALSA
      Gtk::ComboBox                     *cbox_alsa_card;
      Gtk::ComboBox                     *cbox_alsa_device;
      Gtk::SpinButton                   *alsa_buffer_time;
      Glib::RefPtr<Gtk::ListStore>       list_store_alsa_cards;
      Glib::RefPtr<Gtk::ListStore>       list_store_alsa_device;
#endif
      // OSS
      Gtk::ComboBoxEntry                *cbe_oss_device;
      Gtk::SpinButton                   *oss_buffer_time;

      // ESD
      Gtk::Entry                        *esd_host;
      Gtk::SpinButton                   *esd_buffer_time;

#ifdef HAVE_SUNAUDIO
      // SUNAUDIO
      Gtk::ComboBoxEntry                *cbe_sun_device;
      Gtk::SpinButton                   *sun_buffer_time;
#endif

      Glib::RefPtr<Gtk::ListStore>       list_store_skins;
      Glib::RefPtr<Gtk::ListStore>       list_store_categories;
      Glib::RefPtr<Gtk::ListStore>       list_store_columns;

      Glib::RefPtr<Gtk::TreeSelection>   category_selection;
      Glib::RefPtr<Gtk::TreeSelection>   skin_selection;

      // Last.FM indicators
      Glib::RefPtr<Gdk::Pixbuf>          network[LAST_FM_N_IMAGES];

  }; // Preferences

} // namespace Bmp

#endif // BMP_UI_PREFERENCES_HPP
