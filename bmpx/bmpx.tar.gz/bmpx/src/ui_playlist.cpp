#include <config.h>

#include <cstring>

#include <glib/gi18n.h>
#include <glibmm.h>

#include <gtkmm.h>
#include <gtk/gtk.h>

#include <chroma/chroma-list.h>
#include <chroma/chroma-list-selection.h>
#include <chroma/chroma-vscrollbar.h>

#include <bmp/widgets/bmp_window.h>

#include <goa/libgoa.h>

#include <gdk/gdkx.h>
#include <gdk/gdkkeysyms.h>

#include "xdb.hpp"
#include "ui.hpp"
#include "ui_main.hpp"
#include "ui_util.hpp"

#include "main.hpp"
#include "paths.hpp"
#include "trackinfo.hpp"

using namespace Bmp;

G_DEFINE_TYPE (BmpWindowPlaylist, bmp_window_playlist, G_TYPE_OBJECT)

struct BmpPlaylistComponentT
{
	gchar	   *name;
	guint	    x_origin;
	guint	    y_origin;
	guint	    width;
	guint	    height;
	GdkPixbuf  *pixbuf;
};

#define BMP_UIC_PL_INFORMATION  "bmp_pct_pl_information"

#define BMP_UIC_PL_TITLE        "bmp_pct_pl_title"
#define BMP_UIC_PL_TITLE_NOFOCUS     "bmp_pct_pl_title_nf"

#define BMP_UIC_PL_PAD_TOP      "bmp_pct_pl_pad_top"
#define BMP_UIC_PL_PAD_TOP_NOFOCUS   "bmp_pct_pl_pad_top_nf"

#define BMP_UIC_PL_PAD_BOTTOM   "bmp_pct_pl_pad_bottom"

#define BMP_UIC_PL_CORNER_UL    "bmp_pct_pl_corner_ul"
#define BMP_UIC_PL_CORNER_UL_NOFOCUS "bmp_pct_pl_corner_ul_nf"

#define BMP_UIC_PL_CORNER_UR    "bmp_pct_pl_corner_ur"
#define BMP_UIC_PL_CORNER_UR_NOFOCUS "bmp_pct_pl_corner_ur_nf"

#define BMP_UIC_PL_EDGE_LEFT    "bmp_pct_pl_edge_left"
#define BMP_UIC_PL_EDGE_RIGHT   "bmp_pct_pl_edge_right"

#define BMP_UIC_PL_CORNER_LL    "bmp_pct_pl_corner_ll"
#define BMP_UIC_PL_CORNER_LR    "bmp_pct_pl_corner_lr"

static BmpPlaylistComponentT bmp_playlist_component_data[] = {

  {BMP_UIC_PL_TITLE,         26,  0, 100, 20 },
  {BMP_UIC_PL_TITLE_NOFOCUS,      26, 21, 100, 20 },

  {BMP_UIC_PL_PAD_TOP,      127,  0,  25, 20 },
  {BMP_UIC_PL_PAD_TOP_NOFOCUS,   127, 21,  25, 20 },

  {BMP_UIC_PL_PAD_BOTTOM,   179,  0,  25, 38 },

  {BMP_UIC_PL_CORNER_UL,      0,  0,  25, 20 },
  {BMP_UIC_PL_CORNER_UL_NOFOCUS,   0, 21,  25, 20 },

  {BMP_UIC_PL_CORNER_UR,    153,  0,  25, 20 },
  {BMP_UIC_PL_CORNER_UR_NOFOCUS, 153, 21,  25, 20 },

  {BMP_UIC_PL_EDGE_LEFT,      0, 42,  12, 29 },
  {BMP_UIC_PL_EDGE_RIGHT,    32, 42,  19, 29 },

  {BMP_UIC_PL_CORNER_LL,      0, 72, 125, 38 },
  {BMP_UIC_PL_CORNER_LR,    126, 72, 150, 38 },

  {BMP_UIC_PL_INFORMATION,  205,  0,  75, 32 }

};

#define VSCROLLBAR_DEFAULT_WIDTH 14

#define PLAYLIST_INNER_XMARGIN 20
#define PLAYLIST_INNER_YMARGIN 42

#define PLAYLIST_ROOT_X 12
#define PLAYLIST_ROOT_Y 24

#define PLAYLIST_INNERPAD 2


#define REGION_L(x1,x2,y1,y2,w,h)                   \
    (event->x >= (x1) && event->x < (x2) &&     \
     event->y >= h - (y1) &&  \
     event->y < h - (y2))

#define REGION_R(x1,x2,y1,y2,w,h) \
    ((event->x >= (w-x1)) && \
     (event->x < (w-x2)) && \
     (event->y >= (h-y1)) && \
     (event->y < (h-y2)))

static GtkActionEntry bmp_actions_PL[] = {

  { "dummy-tracklist-keep-remove", NULL, N_("Keep/Remove...") },

  { BMP_ACTION_TRACKLIST_EXPORT,
	GTK_STOCK_SAVE,
	N_("Export Tracklist"), "<ctrl>e",
	NULL, G_CALLBACK (bmp_ui_callback_export_tracklist)},

  { BMP_ACTION_FILEINFO,
	GTK_STOCK_INFO,    N_("Track Information"),      "I",
	NULL, G_CALLBACK (bmp_ui_callback_trackinfo)},

  { BMP_ACTION_TRACKLIST_ADD_CD,
	GTK_STOCK_CDROM,   N_("Add CD..."),             "<shift>C",
	NULL, G_CALLBACK (bmp_ui_callback_add_cd)},
  { BMP_ACTION_TRACKLIST_ADD,
	GTK_STOCK_ADD,    N_("Add Files..."),           "F",
	NULL, G_CALLBACK (bmp_ui_callback_add_files)},
  { BMP_ACTION_TRACKLIST_ADD_TO_NEW,
	GTK_STOCK_ADD,    N_("Add Files to New..."),  "<shift>F",
	NULL, G_CALLBACK (NULL)},
  { BMP_ACTION_TRACKLIST_DEL,
	GTK_STOCK_DELETE, N_("Remove Selected"),       "Delete",
	NULL, G_CALLBACK (bmp_ui_callback_del_files)},
  { BMP_ACTION_TRACKLIST_CROP,
	GTK_STOCK_CUT,    N_("Remove Unselected"),     "<ctrl>X",
	NULL, G_CALLBACK (bmp_ui_callback_crop_files)},
  { BMP_ACTION_TRACKLIST_DEL_ALL,
	GTK_STOCK_CLEAR,  N_("Remove All"),            NULL,
	NULL, G_CALLBACK (bmp_ui_callback_del_files_all)},
  { BMP_ACTION_CLEAR_PLAYBACK_HISTORY,
	GTK_STOCK_UNDO,  N_("Clear Playback History"), "<shift>e",
	NULL, G_CALLBACK (bmp_ui_callback_clear_playback_history)},

  { BMP_ACTION_TRACKLIST_LIBRARY,
	GTK_STOCK_FIND,    N_("Music Library"),  "L",
	NULL, G_CALLBACK (bmp_ui_callback_library)},

  { BMP_ACTION_TRACKLIST_STREAMS,
	GTK_STOCK_NETWORK, N_("Radio Streams"),  "R",
	NULL, G_CALLBACK (bmp_ui_callback_streams)},

  { BMP_ACTION_JTT,
	GTK_STOCK_JUMP_TO, N_("Jump To Track"),  "J",
	NULL, G_CALLBACK (bmp_ui_callback_jtt)},

  { BMP_ACTION_TRACKLIST_KEEP_ARTIST,
	GTK_STOCK_APPLY,  N_("Keep Artist"),           NULL,
	NULL, G_CALLBACK (bmp_ui_callback_keep_artist)},
  { BMP_ACTION_TRACKLIST_KEEP_ALBUM,
	GTK_STOCK_APPLY,  N_("Keep Album"),            NULL,
	NULL, G_CALLBACK (bmp_ui_callback_keep_album)},

   { BMP_ACTION_TRACKLIST_REMOVE_ARTIST,
	GTK_STOCK_CUT,  N_("Remove Artist"),           "",
	NULL, G_CALLBACK (bmp_ui_callback_remove_artist)},
   { BMP_ACTION_TRACKLIST_REMOVE_ALBUM,
	GTK_STOCK_CUT,  N_("Remove Album"),            "",
	NULL, G_CALLBACK (bmp_ui_callback_remove_album)},



  { BMP_ACTION_TRACKLIST_SELECT_ALL,
	NULL,N_("Select All"),            "<control>a",
	NULL, G_CALLBACK (bmp_ui_callback_select_all_files)},
  { BMP_ACTION_TRACKLIST_SELECT_NONE,
	NULL,N_("Select None"),           "<control><shift>a",
	NULL, G_CALLBACK (bmp_ui_callback_unselect_all_files)},
  { BMP_ACTION_TRACKLIST_SELECT_INVERT,
	NULL,N_("Invert Selection"),      NULL,
	NULL, G_CALLBACK (bmp_ui_callback_invert_selection)},


  { BMP_ACTION_SORT_VISIBLE,
	NULL,N_("Sort by Visible Title"),      "<shift>s",
	NULL, G_CALLBACK (bmp_ui_callback_sort_current_list)},
  { BMP_ACTION_SORT_ARTIST,
	NULL,N_("Sort by Artist"),             NULL,
	NULL, G_CALLBACK (bmp_ui_callback_sort_current_list_artist)},
  { BMP_ACTION_SORT_ALBUM,
	NULL,N_("Sort by Album"),              NULL,
	NULL, G_CALLBACK (bmp_ui_callback_sort_current_list_album)},
  { BMP_ACTION_SORT_TITLE,
	NULL,N_("Sort by Title"),              NULL,
	NULL, G_CALLBACK (bmp_ui_callback_sort_current_list_title)},
  { BMP_ACTION_SORT_GENRE,
	NULL,N_("Sort by Genre"),              NULL,
	NULL, G_CALLBACK (bmp_ui_callback_sort_current_list_genre)},
  { BMP_ACTION_SORT_TRACK,
	NULL,N_("Sort by Tracknumber"),        NULL,
	NULL, G_CALLBACK (bmp_ui_callback_sort_current_list_track)},
  { BMP_ACTION_SORT_LOCATION,
	NULL,N_("Sort by Location"),           NULL,
	NULL, G_CALLBACK (bmp_ui_callback_sort_current_list_location)}
};

static GtkToggleActionEntry bmp_toggle_actions_PL[] = {

  { BMP_TOGGLE_ACTION_FOLLOW_CURRENT,
	NULL,
	N_("Follow Currently Played Track"),
	NULL,
	NULL,
	G_CALLBACK (NULL),
	FALSE }
};

static void
window_playlist_create (BmpWindowPlaylist *self);

static void
window_playlist_dispose (GObject *gobject);

static gboolean
window_playlist_hide (BmpWindowPlaylist *self);

static void
resize_widgets (BmpWindowPlaylist *self, gint w, gint h);

static void
playlist_resize_widgets (BmpWindowPlaylist *self);

static void
tracklist_set_action_states (BmpWindowPlaylist *self, GtkTreePath *path);

/* GObject stuff */

struct _BmpWindowPlaylistPrivate {

    gboolean dispose_has_run;

//    GtkTreeModel      *filtermodel;
    GHashTable	      *ui_components;
    gint	       columns_visible;
    guint	       timeout_src_id_start_shade;
    gboolean	       in_window;
    gboolean	       focused;
};

void
destroy_value(gpointer data)
{
  BmpPlaylistComponentT *pct;
  pct = (BmpPlaylistComponentT *) data;
  if (pct)
    {
      if (pct->pixbuf) g_object_unref (pct->pixbuf);
      g_free(pct);
    }
}

static int
tracklist_compare_func
	        (GtkTreeModel *model,
                 GtkTreeIter  *a,
                 GtkTreeIter  *b,
                 gpointer      data)

{
	int cmp_result;
	Bmp::Library::DatumDefine define = library->get_metadatum_define (vcolumns_get_item_nth (GPOINTER_TO_INT(data)));
	

	if (define.type == Bmp::DB::VALUE_TYPE_INT)
	  {
		int val_a, val_b;
		gtk_tree_model_get (model, a, GPOINTER_TO_INT(data), &val_a, -1);
		gtk_tree_model_get (model, b, GPOINTER_TO_INT(data), &val_b, -1);
		return val_a - val_b;
	  }
	else
	  {
		char  *text_a,
		      *text_b;

		char  *string_a,
		      *string_b;

		gtk_tree_model_get (model, a, GPOINTER_TO_INT(data), &text_a, -1);
		gtk_tree_model_get (model, b, GPOINTER_TO_INT(data), &text_b, -1);

		if ( (text_a != NULL) && (text_b == NULL)) return  1;
		if ( (text_a == NULL) && (text_b == NULL)) return  0;
		if ( (text_a == NULL) && (text_b != NULL)) return -1;

		string_a = g_utf8_casefold (text_a, std::strlen(text_a));
		string_b = g_utf8_casefold (text_b, std::strlen(text_b));

		if ( (string_a != NULL) && (string_b == NULL)) return  1;
		if ( (string_a == NULL) && (string_b == NULL)) return  0;
		if ( (string_a == NULL) && (string_b != NULL)) return -1;

		cmp_result = g_utf8_collate (string_a, string_b);

		g_free (string_a);
		g_free (string_b);
		g_free (text_a);
		g_free (text_b);

		return cmp_result;
	  }
}

static void
tracklist_cell_data_func   (ChromaList      *self,
                            GtkTreeModel    *model,
                            GtkTreeIter     *iter,
                            GValue          *value,
                            gpointer         data)
{
    int   minutes, seconds;
    int   i_time; 
    char *s_time;

    gtk_tree_model_get (model, iter, 6, &i_time, -1);

    g_value_unset (value);

    minutes = i_time / 60;
    seconds = i_time % 60;

    g_value_init (value, G_TYPE_STRING);
    s_time = g_strdup_printf ("%d:%-2.2d", minutes, seconds);
    g_value_set_string (value, s_time);
    g_free (s_time);
}

static BmpPlaylistComponentT*
playlist_get_component(BmpWindowPlaylist *self, const gchar *key)
{
  return static_cast<BmpPlaylistComponentT*>(g_hash_table_lookup(self->priv->ui_components, key));
}

static void
window_playlist_set_geometry_hints(BmpWindowPlaylist *self)
{
    BmpWindow *window = BMP_WINDOW(self->window);
    GdkGeometry geometry;
    GdkWindowHints mask;

    geometry.width_inc = 25;
    geometry.height_inc = 29;

    /* make sure the min width/height are multiple values of the resize increments */
    geometry.min_width = ((int) (BMP_WINDOW_MAIN_WIDTH * 1 / geometry.width_inc)) * geometry.width_inc;
    geometry.max_width = 0xFFFF;
    geometry.base_width = 0;

    /* make sure the min width/height are multiple values of the resize increments */
    geometry.min_height = ((int) (BMP_WINDOW_MAIN_HEIGHT * 2 / geometry.height_inc)) * geometry.height_inc;
    geometry.max_height = 0xFFFF;
    geometry.base_height = 0;

    mask = GdkWindowHints (GDK_HINT_MIN_SIZE | GDK_HINT_MAX_SIZE | GDK_HINT_RESIZE_INC | GDK_HINT_BASE_SIZE);

    gtk_window_set_geometry_hints  (GTK_WINDOW(window),
                                    GTK_WIDGET(window),
                                    &geometry,
				    mask);

}

static gboolean
on_window_playlist_delete_event (GtkWidget *widget, GdkEvent *event, BmpWindowPlaylist *self)
{
    gtk_toggle_action_set_active (GTK_TOGGLE_ACTION(gtk_action_group_get_action (bmp_toggle_actions, BMP_TOGGLE_ACTION_PL)), FALSE);
    return TRUE;
}

static gboolean
on_window_playlist_focus_out	(GtkWidget	      *widget,
				 GdkEventFocus	      *event,
				 BmpWindowPlaylist    *self)
{
    self->priv->focused = FALSE;
    gtk_widget_queue_draw (widget);
    return FALSE;
}

static gboolean
on_window_playlist_focus_in	(GtkWidget	      *widget,
				 GdkEventFocus	      *event,
				 BmpWindowPlaylist    *self)
{
    self->priv->focused = TRUE;
    gtk_widget_queue_draw (widget);
    return FALSE;
}

static gboolean
on_window_playlist_canvas_expose (GtkWidget *widget, GdkEventExpose *event, BmpWindowPlaylist *self)
{
  BmpPlaylistComponentT      *pct;
  cairo_t	      *cr;
  guint		       w_width,
		       w_height,
		       pad_ctr = 0,
		       i = 0;

  static unsigned int  width_p  = -1,
		       height_p = -1;

  gboolean	       focus;

  focus = self->priv->focused;
  w_width = widget->allocation.width;
  w_height = widget->allocation.height;

  cr = gdk_cairo_create (widget->window);

  pad_ctr =  (w_width - 150)/25;

  pct = playlist_get_component(self, focus ? BMP_UIC_PL_CORNER_UL : BMP_UIC_PL_CORNER_UL_NOFOCUS);
  bmp_draw_pixbuf_simple(cr, pct->pixbuf, 0, 0);

  pct = playlist_get_component(self, focus ? BMP_UIC_PL_CORNER_UR : BMP_UIC_PL_CORNER_UR_NOFOCUS);
  bmp_draw_pixbuf_simple(cr, pct->pixbuf, (w_width-pct->width), 0);

  pct = playlist_get_component(self, focus ? BMP_UIC_PL_TITLE : BMP_UIC_PL_TITLE_NOFOCUS);
  bmp_draw_pixbuf_simple(cr, pct->pixbuf, (w_width/2)-(50), 0);

  pct = playlist_get_component(self, BMP_UIC_PL_CORNER_LL);
  bmp_draw_pixbuf_simple(cr, pct->pixbuf, 0, (w_height-pct->height));

  pct = playlist_get_component(self, BMP_UIC_PL_CORNER_LR);
  bmp_draw_pixbuf_simple(cr, pct->pixbuf, (w_width-pct->width), (w_height-pct->height));

  pct = playlist_get_component(self, focus ? BMP_UIC_PL_PAD_TOP : BMP_UIC_PL_PAD_TOP_NOFOCUS);

  for (i = 0; i < pad_ctr / 2; i++)
    {

        /* Left of title */
	bmp_draw_pixbuf_simple(cr, pct->pixbuf, 25 + i * 25, 0);

        /* Right of title */
	bmp_draw_pixbuf_simple(cr, pct->pixbuf, (w_width+100)/2+i*25, 0);
    }

  if (pad_ctr & 1)
    {
        /* Odd tile count, so one remaining to draw. Here we split
         * it into two and draw half on either side of the title */

	gdk_draw_pixbuf(widget->window,
                        NULL,
                        pct->pixbuf,
			0,
                        0,
                        (w_width/2)+((pad_ctr/2)*25) +50,
                        0,
                        13,
                        -1,
                        GDK_RGB_DITHER_NONE,
                        0,
                        0);

	gdk_draw_pixbuf(widget->window,
                        NULL,
                        pct->pixbuf,
			0,
                        0,
			((pad_ctr / 2) * 25) + 25,
                        0,
                        13,
                        -1,
                        GDK_RGB_DITHER_NONE,
                        0,
                        0);
      }

    /* Frame sides */
    for (i = 0; i < (w_height - (20 + 38)) / 29; i++)
      {
            pct = playlist_get_component(self, BMP_UIC_PL_EDGE_LEFT);
            gdk_draw_pixbuf(widget->window,
                        NULL,
                        pct->pixbuf,
                        0,
                        0,
			0,
                        20 + i *29,
                        -1,
                        -1,
                        GDK_RGB_DITHER_NONE,
                        0,
                        0);

            pct = playlist_get_component(self, BMP_UIC_PL_EDGE_RIGHT);
            gdk_draw_pixbuf(widget->window,
                        NULL,
                        pct->pixbuf,
                        0,
                        0,
			w_width-19,
                        20 + i *29,
                        -1,
                        -1,
                        GDK_RGB_DITHER_NONE,
                        0,
                        0);

      }

    pad_ctr =  (w_width - 275) / 25;
    pct = playlist_get_component(self, BMP_UIC_PL_PAD_BOTTOM);

    for (i = 0; i < pad_ctr+4; i++)
      {
	bmp_draw_pixbuf_simple(cr, pct->pixbuf, (125+i*25), (w_height-pct->height));
      }
    bmp_draw_pixbuf_simple(cr, pct->pixbuf, (125+(pad_ctr+3)*25) + 5, (w_height-pct->height));

    cairo_destroy (cr);

    if ((w_width == width_p) && (w_height == height_p))
        return TRUE;

    width_p = w_width;
    height_p = w_height;

    return FALSE;
}

/* Action adapters */
static void
tracklist_has_sel (BmpWindowPlaylist *self, gboolean active)
{
	gtk_action_set_sensitive (gtk_action_group_get_action (bmp_actions, BMP_ACTION_TRACKLIST_DEL), active);
	gtk_action_set_sensitive (gtk_action_group_get_action (bmp_actions, BMP_ACTION_TRACKLIST_CROP), active);
}

static void
tracklist_has_items (BmpWindowPlaylist *self, gboolean active)
{
	gtk_action_set_sensitive (gtk_action_group_get_action (bmp_actions, BMP_ACTION_TRACKLIST_EXPORT), active);
	gtk_action_set_sensitive (gtk_action_group_get_action (bmp_actions, BMP_ACTION_TRACKLIST_DEL_ALL), active);
	gtk_action_set_sensitive (gtk_action_group_get_action (bmp_actions, BMP_ACTION_PLAY), active);
	gtk_action_set_sensitive (gtk_action_group_get_action (bmp_actions, BMP_ACTION_JTT), active);
}

static void
tracklist_sel (BmpWindowPlaylist *self, gboolean active)
{
	gtk_action_set_sensitive (gtk_action_group_get_action (bmp_actions, BMP_ACTION_TRACKLIST_SELECT_INVERT), active);
	gtk_action_set_sensitive (gtk_action_group_get_action (bmp_actions, BMP_ACTION_TRACKLIST_SELECT_NONE), active);
	gtk_action_set_sensitive (gtk_action_group_get_action (bmp_actions, BMP_ACTION_TRACKLIST_SELECT_ALL), active);
}

#if 0
static void
tracklist_sort (BmpWindowPlaylist *self, gboolean active)
{
	gtk_action_set_sensitive (gtk_action_group_get_action (bmp_actions, BMP_ACTION_SORT_LOCATION), active);
	gtk_action_set_sensitive (gtk_action_group_get_action (bmp_actions, BMP_ACTION_SORT_TRACK), active);
	gtk_action_set_sensitive (gtk_action_group_get_action (bmp_actions, BMP_ACTION_SORT_VISIBLE), active);
	gtk_action_set_sensitive (gtk_action_group_get_action (bmp_actions, BMP_ACTION_SORT_ARTIST), active);
	gtk_action_set_sensitive (gtk_action_group_get_action (bmp_actions, BMP_ACTION_SORT_ALBUM), active);
	gtk_action_set_sensitive (gtk_action_group_get_action (bmp_actions, BMP_ACTION_SORT_TITLE), active);
	gtk_action_set_sensitive (gtk_action_group_get_action (bmp_actions, BMP_ACTION_SORT_GENRE), active);
}
#endif

static void
on_bmp_display_tracklist_numbers_changed
(MCS_CB_DEFAULT_SIGNATURE, BmpWindowPlaylist *self)
{
    chroma_list_set_use_numbers (CHROMA_LIST(c_tracklist), boost::get<bool>(value));
}

static void
on_bmp_use_custom_cursors_changed
(MCS_CB_DEFAULT_SIGNATURE, BmpWindowPlaylist *self)
{
    bmp_window_playlist_configure (self);
}

static void
on_bmp_font_changed
(MCS_CB_DEFAULT_SIGNATURE, BmpWindowPlaylist *self)
		
{
    chroma_list_set_font (CHROMA_LIST(c_tracklist), pango_font_description_from_string (boost::get<std::string>(value) . c_str ()));
}

static void
window_playlist_create_actions (BmpWindowPlaylist *self)
{
  GError    *error = NULL;
  gchar	    *filename = NULL;

  gtk_action_group_add_actions (bmp_actions,
			        bmp_actions_PL,
				G_N_ELEMENTS (bmp_actions_PL),
				NULL);

  gtk_action_group_add_toggle_actions (bmp_toggle_actions,
				       bmp_toggle_actions_PL,
				       G_N_ELEMENTS (bmp_toggle_actions_PL),
				       NULL);

  gtk_action_group_set_sensitive (bmp_actions, TRUE);

  filename = g_build_filename (DATA_DIR, BMP_UI_BASENAME,"tracklist.ui",NULL);
  if (!gtk_ui_manager_add_ui_from_file (bmp_ui_manager, filename, &error))
      {
	g_message ("building menus failed: %s", error->message);
	g_error_free (error);
	error = NULL;
      }
  g_free (filename);

}

static void
adapt_cursor (BmpWindowPlaylist *self, gint x, gint y)
{
   BmpWindow *window = BMP_WINDOW(self->window);
   gint w_width, w_height;

   w_width = GTK_WIDGET(window)->allocation.width;
   w_height = GTK_WIDGET(window)->allocation.height;
}

static gboolean
on_window_playlist_key_press (GtkWidget   *widget,
                              GdkEventKey *event,
                              gpointer     user_data)
{
    g_return_val_if_fail (GTK_IS_WIDGET (widget), FALSE);

    if (event->keyval == GDK_Escape)
    {
        GtkAction *action;

        action = gtk_action_group_get_action (bmp_actions, BMP_ACTION_ICONIFY);
        gtk_action_activate (action);
    }

    return FALSE;
}

static gboolean
on_window_playlist_button_press (GtkWidget	    *widget,
			         GdkEventButton	    *event,
			         BmpWindowPlaylist  *self)
{
    gint x, y;
    gint w_width, w_height;

    g_return_val_if_fail (GTK_IS_WIDGET (widget), FALSE);

    x = int (event->x);
    y = int (event->y);
    w_width = GTK_WIDGET(widget)->allocation.width;
    w_height = GTK_WIDGET(widget)->allocation.height;

    if ( ((event->type == GDK_BUTTON_PRESS) && (event->button == 1) && (y < 24) && (x < (widget->allocation.width - 12))) ||
         ((event->type == GDK_BUTTON_PRESS) && (event->button == 1) && ((event->x > 130) && (event->x < (w_width-40)) && (event->y > (w_height - PLAYLIST_INNER_YMARGIN)))))
      {
	gdk_window_begin_move_drag (GTK_WIDGET(widget)->window,
				    event->button,
				    int (event->x_root),
				    int (event->y_root),
				    event->time);

	return FALSE;
      }
    else if ((event->type == GDK_BUTTON_PRESS) && (event->button == 1) && (y < 16) && (x > (widget->allocation.width - 12)) )
      {
	GtkToggleAction *action;
	action = GTK_TOGGLE_ACTION (gtk_action_group_get_action (bmp_toggle_actions, BMP_TOGGLE_ACTION_PL));
	gtk_toggle_action_set_active (action, FALSE);
	return TRUE;
      }

    return FALSE;
}

static gboolean
on_window_playlist_canvas_button_press (GtkWidget	  *widget,
					GdkEventButton	  *event,
					BmpWindowPlaylist *self)
{
    GtkWidget *menu;
    GtkRequisition req;
    gint x, y, w_width, w_height, w_xpos, w_ypos;

    g_return_val_if_fail (GTK_IS_WIDGET (widget), FALSE);

    gtk_window_get_size (GTK_WINDOW (self->window), &w_width, &w_height);
    gtk_window_get_position (GTK_WINDOW (self->window), &w_xpos, &w_ypos);

    x = int (event->x);
    y = int (event->y);

    if (event->button == 3)
      {
			GtkTreePath *path;
			path = chroma_list_selection_get_selected (CHROMA_LIST_SELECTION(c_tracklist));
			tracklist_set_action_states (self, path);
			tracklist_sel (self, (path != NULL) ? TRUE : FALSE);

			gtk_action_set_sensitive (gtk_action_group_get_action (bmp_actions, BMP_ACTION_FILEINFO),
						 ((path != NULL) && (!chroma_list_selection_multiple_selected (CHROMA_LIST_SELECTION(c_tracklist)))));

			gtk_tree_path_free (path);

#if 0
			gtk_action_set_sensitive (gtk_action_group_get_action (bmp_actions, BMP_ACTION_TRACKLIST_KEEP_ARTIST),
						  !chroma_list_get_multiple_selected (CHROMA_LIST(chroma_widgets[BMP_CHROMA_LIST_TRACKLIST]->widget)));
			gtk_action_set_sensitive (gtk_action_group_get_action (bmp_actions, BMP_ACTION_TRACKLIST_KEEP_ALBUM),
						  !chroma_list_get_multiple_selected (CHROMA_LIST(chroma_widgets[BMP_CHROMA_LIST_TRACKLIST]->widget)));
			gtk_action_set_sensitive (gtk_action_group_get_action (bmp_actions, BMP_ACTION_TRACKLIST_REMOVE_ARTIST),
						  !chroma_list_get_multiple_selected (CHROMA_LIST(chroma_widgets[BMP_CHROMA_LIST_TRACKLIST]->widget)));
			gtk_action_set_sensitive (gtk_action_group_get_action (bmp_actions, BMP_ACTION_TRACKLIST_REMOVE_ALBUM),
						  !chroma_list_get_multiple_selected (CHROMA_LIST(chroma_widgets[BMP_CHROMA_LIST_TRACKLIST]->widget)));
#endif

#if 0
		       if (mcs->key_get<bool>("bmp", "playlist-popup"))
		            {
			  	  GSource *source;

				  if (self->priv->timeout_src_id_start_shade)
			      	    {
			      	      source = g_main_context_find_source_by_id (NULL, self->priv->timeout_src_id_start_shade);
				      if (source)
			  		{
			  		  g_source_destroy (source);
			  		  self->priv->timeout_src_id_start_shade = 0;
			    		}
			  	    }

			          gtk_toggle_action_set_active (GTK_TOGGLE_ACTION(gtk_action_group_get_action (bmp_toggle_actions,
						  		BMP_TOGGLE_ACTION_PLAYLIST_SHADE)), FALSE);

			          gtk_toggle_action_set_active (GTK_TOGGLE_ACTION(gtk_action_group_get_action (bmp_toggle_actions,
						  		BMP_TOGGLE_ACTION_PL)), TRUE);

		            }
#endif

			menu = ui_manager_get_popup (bmp_ui_manager, "/popup-tracklist/menu-tracklist");
			gtk_menu_popup (GTK_MENU(menu), NULL, NULL, NULL, NULL, event->button, event->time);
			return FALSE;
	}

    if (event->button == 1)
      {
	if (REGION_L(12, 37, 29, 11, w_width, w_height))
	  {
	        /* ADD button menu */
		menu = ui_manager_get_popup (bmp_ui_manager, "/popup-tracklist/menu-add");
		gtk_widget_size_request (menu, &req);
		bmp_menu_popup (GTK_MENU(menu), (w_xpos+14), (w_ypos+w_height) - 8 - req.height, event->button, event->time);
		return FALSE;
	  }
#if 0
	else
	if REGION_L(41, 66, 29, 11, w_width, w_height)
	  {
	        /* SUB button menu */

		GList *paths;
		paths = chroma_list_selection_get_selected_paths (CHROMA_LIST_SELECTION(c_tracklist));
		tracklist_set_action_states (self, paths);
		if (paths) g_list_foreach (paths, (GFunc)gtk_tree_path_free, NULL);

		menu = ui_manager_get_popup (bmp_ui_manager, "/popup-tracklist/menu-del");
		gtk_widget_size_request (menu, &req);
		bmp_menu_popup (GTK_MENU(menu), (w_xpos+43), (w_ypos+w_height) - 8 - req.height, event->button, event->time);
		return FALSE;
	  }
	else
	if REGION_L(70, 95, 29, 11, w_width, w_height)
	  {
	        /* SEL button menu */
		GList *paths;
		paths = chroma_list_selection_get_selected_paths (CHROMA_LIST_SELECTION(c_tracklist));
		tracklist_sel (self, paths ? TRUE : FALSE);
		if (paths) g_list_foreach (paths, (GFunc)gtk_tree_path_free, NULL);

		menu = ui_manager_get_popup (bmp_ui_manager, "/popup-tracklist/menu-select");
		gtk_widget_size_request (menu, &req);
		bmp_menu_popup (GTK_MENU(menu), (w_xpos+72), (w_ypos+w_height) - 8 - req.height, event->button, event->time);
		return FALSE;
	  }
    	else
	if REGION_L(99, 124, 29, 11, w_width, w_height)
	  {
	        /* MISC button menu */
		GList *paths;
		paths = chroma_list_selection_get_selected_paths (CHROMA_LIST_SELECTION(c_tracklist));
		tracklist_sort (self, paths ? TRUE : FALSE);
		if (paths) g_list_foreach (paths, (GFunc)gtk_tree_path_free, NULL);

		menu = ui_manager_get_popup (bmp_ui_manager, "/popup-tracklist/menu-sort");
		gtk_widget_size_request (menu, &req);
		bmp_menu_popup (GTK_MENU(menu), (w_xpos+101), (w_ypos+w_height) - 8 - req.height, event->button, event->time);
		return FALSE;
	  }
	else if REGION_R(46,23,29,11, w_width, w_height)
	  {
		/* LIST menu */
		menu = ui_manager_get_popup (bmp_ui_manager, "/popup-tracklist/menu-list");
		gtk_widget_size_request (menu, &req);
		bmp_menu_popup (GTK_MENU(menu), w_xpos + w_width - 12 - req.width, (w_ypos+w_height) - 8 - req.height, event->button, event->time);
		return FALSE;
	  }
#endif
        else if ((event->button == 1 && (((w_width-event->x) <= 24) && ((w_height-event->y) <=24))))
	  {
		gtk_window_begin_resize_drag (GTK_WINDOW(self->window),
                                              GDK_WINDOW_EDGE_SOUTH_EAST,
                                              event->button,
                                              int (event->x_root),
                                              int (event->y_root),
                                              event->time);

		adapt_cursor (self, int (event->x), int (event->y));
	        return FALSE;
	  }
   }

  return FALSE;
}

static void
resize_widgets (BmpWindowPlaylist     *self,
		gint		       w,
	        gint		       h)
{
    gint w_list, h_list;
    gint w_scrollbar, h_scrollbar;

    if (!c_tracklist) return;
    if (!c_tracklist_scrollbar) return;

    w_list = w - PLAYLIST_ROOT_X - PLAYLIST_INNER_XMARGIN - VSCROLLBAR_DEFAULT_WIDTH;
    h_list = h - PLAYLIST_ROOT_Y - PLAYLIST_INNER_YMARGIN;
    if ((w_list>0) && (h_list>0))
      {
	gtk_widget_set_size_request (GTK_WIDGET(c_tracklist),
				 w_list,
				 h_list);
      }

    w_scrollbar = VSCROLLBAR_DEFAULT_WIDTH;
    h_scrollbar = h - PLAYLIST_ROOT_Y - PLAYLIST_INNER_YMARGIN + 2;
    if ((w_scrollbar>0)&&(h_scrollbar>0))
      {
	gtk_widget_set_size_request (GTK_WIDGET(c_tracklist_scrollbar),
				 w_scrollbar,
				 h_scrollbar);
      }

    gtk_fixed_move (GTK_FIXED(BMP_WINDOW(self->window)->canvas),
		    c_tracklist_scrollbar,
		    w - PLAYLIST_ROOT_X - PLAYLIST_INNER_XMARGIN - 2,
		    PLAYLIST_ROOT_Y);
}

static gboolean
on_window_playlist_configure (GtkWidget		  *widget,
			      GdkEventConfigure	  *event,
			      BmpWindowPlaylist	  *self)
{
    static gint width_p = -1 ,  height_p = -1;

    g_return_val_if_fail (GTK_IS_WIDGET(widget), FALSE);

    if ((width_p != event->width) || (height_p != event->height))
      {
	resize_widgets (self, event->width, event->height);
	width_p = event->width;
	height_p = event->height;
      }

    return FALSE;
}

static gboolean
on_window_playlist_configure_after (GtkWidget		  *widget,
				    GdkEventConfigure	  *event,
				    BmpWindowPlaylist	  *self)
{
    while (gtk_events_pending()) gtk_main_iteration ();
    return FALSE;
}



static void
tracklist_set_action_states (BmpWindowPlaylist *self, GtkTreePath *path)
{
	if ((!path) && (!chroma_list_selection_multiple_selected (CHROMA_LIST_SELECTION(c_tracklist))))
	  {
	    tracklist_has_sel (self, FALSE);
	  }
	else 
	  {
	    tracklist_has_sel (self, TRUE);
	  }

	tracklist_has_items (self, (chroma_list_get_length (CHROMA_LIST(c_tracklist)) == 0) ? FALSE : TRUE);
}

static gboolean
activate (GtkAction *action)
{
  gtk_action_activate (action);
  return FALSE;
}

static void
on_tracklist_cursor_position (ChromaList	*list,
			      gint		 row,
			      BmpWindowPlaylist *self)
{
    GtkTreePath *path;

    path = chroma_list_selection_get_selected (CHROMA_LIST_SELECTION(list));
    tracklist_set_action_states (self, path);

    if ((row == -1) || (!path)) 
      {
	bmp_ui_trackinfo_clear ();
      }
    else
      {
	GtkAction *action;
	Bmp::TrackInfo *w_trackinfo;

	w_trackinfo = reinterpret_cast<Bmp::TrackInfo*>(RM_GET_ITEM ("dialogs", "dialog-trackinfo", NOLOCK));

	if (w_trackinfo->is_visible())
	  {
	    action = gtk_action_group_get_action (bmp_actions, BMP_ACTION_FILEINFO);
	    g_idle_add ((GSourceFunc)activate, action);
	  }

	gtk_tree_path_free (path);
      }

    bmp_system_control_update_title (bmp_system_control);
}

static void
on_tracklist_dnd (ChromaList	    *list,
		  gint		     index,
		  gchar		   **uri_list,
		  BmpWindowPlaylist *self)
{
    gint new_ctr;

    bmp_system_control_add_uri_list (bmp_system_control,
			(const gchar**) uri_list,
			index,
			FALSE,
			FALSE,
		        0,
			&new_ctr,
			NULL);
}

static void
on_tracklist_row_activated (ChromaList	       *list,
			    gint	        index,
			    BmpWindowPlaylist  *self)
{
    bmp_system_control_play_track (bmp_system_control, index, NULL);
}

static void
playlist_callback_tracklist_list_sorted (BmpSystemControl *system_control, BmpWindowPlaylist *self)
{
    chroma_list_refresh (CHROMA_LIST(c_tracklist));
    playlist_resize_widgets (self);
}

static void
playlist_callback_tracklist_items_removed (BmpSystemControl  *system_control,
					   GArray	     *removed_rows,
					   gint		      n_removed_rows,
					   BmpWindowPlaylist *self)
{
    chroma_list_refresh (CHROMA_LIST(c_tracklist));
    playlist_resize_widgets (self);
}

static void
playlist_callback_tracklist_items_added (BmpSystemControl  *system_control,
					 GArray		   *added_rows,
					 gint		    n_added_rows,
					 BmpWindowPlaylist *self)
{
    chroma_list_refresh (CHROMA_LIST(c_tracklist));
    playlist_resize_widgets (self);
}

void
bmp_window_playlist_column_set_active (BmpWindowPlaylist *self, gint column, gboolean _visible_arg)
{
      gchar     *key_name;
      gboolean   visible;
      gint	 n;

      key_name = g_strdup_printf ("column_%d_visible", column);
      visible = mcs->key_get<bool>("tracklist", key_name);
      g_free (key_name);

      if (visible == _visible_arg) return;

      key_name = g_strdup_printf ("column_%d_visible", column);
      mcs->key_set<bool>("tracklist", key_name, _visible_arg);
      g_free (key_name);

      chroma_list_set_column_visible (CHROMA_LIST(c_tracklist), column, _visible_arg);
      chroma_list_set_column_show_header (CHROMA_LIST(c_tracklist), column, _visible_arg);

      if (_visible_arg)
	{
	  self->priv->columns_visible++;
	}
      else
	{
	  self->priv->columns_visible--;
	}

      for (n = 0; n < vcolumns_get_n_items(); n++)
	{
	    chroma_list_set_column_width (CHROMA_LIST(c_tracklist), n, 1./self->priv->columns_visible);
            key_name = g_strdup_printf ("column_%d_width", n);
	    mcs->key_set<double>("tracklist", key_name, 1./self->priv->columns_visible);
	    g_free (key_name);
	}

    chroma_list_refresh (CHROMA_LIST(c_tracklist));
}

static gboolean
on_window_playlist_enter	(GtkWidget	    *widget,
				 GdkEventCrossing   *event,
				 BmpWindowPlaylist  *self)
{
    self->priv->in_window = TRUE;

    return FALSE;
}

static gboolean
on_window_playlist_leave	(GtkWidget	    *widget,
				 GdkEventCrossing   *event,
				 BmpWindowPlaylist  *self)
{
    self->priv->in_window = FALSE;
    return FALSE;
}

static gboolean
window_playlist_hide (BmpWindowPlaylist *self)
{
    if (!self->priv->in_window)
      {
	  GSource *source;
          gtk_toggle_action_set_active (GTK_TOGGLE_ACTION(gtk_action_group_get_action (bmp_toggle_actions,
					BMP_TOGGLE_ACTION_PL)), FALSE);

	  if (self->priv->timeout_src_id_start_shade)
	    {
		source = g_main_context_find_source_by_id (NULL, self->priv->timeout_src_id_start_shade);
		if (source)
		  {
		    g_source_destroy (source);
		    self->priv->timeout_src_id_start_shade = 0;
		  }
	    }
      }

    return FALSE;
}


void
bmp_window_playlist_start_shade (BmpWindowPlaylist *self)
{
    GSource *source;

    if (self->priv->timeout_src_id_start_shade)
      {
	source = g_main_context_find_source_by_id (NULL, self->priv->timeout_src_id_start_shade);
	if (source)
	  {
	      g_source_destroy (source);
	      self->priv->timeout_src_id_start_shade = 0;
	  }
      }

    self->priv->timeout_src_id_start_shade = g_timeout_add (1200, (GSourceFunc) window_playlist_hide, self);
}

static void
on_system_control_track_change	  (BmpSystemControl	*system_control,
				   BmpWindowPlaylist	*self)
{

    gtk_action_set_sensitive (GTK_ACTION(gtk_action_group_get_action (bmp_actions, BMP_ACTION_CLEAR_PLAYBACK_HISTORY)), TRUE);

    if (mcs->key_get<bool>("bmp", "follow-current-track"))
      {
	  gint	position,
		length,
	        display,
		scroll;

	  position =
	      g_object_get_int (bmp_system_control, "current_index");
	  display =
	      chroma_list_get_n_item_display (CHROMA_LIST(c_tracklist));
	  length =
	      chroma_list_get_length (CHROMA_LIST(c_tracklist));
	  scroll =
	      position - (display/2);

	  if (scroll > (length-display)) scroll = (length-display);
	  if (scroll < 0) scroll = 0;

	  chroma_list_scroll_to_offset (CHROMA_LIST(c_tracklist), scroll);
      }

    gtk_widget_queue_draw (GTK_WIDGET(c_tracklist));
}

static void
playlist_row_swap_func (GtkTreeModel	*model,
			gint		 pos_1,
		        gint		 pos_2)
{
#if 0
    GtkTreeModel *list_store;
#endif
    GtkTreePath  *path_a, *path_b;
    GtkTreeIter   iter_a,  iter_b; //, iter_l_a, iter_l_b;

    path_a = gtk_tree_path_new_from_indices (pos_1, -1);
    path_b = gtk_tree_path_new_from_indices (pos_2, -1);
    gtk_tree_model_get_iter (model, &iter_a, path_a);
    gtk_tree_model_get_iter (model, &iter_b, path_b);
    gtk_tree_path_free (path_a);
    gtk_tree_path_free (path_b);

#if 0
    list_store = gtk_tree_model_filter_get_model (reinterpret_cast<GtkTreeModelFilter*>(model));
    gtk_tree_model_filter_convert_iter_to_child_iter (reinterpret_cast<GtkTreeModelFilter*>(model),
						    &iter_l_a,
						    &iter_a); 
    gtk_tree_model_filter_convert_iter_to_child_iter (reinterpret_cast<GtkTreeModelFilter*>(model),
						    &iter_l_b,
						    &iter_b); 

    gtk_tree_sortable_set_sort_column_id (reinterpret_cast<GtkTreeSortable*>(list_store),
					  GTK_TREE_SORTABLE_UNSORTED_SORT_COLUMN_ID, 
					  GTK_SORT_ASCENDING);

    gtk_list_store_swap (reinterpret_cast<GtkListStore*>(list_store), &iter_l_a, &iter_l_b);
#endif

    gtk_tree_sortable_set_sort_column_id (reinterpret_cast<GtkTreeSortable*>(model),
					  GTK_TREE_SORTABLE_UNSORTED_SORT_COLUMN_ID, 
					  GTK_SORT_ASCENDING);

    gtk_list_store_swap (reinterpret_cast<GtkListStore*>(model), &iter_a, &iter_b);
}

static void
window_playlist_create (BmpWindowPlaylist *self)
{
    BmpWindow		    *window;
    gint		     n, last_visible;
    gdouble		     sum = 0.0;

    self->window = reinterpret_cast<GtkWidget*>(bmp_window_new(GTK_WINDOW_TOPLEVEL));
    window_playlist_set_geometry_hints(self);
    window = reinterpret_cast<BmpWindow*>(self->window);

    if (use_xdb) xdb_add_filter_for_window (reinterpret_cast<GtkWindow*>(self->window), "Playlist", FALSE);

    window_playlist_create_actions (self);

    bmp_window_set_icon_list (reinterpret_cast<GtkWidget*>(window), "playlist");

    gtk_window_set_title (reinterpret_cast<GtkWindow*>(window), _("Tracklist - BMP"));
    gtk_window_set_role (reinterpret_cast<GtkWindow*>(window), "bmp::window-playlist");

    /* Tracklist */
    c_tracklist = chroma_list_new ();
    c_tracklist_scrollbar = chroma_vscrollbar_new ();
    g_object_set_data (G_OBJECT(c_tracklist_scrollbar), "list", c_tracklist);

    chroma_list_set_adjustment	(reinterpret_cast<ChromaList*>(c_tracklist),
				 reinterpret_cast<ChromaVScrollbar*>(c_tracklist_scrollbar));

//    self->priv->filtermodel = gtk_tree_model_filter_new (reinterpret_cast<GtkTreeModel*>(bmp_playlist_get_playlist (bmp_playlist)), NULL);

    chroma_list_set_model	(CHROMA_LIST (c_tracklist),
//			         self->priv->filtermodel, 
			         reinterpret_cast<GtkTreeModel*>(bmp_playlist_get_playlist (bmp_playlist)),
				 ChromaListRowSwapFunc (playlist_row_swap_func));

    chroma_list_set_use_numbers (CHROMA_LIST (c_tracklist), mcs->key_get<bool>("bmp", "display-tracklist-numbers"));

    for (n = 0; n < vcolumns_get_n_items(); n++)
      {
	    Bmp::Library::DatumDefine define = library->get_metadatum_define (vcolumns_get_item_nth(n));
            chroma_list_set_column_header (CHROMA_LIST(c_tracklist), n, define.title); 
            chroma_list_set_column_show_header (CHROMA_LIST(c_tracklist), n, TRUE);

            gtk_tree_sortable_set_sort_func (GTK_TREE_SORTABLE (bmp_playlist_get_playlist (bmp_playlist)),
					      n,
					      GtkTreeIterCompareFunc (tracklist_compare_func),
					      GINT_TO_POINTER (n),
					      NULL);

      }

    chroma_list_set_cell_data_func (CHROMA_LIST(c_tracklist), 6, tracklist_cell_data_func, NULL); 

    chroma_list_set_column_visible (CHROMA_LIST(c_tracklist), COLUMN_URI, FALSE);
    chroma_list_set_column_visible (CHROMA_LIST(c_tracklist), COLUMN_GUID, FALSE);

    chroma_list_set_column_xalign  (CHROMA_LIST(c_tracklist), 2, 1.0); //Track
    chroma_list_set_column_xalign  (CHROMA_LIST(c_tracklist), 5, 1.0); //Date
    chroma_list_set_column_xalign  (CHROMA_LIST(c_tracklist), 6, 1.0); //Time

    last_visible = 0;
    for (n = 0; n < vcolumns_get_n_items(); n++)
      {
	    gchar     *key_name;
	    gdouble    width;
	    gboolean   visible;

	    key_name = g_strdup_printf ("column_%d_visible", n);
	    visible = mcs->key_get<bool>("tracklist", key_name);
	    g_free (key_name);

	    if (visible)
	      {
		key_name = g_strdup_printf ("column_%d_width", n);
		width = mcs->key_get<double>("tracklist", key_name);
		g_free (key_name);

		self->priv->columns_visible += 1;
		sum += width;
		last_visible = n;
		chroma_list_set_column_width (CHROMA_LIST(c_tracklist), n, width);
	      }
	    else
	      {
		chroma_list_set_column_visible (CHROMA_LIST(c_tracklist), n, FALSE);
		chroma_list_set_column_show_header (CHROMA_LIST(c_tracklist), n, FALSE);
	      }
      }

    if (sum != 1.0)
      {
	gchar     *key_name;
	gdouble    width;

	key_name = g_strdup_printf ("column_%d_width", last_visible);
	width = mcs->key_get<double>("tracklist", key_name);
	g_free (key_name);
	chroma_list_set_column_width (CHROMA_LIST(c_tracklist), n, 1. - sum);
      }

    gtk_fixed_put (GTK_FIXED(window->canvas),
		   c_tracklist,
		   PLAYLIST_ROOT_X,
		   PLAYLIST_ROOT_Y);

    gtk_fixed_put (GTK_FIXED(window->canvas),
		   c_tracklist_scrollbar,
		   GTK_WIDGET(c_tracklist)->allocation.width+1 + PLAYLIST_ROOT_X,
		   PLAYLIST_ROOT_Y);

    g_object_connect (G_OBJECT(c_tracklist),
		      "signal::cursor-position",
		      G_CALLBACK(on_tracklist_cursor_position),
		      self,
		      "signal::row-activated",
		      G_CALLBACK(on_tracklist_row_activated),
		      self,
		      "signal::dnd",
		      G_CALLBACK(on_tracklist_dnd),
		      self,
		      NULL);

    /* BmpWindow Events */
    g_object_connect (G_OBJECT(BMP_WINDOW(window)),

			"signal::realize",
			G_CALLBACK(playlist_resize_widgets),
			self,

			"signal::enter-notify-event",
			G_CALLBACK(on_window_playlist_enter),
			self,

			"signal::leave-notify-event",
			G_CALLBACK(on_window_playlist_leave),
			self,

			"signal::key-press-event",
			G_CALLBACK(on_window_playlist_key_press),
			self,

			"signal::button-press-event",
			G_CALLBACK(on_window_playlist_button_press),
			self,

			"signal::configure_event",
			G_CALLBACK(on_window_playlist_configure),
			self,

			"signal-after::configure_event",
			G_CALLBACK(on_window_playlist_configure_after),
			self,

			"signal::focus-in-event",
			G_CALLBACK(on_window_playlist_focus_in),
			self,

			"signal::focus-out-event",
			G_CALLBACK(on_window_playlist_focus_out),
			self,

			"signal::delete-event",
			G_CALLBACK(on_window_playlist_delete_event),
			self,

			NULL);

    /* BmpWindow->canvas Events */
    g_object_connect (G_OBJECT(BMP_WINDOW(window)->canvas),
			"signal::expose_event",
			G_CALLBACK(on_window_playlist_canvas_expose),
			self,
			"signal::button_press_event",
			G_CALLBACK(on_window_playlist_canvas_button_press),
			self,
			NULL);

    /* Bindings */
    Glib::RefPtr<Gtk::ToggleAction> action;
    action = Glib::wrap (GTK_TOGGLE_ACTION(gtk_action_group_get_action (bmp_toggle_actions, BMP_TOGGLE_ACTION_FOLLOW_CURRENT)));
    mcs_bind->bind_toggle_action (action, "bmp", "follow-current-track");
    
    /* Connections */
    mcs->subscribe ("Ui", "bmp", "font",
		    sigc::bind (sigc::ptr_fun (&on_bmp_font_changed),
				self));

    mcs->subscribe ("Ui", "bmp", "use-custom-cursors",
		    sigc::bind (sigc::ptr_fun(&on_bmp_use_custom_cursors_changed),
			        self));

    mcs->subscribe ("Ui", "bmp", "display-tracklist-numbers",
		    sigc::bind (sigc::ptr_fun(&on_bmp_display_tracklist_numbers_changed),
                                self));

    g_object_connect (
		bmp_system_control,
		"signal::track-change",
		G_CALLBACK (on_system_control_track_change),
		self,
		"signal::tracklist-list-sorted",
		G_CALLBACK (playlist_callback_tracklist_list_sorted),
		self,
		"signal::tracklist-items-removed",
		G_CALLBACK (playlist_callback_tracklist_items_removed),
		self,
		"signal::tracklist-items-added",
		G_CALLBACK (playlist_callback_tracklist_items_added),
		self,
		NULL);	

    gtk_window_add_accel_group (GTK_WINDOW(self->window), gtk_ui_manager_get_accel_group (bmp_ui_manager));
    gtk_action_set_sensitive (GTK_ACTION (gtk_action_group_get_action (bmp_actions, BMP_ACTION_CLEAR_PLAYBACK_HISTORY)), FALSE);

    //We disable this if we can't play CDs anyway
    gtk_action_set_sensitive (GTK_ACTION (gtk_action_group_get_action (bmp_actions, BMP_ACTION_TRACKLIST_ADD_CD)), bmp_play_engine->property_has_cdda().get_value());
}


void
bmp_window_playlist_show_trackinfo (BmpWindowPlaylist *self)
{
    GtkListStore	  *list;
    GtkTreeRowReference	  *reference;
    GtkTreePath		  *path;
    GtkAction		  *action;

    list = bmp_playlist_get_playlist (bmp_playlist);
    reference = static_cast<GtkTreeRowReference *> (g_object_get_data (G_OBJECT(list), "current"));
    if (!reference) return;

    path = gtk_tree_row_reference_get_path (reference);
    chroma_list_set_cursor_position (CHROMA_LIST(c_tracklist), gtk_tree_path_get_indices (path)[0]);
    gtk_tree_path_free (path);

    action = gtk_action_group_get_action (bmp_actions, BMP_ACTION_FILEINFO);
    g_idle_add ((GSourceFunc)activate, action);
}

/* GObject */
static void
bmp_window_playlist_init (BmpWindowPlaylist * self)
{
    self->window = NULL;

    self->priv = g_new (BmpWindowPlaylistPrivate, 1);
    self->priv->dispose_has_run = FALSE;
    self->priv->ui_components = NULL;
    self->priv->columns_visible = 0;
    self->priv->in_window = FALSE;
    self->priv->timeout_src_id_start_shade = 0;
    self->priv->focused = FALSE;

    window_playlist_create(self);
}

static GObject *
window_playlist_constructor (GType type,
	                     guint n_construct_properties,
         	             GObjectConstructParam * construct_properties)
{
    GObject *obj;

    {
        /*
         * Invoke parent constructor.
         */
        BmpWindowPlaylistClass *klass;
        GObjectClass *parent_class;
        klass = BMP_WINDOW_PLAYLIST_CLASS (g_type_class_peek (BMP_TYPE_WINDOW_PLAYLIST));
        parent_class = G_OBJECT_CLASS (g_type_class_peek_parent (klass));
        obj =
            parent_class->constructor (type,
                                       n_construct_properties,
                                       construct_properties);
    }

    /*
     * do stuff.
     */

    return obj;
}

static void
window_playlist_dispose (GObject *gobject)
{
    BmpWindowPlaylist *self = (BmpWindowPlaylist *) gobject;
    gint	       n;

    if (self->priv->dispose_has_run) return;

    self->priv->dispose_has_run = TRUE;

    mcs->key_set<bool>("playlist-window", "visible",
	    gtk_toggle_action_get_active (GTK_TOGGLE_ACTION(gtk_action_group_get_action (bmp_toggle_actions, BMP_TOGGLE_ACTION_PL))));

    for (n = 0; n < vcolumns_get_n_items(); n++)
      {
	  gchar     *key_name;
	  gdouble    width;

	  width = chroma_list_get_column_width (CHROMA_LIST(c_tracklist), n);

	  key_name = g_strdup_printf ("column_%d_width", n);
	  mcs->key_set<double>("tracklist", key_name, width);
	  g_free (key_name);
      }

    chroma_list_set_model (CHROMA_LIST(c_tracklist), NULL, NULL);

    gtk_widget_destroy (c_tracklist);
    gtk_widget_destroy (c_tracklist_scrollbar);

    gtk_widget_destroy (self->window);
}


static void
bmp_window_playlist_class_init (BmpWindowPlaylistClass * klass)
{
    GObjectClass *gobject_class = G_OBJECT_CLASS (klass);

#if 0
    gobject_class->set_property = bmp_play_set_property;
    gobject_class->get_property = bmp_play_get_property;
    gobject_class->finalize = bmp_play_finalize;
#endif
    gobject_class->dispose = window_playlist_dispose;
    gobject_class->constructor = window_playlist_constructor;
}

/* Public API */
static void
playlist_resize_widgets (BmpWindowPlaylist *self)
{
    gint w,h;

    w = self->window->allocation.width;
    h = self->window->allocation.height;

    resize_widgets (self, w, h);
}

void
bmp_window_playlist_set_hourglass (BmpWindowPlaylist *self)
{
    GtkWidget *window;

    if (!self)
      return;

    window = self->window;

    if (!GTK_WIDGET_REALIZED(window))
      return;

    bmp_window_set_busy (GTK_WIDGET(window));
}


void
bmp_window_playlist_set_cursors (BmpWindowPlaylist *self)
{
    GtkWidget *window;

    if (!self)
      return;

    window = self->window;

    if (!GTK_WIDGET_REALIZED(window))
      return;

    SET_CURSOR_FOR_WIDGET (CURSOR_PLAYLIST, BMP_WINDOW(window));
    SET_CURSOR_FOR_WIDGET (CURSOR_PLAYLIST, BMP_WINDOW(window)->canvas);
}


void
bmp_window_playlist_configure (BmpWindowPlaylist *self)
{
	GtkWidget *window = self->window;
	BmpPlaylistComponentT *pct = NULL;

	if (self->priv->ui_components != NULL)
	  {
	    g_hash_table_destroy (self->priv->ui_components);
	  }

        self->priv->ui_components = g_hash_table_new_full  (g_str_hash,
                                                            g_str_equal,
                                                            NULL,
                                                            destroy_value);

        for (unsigned int i = 0; i < G_N_ELEMENTS (bmp_playlist_component_data); i++)
        {
            pct = new BmpPlaylistComponentT;

            pct->name = 0;
            pct->pixbuf = bmp_pixbuf_new_simple (bmp_playlist_component_data[i].width,
                                                 bmp_playlist_component_data[i].height);
            bmp_pixbuf_copy_area_simple (pct->pixbuf,
                                         bmp_playlist_component_data[i].x_origin,
                                         bmp_playlist_component_data[i].y_origin,
                                         bmp_playlist_component_data[i].width,
                                         bmp_playlist_component_data[i].height);


            pct->x_origin = bmp_playlist_component_data[i].x_origin;
            pct->y_origin = bmp_playlist_component_data[i].y_origin;
            pct->width = bmp_playlist_component_data[i].width;
            pct->height = bmp_playlist_component_data[i].height;

            g_hash_table_insert	(self->priv->ui_components,
                                 bmp_playlist_component_data[i].name,
                                 (BmpPlaylistComponentT *) pct);

	}

        gtk_widget_modify_bg (GTK_WIDGET(window), GTK_STATE_NORMAL, bmp_colors_get_color(BMP_SKINCOLOR_PL_BG_NORMAL));
        gtk_widget_modify_bg (GTK_WIDGET(BMP_WINDOW(window)->canvas), GTK_STATE_NORMAL, bmp_colors_get_color(BMP_SKINCOLOR_PL_BG_NORMAL));

        gtk_widget_modify_fg (GTK_WIDGET(window), GTK_STATE_NORMAL, bmp_colors_get_color(BMP_SKINCOLOR_PL_FG_NORMAL));
        gtk_widget_modify_fg (GTK_WIDGET(BMP_WINDOW(window)->canvas), GTK_STATE_NORMAL, bmp_colors_get_color(BMP_SKINCOLOR_PL_FG_NORMAL));

        gtk_widget_modify_bg (GTK_WIDGET(c_tracklist), GTK_STATE_NORMAL, bmp_colors_get_color(BMP_SKINCOLOR_PL_BG_NORMAL));
        gtk_widget_modify_bg (GTK_WIDGET(c_tracklist_scrollbar), GTK_STATE_NORMAL, bmp_colors_get_color(BMP_SKINCOLOR_PL_BG_NORMAL));

        gtk_widget_modify_fg (GTK_WIDGET(c_tracklist), GTK_STATE_NORMAL, bmp_colors_get_color(BMP_SKINCOLOR_PL_FG_NORMAL));
        gtk_widget_modify_fg (GTK_WIDGET(c_tracklist_scrollbar), GTK_STATE_NORMAL, bmp_colors_get_color(BMP_SKINCOLOR_PL_FG_NORMAL));

	gtk_widget_modify_fg (GTK_WIDGET(c_tracklist), GTK_STATE_PRELIGHT, bmp_colors_get_color(BMP_SKINCOLOR_PL_FG_CURRENT));
	gtk_widget_modify_fg (GTK_WIDGET(c_tracklist_scrollbar), GTK_STATE_PRELIGHT, bmp_colors_get_color(BMP_SKINCOLOR_PL_FG_CURRENT));

	bmp_window_playlist_set_cursors (self);

	gtk_widget_queue_draw (c_tracklist);
	gtk_widget_queue_draw (c_tracklist_scrollbar);
}


BmpWindowPlaylist*
bmp_window_playlist_new (void)
{
    BmpWindowPlaylist *self;

    self = BMP_WINDOW_PLAYLIST (g_object_new (BMP_TYPE_WINDOW_PLAYLIST, NULL));

    return self;
}
