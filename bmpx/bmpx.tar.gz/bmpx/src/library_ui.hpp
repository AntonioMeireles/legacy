//  BMPx - The Dumb Music Player
//  Copyright (C) 2005 BMPx development team.
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
//
//  --
//
//  The BMPx project hereby grants permission for non-GPL compatible GStreamer
//  plugins to be used and distributed together with GStreamer and BMPx. This
//  permission is above and beyond the permissions granted by the GPL license
//  BMPx is covered by.

#ifndef BMP_LIBRARY_UI_HPP 
#define BMP_LIBRARY_UI_HPP

#include <glibmm.h>
#include <gtkmm.h>
#include <libglademm.h>

#include <bmp/library.hpp>

namespace Bmp
{

  class LibraryUI
    : public Gtk::Window
  {
    public:

	LibraryUI (BaseObjectType                       *cobject,
		   const Glib::RefPtr<Gnome::Glade::Xml> &xml);

	static LibraryUI*
	create ();

    private:

      enum Views
      {
	VIEW_A,
	VIEW_B,

	N_VIEWS
      };
    
      typedef std::map<std::string, Gtk::TreeModel::iterator> IterMap;

      class AttributeView
	    : public Gtk::TreeModel::ColumnRecord
	  {
	    public:
	      Gtk::TreeModelColumn<Glib::ustring> name;
	      Gtk::TreeModelColumn<std::string>   key;

	      AttributeView ()
	      {
		add (name);
		add (key);
	      }
	  };
      AttributeView attribute_view; 

      class Tracks
	    : public Gtk::TreeModel::ColumnRecord
	  {
	    public:
	      Gtk::TreeModelColumn<int>		  track;
	      Gtk::TreeModelColumn<Glib::ustring> title;
	      Gtk::TreeModelColumn<Glib::ustring> genre;
	      Gtk::TreeModelColumn<int>		  bitrate;
	      Gtk::TreeModelColumn<int>		  samplerate;
	      Gtk::TreeModelColumn<Glib::ustring> uri;

	      Tracks ()
	      {
		add (track);
		add (title);
		add (genre);
		add (bitrate);
		add (samplerate);
		add (uri);
	      }
	  };
      Tracks tracks; 

      class Attribute
	    : public Gtk::TreeModel::ColumnRecord
	  {
	    public:
	      Gtk::TreeModelColumn<Glib::ustring>	  title;
	      Gtk::TreeModelColumn<Bmp::Library::Datum>	  datum;

	      Attribute ()
	      {
		add (title);
		add (datum);
	      }
	  };
      Attribute attribute; 
    
      //GUI Callbacks 
      void
      on_music_add ();

      //Internal stuff dealing with the various views
      void
      update_view ();

      int
      sort_attrs (const Gtk::TreeModel::iterator&	iter_a,
		  const Gtk::TreeModel::iterator&	iter_b);

      void
      attr_a_changed ();
      void
      attr_b_changed ();

      void
      attr_a_datum_changed ();
      void
      attr_b_datum_changed ();

      void
      tracks_selection_changed ();

      void
      enqueue ();
      void
      play    ();

      void
      remove_tracks ();
      void
      remove_album  ();
      void
      remove_artist ();

      void
      del_current_album	  ();
      void
      del_current_artist  ();

      void
      select_all	  ();

      void
      jtc		  (Bmp::LibraryUI::Views view);

      Glib::RefPtr<Gnome::Glade::Xml>  ref_xml;

      Bmp::Library::Datum	       datum[N_VIEWS];  
      Glib::RefPtr<Gtk::ListStore>     store[N_VIEWS];
      Glib::RefPtr<Gtk::ListStore>     store_attr[N_VIEWS];
      Glib::RefPtr<Gtk::ListStore>     store_tracks;
      IterMap			       itermap[N_VIEWS];

      //Persistently needed widgets
      Gtk::Notebook		      *notebook_add;
      Gtk::TreeView		      *view_tracks;
      Gtk::TreeView		      *view[N_VIEWS];
      Gtk::ComboBox		      *cbox[N_VIEWS];

      Gtk::Button		      *b_enqueue;
      Gtk::Button		      *b_play;
      Gtk::Button		      *b_close;
      Gtk::Button		      *b_select_all;

      Gtk::Button		      *b_add;
      Gtk::Button		      *b_remove_tracks;
      Gtk::Button		      *b_remove_album;
      Gtk::Button		      *b_remove_artist;

      Gtk::Button		      *jump_to_current_a;
      Gtk::Button		      *jump_to_current_b;
  };
}
#endif
