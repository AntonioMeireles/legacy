/*  BMP - The Dumb Music Player
 *  Copyright (C) 2003-2006 BMP Project
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * The BMPx project hereby grant permission for non-gpl compatible GStreamer
 * plugins to be used and distributed together with GStreamer and BMPx. This
 * permission are above and beyond the permissions granted by the GPL license
 * BMPx is covered by.
 */

#include <iostream>
#include <sstream>

#include <glibmm.h>
#include <glibmm/markup.h>

#include <glib/gi18n.h>
#include <gtkmm.h>

#include "xml.h"
#include "ui_util.hpp"

#include "streams.hpp"
#include "bookmarks.hpp"
#include "main.hpp"

#include <bmp/vfs.hpp>

namespace {

        static char* shoutcast_headers[] = {
          N_("Stream Name"),
          N_("Bitrate"),
          N_("Stream Genre"),
          N_("Now Playing"),
        };

        static char* icecast_headers[] = {
          N_("Stream Name"),
          N_("Bitrate"),
          N_("Stream Genre"),
          N_("Now Playing")
        };

        static char* bookmark_headers[] = {
          N_("Name"),
          N_("Comment")
        };

        enum Tabs
	{
          TAB_BOOKMARKS = 0,
	  TAB_RECORDING,
          TAB_SHOUTCAST,
          TAB_ICECAST
        };

        enum {
          E_NAME,
          E_COMMENT,
          E_URI,

          N_ENTRIES
        };

        static char* entry_names[] = {
          "ab_entry_name",
          "ab_entry_comment",
          "ab_entry_uri"
        };
};

namespace Bmp {

  namespace Streams
  {
      //General stuff
      void
      Dialog::bookmark_delete ()
      {
        Glib::RefPtr<Gtk::TreeView::Selection>	selection;
        Glib::RefPtr<Gtk::ListStore>		store;
        Gtk::TreeModel::iterator		iter;
        Gtk::TreeModel::Row			row;
        Glib::ustring				name;
        int					response;

        selection = tree_view_bookmarks->get_selection ();

        if (!selection->count_selected_rows ()) return;

        iter = selection->get_selected ();
        row  = *iter;

        name = row[bookmarks.bookmark_columns.title];
        entry_bookmark_name->set_text (name);

        response = dialog_delete_bookmark->run ();

        if (response == GTK_RESPONSE_YES)
          {
            store = bookmarks.get_store ();
            store->erase (iter);
          }
        dialog_delete_bookmark->hide ();
      }

      void
      Dialog::bookmark_edit ()
      {
        Glib::RefPtr<Gtk::TreeView::Selection> selection;
        Gtk::TreeModel::iterator iter;
        Gtk::TreeModel::Row row;
        Glib::ustring name, comment, uri;
        Gtk::Entry          *entry[N_ENTRIES];
        int                  response;

        for (int n = 0; n < N_ENTRIES; n++)
          {
            ref_xml->get_widget (entry_names[n], entry[n]);
          }

        selection = tree_view_bookmarks->get_selection ();

        if (!selection->count_selected_rows ()) return;

        iter = selection->get_selected ();
        row  = *iter;

        name    = row[bookmarks.bookmark_columns.title];
        comment = row[bookmarks.bookmark_columns.desc];
        uri     = row[bookmarks.bookmark_columns.href];

        entry[E_NAME]->set_text (name);
        entry[E_COMMENT]->set_text (comment);
        entry[E_URI]->set_text (uri);

        dialog_add_bookmark->set_title (_("Edit Bookmark - BMP"));
        response = dialog_add_bookmark->run ();

        switch (response)
        {
            case Gtk::RESPONSE_OK:
                {
                    row[bookmarks.bookmark_columns.title] = entry[E_NAME]->get_text ();
                    row[bookmarks.bookmark_columns.desc]  = entry[E_COMMENT]->get_text ();
                    row[bookmarks.bookmark_columns.href]  = entry[E_URI]->get_text ();
                }

            default: break;
        }

        dialog_add_bookmark->hide ();
      }

      void
      Dialog::bookmark_add (Glib::ustring& name,
                                  Glib::ustring& comment,
                                  Glib::ustring& uri)
      {
        Gtk::Entry          *entry[N_ENTRIES];
        int                  response;

        for (int n = 0; n < N_ENTRIES; n++)
          {
            ref_xml->get_widget (entry_names[n], entry[n]);
          }

        entry[E_NAME]->set_text (name);
        entry[E_COMMENT]->set_text (comment);
        entry[E_URI]->set_text (uri);

        dialog_add_bookmark->set_title (_("Bookmark Stream - BMP"));
        response = dialog_add_bookmark->run ();

        switch (response)
        {
            case Gtk::RESPONSE_OK:
                {
                    Glib::RefPtr<Gtk::ListStore> store = bookmarks.get_store ();
                    Gtk::TreeModel::iterator iter;
                    Gtk::TreeModel::Row row;

                    iter = store->append ();
                    row  = *iter;

                    row[bookmarks.bookmark_columns.title] = entry[E_NAME]->get_text ();
                    row[bookmarks.bookmark_columns.desc]  = entry[E_COMMENT]->get_text ();
                    row[bookmarks.bookmark_columns.href]  = entry[E_URI]->get_text ();
                }

            default: break;
        }

        dialog_add_bookmark->hide ();
      }

      void
      Dialog::play ()
      {
          clear = true;
          start = true;
          track  = 0;

          enqueue ();
      }

      void
      Dialog::enqueue ()
      {
        GList *uris = NULL;
        char **uri_list;
        int current_page = notebook->get_current_page ();

        Util::window_set_busy (*this);

        switch (current_page)
          {
            case TAB_ICECAST:
              {
                Glib::RefPtr<Gtk::TreeView::Selection> selection;
                Gtk::TreeModel::iterator iter;
                Gtk::TreeModel::Row row;
                Glib::ustring uri;
                int out;

                selection = tree_view_icecast->get_selection ();

                if (!selection->count_selected_rows ())
                  {
                    Util::window_set_idle (*this);
                    return;
                  }

                iter = selection->get_selected ();
                row  = *iter;

                uri = row[columns_icecast.uri];

                uris = g_list_append (uris, strdup (uri. c_str ()));
                uri_list = glist_to_strv (uris);

                bmp_system_control_add_uri_list (bmp_system_control,
                                            (const char**)uri_list,
                                            -1,
                                            clear,
                                            start,
                                            track,
                                            &out,
                                            NULL);
                break;
              }

          case TAB_SHOUTCAST:
              {
                Glib::RefPtr<Gtk::TreeView::Selection> selection;
                Gtk::TreeModel::iterator iter;
                Gtk::TreeModel::Row row;
                Glib::ustring uri;
                int out;

                selection = tree_view_shoutcast->get_selection ();

                if (!selection->count_selected_rows ())
                  {
                    Util::window_set_idle (*this);
                    return;
                  }

                iter = selection->get_selected ();
                row  = *iter;

                uri = row[columns_shoutcast.uri];

                uris = g_list_append (uris, strdup (uri. c_str ()));
                uri_list = glist_to_strv (uris);

                bmp_system_control_add_uri_list (bmp_system_control,
                                            (const char**)uri_list,
                                            -1,
                                            clear,
                                            start,
                                            track,
                                            &out,
                                            NULL);
                break;
              }

          case TAB_BOOKMARKS:
              {
                Glib::RefPtr<Gtk::TreeView::Selection> selection;
                Gtk::TreeModel::iterator iter;
                Gtk::TreeModel::Row row;
                Glib::ustring uri;
                int out;

                selection = tree_view_bookmarks->get_selection ();

                if (!selection->count_selected_rows ())
                  {
                    Util::window_set_idle (*this);
                    return;
                  }

                iter = selection->get_selected ();
                row  = *iter;

                uri = row[bookmarks.bookmark_columns.href];

                uris = g_list_append (uris, strdup (uri. c_str ()));
                uri_list = glist_to_strv (uris);

                bmp_system_control_add_uri_list (bmp_system_control,
                                            (const char**)uri_list,
                                            -1,
                                            clear,
                                            start,
                                            track,
                                            &out,
                                            NULL);
                break;
              }


          default: break;
        }

        clear = false;
        start = false;
        track = 0;

        Util::window_set_idle (*this);

      }

      void
      Dialog::activate_default (const Gtk::TreeModel::Path& path, Gtk::TreeViewColumn *column)
      {
	Gtk::Window::activate_default ();
      }

      void
      Dialog::switch_page (GtkNotebookPage *page, guint page_nr)
      {
        Glib::RefPtr<Gtk::TreeView::Selection> selection;
	bool sensitive;

        switch (page_nr)
          {
              case TAB_BOOKMARKS: sensitive = tree_view_bookmarks->get_selection ()->count_selected_rows(); break;
              case TAB_ICECAST:   sensitive = tree_view_icecast->get_selection ()->count_selected_rows(); break;
              case TAB_SHOUTCAST: sensitive = tree_view_shoutcast->get_selection ()->count_selected_rows(); break;
	      case TAB_RECORDING: sensitive = false; break;

              default: return; //error condition
          }

        b_enqueue->set_sensitive (sensitive);
        b_play->set_sensitive (sensitive);
      }

      //Shoutcast
      void
      Dialog::shoutcast_build_genre_list ()
      {
        xmlDocPtr                  doc;
        xmlXPathObjectPtr          xpathobj;
        xmlNodeSetPtr              nv;
        Gtk::TreeModel::iterator   iter;

#define SHOUTCAST_GENRE_LIST_URI "http://www.shoutcast.com/sbin/newxml.phtml"

	Bmp::VFS::Handle handle = Bmp::VFS::Handle::create (SHOUTCAST_GENRE_LIST_URI);
	vfs->read_no_container (handle);

        if (!handle.get_buffer()) return;
        doc = xmlParseMemory ((const char*)handle.get_buffer(), handle.get_buffer_size());
        if (!doc) return;

        xpathobj = xml_execute_xpath_expression (doc, BAD_CAST "//genre", NULL);
        nv = xpathobj->nodesetval;
        ref_xml->get_widget ("tree_view_shoutcast_genres", tree_view_shoutcast_genres);

        Gtk::CellRendererText *cell;
        cell = Gtk::manage ( new Gtk::CellRendererText() );
        tree_view_shoutcast_genres->append_column (_("Genre"), *cell);
        tree_view_shoutcast_genres->get_column (0)->add_attribute (*cell, "text", 0);
        tree_view_shoutcast_genres->get_column (0)->set_resizable (false);
        tree_view_shoutcast_genres->get_column (0)->set_sizing (Gtk::TREE_VIEW_COLUMN_AUTOSIZE);

        list_store_shoutcast_genres = Gtk::ListStore::create (columns_shoutcast_genres);

        iter = list_store_shoutcast_genres->append ();
        (*iter)[columns_shoutcast_genres.name] = "Top500";

        for (int n = 0; n < nv->nodeNr; n++)
        {
            xmlChar *prop;

            prop = xmlGetProp (nv->nodeTab[n], BAD_CAST "name");
            iter = list_store_shoutcast_genres->append ();
            (*iter)[columns_shoutcast_genres.name] = reinterpret_cast<char*>(prop);
            g_free (prop);
        }

        tree_view_shoutcast_genres->get_selection()->set_mode (Gtk::SELECTION_BROWSE);
        tree_view_shoutcast_genres->set_model (list_store_shoutcast_genres);
        tree_view_shoutcast_genres->get_selection()->select (Gtk::TreeModel::Path("0"));
        tree_view_shoutcast_genres->get_selection()->signal_changed(). connect(sigc::mem_fun (*this, &::Bmp::Streams::Dialog::shoutcast_refresh), false);

        xmlXPathFreeObject (xpathobj);
        //xmlFreeDoc (doc);

        while (gtk_events_pending ()) gtk_main_iteration();
      }

      void
      Dialog::shoutcast_refresh_enter ()
      {
        Util::window_set_busy (*this);
        refresh_icecast->set_sensitive (false);
        vbox_shoutcast->set_sensitive (false);
        notebook_shoutcast_inner->set_current_page (1);
        while (gtk_events_pending()) gtk_main_iteration ();
      }

      void
      Dialog::shoutcast_refresh_exit  ()
      {
	refresh_icecast->set_sensitive (true);
	vbox_shoutcast->set_sensitive (true);
	notebook_shoutcast_inner->set_current_page (0);
	Util::window_set_idle (*this);
      }

      void
      Dialog::shoutcast_refresh ()
      {
        xmlDocPtr             doc;
        xmlXPathObjectPtr     xpathobj;
        xmlNodeSetPtr         nv;
        xmlNodePtr            node;

        struct ShoutcastEntry
	{
            Glib::ustring   Name;
            Glib::ustring   Genre;
            Glib::ustring   Nowplaying;
            unsigned int    Bitrate;
            Glib::ustring   URI;

            ShoutcastEntry () : Name (""), Genre (""), Nowplaying (""), Bitrate (0), URI ("") {};
        };

#define SHOUTCAST_LIST_URI "http://www.shoutcast.com/sbin/newxml.phtml?genre="

#define P_NAME      "name"
#define P_ID        "id"
#define P_BITRATE   "br"
#define P_GENRE     "genre"
#define P_CT        "ct"

        if (!tree_view_shoutcast_genres->get_selection()->count_selected_rows()) return;

	shoutcast_refresh_enter ();
  
        Gtk::TreeModel::iterator iter = tree_view_shoutcast_genres->get_selection()->get_selected ();
        std::stringstream shoutcast_uri;
        shoutcast_uri << SHOUTCAST_LIST_URI << (*iter)[columns_shoutcast_genres.name];

	g_message (shoutcast_uri.str().c_str());

	Bmp::VFS::Handle handle = Bmp::VFS::Handle::create (shoutcast_uri.str());
        vfs->read_no_container (handle);
	g_message ((const char*)handle.get_buffer());
        doc = xmlParseMemory ((const char*)handle.get_buffer(), handle.get_buffer_size());
        if (!doc)
	{
	  shoutcast_refresh_exit ();
	  return;
	}

        xpathobj = xml_execute_xpath_expression (doc, BAD_CAST "//station", NULL);
        nv = xpathobj->nodesetval;
        list_store_shoutcast = Gtk::ListStore::create (columns_shoutcast);
        for (int n = 0; n < nv->nodeNr; n++)
          {
            ShoutcastEntry           entry;
            Gtk::TreeModel::iterator iter;
            Gtk::TreeModel::Row      row;
            std::stringstream        strstream;
            xmlChar                 *prop;

            node = nv->nodeTab[n];

            prop = xmlGetProp (node, BAD_CAST P_ID);
            strstream << "http://www.shoutcast.com/sbin/tunein-station.pls?id=" << prop;
            entry. URI = strstream.str();
            g_free (prop);

            prop = xmlGetProp (node, BAD_CAST P_GENRE);
            entry. Genre = Glib::ustring(reinterpret_cast<char*>(prop));
            g_free (prop);

            prop = xmlGetProp (node, BAD_CAST P_NAME);
            entry. Name = Glib::ustring(reinterpret_cast<char*>(prop));
            g_free (prop);

            prop = xmlGetProp (node, BAD_CAST P_BITRATE);
            entry. Bitrate = atoi(reinterpret_cast<char*>(prop));
            g_free (prop);

            prop = xmlGetProp (node, BAD_CAST P_CT);
            entry. Nowplaying = Glib::ustring(reinterpret_cast<char*>(prop));
            g_free (prop);

            iter = list_store_shoutcast->append ();
            row  = *iter;

            row[columns_shoutcast.uri]         = entry. URI;
            row[columns_shoutcast.genre]       = entry. Genre;
            row[columns_shoutcast.name]        = entry. Name;
            row[columns_shoutcast.bitrate]     = entry. Bitrate;
            row[columns_shoutcast.nowplaying]  = entry. Nowplaying;
          }

        xmlXPathFreeObject (xpathobj);
        // xmlFreeDoc (doc);

        model_shoutcast_filter = Gtk::TreeModelFilter::create (list_store_shoutcast);
        model_shoutcast_filter->set_visible_func ( sigc::mem_fun (*this, &Bmp::Streams::Dialog::shoutcast_visible_func) );
        shoutcast_filter->signal_changed().connect ( sigc::mem_fun (*this, &Bmp::Streams::Dialog::shoutcast_filter_changed) );
        notebook_shoutcast_inner->set_current_page (0);
        tree_view_shoutcast->set_model (model_shoutcast_filter);
        tree_view_shoutcast->columns_autosize ();
        refresh_icecast->set_sensitive (true);
        vbox_shoutcast->set_sensitive (true);
        Util::window_set_idle (*this);

        while (gtk_events_pending ()) gtk_main_iteration();
      }

      void
      Dialog::shoutcast_column_clicked (int column)
      {
        Gtk::SortType sort_type, sort_type_new;
        int           sort_id;

        list_store_shoutcast->get_sort_column_id (sort_id, sort_type);
        if ((sort_id >= 0) && (sort_id != column))
          {
            tree_view_shoutcast->get_column (sort_id)->set_sort_indicator (false);
          }

        if (sort_id >= 0)
          sort_type_new = (sort_type == Gtk::SORT_ASCENDING) ? Gtk::SORT_DESCENDING : Gtk::SORT_ASCENDING;
        else
          sort_type_new = Gtk::SORT_ASCENDING;

        list_store_shoutcast->set_sort_column_id (column, sort_type_new);
        tree_view_shoutcast->get_column (column)->set_sort_indicator (true);
        tree_view_shoutcast->get_column (column)->set_sort_order (sort_type_new);
      }

      void
      Dialog::shoutcast_bookmark ()
      {
        Glib::RefPtr<Gtk::TreeView::Selection> selection;
        Gtk::TreeModel::iterator iter;
        Gtk::TreeModel::Row row;
        Glib::ustring name, comment, uri;

        selection = tree_view_shoutcast->get_selection ();

        if (!selection->count_selected_rows ()) return;

        iter = selection->get_selected ();
        row  = *iter;

        name    = row[columns_shoutcast.name];
        comment = row[columns_shoutcast.genre];
        uri     = row[columns_shoutcast.uri];

        bookmark_add (name, comment, uri);
      }

      void
      Dialog::shoutcast_selection_changed ()
      {
        bool sensitive = (tree_view_shoutcast->get_selection()->count_selected_rows() > 0) ? true : false;
        b_play->set_sensitive (sensitive);
        b_enqueue->set_sensitive (sensitive);
        bookmark_shoutcast->set_sensitive (sensitive);
      }

      bool
      Dialog::shoutcast_visible_func (const Gtk::TreeModel::iterator& iter)
      {
        Glib::ustring  name,  genre, entry;
        Gtk::TreeModel::Row row;

        entry = shoutcast_filter->get_text ().casefold ();
        if (!entry. length ()) return true;

        row = *iter;
        name  = row[columns_shoutcast.name];
        genre = row[columns_shoutcast.genre];

        name. casefold ();
        genre. casefold ();


        if ((match_keys (name. c_str (),  entry. c_str ())) ||
            (match_keys (genre. c_str (), entry. c_str ())))
          {
            return true;
          }

        return false;
      }

      void
      Dialog::shoutcast_filter_changed ()
      {
        model_shoutcast_filter->refilter ();
      }

      //Icecast
      void
      Dialog::icecast_refresh_exit ()
      {
	notebook_icecast_inner->set_current_page (0); \
	refresh_shoutcast->set_sensitive (true); \
	vbox_icecast->set_sensitive (true); \
	Util::window_set_idle (*this);  \
      }

      void
      Dialog::icecast_refresh_enter ()
      {
        Util::window_set_busy (*this);
        refresh_shoutcast->set_sensitive (false);
        vbox_icecast->set_sensitive (false);
        notebook_icecast_inner->set_current_page (1);
        while (gtk_events_pending()) gtk_main_iteration ();
      } 
  
      void
      Dialog::icecast_refresh ()
      {

        struct IcecastEntry
	{
            Glib::ustring   Name;
            Glib::ustring   Genre;
            Glib::ustring   Nowplaying;
            unsigned int    Bitrate;
            Glib::ustring   URI;

            IcecastEntry () : Name (""), Genre (""), Nowplaying (""), Bitrate (0), URI ("") {};
        };

        xmlDocPtr             doc;
        xmlXPathObjectPtr     xpathobj;
        xmlNodeSetPtr         nv;
        xmlNodePtr            node;

#define ICECAST_LIST_URI "http://dir.xiph.org/yp.xml"

#define IN_URI      "listen_url"
#define IN_NAME     "server_name"
#define IN_GENRE    "genre"
#define IN_NP       "current_song"
#define IN_BITRATE  "bitrate"

	icecast_refresh_enter ();

	Bmp::VFS::Handle handle = Bmp::VFS::Handle::create (std::string(ICECAST_LIST_URI));
        vfs->read_no_container (handle);
        doc = xmlParseMemory ((const char*)handle.get_buffer(), handle.get_buffer_size());
        if (!doc)
	{
	  icecast_refresh_exit ();
	  return;
	}

        xpathobj = xml_execute_xpath_expression (doc, BAD_CAST "//entry", NULL);
        nv = xpathobj->nodesetval;
        list_store_icecast = Gtk::ListStore::create ( columns_icecast );

        for (int n = 0; n < nv->nodeNr; n++)
          {
            IcecastEntry entry;
            xmlNodePtr node_sibling;
            Gtk::TreeModel::iterator iter;
            Gtk::TreeModel::Row row;

            node = nv->nodeTab[n];
            node_sibling = node->children;

            while (node_sibling)
                {
                    if (node_sibling->type != XML_TEXT_NODE)
                    {
                        std::string name = reinterpret_cast<const char*>(node_sibling->name);

                        if (!name. compare(IN_NAME) )
                        {
                            if (node_sibling->children)
                            {
                                char *_data = (char*)XML_GET_CONTENT (node_sibling->children);
                                entry. Name = _data;
                                g_free (_data);
                            }
                        }
                        else if (!name. compare(IN_URI))
                        {
                            if (node_sibling->children)
                            {
                                char *_data = (char*)XML_GET_CONTENT (node_sibling->children);
                                entry. URI = _data;
                                g_free (_data);
                            }
                        }
                        else if (!name. compare(IN_GENRE))
                        {
                            if (node_sibling->children)
                            {
                                char *_data = (gchar*)XML_GET_CONTENT (node_sibling->children);
                                entry. Genre = _data;
                                g_free (_data);
                            }
                        }
                        else if (!name. compare(IN_NP))
                        {
                            if (node_sibling->children)
                            {
                                char *_data = (char*)XML_GET_CONTENT (node_sibling->children);
                                entry. Nowplaying = _data;
                                g_free (_data);
                            }
                        }
                        else if (!name. compare(IN_BITRATE))
                        {
                            char *_data =  (char*)XML_GET_CONTENT (node_sibling->children);
                            entry. Bitrate = strtol (_data, NULL, 10);
                            g_free (_data);
                        }
                    }

                    node_sibling = node_sibling->next;
                    while (gtk_events_pending()) gtk_main_iteration ();
                }

                iter = list_store_icecast->append ();
                row  = *iter;

                row[columns_icecast.genre]       = entry. Genre;
                row[columns_icecast.bitrate]     = entry. Bitrate;
                row[columns_icecast.name]        = entry. Name;
                row[columns_icecast.nowplaying]  = entry. Nowplaying;
                row[columns_icecast.uri]         = entry. URI;
            }

          xmlXPathFreeObject (xpathobj);
          // xmlFreeDoc (doc);

          model_icecast_filter = Gtk::TreeModelFilter::create (list_store_icecast);
          model_icecast_filter->set_visible_func ( sigc::mem_fun (*this, &Bmp::Streams::Dialog::icecast_visible_func) );
          icecast_filter->signal_changed().connect ( sigc::mem_fun (*this, &Bmp::Streams::Dialog::icecast_filter_changed) );
          notebook_icecast_inner->set_current_page (0);
          tree_view_icecast->set_model (model_icecast_filter);
          tree_view_icecast->columns_autosize ();
          refresh_shoutcast->set_sensitive (true);
          vbox_icecast->set_sensitive (true);
          Util::window_set_idle (*this);
          while (gtk_events_pending ()) gtk_main_iteration();
      }

      void
      Dialog::icecast_bookmark ()
      {
        Glib::RefPtr<Gtk::TreeView::Selection> selection;
        Gtk::TreeModel::iterator iter;
        Gtk::TreeModel::Row row;
        Glib::ustring name, comment, uri;

        selection = tree_view_icecast->get_selection ();

        if (!selection->count_selected_rows ()) return;

        iter = selection->get_selected ();
        row  = *iter;

        name    = row[columns_icecast.name];
        comment = row[columns_icecast.genre];
        uri     = row[columns_icecast.uri];

        bookmark_add (name, comment, uri);
      }

      void
      Dialog::icecast_column_clicked (int column)
      {
        Gtk::SortType sort_type, sort_type_new;
        int           sort_id;

        list_store_icecast->get_sort_column_id (sort_id, sort_type);
        if ((sort_id >= 0) && (sort_id != column))
          {
            tree_view_icecast->get_column (sort_id)->set_sort_indicator (false);
          }

        if (sort_id >= 0)
          sort_type_new = (sort_type == Gtk::SORT_ASCENDING) ? Gtk::SORT_DESCENDING : Gtk::SORT_ASCENDING;
        else
          sort_type_new = Gtk::SORT_ASCENDING;

        list_store_icecast->set_sort_column_id (column, sort_type_new);
        tree_view_icecast->get_column (column)->set_sort_indicator (true);
        tree_view_icecast->get_column (column)->set_sort_order (sort_type_new);
      }

      void
      Dialog::icecast_selection_changed ()
      {
        bool sensitive = (tree_view_icecast->get_selection()->count_selected_rows() > 0) ? true : false;

        b_play->set_sensitive (sensitive);
        b_enqueue->set_sensitive (sensitive);
        bookmark_icecast->set_sensitive (sensitive);
      }

      bool
      Dialog::icecast_visible_func (const Gtk::TreeModel::iterator& iter)
      {
        Glib::ustring  name,  genre, entry;
        Gtk::TreeModel::Row row;

        entry = icecast_filter->get_text ().casefold ();
        if (!entry. length ()) return true;

        row = *iter;
        name  = row[columns_icecast.name];
        genre = row[columns_icecast.genre];

        name. casefold ();
        genre. casefold ();


        if ((match_keys (name. c_str (),  entry. c_str ())) ||
            (match_keys (genre. c_str (), entry. c_str ())))
          {
            return true;
          }

        return false;
      }

      void
      Dialog::icecast_filter_changed ()
      {
        model_icecast_filter->refilter ();
      }

      //Bookmarks
      void
      Dialog::bookmarks_column_clicked (int column)
      {
        Glib::RefPtr<Gtk::ListStore> store = bookmarks.get_store ();
        Gtk::SortType sort_type, sort_type_new;
        int           sort_id;

        store->get_sort_column_id (sort_id, sort_type);
        if ((sort_id >= 0) && (sort_id != column))
          {
            tree_view_bookmarks->get_column (sort_id)->set_sort_indicator (false);
          }

        if (sort_id >= 0)
          sort_type_new = (sort_type == Gtk::SORT_ASCENDING) ? Gtk::SORT_DESCENDING : Gtk::SORT_ASCENDING;
        else
          sort_type_new = Gtk::SORT_ASCENDING;

        store->set_sort_column_id (column, sort_type_new);
        tree_view_shoutcast->get_column (column)->set_sort_indicator (true);
        tree_view_shoutcast->get_column (column)->set_sort_order (sort_type_new);
      }

      void
      Dialog::bookmarks_selection_changed ()
      {
        bool sensitive = (tree_view_bookmarks->get_selection()->count_selected_rows() > 0) ? true : false;
        b_play->set_sensitive (sensitive);
        b_enqueue->set_sensitive (sensitive);
        b_bookmark_edit->set_sensitive (sensitive);
        b_bookmark_delete->set_sensitive (sensitive);
      }

      Dialog::Dialog (BaseObjectType                        *cobject,
				  const Glib::RefPtr<Gnome::Glade::Xml> &xml)
	: Gtk::Window (cobject),
	  ref_xml (xml)
      {
        /* Dialogs */
        ref_xml->get_widget ("dialog_add_bookmark", dialog_add_bookmark);
        ref_xml->get_widget ("dialog_delete_bookmark", dialog_delete_bookmark);

        /* Various */
        ref_xml->get_widget ("streams_notebook", notebook);
        notebook->signal_switch_page(). connect ( sigc::mem_fun (*this, &Bmp::Streams::Dialog::switch_page) );
        notebook->set_current_page (0);

        ref_xml->get_widget ("notebook_icecast_inner", notebook_icecast_inner);
        ref_xml->get_widget ("notebook_shoutcast_inner", notebook_shoutcast_inner);

        ref_xml->get_widget ("icecast_filter", icecast_filter);
        ref_xml->get_widget ("shoutcast_filter", shoutcast_filter);
        ref_xml->get_widget ("entry_bookmark_name", entry_bookmark_name);

        struct Images
	{
          const char *widget;
          const char *file;
        };

        static Images images[]={
          {"image_streams", "/images/header-streams.png"},
          {"image_wait1", "/images/wait.gif"},
          {"image_wait2", "/images/wait.gif"},
          {"image_shoutcast", "/images/shoutcast.png"},
          {"image_icecast", "/images/xiph.png"}
        };

        for (unsigned int n = 0; n < (sizeof(images)/sizeof(images[0])); n++)
          {
              Gtk::Image *image;
              std::stringstream imagefile;

              ref_xml->get_widget (images[n].widget, image);
              imagefile << DATA_DIR << images[n].file;
              image->set (imagefile. str ());
          }

        //Setup buttons
        ref_xml->get_widget ("b_bookmark_add", b_bookmark_add);
        ref_xml->get_widget ("b_bookmark_edit", b_bookmark_edit);
        ref_xml->get_widget ("b_bookmark_delete", b_bookmark_delete);

        ref_xml->get_widget ("b_play", b_play);
        ref_xml->get_widget ("b_enqueue", b_enqueue);
        ref_xml->get_widget ("b_close", b_close);

        b_close->signal_clicked().connect ( sigc::mem_fun (*this, &Bmp::Streams::Dialog::hide ) );

        //Setup SHOUTCAST Tab
        shoutcast_build_genre_list ();
        ref_xml->get_widget ("tree_view_shoutcast", tree_view_shoutcast);
        ref_xml->get_widget ("vbox9", vbox_shoutcast);
        tree_view_shoutcast->get_selection()->set_mode (Gtk::SELECTION_SINGLE);
        tree_view_shoutcast->signal_row_activated(). connect ( sigc::mem_fun (*this, &Bmp::Streams::Dialog::activate_default));
        for (unsigned int n = 0; n < ((sizeof(shoutcast_headers)/sizeof(shoutcast_headers[0]))-1); n++)
        {
          Gtk::CellRendererText *cell;
          cell = Gtk::manage ( new Gtk::CellRendererText() );
          tree_view_shoutcast->append_column (shoutcast_headers[n], *cell);
          tree_view_shoutcast->get_column (n)->add_attribute (*cell, "text", n);
          tree_view_shoutcast->get_column (n)->set_resizable (true);
          tree_view_shoutcast->get_column (n)->signal_clicked (). connect ( sigc::bind ( sigc::mem_fun (*this, &Bmp::Streams::Dialog::shoutcast_column_clicked), n ) );
        }
        tree_view_shoutcast->set_headers_clickable (true);
        tree_view_shoutcast->get_selection()->signal_changed ().connect ( sigc::mem_fun (*this, &Bmp::Streams::Dialog::shoutcast_selection_changed ) );
        ref_xml->get_widget ("refresh_shoutcast", refresh_shoutcast);
        refresh_shoutcast->signal_clicked(). connect ( sigc::mem_fun (*this, &Bmp::Streams::Dialog::shoutcast_refresh ));
        ref_xml->get_widget ("bookmark_shoutcast", bookmark_shoutcast);
        bookmark_shoutcast->signal_clicked(). connect ( sigc::mem_fun (*this, &Bmp::Streams::Dialog::shoutcast_bookmark ));

        /* Setup ICECAST Tab */
        ref_xml->get_widget ("tree_view_icecast", tree_view_icecast);
        ref_xml->get_widget ("vbox8", vbox_icecast);
        tree_view_icecast->get_selection()->set_mode (Gtk::SELECTION_SINGLE);
        tree_view_icecast->signal_row_activated(). connect ( sigc::mem_fun (*this, &Bmp::Streams::Dialog::activate_default));
        for (unsigned int n = 0; n < ((sizeof(icecast_headers)/sizeof(icecast_headers[0]))-1); n++)
        {
          Gtk::CellRendererText *cell;
          cell = Gtk::manage ( new Gtk::CellRendererText() );
          tree_view_icecast->append_column (icecast_headers[n], *cell);
          tree_view_icecast->get_column (n)->add_attribute (*cell, "text", n);
          tree_view_icecast->get_column (n)->set_resizable (true);
          tree_view_icecast->get_column (n)->signal_clicked (). connect ( sigc::bind ( sigc::mem_fun (*this, &Bmp::Streams::Dialog::icecast_column_clicked), n ) );
        }
        tree_view_icecast->set_headers_clickable (true);
        tree_view_icecast->get_selection()->signal_changed ().connect ( sigc::mem_fun (*this, &Bmp::Streams::Dialog::icecast_selection_changed ) );
        ref_xml->get_widget ("refresh_icecast", refresh_icecast);
        refresh_icecast->signal_clicked(). connect ( sigc::mem_fun (*this, &Bmp::Streams::Dialog::icecast_refresh ));
        ref_xml->get_widget ("bookmark_icecast", bookmark_icecast);
        bookmark_icecast->signal_clicked(). connect ( sigc::mem_fun (*this, &Bmp::Streams::Dialog::icecast_bookmark ));

        /* Setup Bookmarks tab */
        ref_xml->get_widget ("tree_view_bookmarks", tree_view_bookmarks);

        tree_view_bookmarks->get_selection()->set_mode (Gtk::SELECTION_SINGLE);
        tree_view_bookmarks->signal_row_activated(). connect ( sigc::mem_fun (*this, &Bmp::Streams::Dialog::activate_default));
        for (unsigned int n = 0; n < (sizeof(bookmark_headers)/sizeof(bookmark_headers[0])); n++)
        {
          Gtk::CellRendererText *cell;
          cell = Gtk::manage ( new Gtk::CellRendererText() );
          tree_view_bookmarks->append_column (bookmark_headers[n], *cell);
          tree_view_bookmarks->get_column (n)->add_attribute (*cell, "text", n);
          tree_view_bookmarks->get_column (n)->set_resizable (true);
          tree_view_bookmarks->get_column (n)->signal_clicked (). connect ( sigc::bind ( sigc::mem_fun (*this, &Bmp::Streams::Dialog::bookmarks_column_clicked), n ) );
        }
        tree_view_bookmarks->set_headers_clickable (true);
        tree_view_bookmarks->get_selection()->signal_changed ().connect ( sigc::mem_fun (*this, &Bmp::Streams::Dialog::bookmarks_selection_changed ) );

        tree_view_bookmarks->set_model (bookmarks.get_store ());

        /* Common widgets */
        b_enqueue->signal_clicked().connect ( sigc::mem_fun (*this, &Bmp::Streams::Dialog::enqueue) );
        b_play->signal_clicked().connect ( sigc::mem_fun (*this, &Bmp::Streams::Dialog::play) );
        b_bookmark_add->signal_clicked().connect ( sigc::bind ( sigc::mem_fun (*this, &Bmp::Streams::Dialog::bookmark_add), Glib::ustring(), Glib::ustring(), Glib::ustring() ));
        b_bookmark_edit->signal_clicked().connect ( sigc::mem_fun (*this, &Bmp::Streams::Dialog::bookmark_edit));
        b_bookmark_delete->signal_clicked().connect ( sigc::mem_fun (*this, &Bmp::Streams::Dialog::bookmark_delete));
      }

      Dialog *
      Dialog::create ()
      {
	const std::string path = DATA_DIR "/glade/dialog_streams.glade";

	Glib::RefPtr<Gnome::Glade::Xml> glade_xml = Gnome::Glade::Xml::create (path);

	Dialog *stream_lister = 0;
	glade_xml->get_widget_derived ("dialog_streams", stream_lister);

	return stream_lister;
      }
  }
};
