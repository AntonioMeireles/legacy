//  BMPx - The Dumb Music Player
//  Copyright (C) 2005-2006 BMPx development team.
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
//
//  --
//
//  The BMPx project hereby grants permission for non GPL-compatible GStreamer
//  plugins to be used and distributed together with GStreamer and BMPx. This
//  permission is above and beyond the permissions granted by the GPL license
//  BMPx is covered by.

#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include "skin_view.hpp"

#include <utility>
#include <bmp/file_utils.hpp>

#include "main.hpp"
#include "paths.hpp"

#define SKIN_THUMBNAIL_WIDTH  90
#define SKIN_THUMBNAIL_HEIGHT 40

namespace Bmp
{
  namespace
  {
    class DecompressSkin
    {
    public:

        DecompressSkin (const std::string &path)
        {
            if (Util::file_is_archive (path.c_str ()))
            {
                dec_path   = Util::archive_decompress (path);
                is_archive = true;
            }
            else
            {
                dec_path = path;
            }
        }

        const std::string &
        get_path ()
        {
            return dec_path;
        }

        ~DecompressSkin ()
        {
            if (is_archive)
            {
                Util::del_directory (dec_path);
            }
        }

    private:

        std::string dec_path;
        bool        is_archive;
    };

    typedef std::vector<std::pair<std::string, std::string> > SkinList;

    bool
    run_main_iteration ()
    {
        while (gtk_events_pending())
            gtk_main_iteration ();

        return false;
    }

    Glib::RefPtr<Gdk::Pixbuf>
    load_skin_preview_image (const std::string &path)
    {
        DecompressSkin decompress (path);

        std::string preview_path;

        if (!Util::find_file (decompress.get_path (), "main.bmp", preview_path, 1))
            throw Glib::FileError (Glib::FileError::NO_SUCH_ENTITY, "Could not find image to make thumbnail");

        return Gdk::Pixbuf::create_from_file (preview_path);
    }

    Glib::RefPtr<Gdk::Pixbuf>
    create_skin_thumbnail (const std::string &path)
    {
        std::string thumbname = Glib::build_filename (BMP_PATH_SKIN_THUMB_DIR, Glib::path_get_basename (path) + ".png");

        if (Glib::file_test (thumbname, Glib::FILE_TEST_EXISTS))
            return Gdk::Pixbuf::create_from_file (thumbname);

        Glib::RefPtr<Gdk::Pixbuf> preview = load_skin_preview_image (path);

        Glib::RefPtr<Gdk::Pixbuf> thumbnail = preview->scale_simple (SKIN_THUMBNAIL_WIDTH, SKIN_THUMBNAIL_HEIGHT, Gdk::INTERP_BILINEAR);
        thumbnail->save (thumbname, "png");

        return thumbnail;
    }

    void
    get_skin_list_from_dir (const std::string &dir_path,
                            SkinList          &skin_list)
    {
        Glib::Dir dir (dir_path);

        for (Glib::Dir::const_iterator iter = dir.begin (), end = dir.end ();
             iter != end;
             ++iter)
        {
            if (*iter != "." && *iter != "..")
            {
                std::string full_path = Glib::build_filename (dir_path, *iter);

                if (Glib::file_test (full_path, Glib::FILE_TEST_IS_REGULAR))
                {
                    if (Util::file_is_archive (full_path.c_str ()))
                    {
                        skin_list.push_back (std::make_pair (Util::archive_basename (*iter), full_path));
                    }
                }
                else if (Glib::file_test (full_path, Glib::FILE_TEST_IS_DIR))
                {
                    skin_list.push_back (std::make_pair (*iter, full_path));
                }
            }
        }
    }

    void
    get_skin_list (SkinList &skin_list)
    {
        get_skin_list_from_dir (Glib::build_filename (DATA_DIR, BMP_SKIN_DIR_BASENAME), skin_list);
        get_skin_list_from_dir (BMP_PATH_USER_SKIN_DIR, skin_list);
    }

  } // anonymous namespace

  SkinView::SkinView (BaseObjectType                        *cobject,
                      const Glib::RefPtr<Gnome::Glade::Xml> &xml)
      : Gtk::TreeView (cobject)
  {

      set_headers_clickable (false);
      set_headers_visible (false);
      set_rules_hint (true);

      Gtk::CellRendererPixbuf *cell_pixbuf = Gtk::manage (new Gtk::CellRendererPixbuf ());
      append_column ("Preview", *cell_pixbuf);
      get_column (0)->add_attribute (*cell_pixbuf, "pixbuf", 0);
      get_column (0)->set_resizable (false);
      get_column (0)->set_spacing (16);

      cell_pixbuf->property_xpad () = 6;
      cell_pixbuf->property_ypad () = 2;

      Gtk::CellRendererText *cell_text = Gtk::manage (new Gtk::CellRendererText ());
      append_column ("Name", *cell_text);
      get_column (1)->add_attribute (*cell_text, "text", 1);
      get_column (1)->set_resizable (false);

      list_store = Gtk::ListStore::create (columns);
      list_store->set_sort_func (1, sigc::mem_fun (this, &SkinView::compare_skin));
      list_store->set_sort_column_id (1, Gtk::SORT_ASCENDING);

      set_model (list_store);
  }

  SkinView::RefreshSignal
  SkinView::signal_refresh ()
  {
      return refresh_signal;
  }

  SkinView::RefreshEndSignal
  SkinView::signal_refresh_end ()
  {
      return refresh_end_signal;
  }

  void
  SkinView::on_realize ()
  {
      Gtk::TreeView::on_realize ();

      refresh_signal.emit ();
      Glib::signal_idle ().connect (sigc::ptr_fun (&run_main_iteration));

      SkinList list;
      get_skin_list (list);

      std::string current_skin = mcs->key_get<std::string> ("bmp", "skin");

      Gtk::TreeModel::iterator iter_current;
      bool have_current = false;

      for (SkinList::iterator iter = list.begin ();
           iter != list.end ();
           iter++)
      {
          Gtk::TreeModel::iterator iter_model;

          try
          {
              Glib::RefPtr<Gdk::Pixbuf> thumb = create_skin_thumbnail (iter->second);

              iter_model = list_store->append ();

              (*iter_model)[columns.icon] = thumb;
              (*iter_model)[columns.name] = iter->first;
              (*iter_model)[columns.path] = iter->second;

              pos_map.insert (std::make_pair (iter->second, Gtk::TreeRowReference (list_store, Gtk::TreePath (iter_model))));

              if (!current_skin.compare (iter->second))
              {
                  iter_current = iter_model;
                  have_current = true;
              }
          }
          catch (Glib::FileError &error)
          {
              g_message (G_STRLOC ": %s", error.what ().c_str ());
          }

          Glib::signal_idle ().connect (sigc::ptr_fun (&run_main_iteration));
      }

      refresh_end_signal.emit ();

      if (have_current)
      {
          get_selection ()->select (iter_current);
      }

      std::string skin_dir = Glib::build_filename (DATA_DIR, BMP_SKIN_DIR_BASENAME);
      Glib::ustring skin_dir_name = "skins";
      bmp_file_monitor->add_watch (skin_dir_name, skin_dir,
                                   sigc::mem_fun (this, &SkinView::on_skin_added),
                                   sigc::mem_fun (this, &SkinView::on_skin_removed));

      std::string path_user_skin_dir = BMP_PATH_USER_SKIN_DIR;
      Glib::ustring path_user_skin_dir_name = "user_skins";
      bmp_file_monitor->add_watch (path_user_skin_dir_name, path_user_skin_dir,
                                   sigc::mem_fun (this, &SkinView::on_skin_added),
                                   sigc::mem_fun (this, &SkinView::on_skin_removed));
  }

  void
  SkinView::on_cursor_changed ()
  {
      Gtk::TreeView::on_cursor_changed ();

      Gtk::TreeModel::iterator iter = get_selection ()->get_selected ();
      scroll_to_row (Gtk::TreeModel::Path (iter), 0.5);
  }

  std::string
  SkinView::get_selected_skin_path ()
  {
      Gtk::TreeModel::iterator iter = get_selection ()->get_selected ();
      return (*iter)[columns.path];
  }

  int
  SkinView::compare_skin (const Gtk::TreeModel::iterator& iter_a,
                          const Gtk::TreeModel::iterator& iter_b)
  {
      Glib::ustring name_a = (*iter_a)[columns.name];
      Glib::ustring name_b = (*iter_b)[columns.name];

      return name_a.compare (name_b);
  }

  bool
  SkinView::on_skin_added_idle (const std::string &path)
  {
      Glib::ustring skin_name;

      if (Glib::file_test (path, Glib::FILE_TEST_IS_REGULAR))
      {
          if (Util::file_is_archive (path))
          {
              skin_name = Util::archive_basename (path);
          }
      }
      else if (Glib::file_test (path, Glib::FILE_TEST_IS_DIR))
      {
          skin_name = path;
      }
      else
      {
          return false;
      }

      try
      {
          Glib::RefPtr<Gdk::Pixbuf> thumbnail = create_skin_thumbnail (path);

          Gtk::TreeModel::iterator iter = list_store->append ();
          (*iter)[columns.icon] = thumbnail;
          (*iter)[columns.name] = Glib::path_get_basename (skin_name);
          (*iter)[columns.path] = path;

          pos_map.insert (std::make_pair (path, Gtk::TreeRowReference (list_store, Gtk::TreePath (iter))));
      }
      catch (Glib::FileError &error)
      {}

      return false;
  }

  void
  SkinView::on_skin_added (const std::string &path)
  {
      Glib::signal_idle ().connect (sigc::bind (sigc::mem_fun (*this, &SkinView::on_skin_added_idle), path));
  }

  bool
  SkinView::on_skin_removed_idle (const std::string &path)
  {
      PositionMap::iterator iter = pos_map.find (path);

      if (iter == pos_map.end ())
          return false;

      list_store->erase (list_store->get_iter (iter->second.get_path ()));
      pos_map.erase (iter);

      return false;
  }

  void
  SkinView::on_skin_removed (const std::string &path)
  {
      Glib::signal_idle ().connect (sigc::bind (sigc::mem_fun (this, &SkinView::on_skin_removed_idle), path));
  }

} // Bmp namespace
