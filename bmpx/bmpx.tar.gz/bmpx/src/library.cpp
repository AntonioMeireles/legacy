//  BMPx - The Dumb Music Player
//  Copyright (C) 2005 BMPx development team.
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
//
//  --
//
//  The BMPx project hereby grants permission for non-GPL compatible GStreamer
//  plugins to be used and distributed together with GStreamer and BMPx. This
//  permission is above and beyond the permissions granted by the GPL license
//  BMPx is covered by.

#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <glibmm.h>

#include <glib/gi18n.h>
#include <gtkmm.h>

#include <cstdio>
#include <cstdlib>
#include <cstring>

#include <unistd.h>
#include <sys/stat.h>

#include <iostream>
#include <boost/shared_ptr.hpp>
#include <boost/format.hpp>

// BMP
#include <bmp/uri++.hpp>
#include <bmp/database.hpp>
#include <bmp/library.hpp>

// TagLib
#include <taglib.h>
#include <fileref.h>
#include <tag.h>
#include <audioproperties.h>
#include <tfile.h>

// GStreamer
#include <gst/gst.h>
#include <gst/gstelement.h>

// Musicbrainz
#include <musicbrainz/musicbrainz.h>

#include "main.hpp"
#include "paths.hpp"


#define TAG_READ_TUPLE(_data) ((TagReadTuple*)(_data))

namespace Bmp
{
  namespace Library
  {
    namespace
    {
      struct TagReadTuple
      {
          DB::DataRow row;
          bool        eos;
      };

      // We're using GST-style tag identifiers here, except that we can't use dashes as that seems to confuse sqlite
      DatumDefine mdefines[] = {
          {
              N_("Location"),
              N_("Locations"),
              N_("The location of the track (file, internet stream, etc.)"),
              "location",
              DB::VALUE_TYPE_STRING,
              true,
              0,
              N_("(Unknown Location)")
          },

          {
              N_("Artist"),
              N_("Artists"),
              N_("The artist/peformer of the track"),
              "artist",
              DB::VALUE_TYPE_STRING,
              true,
              0,
              N_("(Unknown Artist)")
          },

          {
              N_("Album"),
              N_("Albums"),
              N_("The album of the track"),
              "album",
              DB::VALUE_TYPE_STRING,
              true,
              0,
              N_("(Unknown Album)")
          },

          {
              N_("Title"),
              N_("Titles"),
              N_("The title of the current track"),
              "title",
              DB::VALUE_TYPE_STRING,
              true,
              0,
              N_("(Unknown Title)")
          },

          {
              N_("Track"),
              N_("Tracks"),
              N_("The track number of the track"),
              "tracknumber",
              DB::VALUE_TYPE_INT,
              false,
              0,
              ""
          },

          {
              N_("Time"),
              N_("Times"),
              N_("The length of the track"),
              "time",
              DB::VALUE_TYPE_INT,
              false,
              0,
              ""
          },

          {
              N_("Genre"),
              N_("Genres"),
              N_("The genre (kind of music) of the track"),
              "genre",
              DB::VALUE_TYPE_STRING,
              false,
              0,
              N_("(Unknown Genre)")
          },

          {
              N_("Comment"),
              N_("Comments"),
              N_("Comments added to the track"),
              "comment",
              DB::VALUE_TYPE_STRING,
              false,
              0,
              N_("(Unknown Comment)")
          },

          {
              N_("Rating"),
              N_("Ratings"),
              N_("The rating of the track"),
              "rating",
              DB::VALUE_TYPE_INT,
              false,
              0,
              ""
          },

          {
              N_("Date"),
              N_("Dates"),
              N_("The date (year) of the track"),
              "date",
              DB::VALUE_TYPE_INT,
              false,
              0,
              ""
          },

          {
              N_("MTIME"),
              N_("MTIMEs"),
              N_("The modification time of the track"),
              "mtime",
              DB::VALUE_TYPE_INT,
              false,
              0,
              ""
          },

          {
              N_("Bitrate"),
              N_("Bitrates"),
              N_("The bitrate of the track"),
              "bitrate",
              DB::VALUE_TYPE_INT,
              false,
              0,
              ""
          },

          {
              N_("Samplerate"),
              N_("Samplerates"),
              N_("The samplerate of the track"),
              "samplerate",
              DB::VALUE_TYPE_INT,
              false,
              0,
              ""
          },

          {
              N_("Play count"),
              N_("Play counts"),
              N_("The number of times this track was played"),
              "count",
              DB::VALUE_TYPE_INT,
              false,
              0,
              ""
          },

          {
              N_("Volume UDI"),
              N_("Volume UDIs"),
              N_("HAL Volume UDI this track resides on"),
              "volume_udi",
              DB::VALUE_TYPE_STRING,
              false,
              0,
              ""
          },

          {
              N_("Device UDI"),
              N_("Device UDIs"),
              N_("HAL Device UDI this track resides on"),
              "device_udi",
              DB::VALUE_TYPE_STRING,
              false,
              0,
              ""
          }
      };

      int
      get_duration_from_sectors (int sectors)
      {
          const int bytes_per_sector   = 2352;
          const int bytes_per_seconds  = (44100 / 8) / 16 / 2;

          return (sectors * bytes_per_sector / bytes_per_seconds)/1000;
      }

      void
      tag_foreach (const GstTagList *list,
                   const gchar      *tag,
                   TagReadTuple     *tuple)
      {
          int count = gst_tag_list_get_tag_size (list, tag);

          for (int i = 0; i < count; i++)
          {
              if (gst_tag_get_type (tag) == G_TYPE_STRING)
              {
                  gchar *str;
                  gst_tag_list_get_string_index (list, tag, i, &str);

                  if (g_utf8_validate (str, std::strlen (str), 0))
                  {
                      tuple->row.insert (DB::DataRowPair (std::string (tag), std::string (str)));
                  }
              }
              else
              {
                  const GValue *value = gst_tag_list_get_value_index (list, tag, i);

                  if (G_VALUE_HOLDS (value, G_TYPE_INT))
                  {
                      tuple->row.insert (DB::DataRowPair (std::string (tag), int (g_value_get_int(value))));
                  }
                  else if (G_VALUE_HOLDS (value, G_TYPE_UINT))
                  {
                      tuple->row.insert (DB::DataRowPair (std::string (tag), int (g_value_get_uint(value))));
                  }
              }
          }
      }

      gboolean
      metadata_bus_handler (GstBus       *bus,
                            GstMessage   *message,
                            TagReadTuple *tuple)
      {
          switch (GST_MESSAGE_TYPE (message))
          {
          case GST_MESSAGE_EOS:
              {
                  tuple->eos = true;
              }
              break;

          case GST_MESSAGE_TAG:
              {
                  GstTagList *tag_list = 0;

                  gst_message_parse_tag (message, &tag_list);
                  if (tag_list)
                  {
                      gst_tag_list_foreach (tag_list, (GstTagForeachFunc) tag_foreach, tuple);
                      gst_tag_list_free (tag_list);
                  }
              }
              break;

          case GST_MESSAGE_ERROR:
              {
                  GError *error = 0;
                  gst_message_parse_error (message, &error, 0);
                  g_print ("%s ERROR: %s\n", G_STRLOC, error->message);
                  g_error_free (error);
              }
              break;

          default:
              break;
          }

          return FALSE;
      }

      void
      metadata_event_loop (TagReadTuple *tuple,
                           GstElement   *element,
                           gboolean      block)
      {
          GstBus *bus = gst_element_get_bus (element);
          g_return_if_fail (bus != 0);

          bool done = false;

          while (!done && !tuple->eos)
          {
              GstMessage *message;

              if (block)
                  message = gst_bus_poll (bus, GST_MESSAGE_ANY, -1);
              else
                  message = gst_bus_pop  (bus);

              if (message == 0)
              {
                  gst_object_unref (bus);
                  return;
              }

              done = metadata_bus_handler (bus, message, tuple);
              gst_message_unref (message);
          }
          gst_object_unref (bus);
      }

    } // anonymous namespace

    DB::DataRowVector
    Library::get_audiocd_metadata_offline (MusicBrainz &o)
    {
        DB::DataRowVector vector;

        if (o.Query (std::string (MBQ_GetCDTOC)))
        {
            g_log (BMPX_SYSTEM_LOG_DOMAIN, G_LOG_LEVEL_INFO, "%s: Unable to get read CD TOC", G_STRLOC);
            return vector;
        }

        unsigned int n_tracks = o.DataInt (MBE_TOCGetLastTrack);

        for (unsigned int i = 1; i <= n_tracks; i++)
        {
            DB::DataRow row;

            std::string uri = (boost::format ("cdda:///%d") % i).str ();
            row.insert (DB::DataRowPair (get_metadatum_id(DATUM_LOCATION), uri));

            std::string title = (boost::format ("Track %d") % i).str ();
            row.insert (DB::DataRowPair (get_metadatum_id(DATUM_TITLE), title));
            row.insert (DB::DataRowPair (get_metadatum_id(DATUM_TRACK), int(i)));
            row.insert (DB::DataRowPair (get_metadatum_id(DATUM_TIME),  int (get_duration_from_sectors(o.DataInt(MBE_TOCGetTrackNumSectors, i)))));
            vector.push_back (row);
        }

        return vector;
    }

    DB::DataRowVector
    Library::get_audiocd_metadata (int &status)
    {
        // Create the musicbrainz object, which will be needed for subsequent calls
        MusicBrainz o;
        o.UseUTF8 (true);

        DB::DataRowVector vector;
	bool isMultipleArtist = false;
	int trackNum = 0;

        int ret;
        ret = o.Query (MBQ_GetCDTOC);
        if (!ret)
        {
            string error;
            o.GetQueryError (error);
            g_message ("%s: Query failed: %s", G_STRLOC, error.c_str());
            status = MB_FAILURE;
            return vector;
        }

        std::string cdindex = o.Data(std::string (MBE_TOCGetCDIndexId));
        if (cdindex.empty())
        {
            std::string error;
            o.GetQueryError (error);
            g_message ("%s: Query failed: %s", G_STRLOC, error.c_str());
            status = MB_FAILURE;
            return vector;
        }

        ret = o.Query(std::string (MBQ_GetCDInfo));
        if (!ret)
        {
            std::string error;
            o.GetQueryError (error);
            g_message ("%s: Query failed: %s", G_STRLOC, error.c_str());
            status = MB_OFFLINE;
            return get_audiocd_metadata_offline (o);
        }

        // Select the first album
        std::list<int> argList;
        argList.push_back (1);
        if (!o.Select (std::string (MBS_SelectAlbum), &argList))
        {
            status = MB_OFFLINE;
            return get_audiocd_metadata_offline (o);
        }

        std::string album_id_url = o.Data(std::string (MBE_AlbumGetAlbumId));
        if (album_id_url.empty ())
        {
            return vector; 
        }

        std::string album_id;
        o.GetIDFromURL (album_id_url, album_id);

        // Extract the album name
        std::string album_name = o.Data(std::string (MBE_AlbumGetAlbumName));

        // Extract the number of tracks
        int n_tracks = o.DataInt(std::string (MBE_AlbumGetNumTracks));

        if (n_tracks < 1)
        {
            status = MB_OFFLINE;
            return get_audiocd_metadata_offline (o);
        }

        // Check to see if there is more than one artist for this album
        std::string artist_check;
        for (int i = 1; i <= n_tracks; i++)
        {
            std::string artist;
            artist = o.Data (std::string (MBE_AlbumGetArtistId));
            if (artist.empty ())
                break;

            if (i == 1)
            {
                artist_check = artist;
                continue;
            }

            if (artist.compare (artist_check))
            {
                isMultipleArtist = true;
                break;
            }
        }

        std::string artist_name, artist_id;

        if (!isMultipleArtist)
        {
            // Extract the artist name from the album
            artist_name = o.Data (std::string (MBE_AlbumGetArtistName), 1);

            // Extract the artist id from the album
            artist_id   = o.Data (std::string (MBE_AlbumGetArtistId), 1);
        }

        for(int i = 1; i <= n_tracks; i++)
        {
            DB::DataRow row;
            std::stringstream uri;

            uri << "cdda://" << cdindex << "/" << i;

            row.insert (DB::DataRowPair (mdefines[DATUM_LOCATION].id, uri.str()));
            row.insert (DB::DataRowPair (mdefines[DATUM_ALBUM].id, std::string (album_name)));
            row.insert (DB::DataRowPair (mdefines[DATUM_BITRATE].id, int(1411)));
            row.insert (DB::DataRowPair (mdefines[DATUM_SAMPLERATE].id, int(44100)));

            // Extract the track name from the album.
            std::string title = o.Data (std::string (MBE_AlbumGetTrackName), i);
            if (!title.empty ())
            {
                row.insert (DB::DataRowPair (mdefines[DATUM_TITLE].id, DB::ValueVariant (std::string (title))));
            }

            // Extract the album id from the track. Just use the
            // first album that this track appears on
            std::string track_id = o.Data (std::string (MBE_AlbumGetTrackId), i);
            if (!track_id.empty ())
            {
                // Extract the track number
                trackNum = o.GetOrdinalFromList (std::string (MBE_AlbumGetTrackList), track_id);
                if (trackNum > 0 && trackNum < 100)
                {
                    row.insert (DB::DataRowPair (mdefines[DATUM_TRACK].id,
                                                 DB::ValueVariant (int(trackNum))));
                }
            }

            // If its a multple artist album, print out the artist for each track
            if (isMultipleArtist)
            {
                // Extract the artist name from this track
                string individual_artist;
                individual_artist = o.Data(std::string (MBE_AlbumGetArtistName), i);

                if (!individual_artist.empty ())
                {
                    row.insert (DB::DataRowPair (mdefines[DATUM_ARTIST].id,
                                                 DB::ValueVariant (std::string (individual_artist))));
                }
            }
            else
            {
                row.insert (DB::DataRowPair (mdefines[DATUM_ARTIST].id,
                                             DB::ValueVariant (std::string (artist_name))));
            }

            vector.push_back (row);
        }

        ret = o.Query(MBQ_GetCDTOC);
        if (!ret)
        {
            std::string error;
            o.GetQueryError (error);
            g_message ("%s: Query failed: %s", G_STRLOC, error.c_str());
            status = MB_FAILURE;
            return vector;
        }

        for(int i = 1; i <= n_tracks; i++)
        {
            DB::DataRow& row = vector[i-1];
            int duration = get_duration_from_sectors(o.DataInt(MBE_TOCGetTrackNumSectors, i+1));
            row.insert (DB::DataRowPair (mdefines[DATUM_TIME].id, duration)); 
	} 

        status = MB_OK;
	return vector;
    }

    DB::DataRow
    Library::metadata_get_taglib (const Glib::ustring &uri)
    {
	Bmp::URI bmpuri (uri);
	bmpuri.unescape ();

        std::string filename = bmpuri.path;
        if (filename.empty())
        {
            throw Bmp::Library::INVALID_PATH;
        }

        TagLib::File *track = TagLib::FileRef::create(filename.c_str());
        if ((!track) || (!track->tag()) || (track->tag()->isEmpty()))
        {
            throw Bmp::Library::NO_METADATA; 
        }

        struct stat file_stat;
        stat (filename.c_str(), &file_stat);

        DB::DataRow row;
        row.insert (DB::DataRowPair (mdefines[DATUM_LOCATION].id,   std::string(uri)));
        row.insert (DB::DataRowPair (mdefines[DATUM_TRACK].id,      int (track->tag()->track())));
        row.insert (DB::DataRowPair (mdefines[DATUM_DATE].id,       int (track->tag()->year())));
        row.insert (DB::DataRowPair (mdefines[DATUM_ARTIST].id,     std::string (track->tag()->artist().to8Bit (true))));
        row.insert (DB::DataRowPair (mdefines[DATUM_ALBUM].id,      std::string (track->tag()->album().to8Bit (true))));
        row.insert (DB::DataRowPair (mdefines[DATUM_GENRE].id,      std::string (track->tag()->genre().to8Bit(true))));
        row.insert (DB::DataRowPair (mdefines[DATUM_COMMENT].id,    std::string (track->tag()->comment().to8Bit(true))));
        row.insert (DB::DataRowPair (mdefines[DATUM_RATING].id,     int (0)));
        row.insert (DB::DataRowPair (mdefines[DATUM_COUNT].id,      int (0)));
        row.insert (DB::DataRowPair (mdefines[DATUM_BITRATE].id,    int (track->audioProperties()->bitrate())));
        row.insert (DB::DataRowPair (mdefines[DATUM_SAMPLERATE].id, int (track->audioProperties()->sampleRate())));
        row.insert (DB::DataRowPair (mdefines[DATUM_TIME].id,       int (track->audioProperties()->length())));

        if  ((!track->tag()->title().toCString(true)) || (!std::strlen(track->tag()->title().toCString(true))))
            row.insert (DB::DataRowPair (mdefines[DATUM_TITLE].id, std::string (Glib::path_get_basename(bmpuri.path))));
        else
            row.insert (DB::DataRowPair (mdefines[DATUM_TITLE].id, std::string (track->tag()->title().to8Bit(true))));

        delete track;
        return row;
    }

    DB::DataRow
    Library::metadata_get_gst  (const Glib::ustring& uri)
    {
        boost::shared_ptr<TagReadTuple> ttuple;

        ttuple = boost::shared_ptr<TagReadTuple> (new TagReadTuple);
        ttuple->eos = false;
        ttuple->row.insert (DB::DataRowPair (get_metadatum_id (DATUM_TITLE),    std::string (uri)));
        ttuple->row.insert (DB::DataRowPair (get_metadatum_id (DATUM_LOCATION), std::string (uri)));

        GstElement *element   = gst_element_factory_make ("playbin",  "playbin0");
        GstElement *fakesink  = gst_element_factory_make ("fakesink", "fakesink0");
        GstElement *videosink = gst_element_factory_make ("fakesink", "fakesink1");

	Bmp::URI u (uri);
	u.unescape ();

        std::string uri_str = std::string (u); 
        g_object_set (G_OBJECT (element), "uri", uri_str.c_str(), "audio-sink", fakesink, "video-sink", videosink, NULL);

        GstStateChangeReturn state_ret = gst_element_set_state (element, GST_STATE_PAUSED);
        gint                 change_timeout = 5;

        while (state_ret == GST_STATE_CHANGE_ASYNC && change_timeout > 0)
        {
            GstState state;
            state_ret = gst_element_get_state (GST_ELEMENT (element), &state, 0, 1 * GST_SECOND);
            change_timeout--;
        }

        if (state_ret != GST_STATE_CHANGE_FAILURE && state_ret != GST_STATE_CHANGE_ASYNC)
        {
            /* Post application specific message so we'll know when to stop
             * the message loop */
            GstBus *bus;
            bus = gst_element_get_bus (GST_ELEMENT (element));
            if (bus)
            {
                gst_bus_post (bus, gst_message_new_application (GST_OBJECT (element), 0));
                gst_object_unref (bus);
            }

            /* Poll the bus for messages */
            metadata_event_loop (ttuple.get(), GST_ELEMENT (element), FALSE);
        }

        GstFormat  format = GST_FORMAT_TIME;
        GstQuery  *query  = gst_query_new_duration (format);

        if (gst_element_query (GST_ELEMENT(element), query))
        {
            gst_element_get_state (GST_ELEMENT(element), 0, 0, 100 * GST_MSECOND);

            gint64 length_in_nanoseconds;
            gst_query_parse_duration (query, &format, &length_in_nanoseconds);

            int length = length_in_nanoseconds / GST_SECOND;
            ttuple->row.insert (DB::DataRowPair (get_metadatum_id (DATUM_TIME), DB::ValueVariant (length)));
        }
        gst_query_unref (query);
        gst_element_set_state (GST_ELEMENT (element), GST_STATE_NULL);
        gst_object_unref (GST_ELEMENT (element));

        return ttuple->row;
    }

    std::string
    Library::get_titlestring (const std::string& uri)
    {
      GString	  *string_out   = 0;
      GString	  *string_field = 0;
      char	  *field;
      const char  *format;
      int	   n;
      bool	   hit = false;

      Bmp::DB::DataRow row;

      try { row = get_metadata (uri); } catch (...) { return std::string(); }

      if (row.empty()) return std::string();

      format = mcs->key_get<std::string>( "bmp", "titlestring-format") . c_str ();
      if (!format) return std::string();

      string_out = g_string_new ("");

      while (*format) {

	/* Begin sequence */
	if ((*format == '%') && (*(format+1) != 0) && (*(format+1) == '{'))
	  {
	    string_field = g_string_new ("");
	    format += 2;
	    while (*format && (*format != '}') && (*format != ' '))
	      {
		g_string_append_c (string_field, *format);
		format++;
	      }

	    field = g_string_free (string_field, FALSE);
	    if (!*format)
	      {
	        free (field);
		char *str = g_string_free (string_out, FALSE);
		std::string stdstr = str;
		free (str);
		return stdstr;
	      }

	    /* Append metadata field */
	    for (n = 0; n < Bmp::Library::DATUM_LAST; ++n)
	      {
		if (!g_ascii_strcasecmp (field, library->get_metadatum_id (Bmp::Library::Datum (n)).c_str())) 
                  {
		    Bmp::DB::ValueVariant v = row[std::string(field)];
		    char *value = 0;

		    if (Bmp::DB::ValueType(v.which()) == Bmp::DB::VALUE_TYPE_INT)
		    {
			value = g_strdup_printf ("%d", boost::get<int>(v)); 
		    }
		    else if (Bmp::DB::ValueType(v.which()) == Bmp::DB::VALUE_TYPE_STRING)
		    {
			value = strdup (boost::get<std::string>(v).c_str());
		    }

		    if (value)
		    {
		      g_strstrip (value);
		      if (strlen(value) && strcmp(value, "0") != 0)
		      {
			  hit = true;
			  g_string_append (string_out, value);
		      }
		      free (value);
		    }
		    break;
		  }
	      }
	    free (field);
	  }
	else
	  {
	    g_string_append_c (string_out, *format);
	  }
	format++;
    }

    if (!hit)
      {
	g_string_free (string_out, TRUE);
	return Glib::path_get_basename (uri);
      }
    else
      {
	char *str = g_string_free (string_out, FALSE);
	std::string stdstr = str;
	free (str);
	return stdstr;
      }
    }

    DB::DataRow 
    Library::cache_metadata (const std::string &uri, const std::string &root_path)
    {
        DB::DataRow row;
	try
	{
	  row = metadata_get_taglib (uri);
	}
	catch (Bmp::Library::Exception e)
	{
	  if (e != Bmp::Library::INVALID_PATH)
	    row = metadata_get_gst (uri);
	}

	if (!row.empty ())
	{
	    db->add ("main", row, map);
	}
	else
	{
	  throw Bmp::Library::NO_METADATA;	
	}

        return row;
    }

    void
    Library::del   (const DB::AttributeList &attrs)
    {
	signal_processing_start_.emit ();
	db->del("main", map, attrs);
	signal_processing_end_.emit ();
    }

    DB::DataRowVector
    Library::query (const DB::AttributeList &attrs)
    {
	return db->get ("main", map, attrs);
    }

    /** The caller must be aware that each row in this vector contains ONLY the requrested column, re-marshaling/transforming
      * the result into something more suitable, i.e. an std::vector<> of std::string would be just too much overhead
      */
    DB::DataRowVector
    Library::project (std::string	       p_col,
		      const DB::AttributeList &attrs)
    {
	return db->project ("main", p_col, map, attrs);
    }

    DB::DataRow
    Library::get_metadata (const std::string &pkey)
    {
	Bmp::URI u (pkey);
	if (u.get_protocol() == Bmp::URI::PROTOCOL_HTTP)
	{
	    DB::DataRow row;
	    row.insert (DB::DataRowPair (mdefines[DATUM_LOCATION].id, pkey)); 
            row.insert (DB::DataRowPair (mdefines[DATUM_TITLE].id, pkey));
	    row.insert (DB::DataRowPair (mdefines[DATUM_SAMPLERATE].id, int(0))); 
            row.insert (DB::DataRowPair (mdefines[DATUM_BITRATE].id, int(0)));
	    return row;
	}

        DB::AttributeList attrs;
        attrs.push_back (DB::Attribute (true, mdefines[DATUM_LOCATION].id, pkey));
        DB::DataRowVector vector = query (attrs);

	if (vector.empty())
	{
	  DB::DataRow row;
	  try
	  {
	    row = metadata_get_taglib (pkey);
	  }
	  catch (Bmp::Library::Exception e)
	  {
	    if (e != Bmp::Library::INVALID_PATH)
	    {
	      row = metadata_get_gst (pkey);
	    }
	  }

	  if (row.empty ())
	  {
	    throw Bmp::Library::NO_METADATA;	
	  }
	  return row;
	}
	else
	{
	  return vector[0]; 
	}	
      
    }

    const std::string
    Library::get_metadatum_id (Bmp::Library::Datum metadatum) const
    {
        return std::string (mdefines[metadatum].id);
    }

    const DatumDefine 
    Library::get_metadatum_define (Bmp::Library::Datum metadatum) const
    {
        return mdefines[metadatum];
    }


    bool
    Library::cache_audiocd (const std::string& cdindex_id)
    {
        int status;
        DB::DataRowVector rows = get_audiocd_metadata (status);
        if (status == MB_FAILURE) return false;

	DB::AttributeList attrs;
	std::stringstream value;
	value << "cdda://" << cdindex_id << "/1";
        attrs.push_back (DB::Attribute (true, mdefines[DATUM_LOCATION].id, value.str ()));

	if (query(attrs).empty())
	{
	  for (DB::DataRowVector::const_iterator iter = rows.begin (); iter != rows.end (); ++iter)
	  {
	    db->add ("main", (*iter), map);
	  }
	}
        return true;
    }

    const DB::ValueMap &
    Library::get_map () const
    {
        return map;
    }

    Library::Library ()
    {
        for (unsigned int n = 0; n < G_N_ELEMENTS(mdefines); n++)
        {
            map.insert (std::make_pair(std::string (mdefines[n].id), mdefines[n].type));
        }

        db = new DB::DB	  ("library", BMP_PATH_USER_DIR, false);
        db->create_table  ("main",				      //table name
			   std::string (mdefines[DATUM_LOCATION].id), //pkey identifier/column name
			   map);				      //mapping for the query (must be the same mapping used to create the table)
    }

    Library::~Library ()
    {
        delete db;
    }

    Library::SignalProcessing&
    Library::signal_processing_start ()
    { 
      return signal_processing_start_;
    }

    Library::SignalProcessing&
    Library::signal_processing_end ()
    { 
      return signal_processing_end_;
    }

  } // Library namespace

} // Bmp namespace
