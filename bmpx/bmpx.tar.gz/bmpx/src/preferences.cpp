//  BMPx - The Dumb Music Player
//  Copyright (C) 2005-2006 BMPx development team.
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
//
//  --
//
//  The BMPx project hereby grants permission for non GPL-compatible GStreamer
//  plugins to be used and distributed together with GStreamer and BMPx. This
//  permission is above and beyond the permissions granted by the GPL license
//  BMPx is covered by.

#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include "preferences.hpp"

#include <revision.h>
#include <build.h>
#include <utility>

#include <boost/format.hpp>
#include <boost/algorithm/string.hpp>

#ifdef HAVE_ALSA
#  define ALSA_PCM_NEW_HW_PARAMS_API
#  define ALSA_PCM_NEW_SW_PARAMS_API

#  include <alsa/global.h>
#  include <alsa/asoundlib.h>
#  include <alsa/pcm_plugin.h>
#  include <alsa/control.h>
#endif

#include <glibmm.h>
#include <glib/gi18n.h>
#include <gtkmm.h>
#include <libglademm.h>

#include <bmp/widgets/bmp_tooltips.h>
#include <mcs/mcs.h>

#include "main.hpp"
#include "paths.hpp"
#include "skin_view.hpp"

namespace Bmp
{
  namespace
  {
    struct Category
    {
        const char *icon_path;
        const char *name;
        int         page;
    };

    Category categories[] =
    {
        {DATA_DIR "/images/preferences/appearance.png", N_("Appearance"), 0},
        //  {DATA_DIR "/images/preferences/eq.png",         N_("Equalizer"),  1},
        {DATA_DIR "/images/preferences/playlist.png",   N_("Playlist"),   2},
        {DATA_DIR "/images/preferences/playback.png",   N_("Audio"),      3},
        //  {DATA_DIR "/images/preferences/plugins.png",    N_("Plugins"),        4},
        {DATA_DIR "/images/preferences/lastfm.png",     N_("Last.FM"),    5},
        {DATA_DIR "/images/preferences/library.png",    N_("Library"),    6},
        {DATA_DIR "/images/preferences/misc.png",    N_("Miscellaneous"),    7},
    };

    struct AudioSystem
    {
        const char		     *description;
        const char		     *sink_name;
        gint			      tab_id;
        Bmp::Preferences::AudioSink   sink_id;
    };

    AudioSystem audio_systems[] =
    {
#ifdef HAVE_ALSA
        {"ALSA (Advanced Linux Sound Architecture)",
         "alsasink",
         1,
         Preferences::SINK_ALSA},
#endif
        {"OSS (Open Sound System)",
         "osssink",
         2,
         Preferences::SINK_OSS},
#ifdef HAVE_SUN
        {"Sun/Solaris Audio",
         "sunaudiosink",
         3,
         Preferences::SINK_SUNAUDIO},
#endif
        {"ESD (Enlightenment Sound Daemon)",
         "esdsink",
         4,
         Preferences::SINK_ESD},
    };


#if 0
    BmpTooltipEntry window_preferences_tooltips[] = {
        { "skin_view",
          N_("Here you can choose a skin to determine how BMPx looks like"),
          GTK_STOCK_INFO },

        { "font_button",
          N_("Click on this button to select a font for BMPx to use"),
          GTK_STOCK_INFO }
    };
#endif

  } // <anonymous> namespace

  class Preferences::CategoryView
      : public Gtk::TreeView
  {
  public:

      CategoryView (BaseObjectType                        *cobject,
                    const Glib::RefPtr<Gnome::Glade::Xml> &xml);

      int
      get_selected_page ();

  private:

      // Category columns record
      class ColumnRecord
          : public Gtk::TreeModel::ColumnRecord
      {
      public:

          Gtk::TreeModelColumn<Glib::RefPtr<Gdk::Pixbuf> > icon;
          Gtk::TreeModelColumn<Glib::ustring>              name;
          Gtk::TreeModelColumn<int>                        page;

          ColumnRecord ()
          {
              add (icon);
              add (name);
              add (page);
          }
      };

      Glib::RefPtr<Gtk::ListStore> list_store;
      ColumnRecord                 columns;
  };

  // List column columns record
  class Preferences::ListColumnView
      : public Gtk::TreeView
  {
  public:

      ListColumnView (BaseObjectType                        *cobject,
                      const Glib::RefPtr<Gnome::Glade::Xml> &xml);

  private:

      class ColumnRecord
          : public Gtk::TreeModel::ColumnRecord
      {
      public:

          Gtk::TreeModelColumn<bool>          active;
          Gtk::TreeModelColumn<Glib::ustring> path;

          ColumnRecord ()
          {
              add (active);
              add (path);
          }
      };

      Glib::RefPtr<Gtk::ListStore> list_store;
      ColumnRecord                 columns;

      void
      on_column_toggled (const Glib::ustring& path_str);
  };

  //-- Preferences::CategoryView implementation --------------------------------

  Preferences::CategoryView::CategoryView (BaseObjectType                        *cobject,
                                           const Glib::RefPtr<Gnome::Glade::Xml> &xml)
      : Gtk::TreeView (cobject)
  {
      set_headers_clickable (false);
      set_headers_visible (false);

      Gtk::CellRendererPixbuf *cell_pixbuf = Gtk::manage (new Gtk::CellRendererPixbuf ());
      cell_pixbuf->property_ypad () = 2;

      append_column ("Icon", *cell_pixbuf);
      get_column (0)->add_attribute (*cell_pixbuf, "pixbuf", 0);
      get_column (0)->set_resizable (false);

      Gtk::CellRendererText *cell_text = Gtk::manage (new Gtk::CellRendererText ());

      append_column ("Description", *cell_text);
      get_column (1)->add_attribute (*cell_text, "text", 1);
      get_column (1)->set_resizable (false);

      list_store = Gtk::ListStore::create (columns);

      for (unsigned int i = 0; i < G_N_ELEMENTS (categories); i++)
      {
          Gtk::TreeModel::iterator iter = list_store->append ();

          (*iter)[columns.icon] = Gdk::Pixbuf::create_from_file (categories[i].icon_path);
          (*iter)[columns.name] = categories[i].name;
          (*iter)[columns.page] = categories[i].page;
      }

      set_model (list_store);
  }

  int
  Preferences::CategoryView::get_selected_page ()
  {
      Gtk::TreeModel::iterator iter = get_selection ()->get_selected ();
      return (*iter)[columns.page];
  }

  //-- Preferences::ListColumnView implementation ------------------------------

  Preferences::ListColumnView::ListColumnView (BaseObjectType                        *cobject,
                                               const Glib::RefPtr<Gnome::Glade::Xml> &xml)
      : Gtk::TreeView (cobject)
  {
      list_store = Gtk::ListStore::create (columns);

      for (unsigned int n = 0; n < vcolumns_get_n_items (); n++)
      {
          std::string key_name = (boost::format ("column_%d_visible") % n).str ();

          Gtk::TreeModel::iterator iter = list_store->append ();
	  Bmp::Library::DatumDefine define = library->get_metadatum_define (vcolumns_get_item_nth (Bmp::Library::Datum (n)));

          (*iter)[columns.active] = mcs->key_get<bool>("tracklist", key_name);
          (*iter)[columns.path]   = define.title; 
      }

      Gtk::CellRendererToggle *cell_toggle = Gtk::manage (new Gtk::CellRendererToggle ());

      append_column ("Active", *cell_toggle);
      get_column (0)->add_attribute (*cell_toggle, "active", 0);
      get_column (0)->set_resizable (false);
      cell_toggle->signal_toggled ().connect (sigc::mem_fun (this, &ListColumnView::on_column_toggled));

      Gtk::CellRendererText *cell_text = Gtk::manage (new Gtk::CellRendererText ());

      append_column ("Name", *cell_text);
      get_column (1)->add_attribute (*cell_text, "text", 1);
      get_column (1)->set_resizable (false);

      set_model (list_store);
  }

  void
  Preferences::ListColumnView::on_column_toggled (const Glib::ustring &path_str)
  {
      Gtk::TreeModel::iterator iter = list_store->get_iter (path_str);
      (*iter)[columns.active] = !(*iter)[columns.active];

      Gtk::TreePath path (path_str);
      int           column_num = path.get_indices ().data ()[0];

      BmpWindowPlaylist *window_playlist = BMP_WINDOW_PLAYLIST (RM_GET_ITEM ("windows","window-playlist", NOLOCK));
      bmp_window_playlist_column_set_active (window_playlist, column_num, (*iter)[columns.active]);
  }

  //-- Preferences implementation ----------------------------------------------

  Preferences *
  Preferences::create ()
  {
      const std::string path = DATA_DIR "/glade/preferences.glade";

      Glib::RefPtr<Gnome::Glade::Xml> glade_xml = Gnome::Glade::Xml::create (path);

      Preferences *preferences = 0;
      glade_xml->get_widget_derived ("preferences", preferences);
      return preferences;
  }

  // ctor
  Preferences::Preferences (BaseObjectType                        *cobject,
                            const Glib::RefPtr<Gnome::Glade::Xml> &xml)
      : Gtk::Window (cobject),
        ref_xml (xml)
  {

      // acquire consistently needed widgets
      ref_xml->get_widget ("category_notebook", notebook_categories);

      ref_xml->get_widget_derived ("category_view", category_view);
      ref_xml->get_widget_derived ("skin_view",     skin_view);
      ref_xml->get_widget_derived ("columns_view",  list_column_view);

      // TODO: Find a nicer way to do this. Most importantly, avoid using literal constants.
      ref_xml->get_widget ("skins_notebook", notebook_skins);
      ref_xml->get_widget ("l_queue_size",   l_queue_size);
      ref_xml->get_widget ("l_version",      l_version);
      ref_xml->get_widget ("close",          close);

      Glib::RefPtr<Gtk::TreeSelection> selection = category_view->get_selection ();
      selection->signal_changed ().connect (sigc::mem_fun (this, &Preferences::on_category_changed));

      skin_view->signal_cursor_changed ().connect (sigc::mem_fun (this, &Preferences::on_skin_changed));
      skin_view->signal_refresh ().connect (sigc::bind (sigc::mem_fun (notebook_skins, &Gtk::Notebook::set_current_page), 1));
      skin_view->signal_refresh_end ().connect (sigc::bind (sigc::mem_fun (notebook_skins, &Gtk::Notebook::set_current_page), 0));

      close->signal_clicked().connect (sigc::mem_fun (this, &Preferences::hide));

      // set version string
      boost::format version_format ("<span size='small' color='#606060'>BMPx %s:%s-R%s (%s / %s)</span>");
      std::string version = (version_format % PACKAGE_VERSION % RV_LAST_CHANGED_DATE % RV_REVISION % BUILD_DATE % BUILD_BUILDUSER).str ();
      l_version->set_markup (version);

      // set misc images
      Gtk::Image *image;
      ref_xml->get_widget ("image_building", image);
      image->set (Glib::build_filename (DATA_DIR, "images/wait.gif"));
      ref_xml->get_widget ("last_fm_header_logo", image);
      image->set (Glib::build_filename (DATA_DIR, "images/lastfm-logo.png"));
      ref_xml->get_widget ("last_fm_poweredby", image);
      image->set (Glib::build_filename (DATA_DIR, "images/audioscrobbler.png"));

      // other widgets
      ref_xml->get_widget ("last_fm_enable", last_fm_enable);
      ref_xml->get_widget ("last_fm_netstatus", last_fm_netstatus);
      ref_xml->get_widget ("last_fm_netstatus", last_fm_netstatus);

      ref_xml->get_widget ("cbox_audio_system", cbox_audio_system);

#ifdef HAVE_ALSA
      ref_xml->get_widget ("cbox_alsa_card", cbox_alsa_card);
      ref_xml->get_widget ("cbox_alsa_device", cbox_alsa_device);
      ref_xml->get_widget ("alsa_buffer_time", alsa_buffer_time);
#endif

      ref_xml->get_widget ("cbe_oss_device", cbe_oss_device);
      ref_xml->get_widget ("oss_buffer_time", oss_buffer_time);

      ref_xml->get_widget ("esd_host", esd_host);
      ref_xml->get_widget ("esd_buffer_time", esd_buffer_time);

#ifdef HAVE_SUNDAUDIO
      ref_xml->get_widget ("cbe_sun_device", cbe_sun_device);
      ref_xml->get_widget ("sun_buffer_time", sun_buffer_time);
#endif

      ref_xml->get_widget ("notebook_audio_system", notebook_audio_system);

      ref_xml->get_widget ("b_audio_system_apply", b_audio_system_apply);
      ref_xml->get_widget ("hbox_warning", hbox_warning);

      // bind togglebuttons
      static char* toggle_buttons[] = {
          "ui-esc-trayconify",
          "library-add-automatically",
          "library-no-incomplete-add",
          "resume-on-startup",
          "use-custom-cursors",
          "display-tooltips",
          "display-tracklist-numbers"
      };

      for (unsigned int n = 0; n < G_N_ELEMENTS (toggle_buttons); n++)
      {
          Gtk::ToggleButton *button;
          ref_xml->get_widget (toggle_buttons[n], button);
          mcs_bind->bind_toggle_button (Glib::RefPtr<Gtk::ToggleButton>(button), "bmp", toggle_buttons[n]);
      }

      // Font Button
      Gtk::FontButton *font_button;
      ref_xml->get_widget ("font_button", font_button);
      mcs_bind->bind_font_button (Glib::RefPtr<Gtk::FontButton>(font_button), "bmp", "font");

      // Last.FM stuff
      Gtk::Entry *entry;

      ref_xml->get_widget ("last_fm_username", entry);
      mcs_bind->bind_entry (Glib::RefPtr<Gtk::Entry>(entry), "lastfm", "username");

      ref_xml->get_widget ("last_fm_password", entry);
      mcs_bind->bind_entry (Glib::RefPtr<Gtk::Entry>(entry), "lastfm", "password");

      mcs->subscribe ("Preferences", "lastfm", "enable", sigc::mem_fun (this, &Preferences::mcs_lastfm_enable_changed));
      mcs->subscribe ("Preferences", "lastfm", "general-enable", sigc::mem_fun (this, &Preferences::mcs_lastfm_general_enable_changed));

      Gtk::ToggleButton *toggle_button;
      ref_xml->get_widget ("last_fm_enable", toggle_button);
      mcs_bind->bind_toggle_button (Glib::RefPtr<Gtk::ToggleButton>(toggle_button), "lastfm", "enable");

      ref_xml->get_widget ("last_fm_general_enable", toggle_button);
      mcs_bind->bind_toggle_button (Glib::RefPtr<Gtk::ToggleButton>(toggle_button), "lastfm", "general-enable");

      // Tooltips
      mcs->subscribe ("Preferences", "bmp", "display-tooltips", sigc::mem_fun (this, &Preferences::mcs_display_tooltips_changed));
  }

  void
  Preferences::on_category_changed ()
  {
      if (category_view->get_selection ()->count_selected_rows () == 0)
          return;

      notebook_categories->set_current_page (category_view->get_selected_page ());
  }

  void
  Preferences::on_skin_changed ()
  {
      std::string skin = skin_view->get_selected_skin_path ();
      std::string skin_current = mcs->key_get<std::string>("bmp", "skin");

      if (skin_current.compare (skin))
      {
          mcs->key_set<std::string>("bmp", "skin", skin);
      }
      else
      {
          return;
      }

      // FIXME: mconfig should in a sensible way ignore re-setting the
      // same value to a key by itself, but this needs to be checked
      // carefully
  }

  void
  Preferences::mcs_display_tooltips_changed (MCS_CB_DEFAULT_SIGNATURE)
  {
      BmpTooltips *tooltips;

#if 0
      tooltips = BMP_TOOLTIPS (RM_GET_ITEM ("tooltips","tooltips-preferences", LOCK));
      if (!boost::get<bool>(value))
          bmp_tooltips_disable (tooltips);
      else
          bmp_tooltips_enable  (tooltips);
      RM_ITEM_UNLOCK("tooltips","tooltips-preferences");
#endif

      tooltips = BMP_TOOLTIPS (RM_GET_ITEM ("tooltips","tooltips-main", LOCK));
      if (!boost::get<bool>(value))
          bmp_tooltips_disable (tooltips);
      else
          bmp_tooltips_enable  (tooltips);
      RM_ITEM_UNLOCK("tooltips","tooltips-main");

  }

  bool
  Preferences::scrobbler_set_idle_image ()
  {
      last_fm_netstatus->set (network[LAST_FM_IDLE]);
      return false;
  }

  bool
  Preferences::scrobbler_set_tx_image ()
  {
      last_fm_netstatus->set (network[LAST_FM_TX]);
      return false;
  }

  void
  Preferences::on_scrobbler_queue_size (unsigned int queue_size)
  {
      l_queue_size->set_text ((boost::format ("%u") % queue_size).str ());
  }

  void
  Preferences::on_scrobbler_submit_end ()
  {
      last_fm_netstatus->set (network[LAST_FM_RX]);
      Glib::signal_timeout().connect (sigc::mem_fun (this, &Preferences::scrobbler_set_idle_image), 1000);
  }

  void
  Preferences::on_scrobbler_submit_start ()
  {
      Glib::signal_timeout().connect (sigc::mem_fun (this, &Preferences::scrobbler_set_tx_image), 1000);
  }

  void
  Preferences::mcs_lastfm_enable_changed
  (MCS_CB_DEFAULT_SIGNATURE)
  {
      bool                 active;
      active = mcs->key_get<bool>("lastfm", "enable");
      if (last_fm_enable->get_active () != active ) last_fm_enable->set_active (active );
      last_fm_netstatus->set_sensitive (active );
  }

  void
  Preferences::mcs_lastfm_general_enable_changed
  (MCS_CB_DEFAULT_SIGNATURE)
  {
      Gtk::Widget *widget;
      bool           active;

      static gchar* widget_names[] = {
          "last_fm_table_credentials",
          "last_fm_hbox_explanation",
          "last_fm_enable",
          "last_fm_label_login",
          "last_fm_status"
      };

      active = mcs->key_get<bool>("lastfm", "general-enable");

      for (unsigned int n = 0; n < G_N_ELEMENTS(widget_names); n++)
      {
          widget = ref_xml->get_widget (widget_names[n]);
          widget->set_sensitive (active );
      }

      static char *last_fm_network[] =
      {
          "lastfm-net-idle.png",
          "lastfm-net-rx.png",
          "lastfm-net-tx.png"
      };

      for (unsigned int n = 0; n < 3; n++)
      {
          Glib::ustring filename;

          filename = Glib::build_filename (DATA_DIR, Glib::build_filename("images", last_fm_network[n]));
          network[n] = Gdk::Pixbuf::create_from_file (filename);
      }

      last_fm_netstatus->set (network[LAST_FM_IDLE]);

      bmp_scrobbler->signal_queue_size ().connect (sigc::mem_fun (this, &Preferences::on_scrobbler_queue_size));
      bmp_scrobbler->signal_submit_start ().connect (sigc::mem_fun (this, &Preferences::on_scrobbler_submit_start));
      bmp_scrobbler->signal_submit_end ().connect (sigc::mem_fun (this, &Preferences::on_scrobbler_submit_end));
      bmp_scrobbler->emit_queue_size ();

      // setup audio..
      setup_audio ();
  }

  // Audio preferences
  void
  Preferences::on_cbox_audio_system_changed     ()
  {
      Gtk::TreeModel::iterator iter = cbox_audio_system->get_active ();
      notebook_audio_system->set_current_page ((*iter)[audio_system_columns.tab_id]);
  }

  void
  Preferences::set_apply_sensitive ()
  {
      b_audio_system_apply->set_sensitive (true);
      hbox_warning->set_sensitive (true);
  }

#ifdef HAVE_ALSA
  void
  Preferences::on_cbox_alsa_card_changed ()
  {
      Gtk::TreeModel::iterator iter_model = cbox_alsa_card->get_active ();

      list_store_alsa_device = Gtk::ListStore::create (alsa_device_columns);
      cbox_alsa_device->set_model (list_store_alsa_device);

      if (cbox_alsa_card->get_active_row_number () == 0)
      {
          cbox_alsa_device->set_sensitive (false);
      }
      else
      {
          AlsaCard                   card = (*iter_model)[alsa_card_columns.card];
          AlsaDevices               &devices = card.devices;
          Gtk::TreeModel::iterator  iter_model_devices;

          for (AlsaDevices::iterator iter_devices = devices.begin (); iter_devices != devices.end (); iter_devices++ )
          {
              AlsaDevice &device = *iter_devices;

              iter_model_devices = list_store_alsa_device->append ();
              (*iter_model_devices)[alsa_device_columns.name]   = device.description;
              (*iter_model_devices)[alsa_device_columns.device] = device;
          }
          cbox_alsa_device->set_sensitive (true);
          cbox_alsa_device->set_active (0);
      }
  }
#endif

  void
  Preferences::on_b_audio_system_apply ()
  {
      b_audio_system_apply->set_sensitive (false );
      hbox_warning->set_sensitive (false );

      Gtk::TreeModel::iterator  iter      = cbox_audio_system->get_active ();
      AudioSink                 sink_id   = (*iter)[audio_system_columns.sink_id];
      Glib::ustring             sink_name = (*iter)[audio_system_columns.sink_name];
      Glib::ustring             device;

      bmp_play_engine->property_status() = PLAYSTATUS_STOPPED;

      mcs->key_set<std::string>("audio", "sink", sink_name);

      switch (sink_id)
      {

#ifdef HAVE_ALSA

      case SINK_ALSA:
          {
              AlsaDevice alsa_device;
              int active;

              active = cbox_alsa_device->get_active_row_number ();

              if (active > 0)
              {
                  Gtk::TreeModel::iterator iter = cbox_alsa_device->get_active ();
                  alsa_device = (*iter)[alsa_device_columns.device];
                  device = alsa_device.dev;

                  mcs->key_set<std::string>("audio", "device-alsa", device);
              }
              else
              {
                  mcs->key_set<std::string>("audio", "device-alsa", "default");
              }
          }
          break;
#endif

      case SINK_OSS:
          {
              device = cbe_oss_device->get_entry()->get_text();
              mcs->key_set<std::string>("audio", "device-oss", device);
          }
          break;

      case SINK_ESD:
          {
              device = esd_host->get_text();
              mcs->key_set<std::string>("audio", "device-esd", device);
          }
          break;

#ifdef HAVE_SUN
      case SINK_SUNAUDIO:
          {
              device = cbe_sun_device->get_entry()->get_text();
              mcs->key_set<std::string>("audio", "device-sun", device);
          }
          break;
#endif

      default: return;

      }

      bmp_play_engine->reset();
  }

#ifdef HAVE_ALSA
  Bmp::Preferences::AlsaCards
  Preferences::get_alsa_cards ()
  {
      Bmp::Preferences::AlsaCards	cards;

      int card = -1;

      int snd_err = snd_card_next (&card);

      if (snd_err)
      {
	  g_critical ("%s: %s", G_STRLOC, snd_strerror (snd_err));
	  return cards;
      }

      while (card > -1)
      {
          snd_pcm_info_t *pcm_info;
          snd_ctl_t	 *ctl;
          int	          pcm_device;

          Bmp::Preferences::AlsaCard        alsa_card;

          char *name;
          snd_card_get_name (card, &name);

          std::string dev = (boost::format ("hw:%d") % card).str ();

          snd_err = snd_ctl_open (&ctl, dev.c_str (), 0);
          if (snd_err)
          {
              g_critical ("%s: %s", G_STRLOC, snd_strerror (snd_err));
              break;
          }

          alsa_card.dev = dev;
          alsa_card.description = name;
          alsa_card.card_id = card;

          pcm_device = -1;

          while (42)
          {
              Bmp::Preferences::AlsaDevice alsa_device;

              if (!ctl)
	      {
		  break;
	      }

              snd_err = snd_ctl_pcm_next_device (ctl, &pcm_device);
              if (snd_err)
	      {
		  g_critical ("%s: %s", G_STRLOC, snd_strerror (snd_err));
		  break;
	      }

              // FIXME: Do we really need this here still?
              if (pcm_device < 0)
                  break;

              snd_pcm_info_malloc (&pcm_info);
              snd_pcm_info_set_device (pcm_info, pcm_device);
              snd_pcm_info_set_subdevice (pcm_info, 0);
              snd_pcm_info_set_stream (pcm_info, SND_PCM_STREAM_PLAYBACK);

              snd_err = snd_ctl_pcm_info (ctl, pcm_info);

              if (snd_err)
	      {
		  g_critical ("%s: %s", G_STRLOC, snd_strerror (snd_err));
		  break;
	      }

              alsa_device.dev         = (boost::format ("hw:%d,%d") % card % pcm_device).str ();
              alsa_device.description = (boost::format ("%s: %s") % name % snd_pcm_info_get_name (pcm_info)).str ();
              alsa_device.card_id     = card;
              alsa_device.device_id   = pcm_device;

              alsa_card.devices.push_back (alsa_device);

              snd_pcm_info_free (pcm_info);
          }

          cards.push_back (alsa_card);

          if (ctl)
          {
              snd_ctl_close (ctl);
          }

          snd_card_next (&card);
          if (card < 0 ) break;
      }

      return cards;
  }
#endif

  void
  Preferences::setup_audio ()
  {
      Gtk::CellRendererText *cell_text;
      std::string            sink;
      int                      current = -1;

      list_store_audio_systems = Gtk::ListStore::create (audio_system_columns);

      sink = mcs->key_get<std::string>("audio", "sink");

      for (unsigned int n = 0; n < G_N_ELEMENTS (audio_systems); n++)
      {
          GstElement  *element;
          Gtk::TreeModel::iterator iter;

          element = gst_element_factory_make (audio_systems[n].sink_name, "sinktest0");
          if (!element) continue;
          gst_object_unref (element);

          available_sinks.insert (std::make_pair (audio_systems[n].sink_name, true));

          iter = list_store_audio_systems->append ();

          (*iter)[audio_system_columns.description] = audio_systems[n].description;
          (*iter)[audio_system_columns.sink_name] = audio_systems[n].sink_name;
          (*iter)[audio_system_columns.tab_id] = audio_systems[n].tab_id;
          (*iter)[audio_system_columns.sink_id] = audio_systems[n].sink_id;

          if (!sink. compare(audio_systems[n].sink_name))
          {
              current = n;
          }
      }

      cell_text = Gtk::manage (new Gtk::CellRendererText() );
      cbox_audio_system->clear ();
      cbox_audio_system->pack_start (*cell_text);
      cbox_audio_system->add_attribute (*cell_text, "text", 0);
      cbox_audio_system->set_model (list_store_audio_systems);
      cbox_audio_system->set_active (current);

      cbox_audio_system->signal_changed().connect (sigc::mem_fun (this, &Preferences::on_cbox_audio_system_changed));

      if (current == -1)
          notebook_audio_system->set_current_page (0);
      else
          notebook_audio_system->set_current_page (audio_systems[current].tab_id);

#ifdef HAVE_ALSA

      if (available_sinks.find ("alsasink") != available_sinks.end ())
      {
          list_store_alsa_cards = Gtk::ListStore::create (alsa_card_columns);
          Gtk::TreeModel::iterator iter_model;
          AlsaCards cards = Bmp::Preferences::get_alsa_cards ();

          iter_model = list_store_alsa_cards->append ();
          (*iter_model)[alsa_card_columns.name] = "System Default";

          for (AlsaCards::iterator iter = cards.begin (); iter != cards.end (); iter++)
          {
              AlsaCard &card = (*iter);

              iter_model = list_store_alsa_cards->append ();
              (*iter_model)[alsa_card_columns.name] = card.description;
              (*iter_model)[alsa_card_columns.card] = card;
          }

          cell_text = Gtk::manage (new Gtk::CellRendererText () );
          cbox_alsa_card->clear ();
          cbox_alsa_card->pack_start (*cell_text);
          cbox_alsa_card->add_attribute (*cell_text, "text", 0);
          cbox_alsa_card->set_model (list_store_alsa_cards);

          cbox_alsa_card->signal_changed ().connect (sigc::mem_fun (this, &Preferences::on_cbox_alsa_card_changed));

          cell_text = Gtk::manage (new Gtk::CellRendererText () );
          cbox_alsa_device->clear ();
          cbox_alsa_device->pack_start (*cell_text);
          cbox_alsa_device->add_attribute (*cell_text, "text", 0);

          // We have to parse the current device here in case in case sink is alsasink
          if (!sink.compare("alsasink"))
          {
              std::string device;
              device = mcs->key_get<std::string>("audio", "device-alsa");

              if (!device. compare("default"))
              {
                  cbox_alsa_card->set_active (0);
              }
              else
              {
                  using namespace boost::algorithm;
                  std::vector<std::string> subs;

                  split (subs, device, is_any_of (":,"));

                  if (subs.size() && subs[0].compare("hw"))
                  {
                      g_message ("Invalid identifier '%s", subs[0].c_str ());
                  }
                  else if (subs.size() && !subs[0].compare("hw"))
                  {
                      int card,
                      device;

                      card    = atoi (subs[1].c_str ()) + 1;
                      device  = atoi (subs[2].c_str ());

                      cbox_alsa_card->set_active (card);
                      cbox_alsa_device->set_active (device);
                  }
              }
          }

          mcs_bind->bind_spin_button (Glib::RefPtr<Gtk::SpinButton>(alsa_buffer_time), "audio", "alsa-buffer-time");

          alsa_buffer_time->signal_value_changed().connect(sigc::mem_fun (this, &Preferences::set_apply_sensitive));
          cbox_alsa_device->signal_changed().connect(sigc::mem_fun (this, &Preferences::set_apply_sensitive));
          cbox_alsa_card->signal_changed().connect(sigc::mem_fun (this, &Preferences::set_apply_sensitive));
      }

#endif

      if (available_sinks.find ("osssink") != available_sinks.end ())
      {
          mcs_bind->bind_cbox_entry (Glib::RefPtr<Gtk::ComboBoxEntry>(cbe_oss_device), "audio", "device-oss");
          mcs_bind->bind_spin_button (Glib::RefPtr<Gtk::SpinButton>(oss_buffer_time), "audio", "oss-buffer-time");

          if (!sink.compare("osssink"))
          {
              std::string device;
              device = mcs->key_get<std::string>("audio", "device-oss");

              cbe_oss_device->get_entry()->set_text (device );
          }

          cbe_oss_device->signal_changed().connect(sigc::mem_fun (this, &Preferences::set_apply_sensitive));
          oss_buffer_time->signal_value_changed().connect(sigc::mem_fun (this, &Preferences::set_apply_sensitive));
      }

#ifdef HAVE_SUN

      if (available_sinks.find ("sunaudiosink") != available_sinks.end ())
      {
          mcs_bind->bind_cbox_entry (Glib::RefPtr<Gtk::ComboBoxEntry>(cbe_sun_device), "audio", "device-sun");
          mcs_bind->bind_spin_button (Glib::RefPtr<Gtk::SpinButton>(sun_buffer_time), "audio", "sun-buffer-time");

          sun_buffer_time->signal_value_changed ().connect(sigc::mem_fun (this, &Preferences::set_apply_sensitive));
          cbe_sun_device->signal_changed ().connect(sigc::mem_fun (this, &Preferences::set_apply_sensitive));
      }

#endif

      if (available_sinks.find ("esdsink") != available_sinks.end ())
      {
          mcs_bind->bind_entry (Glib::RefPtr<Gtk::Entry>(esd_host), "audio", "device-esd");
          mcs_bind->bind_spin_button (Glib::RefPtr<Gtk::SpinButton>(esd_buffer_time), "audio", "esd-buffer-time");

          esd_buffer_time->signal_value_changed ().connect(sigc::mem_fun (this, &Preferences::set_apply_sensitive));
          esd_host->signal_changed ().connect(sigc::mem_fun (this, &Preferences::set_apply_sensitive));
      }

      cbox_audio_system->signal_changed().connect(sigc::mem_fun (this, &Preferences::set_apply_sensitive));
      b_audio_system_apply->signal_clicked().connect(sigc::mem_fun (this, &Preferences::on_b_audio_system_apply));

      // Setup support status indicators
      Gtk::Image *image;
      ref_xml->get_widget ("img_status_cdda", image);
      image->set (bmp_play_engine->property_has_cdda() ? Gtk::Stock::YES : Gtk::Stock::NO , Gtk::ICON_SIZE_MENU);
      ref_xml->get_widget ("img_status_http", image);
      image->set (bmp_play_engine->property_has_http() ? Gtk::Stock::YES : Gtk::Stock::NO , Gtk::ICON_SIZE_MENU);

      b_audio_system_apply->set_sensitive (false);
      hbox_warning->set_sensitive (false);
  }

} // namespace Bmp

