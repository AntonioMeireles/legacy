/*  BMPx - Cross-platform multimedia player
 *  Copyright (C) 2005 BMPx development team.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 *  $Id$
 *
 * The BMPx project hereby grant permission for non-gpl compatible GStreamer
 * plugins to be used and distributed together with GStreamer and BMPx. This
 * permission are above and beyond the permissions granted by the GPL license
 * BMPx is covered by.
 */

#ifndef HAVE_CONFIG_H
#  include "config.h"
#endif

#include <glib.h>
#include <glib/gi18n.h>
#include <gmodule.h>
#include <gtk/gtk.h>
#include <glade/glade.h>

#include <gtkmm/messagedialog.h>
#include <boost/format.hpp>

#include "glade.hpp"


GladeXML *
glade_xml_new_or_die(const gchar * name,
                     const gchar * path,
                     const gchar * root,
                     const gchar * domain)
{
    const gchar *markup =
        N_("<b><big>Unable to create %s.</big></b>\n"
           "\n"
           "Could not open glade file:\n<b>%s</b>\n"
           "\n"
           "Please check your installation.\n");

    GladeXML *xml = glade_xml_new (path, root, domain);

    if (!xml) {
        Glib::ustring message = _((boost::format (markup) % name % path).str ().c_str ());

        Gtk::MessageDialog dialog (message, true,
                                   Gtk::MESSAGE_ERROR,
                                   Gtk::BUTTONS_CLOSE,
                                   true);

        dialog.set_position (Gtk::WIN_POS_CENTER_ALWAYS);
        dialog.run ();

        return NULL;
    }

    return xml;
}


GtkWidget *
glade_xml_get_widget_warn(GladeXML * xml, const gchar * name)
{
    GtkWidget *widget = glade_xml_get_widget(xml, name);

    if (!widget) {
        g_warning("Widget not found (%s)", name);
        return NULL;
    }

    return widget;
}

static gpointer
self_symbol_lookup(const gchar * symbol_name)
{
    static GModule *module = NULL;
    gpointer symbol = NULL;

    if (!module)
        module = g_module_open(NULL, GModuleFlags (0));

    g_module_symbol(module, symbol_name, &symbol);
    return (gpointer)symbol;
}
