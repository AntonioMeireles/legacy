/*  BMPx - Cross-platform multimedia player
 *  Copyright (C) 2003-2004  Edward Brocklesby, Chong Kai Xiong,
 *            Milosz Derezynski, David Lau, Michiel Sikkes
 *  Copyright (C) 2005 Chong Kai Xiong, Milosz Derezynski, Kenneth Ostby
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * The BMPx project hereby grant permission for non-gpl compatible GStreamer
 * plugins to be used and distributed together with GStreamer and BMPx. This
 * permission are above and beyond the permissions granted by the GPL license
 * BMPx is covered by.
 */

#include <glibmm.h>
#include <gtkmm.h>

#include <glib/gi18n.h>

#include "ui_main.hpp"
#include "ui.hpp"
#include "main.hpp"
#include "paths.hpp"

#include <goa/libgoa.h>

#include <bmp/widgets/bmp_button.h>
#include <bmp/widgets/bmp_button_toggle.h>
#include <bmp/widgets/bmp_slider.h>
#include <bmp/widgets/bmp_slider.h>
#include <bmp/widgets/bmp_window.h>
#include <bmp/widgets/bmp_tooltips.h>

#include <gdk/gdkx.h>
#include <gdk/gdkkeysyms.h>
#include <X11/Xatom.h>
#include <X11/Xlib.h>
#include <X11/Xlibint.h>
#include <cstring>

#include <ui_util.hpp>
#include <dnd.hpp>

G_DEFINE_TYPE (BmpWindowMain, bmp_window_main, G_TYPE_OBJECT)

#define NONE (-1)

using namespace Bmp;

static void
window_main_create    (BmpWindowMain *window_main);

static void
toggle_textbox_scroll (GtkToggleAction *action, BmpWindowMain *window_main);

static void
textbox_update	      (BmpWindowMain *window_main, const gchar *text);

static void
textbox_stop	      (BmpWindowMain *window_main);

static GtkActionEntry bmp_actions_MAIN[] = {
  { "dummy", NULL, "dummy" },
  { "dummy-view-menu", NULL, N_("View") },

  { BMP_ACTION_PREV,
    GTK_STOCK_MEDIA_PREVIOUS,
    N_("Previous"), "z",
    N_("Previous"),
    G_CALLBACK(bmp_ui_callback_prev)},

  { BMP_ACTION_TRACKLIST_OPEN,
    GTK_STOCK_OPEN,
    N_("Open files"), "<shift>F",
    N_("Open Files"),
    G_CALLBACK(bmp_ui_callback_open_files)},

  { BMP_ACTION_PLAY,
    GTK_STOCK_MEDIA_PLAY,
    N_("Play"), "x",
    N_("Play"),
    G_CALLBACK(bmp_ui_callback_play)},

  { BMP_ACTION_PAUSE,
    GTK_STOCK_MEDIA_PAUSE,
    N_("Pause"), "space",
    N_("Pause"),
    G_CALLBACK(bmp_ui_callback_pause)},

  { BMP_ACTION_STOP,
    GTK_STOCK_MEDIA_STOP,
    N_("Stop"), "v",
    N_("Stop"),
    G_CALLBACK(bmp_ui_callback_stop)},

  { BMP_ACTION_NEXT,
    GTK_STOCK_MEDIA_NEXT,
    N_("Next"), "b",
    N_("Next"),
    G_CALLBACK(bmp_ui_callback_next)},

  { BMP_ACTION_ICONIFY,
    NULL,
    N_("Minimize BMP"), "<alt>m",
    N_("Minimize"),
    G_CALLBACK(bmp_ui_callback_iconify)},

  { BMP_ACTION_QUIT,
    GTK_STOCK_QUIT,
    N_("Quit BMP"), "<control>w",
    N_("Quit BMP"),
    G_CALLBACK(bmp_ui_callback_quit)},

  { BMP_ACTION_QUIT_TITLE,
    GTK_STOCK_QUIT,
    "", "",
    "",
    G_CALLBACK(bmp_ui_callback_quit_title)},

  { BMP_ACTION_ABOUT,
    GTK_STOCK_ABOUT,
    N_("About BMP"), NULL,
    N_("About BMP"),
    G_CALLBACK(bmp_ui_callback_about)},

  { BMP_ACTION_PREFERENCES,
    GTK_STOCK_PREFERENCES,
    N_("Preferences"), "P",
    N_("Preferences"),
    G_CALLBACK(bmp_ui_callback_preferences)},

  { BMP_ACTION_LIBRARY,
    GTK_STOCK_FIND,
    N_("Music Library"), "L",
    N_("Music Library"),
    G_CALLBACK(bmp_ui_callback_library)},

  { BMP_ACTION_STREAMS,
    GTK_STOCK_NETWORK,
    N_("Radio Streams"), "R",
    N_("Radio Streams"),
    G_CALLBACK(bmp_ui_callback_streams)}

};

static GtkToggleActionEntry bmp_toggle_actions_MAIN[] = {

  { BMP_TOGGLE_ACTION_STOP_AFTER_CURRENT,
	NULL,
	N_("Stop After Current Track"),
	NULL,
	NULL,
	G_CALLBACK (bmp_ui_callback_stop_after_current_track),
	FALSE },

  { BMP_TOGGLE_ACTION_SHUFFLE,
	NULL,
	N_("_Shuffle"),
	NULL,
	N_("Switch between random and continuous playback"),
	G_CALLBACK (bmp_ui_callback_toggle_shuffle),
	FALSE },

  { BMP_TOGGLE_ACTION_REPEAT,
	NULL,
	N_("_Repeat"),
	NULL,
	N_("Whether to repeat the tracklist or not"),
	G_CALLBACK (bmp_ui_callback_toggle_repeat),
	FALSE },

  { BMP_TOGGLE_ACTION_PL,
	NULL,
	N_("Show Playlist Window"),
	NULL,
	N_("Toggles playlist window visibility"),
	G_CALLBACK (bmp_ui_callback_toggle_pl),
	FALSE },

  { BMP_TOGGLE_ACTION_SCROLL,
	NULL,
	N_("Scroll Textbox"),
	NULL,
	N_("Toggles textbox scroll"),
	G_CALLBACK (toggle_textbox_scroll),
	TRUE },

#if 0
  { BMP_TOGGLE_ACTION_VIS,
	NULL,
	N_("Visualisation"),
	NULL,
	N_("Visualisation"),
	G_CALLBACK (lv_bmp_toggle),
	FALSE }
#endif

};

static BmpButtonToggleT bmp_window_main_buttons_toggle[] = {
    /* Shuffle */
    { BMP_TOGGLE_ACTION_SHUFFLE,
	N_("Toggle Shuffle Mode"),
	SKIN_COMPONENT_SHUFREP,
	28, 0,
	28, 15,
	28, 30,
	46, 15,
	164,89,
	TRUE },

    /* Repeat */
    { BMP_TOGGLE_ACTION_REPEAT,
	N_("Toggle Playlist Repeat"),
	SKIN_COMPONENT_SHUFREP,
	0,  0,
	0,  15,
	0,  30,
	28, 15,
	210,89,
	TRUE },

    /* EQ */
    { NULL,
	N_("Toggle Equalizer window visibility"),
	SKIN_COMPONENT_SHUFREP,
	0,  61,
	46, 73,
	0,  73,
	23, 12,
	219,58,
	TRUE },

    /* PL */
    {BMP_TOGGLE_ACTION_PL,
	N_("Toggle Playlist window visibility"),
	SKIN_COMPONENT_SHUFREP,
	23, 61,
	69, 73,
	23, 73,
	23, 12,
	242,58,
	TRUE }
};
static int nbuttons_window_main_toggle = G_N_ELEMENTS(bmp_window_main_buttons_toggle);

enum {
    MAIN_BUTTON_EJECT,
    MAIN_BUTTON_PREV,
    MAIN_BUTTON_PLAY,
    MAIN_BUTTON_PAUSE,
    MAIN_BUTTON_STOP,
    MAIN_BUTTON_NEXT,
    MAIN_BUTTON_ICONIFY,
    MAIN_BUTTON_QUIT
};

static BmpButtonNormalT bmp_window_main_buttons[] =
{
    /* Eject button */
    { BMP_ACTION_TRACKLIST_OPEN,
	N_("Open Files"),
	SKIN_COMPONENT_CBUTTONS,
	114, 0,
	114, 16,
	22,  16,
	136, 89 },

    /* Prev button */
    { BMP_ACTION_PREV,
	N_("Previous Track"),
	SKIN_COMPONENT_CBUTTONS,
	0,  0,
	0,  18,
	23, 18,
	16, 88 },

    /* Play button */
    { BMP_ACTION_PLAY,
	N_("Play Current Track"),
	SKIN_COMPONENT_CBUTTONS,
	22, 0,
	22, 18,
	23, 18,
	38, 88 },

    /* Pause button */
    { BMP_ACTION_PAUSE,
	N_("Toggle Pause"),
	SKIN_COMPONENT_CBUTTONS,
	45, 0,
	45, 18,
	23, 18,
	61, 88 },

    /* Stop button */
    { BMP_ACTION_STOP,
	N_("Stop Playback"),
	SKIN_COMPONENT_CBUTTONS,
	68, 0,
	68, 18,
	23, 18,
	84, 88 },

    /* Next button */
    { BMP_ACTION_NEXT,
	N_("Next Track"),
	SKIN_COMPONENT_CBUTTONS,
	91,  0,
	91,  18,
	23,  18,
	107, 88 },

    /* Minimize button */
    { BMP_ACTION_ICONIFY,
	N_("Minimize BMPx"),
	SKIN_COMPONENT_TITLEBAR,
	9,   0,
	9,   9,
	8,   8,
	244, 3 },

    /* Close button */
    { BMP_ACTION_QUIT_TITLE,
	N_("Quit BMPx"),
	SKIN_COMPONENT_TITLEBAR,
	18,  0,
	18,  9,
	8,   8,
	264, 3 }
};
static int nbuttons_window_main = G_N_ELEMENTS(bmp_window_main_buttons);

/* FIXME: Move this inside Private */
static GPtrArray *array_buttons;
static GPtrArray *array_buttons_toggle;
static GdkPixbuf *numbers[12];

struct NumberPositionT
{
	gint x;
	gint y;
};

static NumberPositionT number_positions[] = {
	{ 48, 26 },
	{ 60, 26 },
	{ 78, 26 },
	{ 90, 26 },
	{ 36, 26 }
};

#define KBPS_X 108
#define KBPS_Y 43

#define TEXTBOX_X 109
#define TEXTBOX_Y 23
#define TEXTBOX_FONT_SIZE 11
#define TEXTBOX_WIDTH 154

#define SLIDER_SEEK_X 16
#define SLIDER_SEEK_Y 72

#define SLIDER_VOLUME_X 107
#define SLIDER_VOLUME_Y 57

#define SLIDER_BALANCE_X 177
#define SLIDER_BALANCE_Y 57

#define PLAYSTATUS_X 24
#define PLAYSTATUS_Y 28

G_LOCK_DEFINE(TEXTBOX_LOCK);

typedef enum {
	SCROLL_RIGHT,
	SCROLL_LEFT
} TextboxScrollDirection;

enum {
	NUMBER_MINUTES_10,
	NUMBER_MINUTES_1,
	NUMBER_SECONDS_10,
	NUMBER_SECONDS_1,
	NUMBER_MINUS
};

struct _BmpWindowMainPrivate {

    gboolean dispose_has_run;

    gboolean seeking;

#if 0
    gint seek_request;
    gint last_position;
#endif

    gint time_minutes;
    gint time_seconds;

    gint time_seek_minutes;
    gint time_seek_seconds;

    gboolean time_inverse;

    gboolean focused;

    /* Sliders */
    GtkWidget *sliders[BMP_UI_MAIN_N_SLIDERS];

    /* Textbox */
    cairo_surface_t	    *textbox;
    gint		     textbox_w;
    gint		     textbox_h;

    TextboxScrollDirection   tb_direction;
    gboolean		     tb_running;
    gboolean		     tb_dragging;
    gint		     tb_offset;
    gint		     tb_drag_offset;
    gint		     tb_drag_event_x;
    guint		     source;
};

#if 0
void
reset_last_position (BmpWindowMain *window_main)
{
	g_return_if_fail (BMP_IS_WINDOW_MAIN(window_main));

	window_main->priv->last_position = -1;
	window_main->priv->seek_request = -1;
}
#endif

#if 0

void
bmp_window_main_set_seek_request (BmpWindowMain *window_main, gint seek_request)
{
	g_return_if_fail (BMP_IS_WINDOW_MAIN(window_main));

	window_main->priv->seek_request = seek_request;
}
#endif

static void
toggle_textbox_scroll (GtkToggleAction *action, BmpWindowMain *window_main)
{
    gboolean scroll;

    scroll = gtk_toggle_action_get_active (action);

    if (!scroll)
    {
	window_main->priv->tb_running = FALSE;
	window_main->priv->tb_offset = 0;
    }
    else
    {
	gchar *text = g_object_get_string (bmp_system_control, "current_title");

	textbox_stop (window_main);

	textbox_update (window_main, text);
	g_free (text);

	gtk_widget_queue_draw (window_main->window);
    }
}

static void
on_system_control_set_volume (BmpSystemControl *control, gint volume, BmpWindowMain *window_main)
{
    bmp_slider_set_position (BMP_SLIDER(window_main->priv->sliders[BMP_UI_MAIN_SLIDER_VOLUME]), volume);
}

static void
on_system_control_stream_pos (BmpSystemControl	  *control,
			      gint		   time_,
			      BmpWindowMain	  *window_main)
{
    gdouble position;
    gint    length;

    if (window_main->priv->seeking) return;

    length = bmp_play_engine->property_length();
    position = time_ / (length/100.);

    if ((position >= 0) && (position <= 100))
      {
	  bmp_slider_set_position (BMP_SLIDER(window_main->priv->sliders[BMP_UI_MAIN_SLIDER_SEEK]), position);

	  if (window_main->priv->time_inverse)
	    {
	      time_ = (length - time_) * -1;
	    }

	  window_main->priv->time_minutes = time_ / 60;
	  window_main->priv->time_seconds = time_ % 60;

	  gtk_widget_queue_draw_area (window_main->window,36,26,99,39);
      }
}

/* Functions */
static gint
set_seek_time_I (BmpWindowMain *window_main)
{
    gdouble position,
	    length;
    gint    time_;

    position = bmp_slider_get_position (BMP_SLIDER(window_main->priv->sliders[BMP_UI_MAIN_SLIDER_SEEK]));
    length = bmp_play_engine->property_length();
    time_ = (gint)(position * (length / 100.));
    window_main->priv->time_seek_minutes = time_ / 60;
    window_main->priv->time_seek_seconds = time_ % 60;

    return time_;
}

static void
seek_motion_hint (BmpSlider	  *slider,
		  BmpWindowMain	  *window_main)
{
    gdouble  length;
    gint     time_;

    g_return_if_fail (BMP_IS_WINDOW_MAIN (window_main));

    time_ = set_seek_time_I (window_main);
    length = bmp_play_engine->property_length();

    if (window_main->priv->time_inverse)
      {
	time_ = (int (length) - time_) * -1;
      }

    window_main->priv->time_minutes = time_ / 60;
    window_main->priv->time_seconds = time_ % 60;

    gtk_widget_queue_draw_area (window_main->window,36,26,99,39);
}


static gboolean
seek_started (GtkWidget	      *widget,
	      GdkEventButton  *event,
	      BmpWindowMain   *window_main)
{
	g_return_val_if_fail (GTK_IS_WIDGET(widget), FALSE);

	window_main->priv->seeking = TRUE;
	return FALSE;
}

static gboolean
seek_ended    (GtkWidget      *widget,
	       GdkEventButton *event,
	       BmpWindowMain  *window_main)
{
	g_return_val_if_fail (GTK_IS_WIDGET(widget), FALSE);

	window_main->priv->seeking = FALSE;
	return FALSE;
}

static gboolean
on_window_main_state_event (GtkWidget *widget, GdkEventWindowState *event, gpointer data)
{
    BmpWindowPlaylist *window_playlist;

    g_return_val_if_fail (GTK_IS_WIDGET (widget), FALSE);

    if (event->changed_mask & GDK_WINDOW_STATE_ICONIFIED)
      {
	   if (!(event->new_window_state & GDK_WINDOW_STATE_ICONIFIED) &&
		mcs->key_get<bool>("playlist-window", "visible"))
	     {
                 window_playlist = BMP_WINDOW_PLAYLIST (RM_GET_ITEM("windows", "window-playlist", NOLOCK));
                 gdk_window_show (GTK_WIDGET(window_playlist->window)->window);
                 gdk_window_raise (GTK_WIDGET(window_playlist->window)->window);
                 return TRUE;
	     }

	   if (event->new_window_state & GDK_WINDOW_STATE_ICONIFIED)
             {
                 window_playlist = BMP_WINDOW_PLAYLIST (RM_GET_ITEM("windows", "window-playlist", NOLOCK));
                 gtk_window_iconify (GTK_WINDOW(window_playlist->window));
                 return TRUE;
	     }

    }

    return FALSE;
}

static gboolean
on_window_main_focus_out    (GtkWidget	    *widget,
			     GdkEventFocus  *event,
			     BmpWindowMain  *window_main)
{
    GtkWidget *button;

    window_main->priv->focused = FALSE;

    button = GTK_WIDGET (g_ptr_array_index (array_buttons, MAIN_BUTTON_ICONIFY));
    gtk_widget_hide (button);

    button = GTK_WIDGET (g_ptr_array_index (array_buttons, MAIN_BUTTON_QUIT));
    gtk_widget_hide (button);

    gtk_widget_queue_draw (widget);

    return FALSE;
}

static gboolean
on_window_main_focus_in	    (GtkWidget	    *widget,
			     GdkEventFocus  *event,
			     BmpWindowMain  *window_main)
{
    BmpWindowPlaylist *window_playlist;
    GtkWidget	      *button;
    Atom	       ret_type;
    int		       ret_size;
    gulong	       n_items;
    gulong	       ret_bytes;
    guchar	      *data = NULL;
    Window	       xid,
		       top;
    Display	      *display;

    GdkRectangle       rect_pl, rect_main, rect_dummy;

    g_return_val_if_fail (GTK_IS_WIDGET (widget), FALSE);

    button = GTK_WIDGET (g_ptr_array_index (array_buttons, MAIN_BUTTON_ICONIFY));
    gtk_widget_show (button);
    button = GTK_WIDGET (g_ptr_array_index (array_buttons, MAIN_BUTTON_QUIT));
    gtk_widget_show (button);

    window_playlist = BMP_WINDOW_PLAYLIST (RM_GET_ITEM("windows", "window-playlist", NOLOCK));
    gdk_window_get_position (GTK_WIDGET(window_playlist->window)->window, &rect_pl.x, &rect_pl.y);
    gdk_drawable_get_size (GDK_DRAWABLE(GTK_WIDGET(window_playlist->window)->window), &rect_pl.width, &rect_pl.height);
    gdk_window_get_position (GTK_WIDGET(window_main->window)->window, &rect_main.x, &rect_main.y);
    gdk_drawable_get_size (GDK_DRAWABLE(GTK_WIDGET(window_main->window)->window), &rect_main.width, &rect_main.height);

    if (!gdk_rectangle_intersect (&rect_pl, &rect_main, &rect_dummy))
      {
	xid = GDK_WINDOW_XID(gdk_get_default_root_window());
	display = GDK_DISPLAY_XDISPLAY(gdk_display_get_default());

	if (XGetWindowProperty (display, xid,
                          gdk_x11_get_xatom_by_name_for_display (gdk_display_get_default(), "_NET_CLIENT_LIST_STACKING"),
                          0l, (long)BUFSIZE, False, XA_WINDOW,
                          &ret_type, &ret_size, &n_items, &ret_bytes, &data) != Success) return FALSE;


	if (data != NULL)
	  {
	    top  = ((Window*)data)[n_items-1];
	    if (widget->window && (top == GDK_WINDOW_XID(GTK_WIDGET(widget)->window)))
	      {
		gdk_window_raise (window_playlist->window->window);
	      }
	    g_free (data);
	  }
      }

    window_main->priv->focused = TRUE;
    gtk_widget_queue_draw (widget);
    return FALSE;
}

static gboolean
on_window_main_button_release (GtkWidget *widget,
		    GdkEventButton *event,
		    BmpWindowMain *window_main)
{
    g_return_val_if_fail (GTK_IS_WIDGET (widget), FALSE);

    window_main->priv->tb_dragging = FALSE;
    return FALSE;
}

static gboolean
on_window_main_scroll_event (GtkWidget *widget,
		    GdkEventScroll *event,
		    BmpWindowMain *window_main)
{
	gpointer instance;
	gboolean rv;

	g_return_val_if_fail (GTK_IS_WIDGET(widget), FALSE);

	instance = window_main->priv->sliders[BMP_UI_MAIN_SLIDER_VOLUME];
	g_signal_emit_by_name (instance, "scroll-event", event, &rv);

	return TRUE;
}


static gboolean
on_window_main_key_press (GtkWidget   *widget,
                          GdkEventKey *event,
                          gpointer     user_data)
{
    g_return_val_if_fail (GTK_IS_WIDGET (widget), FALSE);

    if (event->keyval == GDK_Escape)
    {
        GtkAction *action;

        action = gtk_action_group_get_action (bmp_actions, BMP_ACTION_ICONIFY);
        gtk_action_activate (action);
    }

    return FALSE;
}

static gboolean
on_window_main_stop_button_press (GtkWidget	    *widget,
				  GdkEventButton    *event,
				  BmpWindowMain	    *window_main)
{
    GtkWidget *menu;

    if (event->button == 3)
      {

	menu = ui_manager_get_popup (bmp_ui_manager, "/popup/menu-button-stop");
	gtk_widget_realize (menu);
	SET_CURSOR_FOR_WIDGET(CURSOR_MAINMENU,menu);
	gtk_menu_popup (GTK_MENU(menu), NULL, NULL, NULL, NULL, event->button, event->time);
	return FALSE;
      }

    return FALSE;
}

static gboolean
on_window_main_button_press (GtkWidget	    *widget,
			     GdkEventButton *event,
			     BmpWindowMain  *window_main)
{
    BmpWindowPlaylist *window_playlist;
    GtkWidget *menu;
    double x, y;
    GdkRectangle rect_pl, rect_main, rect_dummy;

    g_return_val_if_fail (GTK_IS_WIDGET (widget), FALSE);

    window_playlist = BMP_WINDOW_PLAYLIST (RM_GET_ITEM("windows", "window-playlist", NOLOCK));
    x = event->x;
    y = event->y;
    gdk_window_raise (GTK_WIDGET(widget)->window);

    gdk_window_get_position (GTK_WIDGET(window_playlist->window)->window, &rect_pl.x, &rect_pl.y);
    gdk_drawable_get_size (GDK_DRAWABLE(GTK_WIDGET(window_playlist->window)->window), &rect_pl.width, &rect_pl.height);
    gdk_window_get_position (GTK_WIDGET(window_main->window)->window, &rect_main.x, &rect_main.y);
    gdk_drawable_get_size (GDK_DRAWABLE(GTK_WIDGET(window_main->window)->window), &rect_main.width, &rect_main.height);

    if (!gdk_rectangle_intersect (&rect_pl, &rect_main, &rect_dummy))
      {
	gdk_window_raise (GTK_WIDGET(window_playlist->window)->window);
      }

    /* Titlebar */
    if (event->type == GDK_BUTTON_PRESS && event->button == 1 && ((y < 24) && (x < 240)))
      {
	//FIXME: Sort of sucks
	gdk_window_raise (GTK_WIDGET(widget)->window);
	gdk_window_begin_move_drag (GTK_WIDGET(widget)->window,
				    event->button,
				    gint (event->x_root),
				    gint (event->y_root),
				    event->time);

	return FALSE;
      }

    if (event->type == GDK_BUTTON_PRESS && (event->button == 3))
      {

	menu = ui_manager_get_popup (bmp_ui_manager, "/popup/menu-main");
	gtk_widget_realize (menu);
	SET_CURSOR_FOR_WIDGET(CURSOR_MAINMENU,menu);
	gtk_menu_popup (GTK_MENU(menu), NULL, NULL, NULL, NULL, event->button, event->time);
	return FALSE;

      }
    else
    if (event->type == GDK_BUTTON_PRESS && event->button == 1 && (x >= 36) && (x <= 99) && (y >= 26) && (y <= 39))
      {
	    window_main->priv->time_inverse = !window_main->priv->time_inverse;
	    mcs->key_set<bool>("bmp","time-remaining", window_main->priv->time_inverse);
	    return FALSE;
      }
    else
    /* Textbox */
    if (event->button == 1 && window_main->priv->textbox &&
	    ((x >= TEXTBOX_X) &&
	     (x <= TEXTBOX_X+TEXTBOX_WIDTH) &&
	     (y >= TEXTBOX_Y) &&
	     (y <= TEXTBOX_Y+11))) {

      if (event->type == GDK_BUTTON_PRESS)
	{
	  if (window_main->priv->textbox_w > TEXTBOX_WIDTH)
	    {
	      window_main->priv->tb_dragging = TRUE;
	      window_main->priv->tb_drag_offset = window_main->priv->tb_offset;
	      window_main->priv->tb_drag_event_x = int (event->x);
	    }
	}
      else
      if (event->type == GDK_2BUTTON_PRESS)
	{
	      BmpWindowPlaylist *window_playlist;

	      window_playlist = BMP_WINDOW_PLAYLIST (RM_GET_ITEM("windows", "window-playlist", NOLOCK));
	      bmp_window_playlist_show_trackinfo (window_playlist);
	}
    }

    return FALSE;
}

static gboolean
on_window_main_motion_notify (GtkWidget *widget, GdkEventMotion *event, BmpWindowMain *window_main)
{
    GdkModifierType state;
    int x, y;

    if (event->is_hint)
      {
	gdk_window_get_pointer (event->window, &x, &y, &state);
      }
    else
      {
        x = int (event->x);
        y = int (event->y);
        state = GdkModifierType (event->state);
      }

	if (window_main->priv->tb_dragging && window_main->priv->textbox)
	  {
	    gint offset;

	    offset = window_main->priv->tb_drag_offset - (x - window_main->priv->tb_drag_event_x);

	    if (offset < 0) offset = 0;
	    if (offset+TEXTBOX_WIDTH > window_main->priv->textbox_w) offset = window_main->priv->textbox_w - TEXTBOX_WIDTH;

	    if (offset < window_main->priv->tb_offset)
	      {
		window_main->priv->tb_direction = SCROLL_LEFT;
	      }
	    else if (offset > window_main->priv->tb_offset)
	      {
		window_main->priv->tb_direction = SCROLL_RIGHT;
	      }

	    window_main->priv->tb_offset = offset;
	    gtk_widget_queue_draw (window_main->window);
	  }

  return TRUE;
}

static gboolean
on_window_main_canvas_expose (GtkWidget	      *widget,
			      GdkEventExpose  *event,
			      BmpWindowMain   *window_main)
{
	PangoFontDescription	*pfd;
    	PangoLayout		*layout;
	GtkWidget		*window;
	GdkPixbuf		*pb_aux;
	gchar			*aux0, *text;
	gint			 nums[4];
	gint		         n, playstatus;
	gboolean		 quit;

	quit = FALSE;
        window = window_main->window;

	/* Draw background ("main") pixmap */
	gdk_draw_pixbuf(widget->window,
			NULL,
                        bmp_skin_component[SKIN_COMPONENT_MAIN]->pixbuf,
                        0,
                        0,
                        0,
                        0,
                        -1,
                        -1,
                        GDK_RGB_DITHER_NONE,
                        0,
                        0);

	/* Draw playstatus */
	playstatus = bmp_play_engine->property_status(); 

	if (!bmp_skin_component[SKIN_COMPONENT_PLAYPAUSE]) goto RENDER_TEXTBOX;

	pb_aux = bmp_skin_component[SKIN_COMPONENT_PLAYPAUSE]->pixbuf;
	if ((!pb_aux) || (gdk_pixbuf_get_width (pb_aux) < 36)) goto RENDER_TEXTBOX;

	if (playstatus == PLAYSTATUS_PLAYING)
	  {
        	gdk_draw_pixbuf(widget->window,
			NULL,
			pb_aux,
                        36, 0,
                        PLAYSTATUS_X, PLAYSTATUS_Y,
                        3,  9,
                        GDK_RGB_DITHER_NONE,
                        0,
                        0);
	  }
	else
	  {
        	gdk_draw_pixbuf(widget->window,
			NULL,
                        pb_aux,
                        27, 0,
                        PLAYSTATUS_X, PLAYSTATUS_Y,
                        2,  9,
                        GDK_RGB_DITHER_NONE,
                        0,
                        0);
	  }

	switch (playstatus)
	  {

	    case PLAYSTATUS_STOPPED:
	      {
	    	gdk_draw_pixbuf(widget->window,
			NULL,
                        pb_aux,
                        18, 0,
                        PLAYSTATUS_X + 2,  PLAYSTATUS_Y,
                        9,  9,
                        GDK_RGB_DITHER_NONE,
                        0,
                        0);
	      }
	    break;

	    case PLAYSTATUS_PAUSED:
	      {

	    	gdk_draw_pixbuf(widget->window,
			NULL,
                        pb_aux,
                        9, 0,
                        PLAYSTATUS_X + 2,  PLAYSTATUS_Y,
                        9, 9,
                        GDK_RGB_DITHER_NONE,
                        0,
                        0);
	      }
	    break;

	    case PLAYSTATUS_PLAYING:
	      {
	    	gdk_draw_pixbuf(widget->window,
			NULL,
                        pb_aux,
                        1, 0,
                        PLAYSTATUS_X + 3,  PLAYSTATUS_Y,
                        8, 9,
                        GDK_RGB_DITHER_NONE,
                        0,
                        0);
	      }
	    break;

	    default: break;
	  }

	RENDER_TEXTBOX:

	if ( (event->area.x >= TEXTBOX_X) &&
	     (event->area.x <= TEXTBOX_X+TEXTBOX_WIDTH) &&
	     (event->area.width <= TEXTBOX_WIDTH) &&
	     (event->area.height <= 11))
	  {
	    quit = TRUE;
	    goto expose_draw_textbox;
	  }

	expose_draw_textbox:

	if (window_main->priv->textbox != NULL)
	  {
	    cairo_t	    *cr;
	    cr = gdk_cairo_create (widget->window);

	    cairo_rectangle (cr, TEXTBOX_X, TEXTBOX_Y, TEXTBOX_WIDTH, window_main->priv->textbox_h);
	    cairo_clip (cr);

	    cairo_set_source_surface (cr, window_main->priv->textbox, TEXTBOX_X - window_main->priv->tb_offset, TEXTBOX_Y);
	    cairo_rectangle (cr, TEXTBOX_X - window_main->priv->tb_offset,
				 TEXTBOX_Y,
				 TEXTBOX_WIDTH + window_main->priv->tb_offset,
				 window_main->priv->textbox_h);
	    cairo_fill (cr);
	    cairo_destroy (cr);
	  }
	if (quit) return FALSE;

	/* Bitrate */
	text = g_strdup_printf("%d", g_object_get_int(bmp_system_control, "bitrate"));
	if (text && std::strlen(text))
	  {
		const char *fontname;

    		layout = gtk_widget_create_pango_layout (widget, "");
		aux0 = g_markup_escape_text (text, std::strlen(text));

		fontname = mcs->key_get<std::string>("bmp", "font") . c_str ();
		pfd = pango_font_description_from_string (fontname);
		pango_font_description_set_absolute_size (pfd, 8*PANGO_SCALE);
		g_free (text);

		pango_layout_set_markup (layout, aux0, std::strlen(aux0));
    		pango_layout_set_font_description (layout, pfd);
		pango_font_description_free (pfd);
    		gtk_paint_layout            (GTK_WIDGET (widget)->style,
                                             GTK_WIDGET (widget)->window,
                                             GTK_STATE_NORMAL,
                                             TRUE,
                                             NULL,
                                             widget,
                                             "",
                                             111,
                                             41,
                                             layout);
		g_free (aux0);
		g_object_unref (layout);
	  }

	/* Samplerate */
	text = g_strdup_printf("%d", g_object_get_int(bmp_system_control, "samplerate")/1000);
	if (text && std::strlen(text))
	  {
		const char *fontname;

    		layout = gtk_widget_create_pango_layout (widget, "");
		fontname = mcs->key_get<std::string>("bmp", "font"). c_str ();
		pfd = pango_font_description_from_string (fontname);
		pango_font_description_set_absolute_size (pfd, 8*PANGO_SCALE);

		aux0 = g_markup_escape_text (text, std::strlen(text));

		pango_layout_set_markup (layout, aux0, std::strlen(aux0));
    		pango_layout_set_font_description (layout, pfd);
		pango_font_description_free (pfd);
    		gtk_paint_layout            (GTK_WIDGET (widget)->style,
                                             GTK_WIDGET (widget)->window,
                                             GTK_STATE_NORMAL,
                                             TRUE,
                                             NULL,
                                             widget,
                                             "",
                                             155,
                                             41,
                                             layout);

		g_free (aux0);
		g_object_unref (layout);
	  }

	if ( (event->area.x == 0) &&
	     (event->area.y == 0) &&
	     (event->area.width == 275) &&
	     (event->area.height == 14))
	  {
	      quit = TRUE;
	      goto on_window_main_canvas_expose_DRAW_TITLEBAR;
	  }

	if ( (event->area.x == 36) &&
	     (event->area.y == 26) &&
	     (event->area.width == 99) &&
	     (event->area.height == 39))
	  {
	      quit = TRUE;
	      goto on_window_main_canvas_expose_DRAW_NUMBERS;
	  }

	on_window_main_canvas_expose_DRAW_TITLEBAR:
	/* Draw titlebar */
	pb_aux = gdk_pixbuf_new (gdk_pixbuf_get_colorspace(bmp_skin_component[SKIN_COMPONENT_TITLEBAR]->pixbuf),
                 		 gdk_pixbuf_get_has_alpha(bmp_skin_component[SKIN_COMPONENT_TITLEBAR]->pixbuf),
                                 gdk_pixbuf_get_bits_per_sample(bmp_skin_component[SKIN_COMPONENT_TITLEBAR]->pixbuf),
                                 275,
				 14);

	/* FIXME: Precache these pixbufs */
	if (window_main->priv->focused)
	  {
		gdk_pixbuf_copy_area (bmp_skin_component[SKIN_COMPONENT_TITLEBAR]->pixbuf,
				27,
				0,
				275,
				14,
				pb_aux,
				0,
				0);
	  }
	else
	  {
		gdk_pixbuf_copy_area (bmp_skin_component[SKIN_COMPONENT_TITLEBAR]->pixbuf,
				27,
				15,
				275,
				14,
				pb_aux,
				0,
				0);
	  }

	gdk_draw_pixbuf(widget->window,
			NULL,
                        pb_aux,
                        0,
                        0,
                        0,
                        0,
                        -1,
                        -1,
                        GDK_RGB_DITHER_NONE,
                        0,
                        0);
	g_object_unref (pb_aux);
	if (quit) return FALSE;

	on_window_main_canvas_expose_DRAW_NUMBERS:

	/* FIXME: Hack */
	if (playstatus == PLAYSTATUS_STOPPED)
	  {
	    window_main->priv->time_minutes = 0;
	    window_main->priv->time_seconds = 0;
	  }

	/* Draw numbers */
	if (abs(window_main->priv->time_minutes) < 100)
	  {
	    nums[NUMBER_MINUTES_10] = abs(window_main->priv->time_minutes) / 10;
	    nums[NUMBER_MINUTES_1]  = abs(window_main->priv->time_minutes) % 10;
	    nums[NUMBER_SECONDS_10] = abs(window_main->priv->time_seconds) / 10;
	    nums[NUMBER_SECONDS_1]  = abs(window_main->priv->time_seconds) % 10;
	  }
	else
	  {
	    gint time_hours, time_minutes;

	    time_hours   = window_main->priv->time_minutes / 60;
	    time_minutes = window_main->priv->time_minutes % 60;

	    nums[NUMBER_MINUTES_10] = abs(time_hours) / 10;
	    nums[NUMBER_MINUTES_1]  = abs(time_hours) % 10;
	    nums[NUMBER_SECONDS_10] = abs(time_minutes) / 10;
	    nums[NUMBER_SECONDS_1]  = abs(time_minutes) % 10;
	  }

	/* Draw Time */
	for (n = 0; n < 4; n++)
	  {
		if (!numbers[nums[n]]) continue;

		gdk_draw_pixbuf(widget->window,
				NULL,
                	        numbers[nums[n]],
	                        0,
        	                0,
                	        number_positions[n].x,
	                        number_positions[n].y,
        	                -1,
                	        (gdk_pixbuf_get_height(numbers[nums[n]]) < 13) ? gdk_pixbuf_get_height(numbers[nums[n]]) : 13,
	                        GDK_RGB_DITHER_NONE,
        	                0,
                	        0);
	  }

	if ((((window_main->priv->time_minutes*60)+(window_main->priv->time_seconds)) > 0) && (numbers[10] != NULL))
	  {

		gdk_draw_pixbuf(widget->window,
				NULL,
                	        numbers[10],
	                        0,
        	                0,
                	        number_positions[NUMBER_MINUS].x,
	                        number_positions[NUMBER_MINUS].y,
        	                -1,
                	        (gdk_pixbuf_get_height(numbers[10]) < 13) ? gdk_pixbuf_get_height(numbers[10]) : 13,
	                        GDK_RGB_DITHER_NONE,
        	                0,
                	        0);
	  }
	else
	if ((((window_main->priv->time_minutes*60)+(window_main->priv->time_seconds)) < 0) && (numbers[11] != NULL)) {

		gdk_draw_pixbuf(widget->window,
				NULL,
                	        numbers[11],
	                        0,
        	                0,
                	        number_positions[NUMBER_MINUS].x,
	                        number_positions[NUMBER_MINUS].y,
        	                -1,
                	        (gdk_pixbuf_get_height(numbers[11]) < 13) ? gdk_pixbuf_get_height(numbers[11]) : 13,
	                        GDK_RGB_DITHER_NONE,
        	                0,
                	        0);
	  }

	return FALSE;
}


static gboolean
tb_offset_timeout (BmpWindowMain *window_main)
{
	static gint wait_cycle = 0;

	if (!bmp_ui)
	    return FALSE;

	if (!window_main)
	    return FALSE;

	if (!window_main->window)
	    return FALSE;

	if (window_main->priv->tb_dragging)
	    return TRUE;

	if (!G_TRYLOCK (TEXTBOX_LOCK))
	  {
	    window_main->priv->tb_running = FALSE;
	    return FALSE;
	  }

	if (!window_main->priv->textbox)
	{
	    window_main->priv->tb_running = FALSE;
	    G_UNLOCK (TEXTBOX_LOCK);
	    return FALSE;
	}

	if (!window_main->priv->tb_running)
	{
	    G_UNLOCK (TEXTBOX_LOCK);
	    return FALSE;
	}

	if (wait_cycle != 0)
	{
	    wait_cycle--;
	    G_UNLOCK (TEXTBOX_LOCK);
	    return TRUE;
	}

	switch (window_main->priv->tb_direction)
	{
		case SCROLL_RIGHT:
		{
			gint offset;

			offset = window_main->priv->tb_offset + 1;

			if ((offset+TEXTBOX_WIDTH) > window_main->priv->textbox_w)
			{
			    window_main->priv->tb_direction = SCROLL_LEFT;
			    wait_cycle = 20;
			    G_UNLOCK (TEXTBOX_LOCK);
			    return TRUE;
			}
			else
			{
			    window_main->priv->tb_offset = offset;
			    G_UNLOCK (TEXTBOX_LOCK);
			    gtk_widget_queue_draw_area (window_main->window, TEXTBOX_X, TEXTBOX_Y, TEXTBOX_X+TEXTBOX_WIDTH-1, TEXTBOX_Y+10);
			    return TRUE;
			}
		}
		break;

		case SCROLL_LEFT:
		{
			gint offset;

			offset = window_main->priv->tb_offset - 1;
			if (offset < 0)
			  {
			    window_main->priv->tb_direction = SCROLL_RIGHT;
			    wait_cycle = 20;
			    G_UNLOCK (TEXTBOX_LOCK);
			    return TRUE;
			  }
			else
			  {
			    window_main->priv->tb_offset = offset;
			    G_UNLOCK (TEXTBOX_LOCK);
			    gtk_widget_queue_draw_area (window_main->window, TEXTBOX_X, TEXTBOX_Y, TEXTBOX_X+TEXTBOX_WIDTH-1, TEXTBOX_Y+10);
			    return TRUE;
			  }
		}
		break;

		default: {
			    window_main->priv->tb_running = FALSE;
			    G_UNLOCK (TEXTBOX_LOCK);
			    return FALSE; }
	}

	window_main->priv->tb_running = FALSE;
	G_UNLOCK(TEXTBOX_LOCK);
	return FALSE;
}

static void
textbox_stop (BmpWindowMain *window_main)
{
    GSource *source;

    if (window_main->priv->source)
      {
	  source = g_main_context_find_source_by_id (NULL, window_main->priv->source);
	  if (source)
	    {
	      g_source_destroy (source);
	      window_main->priv->tb_running = FALSE;
	    }
      }
}

static void
textbox_update (BmpWindowMain *window_main, const gchar *text)
{

    PangoFontDescription  *pfd;
    PangoLayout		  *layout;
    PangoRectangle	   rect_ink, rect_logical;
    cairo_t		  *cr;
    double r,g,b,a;

    /* Recreate textbox pixmap */
    /* FIXME: Operate with Cairo here instead of GDK */

    if (!G_TRYLOCK(TEXTBOX_LOCK))
      return;

    if ((text) && std::strlen(text))
      {
	const char *fontname;

	layout = gtk_widget_create_pango_layout (BMP_WINDOW(window_main->window)->canvas, "");
	fontname = mcs->key_get<std::string>("bmp", "font"). c_str ();
	pfd = pango_font_description_from_string (fontname);
	pango_font_description_set_absolute_size (pfd, TEXTBOX_FONT_SIZE*PANGO_SCALE);
	pango_layout_set_font_description (layout, pfd);
	pango_font_description_free (pfd);
	pango_layout_set_text (layout, text, std::strlen(text));
	pango_layout_get_pixel_extents (layout, &rect_ink, &rect_logical);

	if (rect_logical.width < TEXTBOX_WIDTH) rect_logical.width = TEXTBOX_WIDTH;

	//Cairo textbox
	if (window_main->priv->textbox != NULL) cairo_surface_destroy (window_main->priv->textbox);
	window_main->priv->textbox = cairo_image_surface_create (CAIRO_FORMAT_ARGB32,
							       rect_logical.width,
							       rect_logical.height);
	window_main->priv->textbox_w = rect_logical.width;
	window_main->priv->textbox_h = rect_logical.height;

	cr = cairo_create (window_main->priv->textbox);
	gdk_color_to_rgba (bmp_colors_get_color(BMP_SKINCOLOR_PL_BG_NORMAL), &r, &g, &b, &a);
	cairo_rectangle (cr, 0, 0, rect_logical.width, rect_logical.height);
	cairo_set_source_rgba (cr, r, g, b, 1.0);
	cairo_fill (cr);

	cairo_move_to (cr, 0, 0);
	gdk_color_to_rgba (bmp_colors_get_color(BMP_SKINCOLOR_PL_FG_CURRENT), &r, &g, &b, &a);
	cairo_set_source_rgba (cr, r, g, b, a);
	pango_cairo_show_layout (cr, layout);
	cairo_surface_reference (window_main->priv->textbox);
	cairo_destroy (cr);

	//Start textbox run
	window_main->priv->tb_offset = 0;
	window_main->priv->tb_direction = SCROLL_RIGHT;
	if (!window_main->priv->tb_running)
          {
		window_main->priv->source = g_timeout_add (50, GSourceFunc(tb_offset_timeout), window_main);
		window_main->priv->tb_running = TRUE;
	  }
      }
    else if (window_main->priv->textbox)
      {
	cr = cairo_create (window_main->priv->textbox);
	gdk_color_to_rgba (bmp_colors_get_color(BMP_SKINCOLOR_PL_BG_NORMAL), &r, &g, &b, &a);
	cairo_rectangle (cr, 0, 0, TEXTBOX_WIDTH, 13);
	cairo_set_source_rgba (cr, r, g, b, 1.0);
	cairo_fill (cr);
	cairo_destroy (cr);

	window_main->priv->tb_offset = 0;
	window_main->priv->tb_running = FALSE;
      }

    gtk_widget_queue_draw (window_main->window);

    G_UNLOCK(TEXTBOX_LOCK);
}

static void
on_system_control_set_title (BmpSystemControl  *control,
			     char	       *title,
			     BmpWindowMain    *window_main)
{
    textbox_stop (window_main);
    textbox_update (window_main, title);
}

static void
on_system_control_set_bitrate   (GObject          *control,
				 unsigned int	   bitrate,
				 BmpWindowMain    *window_main)
{
    gtk_widget_queue_draw (window_main->window);
}

static void
on_system_control_set_samplerate (GObject          *control,
				  unsigned int	    bitrate,
				  BmpWindowMain    *window_main)
{
    gtk_widget_queue_draw (window_main->window);
}

static void
on_system_control_track_change (BmpSystemControl *control, BmpWindowMain *window_main)
{
    g_return_if_fail (BMP_IS_SYSTEM_CONTROL(control));
    g_return_if_fail (BMP_IS_WINDOW_MAIN(window_main));

    window_main->priv->time_seek_minutes = NONE;
    window_main->priv->time_seek_seconds = NONE;
    gtk_widget_queue_draw (window_main->window);
}

/* Xcs callbacks */
static void
on_bmp_use_custom_cursors_changed (const Glib::ustring&	      domain,
				   const Glib::ustring&	      key,
				   const ::Mcs::KeyVariant&  keyvalue,
				   BmpWindowMain	     *window_main)

{
    bmp_window_main_configure (window_main);
}

static void
on_bmp_font_changed		  (const Glib::ustring&	      domain,
				   const Glib::ustring&	      key,
				   const ::Mcs::KeyVariant&  keyvalue,
				   BmpWindowMain	     *window_main)
{
    char *text;

    if (GTK_IS_WIDGET(window_main->window))
       {
	  text = g_object_get_string (bmp_system_control, "current_title");
	  textbox_update (window_main, text);
	  g_free (text);
	  gtk_widget_queue_draw (window_main->window);
       }
}

static void
create_actions(BmpWindowMain *window_main)
{
  GError *error = NULL;

  gtk_action_group_add_actions (bmp_actions, bmp_actions_MAIN, G_N_ELEMENTS (bmp_actions_MAIN), window_main);
  gtk_action_group_add_toggle_actions (bmp_toggle_actions, bmp_toggle_actions_MAIN, G_N_ELEMENTS (bmp_toggle_actions_MAIN), window_main);

  if (!gtk_ui_manager_add_ui_from_file (bmp_ui_manager, DATA_DIR G_DIR_SEPARATOR_S BMP_UI_BASENAME G_DIR_SEPARATOR_S "main.ui", &error))
    {
		g_message ("building menus failed: %s", error->message);
		g_error_free (error);
		error = NULL;
    }
}

#define BMP_SLIDER_DEFAULT_STEP 4

static void
allocate_widgets(BmpWindowMain *window_main)
{
  BmpTooltips *tooltips;
  BmpWindow *window = BMP_WINDOW(window_main->window);
  BmpButton *button;
  BmpButtonToggle *button_toggle;
  GtkAction *action;
  gint i;

  array_buttons = g_ptr_array_new();
  array_buttons_toggle = g_ptr_array_new();

  tooltips = bmp_tooltips_new();
  bmp_tooltips_set_draw_hotspot (tooltips, TRUE);
  RM_ITEM_NEW("tooltips", "tooltips-main", tooltips, NULL);

  /* Normal buttons */
  for (i = 0; i < nbuttons_window_main; ++i)
    {

      button = bmp_button_new((bmp_window_main_buttons[i].action_id != NULL) ? FALSE : TRUE);

      if (bmp_window_main_buttons[i].action_id != NULL)
	{
             action = gtk_action_group_get_action(bmp_actions, bmp_window_main_buttons[i].action_id);
             if (action != NULL)
		{
                     gtk_action_connect_proxy (GTK_ACTION (action), GTK_WIDGET (button));
		}
	}
      else
	{
	    gtk_widget_set_sensitive(GTK_WIDGET(button), FALSE);
	}

     bmp_tooltips_set_tip (tooltips,
                           GTK_WIDGET (button),
                           GTK_STOCK_INFO,
                           gettext (bmp_window_main_buttons[i].tooltip),
                           NULL,
                           FALSE);

      gtk_fixed_put(GTK_FIXED (BMP_WINDOW(window)->canvas),
		GTK_WIDGET (button),
		bmp_window_main_buttons[i].pos_x,
		bmp_window_main_buttons[i].pos_y);
       g_ptr_array_add(array_buttons,button);
    }

  /* Toggle buttons */
  for (i = 0; i < nbuttons_window_main_toggle; ++i)
    {

      button_toggle = bmp_button_toggle_new();

      if (bmp_window_main_buttons_toggle[i].action_id != NULL)
	{
            action = gtk_action_group_get_action(bmp_toggle_actions, bmp_window_main_buttons_toggle[i].action_id);
            if (action != NULL)
		gtk_action_connect_proxy(GTK_ACTION (action), GTK_WIDGET (button_toggle));
	}
      else
	{
	    gtk_widget_set_sensitive(GTK_WIDGET(button_toggle), FALSE);
	}

      bmp_tooltips_set_tip (tooltips,
                            GTK_WIDGET (button_toggle),
                            GTK_STOCK_INFO,
                            gettext (bmp_window_main_buttons_toggle[i].tooltip),
                            NULL,
                            TRUE);

      gtk_fixed_put (GTK_FIXED(BMP_WINDOW(window)->canvas),
		GTK_WIDGET(button_toggle),
		bmp_window_main_buttons_toggle[i].pos_x,
		bmp_window_main_buttons_toggle[i].pos_y);
      g_ptr_array_add (array_buttons_toggle, button_toggle);
    }

  /* Seek slider */
  window_main->priv->sliders[BMP_UI_MAIN_SLIDER_SEEK] = bmp_slider_new();
  g_object_connect (G_OBJECT(window_main->priv->sliders[BMP_UI_MAIN_SLIDER_SEEK]),
		    "signal::moved",
		    G_CALLBACK (bmp_ui_callback_seek_moved),
		    window_main,
		    "signal::motion-hint",
		    G_CALLBACK (seek_motion_hint),
		    window_main,
		    "signal::button-press-event",
		    G_CALLBACK (seek_started),
		    window_main,
		    "signal::button-release-event",
		    G_CALLBACK (seek_ended),
		    window_main,
		    NULL);

  gtk_fixed_put (GTK_FIXED(BMP_WINDOW(window)->canvas),
		 GTK_WIDGET(window_main->priv->sliders[BMP_UI_MAIN_SLIDER_SEEK]),
		 SLIDER_SEEK_X,
		 SLIDER_SEEK_Y);

  bmp_tooltips_set_tip (tooltips,
			window_main->priv->sliders[BMP_UI_MAIN_SLIDER_SEEK],
			GTK_STOCK_INFO,
		        _("With this slider you can seek within the track"),
		        NULL,
		        TRUE);

  /* Volume slider */
  window_main->priv->sliders[BMP_UI_MAIN_SLIDER_VOLUME] = bmp_slider_new();
  bmp_slider_set_scroll_step (BMP_SLIDER (window_main->priv->sliders[BMP_UI_MAIN_SLIDER_VOLUME]), BMP_SLIDER_DEFAULT_STEP);
  bmp_slider_set_report_on_motion (BMP_SLIDER (window_main->priv->sliders[BMP_UI_MAIN_SLIDER_VOLUME]), TRUE);
  g_object_connect (G_OBJECT(window_main->priv->sliders[BMP_UI_MAIN_SLIDER_VOLUME]),
		    "signal::moved",
		    G_CALLBACK(bmp_ui_callback_volume_moved),
		    NULL,
		    NULL);

  gtk_fixed_put (GTK_FIXED(BMP_WINDOW(window)->canvas),
		 GTK_WIDGET(window_main->priv->sliders[BMP_UI_MAIN_SLIDER_VOLUME]),
		 SLIDER_VOLUME_X,
		 SLIDER_VOLUME_Y);

  bmp_tooltips_set_tip (tooltips,
			window_main->priv->sliders[BMP_UI_MAIN_SLIDER_VOLUME],
			GTK_STOCK_INFO,
			_("This slider controls the volume"),
			NULL,
		        TRUE);

  /* Balance slider */
  window_main->priv->sliders[BMP_UI_MAIN_SLIDER_BALANCE] = bmp_slider_new();
  bmp_slider_set_scroll_step (BMP_SLIDER (window_main->priv->sliders[BMP_UI_MAIN_SLIDER_BALANCE]), BMP_SLIDER_DEFAULT_STEP);
  g_object_connect (G_OBJECT(window_main->priv->sliders[BMP_UI_MAIN_SLIDER_BALANCE]),
		    "signal::moved",
		    G_CALLBACK(bmp_ui_callback_balance_moved),
		    NULL,
		    NULL);

  gtk_fixed_put (GTK_FIXED(BMP_WINDOW(window)->canvas),
		 GTK_WIDGET(window_main->priv->sliders[BMP_UI_MAIN_SLIDER_BALANCE]),
		 SLIDER_BALANCE_X,
		 SLIDER_BALANCE_Y);

  bmp_tooltips_set_tip (tooltips,
		        window_main->priv->sliders[BMP_UI_MAIN_SLIDER_BALANCE],
			GTK_STOCK_INFO,
			_("This slider controls the left/right balance"),
		        NULL,
		        TRUE);

  for (i = 0; i < 10; numbers[i++] = NULL);

  if (mcs->key_get<bool>("bmp", "display-tooltips"))
    {
      bmp_tooltips_enable (tooltips);
    }
  else
    {
      bmp_tooltips_disable (tooltips);
    }

  gtk_widget_set_sensitive (GTK_WIDGET(window_main->priv->sliders[BMP_UI_MAIN_SLIDER_SEEK]), FALSE);

  gtk_action_set_sensitive (gtk_action_group_get_action (bmp_actions, BMP_ACTION_PREV), FALSE);
  gtk_action_set_sensitive (gtk_action_group_get_action (bmp_actions, BMP_ACTION_NEXT), FALSE);
  gtk_action_set_sensitive (gtk_action_group_get_action (bmp_actions, BMP_ACTION_PAUSE), FALSE);
  gtk_action_set_sensitive (gtk_action_group_get_action (bmp_actions, BMP_ACTION_STOP), FALSE);
}

static void
on_system_control_set_playstatus (BmpSystemControl *system_control, gint status, BmpWindowMain *window_main)
{
    g_return_if_fail (BMP_IS_WINDOW_MAIN(window_main));

    if (status & PLAYSTATUS_SEEKING)
      {
	gtk_widget_queue_draw (window_main->window);
        return;
      }

    if (status & PLAYSTATUS_STOPPED)
      {
#if 0
	reset_last_position (window_main);
#endif

	bmp_slider_set_position (BMP_SLIDER(window_main->priv->sliders[BMP_UI_MAIN_SLIDER_SEEK]), 0);

	gtk_widget_set_sensitive (GTK_WIDGET(window_main->priv->sliders[BMP_UI_MAIN_SLIDER_SEEK]), FALSE);

	gtk_action_set_sensitive (gtk_action_group_get_action (bmp_actions, BMP_ACTION_PREV), FALSE);
        gtk_action_set_sensitive (gtk_action_group_get_action (bmp_actions, BMP_ACTION_NEXT), FALSE);
	gtk_action_set_sensitive (gtk_action_group_get_action (bmp_actions, BMP_ACTION_PAUSE), FALSE);
        gtk_action_set_sensitive (gtk_action_group_get_action (bmp_actions, BMP_ACTION_STOP), FALSE);

	gtk_widget_queue_draw (window_main->window);
        return;
      }

    if (status & PLAYSTATUS_PAUSED)
      {
	gtk_widget_set_sensitive (GTK_WIDGET(window_main->priv->sliders[BMP_UI_MAIN_SLIDER_SEEK]), FALSE);
	gtk_widget_queue_draw (window_main->window);
        return;
      }

    if (status & PLAYSTATUS_PLAYING)
      {
	gtk_widget_set_sensitive (GTK_WIDGET(window_main->priv->sliders[BMP_UI_MAIN_SLIDER_SEEK]), TRUE);

	gtk_action_set_sensitive (gtk_action_group_get_action (bmp_actions, BMP_ACTION_PREV), TRUE);
        gtk_action_set_sensitive (gtk_action_group_get_action (bmp_actions, BMP_ACTION_NEXT), TRUE);
	gtk_action_set_sensitive (gtk_action_group_get_action (bmp_actions, BMP_ACTION_PAUSE), TRUE);
        gtk_action_set_sensitive (gtk_action_group_get_action (bmp_actions, BMP_ACTION_STOP), TRUE);

	gtk_widget_queue_draw (window_main->window);
        return;
      }
}

//DnD
static void
on_window_main_drag_data_received (GtkWidget	     *widget,
                                   GdkDragContext    *context,
                                   gint		      x,
				   gint		      y,
                                   GtkSelectionData  *selection_data,
                                   guint	      info,
                                   guint	      time_,
				   gpointer	      data)
{
    gchar **uri_strv;
    gchar  *uri_string;
    gint    new_ctr = 0;

    g_return_if_fail (selection_data != NULL);

    /* accept the drop */
    if (!selection_data->data)
      {
  	  gtk_drag_finish (context, FALSE, FALSE, time_);
          return;
      }

    uri_string = g_strdup((char*)selection_data->data);
    g_strstrip (uri_string);
    uri_strv = g_uri_list_extract_uris (uri_string);
    gtk_drag_finish (context, TRUE, FALSE, time_);

    bmp_system_control_add_uri_list (bmp_system_control,
			(const gchar**) uri_strv,
			0,
			TRUE,
			TRUE,
			0,
			&new_ctr,
			NULL);
}

static void
window_main_set_geometry_hints (BmpWindowMain *window_main)
{
    BmpWindow *window = BMP_WINDOW(window_main->window);
    GdkGeometry geometry;
    GdkWindowHints mask;

    geometry.width_inc = 0;
    geometry.height_inc = 0;

    /* make sure the min width/height are multiple values of the resize increments */
    geometry.min_width = BMP_WINDOW_MAIN_WIDTH;
    geometry.max_width =  BMP_WINDOW_MAIN_WIDTH;
    geometry.base_width = 0;

    /* make sure the min width/height are multiple values of the resize increments */
    geometry.min_height = BMP_WINDOW_MAIN_HEIGHT;
    geometry.max_height = BMP_WINDOW_MAIN_HEIGHT;
    geometry.base_height = 0;

    mask = GdkWindowHints (GDK_HINT_MIN_SIZE | GDK_HINT_MAX_SIZE | GDK_HINT_RESIZE_INC | GDK_HINT_BASE_SIZE);

    gtk_window_set_geometry_hints  (GTK_WINDOW(window),
                                    GTK_WIDGET(window),
                                    &geometry,
				    mask);

}

static void
window_main_create (BmpWindowMain *window_main)
{
    BmpWindow *window;

    window_main->window = GTK_WIDGET(bmp_window_new(GTK_WINDOW_TOPLEVEL));
    window = BMP_WINDOW(window_main->window);

    gtk_widget_set_size_request (GTK_WIDGET(BMP_WINDOW(window)->canvas), BMP_WINDOW_MAIN_WIDTH, BMP_WINDOW_MAIN_HEIGHT);

    window_main_set_geometry_hints (window_main);

    create_actions (window_main);
    allocate_widgets (window_main);

    bmp_window_set_icon_list (GTK_WIDGET(window), "player");
    gtk_window_set_title (GTK_WINDOW(window), "BMP");
    gtk_window_set_role (GTK_WINDOW(window), "bmp::window-main");

    g_object_set_data (G_OBJECT(window), "id", g_strdup("main"));

    /* DnD */
    bmp_drag_dest_set (GTK_WIDGET (window));
    g_object_connect (G_OBJECT (BMP_WINDOW (window)),
			"signal::drag-data-received",
			G_CALLBACK (on_window_main_drag_data_received),
			window_main,
			NULL);

    g_object_connect (G_OBJECT(g_ptr_array_index(array_buttons, MAIN_BUTTON_STOP)),
			"signal::button-press-event",
			G_CALLBACK(on_window_main_stop_button_press),
			window_main,
			NULL);

    g_object_connect (G_OBJECT(BMP_WINDOW(window)),

			"signal::focus-in-event",
			G_CALLBACK(on_window_main_focus_in),
		        window_main,

			"signal::focus-out-event",
			G_CALLBACK(on_window_main_focus_out),
		        window_main,

  			"signal::button-press-event",
			G_CALLBACK(on_window_main_button_press),
			window_main,

			"signal::button-release-event",
			G_CALLBACK(on_window_main_button_release),
			window_main,

			"signal::motion-notify-event",
			G_CALLBACK(on_window_main_motion_notify),
			window_main,

			"signal::key-press-event",
			G_CALLBACK(on_window_main_key_press),
			window_main,

			"signal::scroll-event",
			G_CALLBACK(on_window_main_scroll_event),
			window_main,

			"signal::window-state-event",
			G_CALLBACK(on_window_main_state_event),
			window_main,

			"swapped-signal::delete-event",
			G_CALLBACK(bmp_ui_callback_quit_title),
			window_main,

			NULL);

    g_signal_connect (G_OBJECT(BMP_WINDOW(window)->canvas),
			"expose-event",
			G_CALLBACK(on_window_main_canvas_expose),
			window_main);

    g_object_connect (
		bmp_system_control,

		"signal::track-change",
		G_CALLBACK (on_system_control_track_change),
		window_main,

		"signal::set-stream-pos",
		G_CALLBACK (on_system_control_stream_pos),
		window_main,

		"signal::set-volume",
		G_CALLBACK (on_system_control_set_volume),
		window_main,

		"signal::set-playstatus",
		G_CALLBACK (on_system_control_set_playstatus),
		window_main,

		"signal::set-title",
		G_CALLBACK (on_system_control_set_title),
		window_main,

		"signal::set-bitrate",
		G_CALLBACK (on_system_control_set_bitrate),
		window_main,

		"signal::set-samplerate",
		G_CALLBACK (on_system_control_set_samplerate),
		window_main,

		NULL);	

    mcs->subscribe ("UiMain", "bmp", "font", sigc::bind (sigc::ptr_fun (&on_bmp_font_changed), window_main));
    mcs->subscribe ("UiMain", "bmp", "use-custom-cursors", sigc::bind (sigc::ptr_fun (&on_bmp_use_custom_cursors_changed), window_main));

    gtk_window_add_accel_group (GTK_WINDOW(window), gtk_ui_manager_get_accel_group(bmp_ui_manager));
    gtk_widget_hide (BMP_WINDOW(window_main->window)->canvas);
}

void
bmp_window_main_configure (BmpWindowMain *window_main)
{
    BmpWindow *window = BMP_WINDOW(window_main->window);
    BmpButton *button;
    BmpButtonToggle *button_toggle;
    GdkPixbuf *pixbuf_aux;
    gchar *text;
    gint i;

    /* Normal buttons */
    for (i = 0; i < nbuttons_window_main; ++i)
      {
        button = BMP_BUTTON (g_ptr_array_index(array_buttons, i));

        bmp_button_set_from_table(BMP_BUTTON (button),
				  bmp_skin_component[bmp_window_main_buttons[i].pixmap_id]->pixbuf,
				  bmp_window_main_buttons[i].width,
				  bmp_window_main_buttons[i].height,
				  bmp_window_main_buttons[i].img_x,
				  bmp_window_main_buttons[i].img_y,
				  bmp_window_main_buttons[i].img_x_pressed,
				  bmp_window_main_buttons[i].img_y_pressed);

        gtk_widget_set_size_request (GTK_WIDGET (button),
	    bmp_window_main_buttons[i].width,
	    bmp_window_main_buttons[i].height);
    }
    BMP_BUTTON(g_ptr_array_index(array_buttons, MAIN_BUTTON_ICONIFY))->passtrough = FALSE;
    BMP_BUTTON(g_ptr_array_index(array_buttons, MAIN_BUTTON_QUIT))->passtrough = FALSE;

    /* Toggle buttons */
    for (i = 0; i < nbuttons_window_main_toggle; ++i)
      {
        button_toggle = BMP_BUTTON_TOGGLE (g_ptr_array_index(array_buttons_toggle, i));

        bmp_button_toggle_set_from_table (BMP_BUTTON_TOGGLE (button_toggle),
					  bmp_skin_component[bmp_window_main_buttons_toggle[i].pixmap_id]->pixbuf,
					  bmp_window_main_buttons_toggle[i].width,
					  bmp_window_main_buttons_toggle[i].height,
					  bmp_window_main_buttons_toggle[i].img_x,
					  bmp_window_main_buttons_toggle[i].img_y,
					  bmp_window_main_buttons_toggle[i].img_x_pressed,
					  bmp_window_main_buttons_toggle[i].img_y_pressed,
					  bmp_window_main_buttons_toggle[i].img_x_active,
					  bmp_window_main_buttons_toggle[i].img_y_active );

        gtk_widget_set_size_request (GTK_WIDGET (button_toggle),
	    bmp_window_main_buttons_toggle[i].width,
	    bmp_window_main_buttons_toggle[i].height);
    }

    /* Posbar slider */
    if (gdk_pixbuf_get_width(bmp_posbar->pixbuf) == 307) {

        bmp_slider_set_from_table (BMP_SLIDER (window_main->priv->sliders[BMP_UI_MAIN_SLIDER_SEEK]), bmp_posbar->pixbuf,
				   247,
				   gdk_pixbuf_get_height(bmp_posbar->pixbuf),
				   29,
				   gdk_pixbuf_get_height(bmp_posbar->pixbuf),
				   0,
				   0,
				   248,
				   0,
				   278,
				   0,
				   TRUE);

	gtk_widget_set_size_request (GTK_WIDGET(window_main->priv->sliders[BMP_UI_MAIN_SLIDER_SEEK]),
				      247,
				      gdk_pixbuf_get_height(bmp_posbar->pixbuf));

        gtk_widget_show (GTK_WIDGET(window_main->priv->sliders[BMP_UI_MAIN_SLIDER_SEEK]));

  	SET_CURSOR_FOR_WIDGET(CURSOR_POSBAR, window_main->priv->sliders[BMP_UI_MAIN_SLIDER_SEEK]);
    }
    else
        gtk_widget_hide (GTK_WIDGET(window_main->priv->sliders[BMP_UI_MAIN_SLIDER_SEEK]));

    /* Volume slider */
    bmp_slider_set_from_table (BMP_SLIDER(window_main->priv->sliders[BMP_UI_MAIN_SLIDER_VOLUME]), bmp_volume->pixbuf,
				(gdk_pixbuf_get_width(bmp_volume->pixbuf) > 68) ? 68 : gdk_pixbuf_get_width(bmp_volume->pixbuf),
                		gdk_pixbuf_get_height(bmp_volume->pixbuf),
				14,
				bmp_volume->height,
				0,
				0,
                		15,
                	 	422,
                		0,
                	 	422,
				bmp_volume->has_button);



    if (bmp_volume->has_button)
    {
  	gtk_widget_set_size_request (GTK_WIDGET (window_main->priv->sliders[BMP_UI_MAIN_SLIDER_VOLUME]),
	    (gdk_pixbuf_get_width(bmp_volume->pixbuf) > 68) ? 68 : gdk_pixbuf_get_width(bmp_volume->pixbuf),
	     gdk_pixbuf_get_height(bmp_volume->pixbuf) - 421);
    }
    else
    {
  	gtk_widget_set_size_request (GTK_WIDGET (window_main->priv->sliders[BMP_UI_MAIN_SLIDER_VOLUME]),
	    (gdk_pixbuf_get_width(bmp_volume->pixbuf) > 68) ? 68 : gdk_pixbuf_get_width(bmp_volume->pixbuf), 13);
    }

    bmp_slider_set_slice_data(BMP_SLIDER (window_main->priv->sliders[BMP_UI_MAIN_SLIDER_VOLUME]),
	     TRUE,
	     15,
	     27,
	     bmp_volume->has_button);

    BMP_SLIDER(window_main->priv->sliders[BMP_UI_MAIN_SLIDER_VOLUME])->button_yoffset = 1;
    SET_CURSOR_FOR_WIDGET(CURSOR_VOLBAR,window_main->priv->sliders[BMP_UI_MAIN_SLIDER_VOLUME]);
    bmp_slider_set_position (BMP_SLIDER(window_main->priv->sliders[BMP_UI_MAIN_SLIDER_VOLUME]),
 		g_object_get_int (G_OBJECT(bmp_system_control), "volume"));

    /* Balance slider */
    if (bmp_balance)
      {
	BMP_SLIDER (window_main->priv->sliders[BMP_UI_MAIN_SLIDER_BALANCE])->max_adjust = 2;
	bmp_slider_set_from_table (BMP_SLIDER (window_main->priv->sliders[BMP_UI_MAIN_SLIDER_BALANCE]), bmp_balance->pixbuf,
                		38,
                		gdk_pixbuf_get_height(bmp_balance->pixbuf),
				14,
				bmp_balance->height-1,
				9,
				0,
                		15,
                		422,
                		0,
                		422,
				TRUE);
	if ((!bmp_balance->has_button) && (bmp_volume->has_button) )
          {
	    pixbuf_aux = gdk_pixbuf_new (gdk_pixbuf_get_colorspace(bmp_volume->pixbuf),
                                            gdk_pixbuf_get_has_alpha(bmp_volume->pixbuf),
                                            gdk_pixbuf_get_bits_per_sample(bmp_volume->pixbuf),
                                            14, 11);
	    gdk_pixbuf_copy_area(bmp_volume->pixbuf,15,421,14,gdk_pixbuf_get_height(bmp_volume->pixbuf)-421,pixbuf_aux,0,0);
	    g_object_unref (pixbuf_aux);
	    BMP_SLIDER (window_main->priv->sliders[BMP_UI_MAIN_SLIDER_BALANCE])->pb_pressed = pixbuf_aux;
	    BMP_SLIDER (window_main->priv->sliders[BMP_UI_MAIN_SLIDER_BALANCE])->pb_normal  = pixbuf_aux;
	    bmp_balance->has_button = TRUE;
	  }

	BMP_SLIDER (window_main->priv->sliders[BMP_UI_MAIN_SLIDER_BALANCE])->button_yoffset = 1;
	gtk_widget_set_size_request (GTK_WIDGET(window_main->priv->sliders[BMP_UI_MAIN_SLIDER_BALANCE]), 38, 13);
	bmp_slider_set_slice_data(BMP_SLIDER (window_main->priv->sliders[BMP_UI_MAIN_SLIDER_BALANCE]), TRUE, 15, 27, bmp_balance->has_button);
    }

#if 0
    reset_last_position (window_main);
#endif

    if (bmp_play_engine->property_status() == PLAYSTATUS_STOPPED)
      {
	bmp_slider_set_position (BMP_SLIDER(window_main->priv->sliders[BMP_UI_MAIN_SLIDER_SEEK]), 0);
      }

    gtk_widget_queue_draw (window_main->window);

    /* Main window numbers */
    for (i = 0; i < 12; ++i) {

        if (numbers[i]) {
	    g_object_unref (numbers[i]);
	    numbers[i] = NULL;
        }
    }

    for (i = 0; i < GPOINTER_TO_INT(bmp_skin_component[SKIN_COMPONENT_NUMBERS]->user_data); ++i)
    {
	numbers[i] =
		gdk_pixbuf_new (gdk_pixbuf_get_colorspace(bmp_skin_component[SKIN_COMPONENT_NUMBERS]->pixbuf),
                                            gdk_pixbuf_get_has_alpha(bmp_skin_component[SKIN_COMPONENT_NUMBERS]->pixbuf),
                                            gdk_pixbuf_get_bits_per_sample(bmp_skin_component[SKIN_COMPONENT_NUMBERS]->pixbuf),
                                            9,
					    gdk_pixbuf_get_height(bmp_skin_component[SKIN_COMPONENT_NUMBERS]->pixbuf));

	gdk_pixbuf_copy_area (bmp_skin_component[SKIN_COMPONENT_NUMBERS]->pixbuf,
				0 + (i*9),
				0,
				9,
				gdk_pixbuf_get_height(bmp_skin_component[SKIN_COMPONENT_NUMBERS]->pixbuf),
				numbers[i],
				0,
				0);
    }

    SET_CURSOR_FOR_WIDGET(CURSOR_NORMAL,BMP_WINDOW(window)->canvas);
    SET_CURSOR_FOR_WIDGET(CURSOR_NORMAL,window);

    gtk_widget_modify_bg
	(GTK_WIDGET(BMP_WINDOW(window)->canvas),
	    GTK_STATE_NORMAL,
	    bmp_colors_get_color(BMP_SKINCOLOR_PL_BG_NORMAL));

    gtk_widget_modify_base
	(GTK_WIDGET(BMP_WINDOW(window)->canvas),
	    GTK_STATE_NORMAL,
	    bmp_colors_get_color(BMP_SKINCOLOR_PL_BG_NORMAL));

    gtk_widget_modify_fg
	(GTK_WIDGET(BMP_WINDOW(window)->canvas),
	    GTK_STATE_NORMAL,
	    bmp_colors_get_color(BMP_SKINCOLOR_PL_FG_CURRENT));

    gtk_widget_modify_text
	(GTK_WIDGET(BMP_WINDOW(window)->canvas),
	    GTK_STATE_NORMAL,
	    bmp_colors_get_color(BMP_SKINCOLOR_PL_FG_CURRENT));

    text = g_object_get_string (bmp_system_control, "current_title");
    textbox_update (window_main, text);
    g_free (text);

    gdk_window_shape_combine_mask (GTK_WIDGET(window)->window, bmp_ui_get_mask_window_main(bmp_ui), 0, 0);
    gtk_widget_queue_draw (GTK_WIDGET (window));
}

/* GObject */

BmpWindowMain*
bmp_window_main_new (void)
{
    BmpWindowMain *window_main;

    window_main = BMP_WINDOW_MAIN (g_object_new (BMP_TYPE_WINDOW_MAIN, NULL));

    return window_main;
}

static GObject *
bmp_window_main_constructor (GType type,
	                     guint n_construct_properties,
         	             GObjectConstructParam * construct_properties)
{
    GObject *obj;

    {
        BmpWindowMainClass *klass;
        GObjectClass *parent_class;
        klass = BMP_WINDOW_MAIN_CLASS (g_type_class_peek (BMP_TYPE_WINDOW_MAIN));
        parent_class = G_OBJECT_CLASS (g_type_class_peek_parent (klass));
        obj =
            parent_class->constructor (type,
                                       n_construct_properties,
                                       construct_properties);
    }

    return obj;
}

static void
bmp_window_main_dispose (GObject *gobj)
{
    BmpWindowMain *window_main = (BmpWindowMain *) gobj;

    if (window_main->priv->dispose_has_run)
      {
	return;
      }
    else
      {
	window_main->priv->dispose_has_run = TRUE;
      }

    textbox_stop (window_main);

    if (window_main->priv->textbox != NULL)
    {
      cairo_surface_destroy (window_main->priv->textbox);
    }

    gtk_widget_destroy (window_main->window);
}

static void
bmp_window_main_finalize (GObject *gobj)
{}

static void
bmp_window_main_class_init (BmpWindowMainClass * klass)
{
    GObjectClass *gobject_class = G_OBJECT_CLASS (klass);

#if 0
    gobject_class->set_property = bmp_play_set_property;
    gobject_class->get_property = bmp_play_get_property;
#endif
    gobject_class->finalize = bmp_window_main_finalize;
    gobject_class->dispose = bmp_window_main_dispose;
    gobject_class->constructor = bmp_window_main_constructor;
}

static void
bmp_window_main_init (BmpWindowMain *window_main)
{
    window_main->priv = g_new (BmpWindowMainPrivate, 1);

    window_main->priv->dispose_has_run = FALSE;

    window_main->priv->seeking = FALSE;

    window_main->priv->focused = FALSE;

#if 0
    window_main->priv->seek_request = -1;
    window_main->priv->last_position = -1;
#endif

    window_main->priv->time_minutes = 0;
    window_main->priv->time_seconds = 0;

    window_main->priv->time_seek_minutes = 0;
    window_main->priv->time_seek_seconds = 0;

    window_main->priv->time_inverse = mcs->key_get<bool>("bmp", "time-remaining");

    window_main->priv->textbox	= NULL;
    window_main->priv->textbox_w	= 0;
    window_main->priv->textbox_h	= 0;

    window_main->priv->source = 0;

    window_main->priv->tb_offset = 0;
    window_main->priv->tb_drag_offset = 0;
    window_main->priv->tb_running = FALSE;
    window_main->priv->tb_dragging = FALSE;

    window_main_create (window_main);
}


void
bmp_window_main_get_seek_time   (BmpWindowMain *window_main,
				 gint	       *minutes,
				 gint	       *seconds)
{
    if ((window_main->priv->time_seek_minutes == NONE) && (window_main->priv->time_seek_seconds == NONE))
      {
	set_seek_time_I (window_main);
      }

  *minutes = window_main->priv->time_seek_minutes;
  *seconds = window_main->priv->time_seek_seconds;

  window_main->priv->time_seek_minutes = NONE;
  window_main->priv->time_seek_seconds = NONE;

}
