//  BMPx - The Dumb Music Player
//  Copyright (C) 2005 BMPx development team.
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
//
//  --
//
//  The BMPx project hereby grants permission for non-GPL compatible GStreamer
//  plugins to be used and distributed together with GStreamer and BMPx. This
//  permission is above and beyond the permissions granted by the GPL license
//  BMPx is covered by.

#include <bmp/vfs.hpp>
#include <bmp/file_utils.hpp>
#include <bmp/util.h>

#include <boost/algorithm/string.hpp>
#include <boost/shared_ptr.hpp>

#include <dlfcn.h>

namespace
{

  inline bool
  is_module (const std::string &basename)
  {
    return str_has_suffix_nocase (basename.c_str (), G_MODULE_SUFFIX);
  }

  enum
  {
    LIB_BASENAME,
    LIB_PLUGNAME,
    LIB_SUFFIX
  };

}

namespace Bmp {

      namespace VFS {

	  bool
	  VFS::load_plugins_transport (const std::string& path,
				       const std::string& type)
	  {
	    using namespace boost::algorithm;

	    std::string basename (Glib::path_get_basename (path));
	    std::string pathname (Glib::path_get_dirname  (path));

	    if (!is_module (basename)) return false;

	    std::vector<std::string> subs;
	    split (subs, basename, is_any_of ("_."));
	    std::string dir   = Glib::build_filename (PLUGIN_DIR, Glib::build_filename ("vfs", type)); 
	    std::string name  = type + std::string("_") + subs[LIB_PLUGNAME];
	    std::string mpath = Glib::Module::build_path (dir, name);

	    Glib::Module module (mpath, Glib::MODULE_BIND_LAZY);

	    if (module)
	    {
		module.make_resident ();

		Bmp::VFS::PluginTransportBase* (*plugin_create) ();
		if (!module.get_symbol ("plugin_create", (void*&)plugin_create))
		{
		  g_critical ("Unable to acquire plugin_create symbol from library %s", mpath.c_str ());
		}
		else
		{
		  Bmp::VFS::PluginTransportBase* plugin = plugin_create ();
		  transport_plugins.insert (std::make_pair (subs[LIB_PLUGNAME], plugin));
		  g_message ("Transport plugin '%s' loaded.", subs[LIB_PLUGNAME].c_str ()); 
		}
	    }
	    else
	    {
		g_critical ("Failed to load plugin: %s :: %s", mpath.c_str (), module.get_last_error().c_str() );
	    }

	    return false;
	  }

	  bool
	  VFS::load_plugins_container (const std::string& path,
				       const std::string& type)
	  {
	    using namespace boost::algorithm;

	    std::string basename (Glib::path_get_basename (path));
	    std::string pathname (Glib::path_get_dirname  (path));

	    if (!is_module (basename)) return false;

	    std::vector<std::string> subs;
	    split (subs, basename, is_any_of ("_."));
	    std::string dir   = Glib::build_filename (PLUGIN_DIR, Glib::build_filename ("vfs", type)); 
	    std::string name  = type + std::string("_") + subs[LIB_PLUGNAME];
	    std::string mpath = Glib::Module::build_path (dir, name);

	    Glib::Module module (mpath, Glib::MODULE_BIND_LAZY);
	  
	    if (module)
	    {
		module.make_resident ();

		Bmp::VFS::PluginContainerBase* (*plugin_create) ();
		if (!module.get_symbol ("plugin_create", (void*&)plugin_create))
		{
		  g_critical ("Unable to acquire plugin_create symbol from library %s", mpath.c_str ());
		}
		else
		{
		  Bmp::VFS::PluginContainerBase* plugin = plugin_create ();
		  container_plugins.insert (std::make_pair (subs[LIB_PLUGNAME], plugin));
		  Bmp::VFS::ExportData exportdata = plugin->get_export_data ();
		  g_message ("Container plugin '%s' loaded ('%s')",
			      exportdata.description.c_str(), typeid(*plugin).name()); 
		}
	    }
	    else
	    {
		g_critical ("Failed to load plugin: %s :: %s", mpath.c_str (), module.get_last_error().c_str() );
	    }

	    return false;
	  }

	  VFS::VFS ()
	  {
	      Util::dir_for_each_entry (Glib::build_filename (PLUGIN_DIR, Glib::build_filename ("vfs", "transport")),
                                        sigc::bind (sigc::mem_fun (*this, &Bmp::VFS::VFS::load_plugins_transport), "transport"));

	      Util::dir_for_each_entry (Glib::build_filename (PLUGIN_DIR, Glib::build_filename ("vfs", "container")),
                                        sigc::bind (sigc::mem_fun (*this, &Bmp::VFS::VFS::load_plugins_container), "container"));
	  }

	  VFS::~VFS ()
	  {
	  }

	  void
	  VFS::get_containers (ExportDataList& list)
	  {
	    for (ContainerPlugins::iterator i = container_plugins.begin(); i != container_plugins.end(); ++i)
	    {
	      Bmp::VFS::PluginContainerBase *container = (*i).second; 
	      Bmp::VFS::ExportData exportdata = container->get_export_data (); 

	      if (!exportdata.extension.empty())
	      {
		list.push_back (exportdata);
	      }
	    }
	  }

	  bool 
	  VFS::read_no_container (Bmp::VFS::Handle  &handle)
	  {
	    Bmp::VFS::PluginTransportBase *transport = 0;
	    std::string uri = handle.get_uri ();

	    for (TransportPlugins::iterator iter = transport_plugins.begin ();
		  iter != transport_plugins.end ();
		++iter)
	    {
		transport = (*iter).second;		
		if (transport->can_process (uri)) break;
	    }

	    if (!transport)
	      throw Bmp::VFS::UNABLE_TO_PROCESS;
	    else
	      return transport->handle_read (handle);
	  }

	  bool 
	  VFS::read  (Bmp::VFS::Handle  &handle,
		      Util::FileList	&list)
	  {
	    Bmp::VFS::PluginContainerBase *container = 0;
	    Bmp::VFS::PluginTransportBase *transport = 0;

	    std::string uri = handle.get_uri ();

	    for (TransportPlugins::iterator iter = transport_plugins.begin ();
		  iter != transport_plugins.end ();
		++iter)
	    {
		transport = (*iter).second;		
		if (transport->can_process (uri)) break;
	    }

	    if (!transport)
	      throw Bmp::VFS::UNABLE_TO_PROCESS;
	    else
	      transport->handle_read (handle);

	    for (ContainerPlugins::iterator iter = container_plugins.begin ();
		  iter != container_plugins.end ();
		++iter)
	    {
		container = (*iter).second;		
		Bmp::VFS::ExportData exportdata = container->get_export_data ();
		if (container->can_process (uri)) break;
	    }

	    if (!container)
	      throw Bmp::VFS::UNABLE_TO_PROCESS;
	    else
	      return container->handle_read (handle, list);
	  }

	  bool
	  VFS::write (const Util::FileList &list,
		      const std::string    &uri,
		      const std::string    &container_name)
	  {
	    Bmp::VFS::Handle handle = Bmp::VFS::Handle::create (uri); 

	    Bmp::VFS::PluginContainerBase *container = 0;
	    Bmp::VFS::PluginTransportBase *transport = 0;

	    ContainerPlugins::iterator iter = container_plugins.find (container_name);
	    container = (*iter).second;
	    container->handle_write (handle, list);

	    for (TransportPlugins::iterator iter = transport_plugins.begin ();
		  iter != transport_plugins.end ();
		++iter)
	    {
		transport = (*iter).second;		
		if (transport->can_process (uri)) break;
	    }
	    if (!transport) throw Bmp::VFS::UNABLE_TO_PROCESS;
	    return transport->handle_write (handle);
	  } 

      } // namespace VFS

} // namespace Bmp
