/*  BMPx - The Dumb Music Player
 *  Copyright (C) 2005 BMPx development team.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 *  $Id$
 *
 * The BMPx project hereby grant permission for non-gpl compatible GStreamer
 * plugins to be used and distributed together with GStreamer and BMPx. This
 * permission are above and beyond the permissions granted by the GPL license
 * BMPx is covered by.
 */


#ifndef _STORE_STORE_H
#define _STORE_STORE_H

#include <glib-object.h>

#include <libhrel/types.h>
#include <libhrel/tuple.h>

#include <bmp/list.h>

#define B_TYPE_STORE		  (b_store_get_type ())
#define B_STORE(obj)		  (G_TYPE_CHECK_INSTANCE_CAST ((obj), B_TYPE_STORE, BStore))
#define B_STORE_CLASS(klass)	  (G_TYPE_CHECK_CLASS_CAST ((klass), B_TYPE_STORE, BStoreClass))
#define B_IS_STORE(obj)		  (G_TYPE_CHECK_INSTANCE_TYPE ((obj), B_TYPE_STORE))
#define B_IS_STORE_CLASS(klass)	  (G_TYPE_CHECK_CLASS_TYPE ((klass), B_TYPE_STORE))
#define B_STORE_GET_CLASS(obj)	  (G_TYPE_INSTANCE_GET_CLASS ((obj), B_TYPE_STORE, BStoreClass))

#define B_TYPE_STORE_ROW	  (b_store_row_get_type ())

typedef struct _BStore BStore;
typedef struct _BStoreClass BStoreClass;
typedef struct _BStorePrivate BStorePrivate;

struct _BStore {
    GObject parent;

    /*
     * instance members 
     */
    BStorePrivate *private;
};

struct _BStoreClass {
    GObjectClass parent;

};

typedef struct _BStoreRow BStoreRow;
struct _BStoreRow {
    HTuple	 *tuple;
    RowGUID	 *guid;
};

/*StoreRow stuff*/
GType
b_store_row_get_type (void);

void
b_store_row_free (BStoreRow *store_row);

BStoreRow*
b_store_row_copy (BStoreRow *store_row);

BStoreRow*
b_store_row_new (HTuple *tuple);
#define B_STORE_ROW(x) ((BStoreRow*)(x))

/*Store stuff*/
GType
b_store_get_type (void);

BStore*
b_store_new (const gchar *name);

time_t
b_store_get_time (BStore *self);

const gchar*
b_store_get_name (BStore *self);
 
BStoreRow*
b_store_row_fetch (BStore      *self,
		   GtkTreeIter *iter);

void
b_store_row_append (BStore    *self, 
		    BStoreRow *row);

BStoreRow*
b_store_row_get (BStore	     *self,
		 GtkTreeIter *iter);

BStoreRow*
b_store_row_get_by_index (BStore *self,
			  gint	  _index);

gint
b_store_get_n_rows (BStore *self);

gint
b_store_iter_get_index (BStore	    *self, 
		        GtkTreeIter *iter);

gboolean
b_store_get_iter_next (BStore	   *self,
		       GtkTreeIter *iter);
gboolean
b_store_get_iter_prev (BStore	   *self,
		       GtkTreeIter *iter);
gboolean
b_store_get_iter_current (BStore      *self,
			  GtkTreeIter *iter);

void
b_store_store_clear (BStore *self);

void
b_store_row_add (BStore	    *self, 
		 BStoreRow  *row);

void
b_store_remove_rows (BStore *self, 
		     gint   *rows);

#if 0
gboolean
b_store_store_row_remove(BStore *self, GtkTreeIter * iter);

gboolean
b_store_store_row_move_down(BStore *self, GtkTreeIter * iter);

gboolean
b_store_store_row_move_up(BStore *self, GtkTreeIter * iter);
#endif

#endif
