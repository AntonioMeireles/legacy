//-*- Mode: C++; indent-tabs-mode: nil; -*-

/*  BMPx - The Dumb Music Player
 *  Copyright (C) 2005 BMPx development team.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 *  $Id$
 *
 * The BMPx project hereby grant permission for non-gpl compatible GStreamer
 * plugins to be used and distributed together with GStreamer and BMPx. This
 * permission are above and beyond the permissions granted by the GPL license
 * BMPx is covered by.
 */

/*
 * This file contains code originally taken from XMMS-scrobbler:
 *
 * XMMS-scrobbler (C) GPL by
 *
 * Audun Hove <audun@nlc.no>
 * Pipian <pipian@pipian.com>
 *
 */

#include <config.h>

#include <glibmm.h>
#include <glib/gi18n.h>


#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cctype>
#include <iostream>
#include <fstream>

#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <errno.h>
#include <fcntl.h>
#include <strings.h>

#ifdef ENABLE_NLS
# include <libintl.h>
#endif

#include <ne_basic.h>
#include <ne_compress.h>
#include <ne_socket.h>
#include <ne_utils.h>
#include <ne_props.h>
#include <ne_session.h>
#include <ne_request.h>
#include <ne_uri.h>

#include <bmp/util.h>
#include <bmp/uri++.hpp>
#include <goa/libgoa.h>

#include "system_control.hpp"
#include "play.hpp"
#include "paths.hpp"
#include "md5.h"
#include "scrobbler.hpp"

#include <vector>
#include <boost/algorithm/string.hpp>
#include "main.hpp"

#define BMPX_SCROBBLER_URI_SCHEME   "http"
#define BMPX_SCROBBLER_URI_HOST     "post.audioscrobbler.com"
#define BMPX_SCROBBLER_URI_PORT	     80
#define BMPX_SCROBBLER_USERAGENT    "BMP2"

#define BMPX_SCROBBLER_URI_PATH     "/?hs=true&p=1.1&c=%s&v=%s&u=%s"

#define RESP_UPTODATE		    "UPTODATE"
#define RESP_UPDATE		    "UPDATE"
#define RESP_FAILED		    "FAILED"
#define RESP_BADUSER		    "BADUSER"

#define BMPX_SCROBBLER_CLIENT_ID "mpx"
#define BMPX_SCROBBLER_CLIENT_VERSION "1.0"

#define MILLISECOND (1000)

namespace {

  static char*
  hexify (char *pass, int len)
  {
    char *hash;
    char *bp;
    char hexchars[] = "0123456789abcdef";
    int i;

    hash = static_cast<char *> (g_malloc0 (33));
    bp = hash;

    for(i = 0; i < len; i++)
	{
	    *(bp++) = hexchars[(pass[i] >> 4) & 0x0f];
	    *(bp++) = hexchars[pass[i] & 0x0f];
	}
    *bp = 0;

    return hash;
  }

  static char*
  get_timestr (time_t t, int gmt)
  {
	struct tm *tm;
	static char buf[30];

	tm = gmt ? gmtime(&t) : localtime(&t);
	snprintf(buf, sizeof(buf), "%d-%.2d-%.2d %.2d:%.2d:%.2d",
			tm->tm_year + 1900,
			tm->tm_mon + 1,
			tm->tm_mday,
			tm->tm_hour,
			tm->tm_min,
			tm->tm_sec);
	return buf;
  }

  struct SCReadHandle {
    Glib::Mutex  lock;
    char	*memory;
    size_t       size;
  };

  static int
  read_block (void *data, const char *buf, size_t len)
  {
    SCReadHandle *rhandle = reinterpret_cast<SCReadHandle*>(data);

    if (!len)
    {
	rhandle->lock.unlock();
        return 0;
    }

    rhandle->memory = static_cast<char *> (realloc (rhandle->memory, rhandle->size+len));
    std::memcpy  (rhandle->memory+rhandle->size, buf, len);
    rhandle->size += len;
    return 0;
  }

}

namespace Bmp {

    Scrobbler::Scrobbler ()
    {
	green_light = false;
	handshaked  = false;
	enabled     = false;
	sent	    = false;
	duration = 0;
	position = 0;

	for (unsigned int i = 0; i < N_HANDLERS; handler[i++] = 0);

	std::string filename = Glib::build_filename (BMP_PATH_USER_DIR, "lastfm.queue");
	std::string queue_contents;
	try
	{
	    queue_contents = Glib::file_get_contents (filename);

	    if (queue_contents.length () > 1)
	      {
		lock_queue.lock ();

		std::vector<std::string> particles;	    
		boost::algorithm::split (particles, queue_contents, boost::algorithm::is_any_of("\n"));

		if (particles.size () > 1)
		  {
		    for (unsigned int n = 0; n < (particles.size()-1); )
		      {    
			QueueItem item;

			item.md5_pre  = particles[n];
			item.md5_post = particles[n+1];
			queue.push_back (item);
			n += 2;
		      }
		  }

		lock_queue.unlock ();
	      }

	    signal_queue_size_. emit (queue. size());
	}
	catch (...)
	{
	    g_log (BMPX_SCROBBLER_LOG_DOMAIN, G_LOG_LEVEL_INFO, "%s: No queue to load.", G_STRLOC); //FIXME: We need to catch different exceptions here
	}

	message_domain_id = bmp_system_control_message_domain_register (bmp_system_control,
								        "lastfm",
  								        "BMP: Last.FM");

	if (mcs->key_get<bool>("lastfm", "general-enable"))
	  {
	    Mcs::KeyVariant variant = true;
	    Bmp::Scrobbler::general_enable ("lastfm", "general-enable", variant); 
	  }

	mcs->subscribe ("Scrobbler", "lastfm", "general-enable", sigc::mem_fun (*this, &::Bmp::Scrobbler::general_enable));
      }

    Scrobbler::~Scrobbler ()
    {
      std::string queue_string, filename;

      lock_green_light. lock ();
      green_light_conn.disconnect ();
      lock_green_light. unlock ();

      lock_queue. lock ();
      queue_conn.disconnect ();
      lock_queue. unlock ();
      
      for (std::list<QueueItem>::iterator iter = queue.begin (); iter != queue.end (); iter++)
	{
	    QueueItem item;
	    item = *iter;

	    queue_string += item.md5_pre + "\n" + item.md5_post + "\n"; 
	}

      filename = Glib::build_filename (BMP_PATH_USER_DIR, "lastfm.queue");

      std::ofstream queuefile;
      queuefile. open (filename.c_str());
      queuefile << queue_string;
      queuefile. close ();
    }

    void
    Scrobbler::general_enable (const std::string&	 domain,
			       const std::string&	 key,
			       const Mcs::KeyVariant&   value) 
    {
	if (boost::get<bool>(value))
	  {
	      this->handler[H_TRACK_CHANGE] =
			g_signal_connect (G_OBJECT(bmp_system_control),
				          "track-change",
					  G_CALLBACK(track_change),
					  this);

	      this->handler[H_SET_STREAM_POS] =
			g_signal_connect (G_OBJECT(bmp_system_control),
				          "set-stream-pos",
					  G_CALLBACK(set_stream_pos),
					  this);

	      this->handler[H_SEEK_EVENT] =
			g_signal_connect (G_OBJECT(bmp_system_control),
				          "seek-event",
					  G_CALLBACK(seek_event),
					  this);

	      mcs->subscribe ("Scrobbler", "lastfm", "enable", sigc::mem_fun (*this, &::Bmp::Scrobbler::enable_changed));

	      if (mcs->key_get<bool>("lastfm", "enable"))
		{
		  if (!this->handshaked) this->run_handshake ();
		}
	  }
	else
	  {
	      if (this->handler[H_TRACK_CHANGE])
		{
		  g_signal_handler_disconnect (bmp_system_control, this->handler[H_TRACK_CHANGE]);
		}

	      if (this->handler[H_SET_STREAM_POS])
		{
		  g_signal_handler_disconnect (bmp_system_control, this->handler[H_SET_STREAM_POS]);
		}

	      if (this->handler[H_SEEK_EVENT])
		{
		  g_signal_handler_disconnect (bmp_system_control, this->handler[H_SEEK_EVENT]);
		}

	      if (this->handler[H_LASTFM_ENABLE])
		{
		  mcs->unsubscribe ("Scrobbler", "lastfm", "enable");
		}

	      this->lock_green_light. lock ();
	      if (this->green_light_conn.connected ()) this->green_light_conn.disconnect ();
	      this->lock_green_light. unlock ();

	      this->lock_queue. lock ();
	      if (this->queue_conn.connected ()) this->queue_conn.disconnect ();
	      this->lock_queue. unlock ();

	      this->handshaked = false;
	}
    }

    Scrobbler::HandshakeStatus
    Scrobbler::handshake ()
    {
        SCReadHandle		   rhandle;
        ne_session		  *sess;
        ne_request		  *reqs;
        gchar			  *path; //XCS always returns newly allocated C strings
	std::vector<std::string>   resp, line;	    
	Glib::ustring		   user;
        Scrobbler::HandshakeStatus status = SCROBBLER_HANDSHAKE_STATE_UNDEFINED;
    
        user = mcs->key_get<std::string>("lastfm", "username");
        path = g_strdup_printf (BMPX_SCROBBLER_URI_PATH,
                                BMPX_SCROBBLER_CLIENT_ID,
                                BMPX_SCROBBLER_CLIENT_VERSION,
                                user. c_str ());
    
        sess = ne_session_create (BMPX_SCROBBLER_URI_SCHEME,
                                  BMPX_SCROBBLER_URI_HOST,
                                  BMPX_SCROBBLER_URI_PORT);
    
        ne_set_useragent (sess, BMPX_SCROBBLER_USERAGENT);
        ne_set_read_timeout (sess, 15);
        reqs = ne_request_create (sess, "GET", path);
	g_free (path);
    
        rhandle. memory = NULL;
        rhandle. size = 0;
	rhandle. lock. lock (); 
    
        ne_add_response_body_reader (reqs, ne_accept_2xx, read_block, &rhandle);
    
        if (ne_request_dispatch (reqs) != NE_OK)
            {
		std::string message;
   
		rhandle. lock. unlock (); 

                ne_request_destroy (reqs);
                message  = _("A Network error occured while trying to connect to Last.FM: ");
		message += ne_get_error (sess);
                ne_session_destroy (sess);
    
                bmp_system_control_message_dispatch (bmp_system_control,
                                                     message_domain_id,
                                                     GTK_MESSAGE_ERROR,
                                                     message.c_str ());
                mcs->key_set<bool>("lastfm", "enable", false);
                status = SCROBBLER_HANDSHAKE_NETWORK_ERROR;
                return status;
            }
    
        while (!rhandle. lock. trylock ())
        {
	    Glib::RefPtr< Glib::MainContext > context;
	    context = Glib::MainContext::get_default();
	    while (context->pending ()) { context->iteration (true); }; 
        }
   
	rhandle. lock. unlock (); 
    
        ne_request_destroy (reqs);
        ne_session_destroy (sess);
    
        //Parse response
        if (!rhandle.memory)
            {
                status = SCROBBLER_HANDSHAKE_NETWORK_ERROR; //FIXME: We need to potentially differentiate here
                return status;
            }

	boost::algorithm::split (resp, rhandle.memory, boost::algorithm::is_any_of("\n"));
	g_free (rhandle. memory);

	boost::algorithm::split (line, resp[0], boost::algorithm::is_any_of(" "));
        if (!line[0]. compare(RESP_UPTODATE))
            {
                info.uptodate = true;
                info.md5 = resp[1];
                info.uri = resp[2];
   
		boost::algorithm::split (line, resp[3], boost::algorithm::is_any_of(" "));
		if (line. size() >= 2) info.interval = std::atoi (line[1]. c_str ());
                status = SCROBBLER_HANDSHAKE_UPTODATE;
            }
        else
        if (!line[0]. compare(RESP_UPDATE))
            {
                info.uptodate = false;
                info.info = resp[0];
                info.md5  = resp[1];
                info.uri  = resp[2];

		boost::algorithm::split (line, resp[3], boost::algorithm::is_any_of(" "));
		if (line. size() >= 2) info.interval = std::atoi (line[1]. c_str ());
                status = SCROBBLER_HANDSHAKE_UPDATE;
            }
        else
        if (!line[0]. compare(RESP_BADUSER))
            {
		boost::algorithm::split (line, resp[1], boost::algorithm::is_any_of(" "));
		if (line. size() >= 2) info.interval = std::atoi (line[1]. c_str ());
                status = SCROBBLER_HANDSHAKE_BADUSER;
            }
	else
        if (!line[0]. compare(RESP_FAILED))
            {
                info.info = resp[0];
		boost::algorithm::split (line, resp[1], boost::algorithm::is_any_of(" "));
		if (line. size() >= 2) info.interval = std::atoi (line[1]. c_str ());
                status = SCROBBLER_HANDSHAKE_FAILED;
            }
    
        if ((status == SCROBBLER_HANDSHAKE_BADUSER) || (status == SCROBBLER_HANDSHAKE_FAILED))
	  {
	    boost::algorithm::split (line, resp[1], boost::algorithm::is_any_of(" "));
            restart_green_light_timeout (atoi(line[1]. c_str()));
	  }
        else
	  {
	    boost::algorithm::split (line, resp[3], boost::algorithm::is_any_of(" "));
            restart_green_light_timeout (atoi(line[1]. c_str()));
	  }
   
        return status;
    }
    
    void
    Scrobbler::run_handshake ()
    {
        Scrobbler::HandshakeStatus hs_result;
	Glib::ustring user, pass;
    
        if (handshaked) return;
    
        user = mcs->key_get<std::string>("lastfm", "username");
        pass = mcs->key_get<std::string>("lastfm", "password");

        if (user.empty () || pass.empty ())
            {
                //FIXME: Error here
    
                return;
            }
    
        hs_result = handshake ();
    
        switch (hs_result)
            {
                    case SCROBBLER_HANDSHAKE_UPTODATE:
                        {
                            md5_state_t  md5state;
                            char         md5pword[16];
                            char	*str;
                            char	*pass, *aux;
   
                            g_log (BMPX_SCROBBLER_LOG_DOMAIN, G_LOG_LEVEL_INFO, "%s: UPTODATE. MD5:'%s', URL:'%s', INTERVAL:'%d'", G_STRLOC,
                                                                                        info.md5.c_str (),
                                                                                        info.uri.c_str (),
                                                                                        info.interval);
    
                            pass = g_strdup (mcs->key_get<std::string>("lastfm", "password"). c_str ());
    
                            md5_init (&md5state);
                            md5_append (&md5state, (unsigned const char *)pass, std::strlen(pass));
                            md5_finish (&md5state, (unsigned char *)md5pword);
                            aux = hexify (md5pword, sizeof(md5pword));
    
                            str = g_strconcat (aux, info.md5.c_str (), NULL);
                            md5_init (&md5state);
                            md5_append (&md5state, (unsigned const char *)str, std::strlen(str));
                            md5_finish (&md5state, (unsigned char *)md5pword);
    
                            md5_response = hexify (md5pword, sizeof(md5pword));
    
			    if (!queue_conn.connected ())
			    {
                                g_log (BMPX_SCROBBLER_LOG_DOMAIN, G_LOG_LEVEL_INFO, "%s: Restarting queue processing", G_STRLOC);
				queue_conn = Glib::signal_timeout().connect (sigc::mem_fun (this, &Bmp::Scrobbler::process_queue ), 2000);
			    }
    
                            g_free (aux);
                            g_free (str);
			    g_free (pass);
                        }
                        break;
    
                    case SCROBBLER_HANDSHAKE_UPDATE:
                        {
                            md5_state_t  md5state;
                            char         md5pword[16];
                            char	*str;
                            char	*pass, *aux;
   
                            g_log (BMPX_SCROBBLER_LOG_DOMAIN, G_LOG_LEVEL_INFO, "%s: UPDATE. UPDATE_URL:'%s', MD5:'%s', URL:'%s', INTERVAL:'%d'", G_STRLOC,
                                                                                        info.info.c_str (),
                                                                                        info.md5.c_str (),
                                                                                        info.uri.c_str (),
                                                                                        info.interval);
    
                            pass = g_strdup (mcs->key_get<std::string>("lastfm", "password"). c_str ());
                            md5_init (&md5state);
                            md5_append (&md5state, (unsigned const char *)pass, std::strlen(pass));
                            md5_finish (&md5state, (unsigned char *)md5pword);
                            aux = hexify (md5pword, sizeof(md5pword));
    
                            str = g_strconcat (aux, info.md5.c_str(), NULL);
                            md5_init (&md5state);
                            md5_append (&md5state, (unsigned const char *)str, std::strlen(str));
                            md5_finish (&md5state, (unsigned char *)md5pword);
    
                            md5_response = hexify (md5pword, sizeof(md5pword));
   
			    if (!queue_conn.connected ())
			    {
                                g_log (BMPX_SCROBBLER_LOG_DOMAIN, G_LOG_LEVEL_INFO, "%s: Restarting queue processing", G_STRLOC);
				queue_conn = Glib::signal_timeout().connect (sigc::mem_fun (this, &Bmp::Scrobbler::process_queue ), 2000);
			    }
    
                            g_free (aux);
                            g_free (str);
			    g_free (pass);
                        }
                        break;
    
                    case SCROBBLER_HANDSHAKE_BADUSER:
                        {
                            g_log (BMPX_SCROBBLER_LOG_DOMAIN, G_LOG_LEVEL_INFO, "%s: BADUSER. INTERVAL:'%d'", G_STRLOC, info.interval);
    
                            bmp_system_control_message_dispatch (bmp_system_control,
                                                                 message_domain_id,
                                                                 GTK_MESSAGE_ERROR,
                                                                "Please check your Last.FM username/password!\n\nLast.FM support has to be disabled until proper credentials are provided.");
                            mcs->key_set<bool>("lastfm", "enable", false);
                        }
                        break;
    
                    case SCROBBLER_HANDSHAKE_FAILED:
                        {
			    std::string message;
                            g_log (BMPX_SCROBBLER_LOG_DOMAIN, G_LOG_LEVEL_INFO, "%s: FAILED. REASON:'%s', INTERVAL:'%d'", G_STRLOC,
										info.info.c_str (),
										info.interval);
                            message  = _("Connection with Last.FM failed. Reason given is: ");
			    message += info.info;
                            bmp_system_control_message_dispatch (bmp_system_control,
                                                                 message_domain_id,
                                                                 GTK_MESSAGE_ERROR,
                                                                 message.c_str ());
                            mcs->key_set<bool>("lastfm", "enable", false);
                        }
                        break;
    
                    case SCROBBLER_HANDSHAKE_NETWORK_ERROR:
                        {
                            g_log (BMPX_SCROBBLER_LOG_DOMAIN, G_LOG_LEVEL_INFO, "%s: NETWORK ERROR", G_STRLOC);
                            bmp_system_control_message_dispatch	    (bmp_system_control,
                                                                     message_domain_id,
                                                                     GTK_MESSAGE_ERROR,
                                                                     "A network error occured during connection handshake with Last.FM");
                            mcs->key_set<bool>("lastfm", "enable", false);
                        }
                        break;
    
                    case SCROBBLER_HANDSHAKE_STATE_UNDEFINED:
                        {
                            g_log (BMPX_SCROBBLER_LOG_DOMAIN, G_LOG_LEVEL_INFO, "%s: STATE UNDEFINED", G_STRLOC);
                            mcs->key_set<bool>("lastfm", "enable", false);
                        }
                        break;
    
                    default:
                            g_log (BMPX_SCROBBLER_LOG_DOMAIN, G_LOG_LEVEL_WARNING, "%s: Unknown Scrobbler handshake status response!", G_STRLOC);
                            break;
            }
    
        handshaked = true;
    }

    void
    Scrobbler::track_change  (BmpSystemControl    *system_control,
			      gpointer		   data)	
    {
      //Determine the length of the current song
      GError	    *error;
      char	    *uri;

      Bmp::Scrobbler *scrobbler = reinterpret_cast<Bmp::Scrobbler*>(data);
      error = NULL;

      bmp_system_control_get_current_uri (system_control, &uri, &error);

      Bmp::URI u (uri);
  
      if (u.get_protocol() != Bmp::URI::PROTOCOL_HTTP)
      {
	Bmp::DB::DataRow row = library->get_metadata (std::string(uri));
	free (uri);
	Bmp::DB::ValueVariant v_duration = row[library->get_metadatum_id (Bmp::Library::DATUM_TIME)];
	scrobbler->duration = boost::get<int>(v_duration); 
	scrobbler->sent = false;
	scrobbler->position = 0;
      }
      else
      {
	scrobbler->duration = 0; 
	scrobbler->sent = true;
	scrobbler->position = 0;
      }
    }

    bool
    Scrobbler::process_queue ()
    {
      SCReadHandle		 rhandle;
      QueueItem			 queue_item;
      std::string		 post_data;
      std::vector<std::string>	 resp, line;	    
      ne_session		*sess;
      ne_request		*reqs;

      if (!handshaked) 
	{
	  green_light_conn. disconnect ();
	  return false;
	}

      lock_green_light. lock ();
      if (!green_light)
	{
	  g_log (BMPX_SCROBBLER_LOG_DOMAIN, G_LOG_LEVEL_INFO, "%s: Interval not reached yet: cannot send", G_STRLOC);
	  return false;
	}
      lock_green_light. unlock ();

      if (queue.empty())
	{
	  return false;
	}

      queue_item = queue.front ();
      queue.pop_front ();

      //Emit submit_start signal
      signal_submit_start_. emit ();

      post_data = queue_item.md5_pre + md5_response + queue_item.md5_post; 
      g_log (BMPX_SCROBBLER_LOG_DOMAIN, G_LOG_LEVEL_INFO, "%s: Submitting song with POST data '%s'", G_STRLOC, post_data.c_str ());

      Bmp::URI uri (info.uri);

      sess = ne_session_create (uri.scheme.c_str(),
			        uri.hostname.c_str(),
			        80);

      ne_set_useragent (sess, BMPX_SCROBBLER_USERAGENT);
      ne_set_read_timeout (sess, 15);

      reqs = ne_request_create (sess, "POST", uri.path.c_str());

      ne_add_request_header (reqs, "Content-Type", "application/x-www-form-urlencoded");
      ne_set_request_body_buffer (reqs, post_data.c_str (), (size_t)post_data.length());

      rhandle. memory = 0;
      rhandle. size = 0;
      rhandle. lock. lock ();

      ne_add_response_body_reader (reqs, ne_accept_2xx, read_block, &rhandle);

      if (ne_request_dispatch (reqs) != NE_OK)
	{
	    std::string message;

	    ne_request_destroy (reqs);

	    rhandle. lock. unlock ();

	    message  = _("A Network error occured while trying to connect to Last.FM: ");
	    message += ne_get_error (sess);
	    ne_session_destroy (sess);

	    bmp_system_control_message_dispatch (bmp_system_control,
						 message_domain_id,
						 GTK_MESSAGE_ERROR,
					         message.c_str ());
	    mcs->key_set<bool>("lastfm", "enable", false);
	    lock_green_light. unlock ();
	    signal_submit_end_. emit ();
	    return false;
	}

      while (!rhandle. lock. trylock ())
        {
	    Glib::RefPtr< Glib::MainContext > context;
	    context = Glib::MainContext::get_default();
	    while (context->pending ()) { context->iteration (true); }; 
        }

      rhandle. lock. unlock ();

      ne_request_destroy (reqs);
      ne_session_destroy (sess);

      boost::algorithm::split (resp, rhandle. memory, boost::algorithm::is_any_of("\n"));
      g_free (rhandle. memory);

      if (!resp[0]. compare("BADAUTH"))
	{
	    bmp_system_control_message_dispatch (bmp_system_control,
						 message_domain_id,
					         GTK_MESSAGE_ERROR,
						 _("There was an authentication error during song submission.\n\nPlease check your Last.FM username/password.\n\nLast.FM support has to be disabled until proper credentials are provided."));
	    mcs->key_set<bool>("lastfm", "enable", false);
	}
      else
      if (!resp[0]. substr(0,6). compare("FAILED"))
	{
	    g_log (BMPX_SCROBBLER_LOG_DOMAIN, G_LOG_LEVEL_INFO, "%s: Submitting song '%s' failed: %s", G_STRLOC, post_data.c_str (), resp[0]. c_str());
	}
      else /* OK assumed */
	{
	    g_log (BMPX_SCROBBLER_LOG_DOMAIN, G_LOG_LEVEL_INFO, "%s: Submitting song '%s' succeeded.", G_STRLOC, post_data.c_str ());
	}


      boost::algorithm::split (line, resp[1], boost::algorithm::is_any_of(" "));
      restart_green_light_timeout (std::atoi(line[1]. c_str()));

      signal_queue_size_. emit(queue. size());
      signal_submit_end_. emit ();

      if (queue.empty ()) return false;
      return true;
  }

  void
  Scrobbler::restart_green_light_timeout (int seconds)
  {
    Glib::Mutex::Lock lock (lock_green_light);
    if (green_light_conn.connected ()) return;

    g_log (BMPX_SCROBBLER_LOG_DOMAIN, G_LOG_LEVEL_INFO, "%s: GREEN LIGHT in %d seconds", G_STRLOC, seconds);
    green_light_conn = Glib::signal_timeout().connect (sigc::mem_fun (this, &Bmp::Scrobbler::set_green_light ), seconds * MILLISECOND);
  }

  bool
  Scrobbler::set_green_light ()
  {
    Glib::Mutex::Lock lock (lock_green_light);
    green_light = true;

    return false;
  }

  void
  Scrobbler::enable_changed (const std::string&     domain,
			     const std::string&     key,
			     const Mcs::KeyVariant&  value)
  {
    if (boost::get<bool>(value))
      {
	this->run_handshake ();
      }
    else
      {
	this->handshaked = false;
      }
  }

  void
  Scrobbler::seek_event (BmpSystemControl  *control,
		         gint		    position,
		         gpointer	    data)
  {
    Bmp::Scrobbler *scrobbler = reinterpret_cast<Bmp::Scrobbler*>(data);
    bool playing = (bmp_play_engine->property_status() == PLAYSTATUS_PLAYING) ? true : false;

    if (playing && (!scrobbler->sent))
	{
	    if ((position >= 240) || (position >= (scrobbler->duration/2)))
		{
		    scrobbler->sent = true;
		}
	}
  }

  void
  Scrobbler::set_stream_pos	(BmpSystemControl   *system_control,
				 gint		     position,
				 gpointer	     data)
  {
    Bmp::Scrobbler *scrobbler = reinterpret_cast<Bmp::Scrobbler*>(data);
    bool playing = (bmp_play_engine->property_status() == PLAYSTATUS_PLAYING) ? true : false;
  
    if (scrobbler->duration < 30) return;
    if (playing && (!scrobbler->sent))
	{
	    if ((position >= 240) || (position >= (scrobbler->duration/2)))
		{
		    scrobbler->send_song_information (position);
		}
	}
  }

  void
  Scrobbler::send_song_information (int position)
  {

#define SCROBBLER_SONG_POST_STRING_PRE  "u=%s&s="
#define SCROBBLER_SONG_POST_STRING_POST "&a[0]=%s&t[0]=%s&m[0]=&b[0]=%s&l[0]=%d&i[0]=%s"

    GError		*error;
    char		*timestr;
    char		*artist, *artist_e,
			*title,  *title_e,
			*album,  *album_e;
    std::string		 current_uri, user;
    QueueItem		 queue_item;
    int			 duration;
    char		*uri;

    if (sent) return;
    sent = true;
    error = 0; 

    bmp_system_control_get_current_uri (bmp_system_control, &uri, &error);
    Bmp::DB::DataRow row = library->get_metadata (std::string(uri));
    current_uri = uri; 
    free (uri);

    Bmp::URI bmpuri (current_uri);
    if (bmpuri.get_protocol() == Bmp::URI::PROTOCOL_HTTP) return;
  
    Bmp::DB::ValueVariant v_duration,
			  v_artist,
			  v_album,
			  v_title;

    v_duration = row[library->get_metadatum_id (Bmp::Library::DATUM_TIME)];
    if (v_duration.which () != Bmp::DB::VALUE_TYPE_INT) return;
    duration = boost::get<int>(v_duration); 

    if (duration < 30)
    {
      g_log (BMPX_SCROBBLER_LOG_DOMAIN,
	     G_LOG_LEVEL_INFO,
	     "%s: Not submitting '%s' to scrobbler: duration of less than 30 seconds",
	     G_STRLOC,
	     current_uri.c_str ());
      return;
    }

    v_artist = row[library->get_metadatum_id (Bmp::Library::DATUM_ARTIST)];
    if (v_artist.which () != Bmp::DB::VALUE_TYPE_STRING) return;
    artist = strdup (boost::get<std::string>(v_artist).c_str()); 

    v_album  = row[library->get_metadatum_id (Bmp::Library::DATUM_ALBUM)];
    if (v_album.which () != Bmp::DB::VALUE_TYPE_STRING) return;
    album  = strdup (boost::get<std::string>(v_album).c_str ()); 

    v_title  = row[library->get_metadatum_id (Bmp::Library::DATUM_TITLE)];
    if (v_title.which () != Bmp::DB::VALUE_TYPE_STRING) return;
    title  = strdup(boost::get<std::string>(v_title).c_str()); 

    if (artist) g_strstrip (artist);
    if (album)  g_strstrip (album);
    if (title)  g_strstrip (title);

    if (artist && !std::strlen(artist))
      {
	  free (artist);
	  artist = NULL;
      }

    if (title && !std::strlen(title))
      {
	  free (title);
	  title = NULL;
      }

    if (!duration || !artist || !title)
	{
	    g_log (BMPX_SCROBBLER_LOG_DOMAIN, G_LOG_LEVEL_INFO, "%s: Not submitting '%s' to scrobbler: missing metadata!",
						    G_STRLOC,
						    current_uri.c_str());
	    return;
	}


    timestr = get_timestr (time(NULL),1);
    user = mcs->key_get<std::string>("lastfm", "username");

    //Push to queue
    lock_queue. lock ();
    g_log (BMPX_SCROBBLER_LOG_DOMAIN, G_LOG_LEVEL_INFO, "%s: Pushing '%s' onto the queue", G_STRLOC, current_uri.c_str ());
    queue_item.md5_pre = g_strdup_printf (SCROBBLER_SONG_POST_STRING_PRE, user. c_str ());

    artist_e = ne_path_escape (artist);
    album_e  = ne_path_escape (album);
    title_e  = ne_path_escape (title);

    queue_item.md5_post = g_strdup_printf (SCROBBLER_SONG_POST_STRING_POST,
					    artist_e,
					    title_e,
					    album_e,
					    duration,
					    timestr);

    g_free (artist);
    g_free (title);
    g_free (album);
    g_free (artist_e);
    g_free (title_e);
    g_free (album_e);

    queue.push_back (queue_item);
    lock_queue. unlock ();

    signal_queue_size_. emit(queue. size());

    if ((!queue_conn.connected ()) && mcs->key_get<bool>("lastfm", "enable"))
      {
	  g_log (BMPX_SCROBBLER_LOG_DOMAIN, G_LOG_LEVEL_INFO, "%s: Restarting queue processing", G_STRLOC);
	  queue_conn = Glib::signal_timeout().connect (sigc::mem_fun (this, &Bmp::Scrobbler::process_queue ), 2000);
      }
  }

  void
  Scrobbler::emit_queue_size ()
  {
      signal_queue_size_. emit (queue. size());
  }

  //Signals
  Bmp::Scrobbler::SignalQueueSize&
  Bmp::Scrobbler::signal_queue_size() {
      return signal_queue_size_;
  }

  Bmp::Scrobbler::SignalSubmitStart&
  Bmp::Scrobbler::signal_submit_start() { 
      return signal_submit_start_;
  }

  Bmp::Scrobbler::SignalSubmitEnd&
  Bmp::Scrobbler::signal_submit_end() {
      return signal_submit_end_;
  }

};
