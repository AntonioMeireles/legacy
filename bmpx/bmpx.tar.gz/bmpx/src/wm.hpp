#ifndef BMP_WM_HPP
#define BMP_WM_HPP

#include <glib.h>

typedef enum {
    BMP_WINDOW_PERSISTENT,
    BMP_WINDOW_TRANSIENT
} BmpWindowType;

void
wm_init ();

void
wm_set_keep_above (gboolean keep_above);

void
wm_about_start ();

void
wm_about_stop ();

#endif // BMP_WM_HPP
