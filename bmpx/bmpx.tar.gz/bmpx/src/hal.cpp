#include <config.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <dirent.h>
#include <signal.h>
#include <unistd.h>
#include <string.h>

#include <glib.h>
#include <glib-object.h>
#include <glib/gi18n.h>

#include <dbus/dbus.h>
#include <dbus/dbus-glib.h>
#include <dbus/dbus-glib-lowlevel.h>

#include <libhal.h>
#include <libhal-storage.h>

#if 0
#include <bmp/dbus.h>
#include <bmp/util.h>
#endif
#include <bmp/hal.h>
#include <goa/libgoa.h>

G_DEFINE_TYPE (BmpHal, bmp_hal, G_TYPE_OBJECT)

#include <main.hpp>

typedef enum
{
	BMP_HAL_SIGNAL_VOLUME_ADDED,
	BMP_HAL_SIGNAL_VOLUME_REMOVED,

	BMP_HAL_N_SIGNALS

} BmpHalSignals;

static guint
signals[BMP_HAL_N_SIGNALS] = {0};

typedef enum {
	BMP_HAL_N_PROPERTIES
} BmpHalProperties;

struct _BmpHalPrivate
{
        gboolean	 dispose_has_run;

        DBusConnection	*dbus_connection;
	LibHalContext	*ctx;
	GHashTable	*volumes;
	gboolean	 initialized;

	gint		 msg_domain_id;
};

static void
print_bmp_hal_volume_data (BmpHalVolumeData *v_data)
{
  g_message ("Volume UDI [%s]", v_data->volume_udi);
  g_message ("\tMount Path....: [%s]", v_data->mount_path);
  g_message ("\tIs Disc.......: [%s]", v_data->is_disc ? "TRUE" : "FALSE");
  g_message ("\tDevice UDI....: [%s]", v_data->device_udi);
  g_message ("\tDevice Serial.: [%s]", v_data->device_serial);
}

/* GBoxed for BmpHalVolumeData */

BmpHalVolumeData*
bmp_hal_volume_data_copy (BmpHalVolumeData *item)
{
    BmpHalVolumeData *_copy;

    _copy = g_new0 (BmpHalVolumeData, 1);

    _copy->volume_udi	  = g_strdup (item->volume_udi);
    _copy->mount_path	  = g_strdup (item->mount_path);
    _copy->device_udi	  = g_strdup (item->device_udi);
    _copy->device_serial  = g_strdup (item->device_serial);
    _copy->is_disc	  = item->is_disc;

    return _copy;
}


void
bmp_hal_volume_data_free (BmpHalVolumeData *item)
{
    g_free (item->volume_udi);
    g_free (item->mount_path);
    g_free (item->device_udi);
    g_free (item->device_serial);

    g_free (item);
}


GType
bmp_hal_volume_data_get_type (void)
{
    static GType our_type = 0;

    if (our_type == 0)
        our_type = g_boxed_type_register_static ("BmpHalVolumeData",
                                                 (GBoxedCopyFunc)
                                                 bmp_hal_volume_data_copy,
                                                 (GBoxedFreeFunc)
                                                 bmp_hal_volume_data_free);
    return our_type;
}

static void
bmp_hal_add_volume (BmpHal	*hal,
		    const gchar	*udi)
{
    BmpHalVolumeData	*v_data;
    LibHalVolume	*hal_volume;
    LibHalDrive		*hal_drive;
    gchar	       **path_elements;

    path_elements = g_strsplit (udi+1, "/", -1);

    if (!g_ascii_strncasecmp (path_elements[4], "volume", strlen("volume")))
      {
			//Houston, we've got a volume

			v_data = g_new0 (BmpHalVolumeData, 1);
			v_data->volume_udi = g_strdup (udi);

			hal_volume = libhal_volume_from_udi (hal->priv->ctx, v_data->volume_udi);

			if (hal_volume)
			  {
			    const char *storage_device_udi;

			    v_data->mount_path = g_strdup (libhal_volume_get_mount_point (hal_volume));

			    //If not mounted, it's pointless, since you can't add music from it then anyway
			    if (!v_data->mount_path)
			      {
				libhal_volume_free (hal_volume);
				g_free (v_data);
				g_strfreev (path_elements);
				return;
			      }

			    v_data->is_disc = libhal_volume_is_disc (hal_volume);

			    storage_device_udi = libhal_volume_get_storage_device_udi (hal_volume);
			    v_data->device_udi = g_strdup (storage_device_udi);

			    hal_drive = libhal_drive_from_udi (hal->priv->ctx, storage_device_udi);
			    v_data->device_serial = g_strdup (libhal_drive_get_serial (hal_drive));

			    libhal_volume_free (hal_volume);
			    libhal_drive_free (hal_drive);
			  }
			else
			  {
			    g_log (G_LOG_DOMAIN, G_LOG_LEVEL_CRITICAL, "%s: Unable to retrieve information from HAL for volume UDI '%s'",
								  G_STRLOC,
								  udi);
			  }

			g_hash_table_insert (hal->priv->volumes, g_strdup (v_data->volume_udi), v_data);
#if 0
			print_bmp_hal_volume_data (v_data);
#endif
			g_signal_emit (G_OBJECT(hal), signals[BMP_HAL_SIGNAL_VOLUME_ADDED], 0);
    }

  g_strfreev (path_elements);

}

static void
hal_device_added (LibHalContext *ctx,
                  const char	*udi)
{
	// BmpHal *hal = BMP_HAL (libhal_ctx_get_user_data (ctx));
}

static void
hal_device_removed (LibHalContext   *ctx,
                    const char	    *udi)
{
	// BmpHal *hal = BMP_HAL (libhal_ctx_get_user_data (ctx));

}

static void
hal_property_modified (LibHalContext	*ctx,
                       const char	*udi,
                       const char	*key,
                       dbus_bool_t       is_removed,
                       dbus_bool_t	 is_added)
{
	BmpHal	  *hal = BMP_HAL (libhal_ctx_get_user_data (ctx));
        // char	  *mounting_udi;
        gboolean   mounted;
        // GSList	  *l, *n;

        if (strcmp (key, "volume.is_mounted") != 0)
                return;

        mounted = libhal_device_get_property_bool (ctx, udi, key, NULL);

        if (mounted)
	  {
	    bmp_hal_add_volume (hal, udi);
	  }
	else
	  {
	    BmpHalVolumeData *v_data;

	    v_data = reinterpret_cast<BmpHalVolumeData*>(g_hash_table_lookup (hal->priv->volumes, udi));

	    if (v_data)
	      {
#if 0
		g_message ("REMOVING:");
		print_bmp_hal_volume_data (v_data);
#endif
		g_hash_table_remove (hal->priv->volumes, udi);
	      }

	    g_signal_emit (G_OBJECT(hal), signals[BMP_HAL_SIGNAL_VOLUME_REMOVED], 0);
	  }
}

static dbus_bool_t
bmp_hal_mainloop_integration (BmpHal	    *hal,
			      LibHalContext *ctx,
			      DBusError	    *error)
{
        hal->priv->dbus_connection = dbus_bus_get (DBUS_BUS_SYSTEM, error);

        if (dbus_error_is_set (error))
	    {
		g_message ("%s: Error connecting to DBus", G_STRLOC);
                return FALSE;
	    }

        dbus_connection_setup_with_g_main (hal->priv->dbus_connection, NULL);
        libhal_ctx_set_dbus_connection (hal->priv->ctx, hal->priv->dbus_connection);

        return TRUE;
}

static gboolean
bmp_do_hal_init (BmpHal *hal)
{
        DBusError     error;
        char	    **devices;
        int	      nr;
	int	      n;

        if (!(hal->priv->ctx = libhal_ctx_new ()))
	    {
                g_message ("%s: Failed to initialize HAL!", G_STRLOC);
                return FALSE;
	    }

        dbus_error_init (&error);
        if (!bmp_hal_mainloop_integration (hal, hal->priv->ctx, &error))
	    {
                g_message ("%s: hal_initialize failed: %s", G_STRLOC, error.message);
                dbus_error_free (&error);
                return FALSE;
	    }

        libhal_ctx_set_device_added (hal->priv->ctx, hal_device_added);
        libhal_ctx_set_device_removed (hal->priv->ctx, hal_device_removed);
#if 0
        libhal_ctx_set_device_new_capability (ctx, hal_device_new_capability);
        libhal_ctx_set_device_lost_capability (ctx, hal_device_lost_capability);
#endif
        libhal_ctx_set_device_property_modified (hal->priv->ctx, hal_property_modified);
#if 0
        libhal_ctx_set_device_condition (ctx, hal_device_condition);
#endif

        if (!libhal_device_property_watch_all (hal->priv->ctx, &error))
	    {
                g_message ("%s: Failed to set up HAL properties watch: %s", G_STRLOC, error.message);
                dbus_error_free (&error);
                libhal_ctx_free (hal->priv->ctx);
                return FALSE;
	    }

	libhal_ctx_set_user_data (hal->priv->ctx, hal);

        if (!libhal_ctx_init (hal->priv->ctx, &error))
	    {
                g_message ("%s: hal_initialize failed: %s", G_STRLOC, error.message);
                dbus_error_free (&error);
                libhal_ctx_free (hal->priv->ctx);

                return FALSE;
	    }

        if (!(devices = libhal_get_all_devices (hal->priv->ctx, &nr, &error)))
	    {
                g_message ("seems that HAL is not running: %s", error.message);
                dbus_error_free (&error);

                libhal_ctx_shutdown (hal->priv->ctx, NULL);
                libhal_ctx_free (hal->priv->ctx);

                return FALSE;
	    }

	//Create an initial list of volumes and their devices
	for (n = 0; n < nr; n++)
	    {
		bmp_hal_add_volume (hal, devices[n]);
	    }

        libhal_free_string_array (devices);

	return TRUE;
}

static gboolean
v_data_for_each (gpointer _k,
		 gpointer _v,
		 gpointer _d)
{
    BmpHalVolumeData *_v_data;

    _v_data = BMP_HAL_VOLUME_DATA(_v);

    if (!g_ascii_strncasecmp ((gchar*)_d, _v_data->mount_path, strlen (_v_data->mount_path)))
      {
	  return TRUE;
      }

    return FALSE;
}

gboolean
bmp_hal_find_volume_data_for_path (BmpHal	     *hal,
				   const gchar	     *path,
				   BmpHalVolumeData **v_data)
{
    BmpHalVolumeData *_v_data;

    if (!hal->priv->initialized) return FALSE;

    _v_data = reinterpret_cast<BmpHalVolumeData*>(g_hash_table_find (hal->priv->volumes,
		       (GHRFunc)v_data_for_each,
		       (gpointer)path)); 

    if (_v_data)
      {
	  *v_data = _v_data;
	  return TRUE;
      }
    else
      {
	  *v_data = NULL;
	  return FALSE;
      }

    g_assert_not_reached ();
}


gboolean
bmp_hal_volume_is_present (BmpHal	*hal,
			   const gchar	*udi)
{
    return (g_hash_table_lookup (hal->priv->volumes, udi) != NULL) ? TRUE : FALSE;
}

static void
bmp_hal_init (BmpHal *hal)
{
    hal->priv = g_new (BmpHalPrivate, 1);
    hal->priv->dispose_has_run = FALSE;
    hal->priv->volumes = g_hash_table_new_full (g_str_hash, g_str_equal, (GDestroyNotify)g_free, (GDestroyNotify)bmp_hal_volume_data_free);
    hal->priv->msg_domain_id =
			     bmp_system_control_message_domain_register (bmp_system_control,
									 "hal",
								         "BMP: Volume/Device Management");

    if (!bmp_do_hal_init (hal))
	{
	    bmp_system_control_message_dispatch (bmp_system_control,
						  hal->priv->msg_domain_id,
						  GTK_MESSAGE_ERROR,
						  _("Volume/Device Management could not be initialized; you will not be able to add items permanently to the library.\n\nPlease check your HAL installation and/or contact your distributor."));
	    hal->priv->initialized = FALSE;
	}
      else
	{
	    hal->priv->initialized = TRUE;
	}
}

static void
bmp_hal_set_property (GObject      *object,
                        guint         property_id,
                        const GValue *value,
                        GParamSpec   *pspec)
{
        switch (property_id)
	    {
		default: break;
	    }
}

static void
bmp_hal_get_property (GObject      *object,
                        guint         property_id,
                        GValue       *value,
                        GParamSpec   *pspec)
{
        switch (property_id)
	{
	    default: break;
        }
}

static GObject *
bmp_hal_constructor (GType                  type,
                       guint                  n_construct_properties,
                       GObjectConstructParam *construct_properties)
{
        GObject *obj;

        {
                /* Invoke parent constructor. */
                BmpHalClass *klass;
                GObjectClass *parent_class;
                klass = BMP_HAL_CLASS (g_type_class_peek (BMP_TYPE_HAL));
                parent_class = G_OBJECT_CLASS (g_type_class_peek_parent (klass));
                obj = parent_class->constructor (type,
                                                 n_construct_properties,
                                                 construct_properties);
        }

        /* do stuff. */

        return obj;
}

static void
bmp_hal_dispose (GObject *obj)
{
        BmpHal *hal = (BmpHal *)obj;
	DBusError error;

        if (hal->priv->dispose_has_run) return;
        hal->priv->dispose_has_run = TRUE;

	dbus_error_init (&error);
	libhal_ctx_shutdown (hal->priv->ctx, &error);
	libhal_ctx_free (hal->priv->ctx);

	dbus_connection_close (hal->priv->dbus_connection);
}

static void
bmp_hal_finalize (GObject *obj)
{
        BmpHal *hal = (BmpHal *)obj;

        g_free (hal->priv);
}


BmpHal*
bmp_hal_new (void)
{
  BmpHal *hal;

  hal = reinterpret_cast<BmpHal*>(g_object_new (bmp_hal_get_type (), NULL));

  return hal;
}


static void
bmp_hal_class_init (BmpHalClass *g_class)
{
        GObjectClass *gobject_class = G_OBJECT_CLASS (g_class);

        gobject_class->set_property = bmp_hal_set_property;
        gobject_class->get_property = bmp_hal_get_property;
        gobject_class->dispose = bmp_hal_dispose;
        gobject_class->finalize = bmp_hal_finalize;
        gobject_class->constructor = bmp_hal_constructor;

    signals[BMP_HAL_SIGNAL_VOLUME_ADDED] =
      g_signal_new ("volume-added",
		    G_OBJECT_CLASS_TYPE (gobject_class),
		    (GSignalFlags)0,
		    G_STRUCT_OFFSET (BmpHalClass, volume_added),
		    NULL, NULL, g_cclosure_marshal_VOID__VOID,
		    G_TYPE_NONE, 0);

    signals[BMP_HAL_SIGNAL_VOLUME_REMOVED] =
      g_signal_new ("volume-removed",
		    G_OBJECT_CLASS_TYPE (gobject_class),
		    (GSignalFlags)0,
		    G_STRUCT_OFFSET (BmpHalClass, volume_removed),
		    NULL, NULL, g_cclosure_marshal_VOID__VOID,
		    G_TYPE_NONE, 0);
}

#if 0
typedef gboolean (* DeviceAddedHandler) (const char *udi, const char *capability);
static  gboolean block_device_added (const char *udi, const char *capability __attribute__((__unused__)));

static struct {
        const char *capability;
        DeviceAddedHandler handler;
} devices[] = {
        { "block",          block_device_added   }
};

inline static int
strptrcmp (const void *strptr0, const void *strptr1) {
        return strcmp (*((const char **) strptr0), *((const char **) strptr1));
}



/*
 * cdrom_policy - There has been a media change event on the CD-ROM
 * associated with the given UDI.  Enforce policy.
 */
static void
cdrom_policy (const char *udi)
{
        char *device = NULL;
        char *drive_udi = NULL;
        dbus_bool_t has_audio;
        dbus_bool_t has_data;
        dbus_bool_t is_blank;
        DBusError error;
        int type;

	g_message (G_STRFUNC);

        dbus_error_init (&error);

        has_audio = libhal_device_get_property_bool (hal_ctx, udi, "volume.disc.has_audio", NULL);
        has_data = libhal_device_get_property_bool (hal_ctx, udi, "volume.disc.has_data", NULL);
        is_blank = libhal_device_get_property_bool (hal_ctx, udi, "volume.disc.is_blank", NULL);
        drive_udi = libhal_device_get_property_string (hal_ctx, udi, "info.parent", NULL);
        device = libhal_device_get_property_string (hal_ctx, udi, "block.device", &error);

        if (!device) {
                g_message ("cannot get block.device: %s", error.message);
                dbus_error_free (&error);
                goto out;
        }

        if (has_audio && !has_data) {
			g_message ("CD is CDDA and has no data");
        } else if (has_audio && has_data) {
			g_message ("CD is CDDA/Mixed-Mode");
        } else if (has_data) {
			g_message ("CD is CDROM");
        } else if (is_blank) {
			g_message ("CD is blank CD-R");
        }

        /** @todo enforce policy for all the new disc types now supported */

 out:

        libhal_free_string (device);
        libhal_free_string (drive_udi);
}

/*
 * gvm_media_changed - generic media change handler.
 *
 * This is called on a UDI and the media's parent device in response to a media
 * change event.  We have to decipher the storage media type to run the
 * appropriate media-present check.  Then, if there is indeed media in the
 * drive, we enforce the appropriate policy.
 *
 * At the moment, we only handle CD-ROM and DVD drives.
 *
 * Returns TRUE if the device was handled or FALSE otherwise
 */
static gboolean
media_changed (const char *udi, const char *storage_device)
{
        gboolean handled = FALSE;
        char *media_type;
        DBusError error;

	g_message (G_STRFUNC);

        /* Refuse to enforce policy on removable media if drive is locked */
        dbus_error_init (&error);
        if (libhal_device_property_exists (hal_ctx, storage_device, "info.locked", NULL)
            && libhal_device_get_property_bool (hal_ctx, storage_device, "info.locked", NULL)) {
                g_message ("Drive with udi %s is locked through hal; skipping policy\n", storage_device);
                /* we return TRUE here because the device is locked - we can pretend we handled it */
                return TRUE;
        }

        /*
         * Get HAL's interpretation of our media type.  Note that we must check
         * the storage device and not hal UDI
         */
        if (!(media_type = libhal_device_get_property_string (hal_ctx, storage_device, "storage.drive_type", &error))) {
                g_message ("cannot get storage.drive_type: %s", error.message);
                dbus_error_free (&error);

                /* FIXME: should we really return TRUE here? not sure... need a test case */

                return TRUE;
        }

        if (!strcmp (media_type, "cdrom")) {
                cdrom_policy (udi);
                handled = TRUE;
        }

        libhal_free_string (media_type);

        return handled;
}


static gboolean
block_device_added (const char *udi, const char *capability __attribute__((__unused__)))
{
        char *fsusage = NULL, *device = NULL, *storage_device = NULL;
        DBusError error;
        int mountable;

	g_message (G_STRFUNC);

        dbus_error_init (&error);

        /* is hal a mountable volume? */
        if (!(mountable = libhal_device_get_property_bool (hal_ctx, udi, "block.is_volume", NULL))) {
                g_message ("not a mountable volume: %s\n", udi);
                goto out;
        }

        /* if it is a volume, it must have a device node */
        if (!(device = libhal_device_get_property_string (hal_ctx, udi, "block.device", &error))) {
                g_message ("cannot get block.device: %s\n", error.message);
                goto out;
        }

        if (mountable) {
                /* only mount if the block device has a sensible filesystem */
                fsusage = libhal_device_get_property_string (hal_ctx, udi, "volume.fsusage", &error);
                if (!fsusage || strcmp (fsusage, "filesystem") != 0) {
                        g_message ("no sensible filesystem for %s\n", udi);
                        mountable = FALSE;
                }
        }

        /* get the backing storage device */
        if (!(storage_device = libhal_device_get_property_string (hal_ctx, udi, "block.storage_device", &error))) {
                g_message ("cannot get block.storage_device: %s\n", error.message);
                goto out;
        }

        /*
         * Does hal device support removable media?  Note that we
         * check storage_device and not our own UDI
         */
        if (libhal_device_get_property_bool (hal_ctx, storage_device, "storage.removable", NULL)) {
                /* we handle media change events separately */
                g_message ("Changed: %s\n", device);
                if (media_changed (udi, storage_device))
                        goto out;
        }

#if 0
        if (config.automount_drives && mountable) {
                if (!gvm_udi_is_subfs_mount (udi)) {
                        if (gvm_automount_enabled (udi)) {
                                gvm_device_mount (udi, device, NULL);
                        } else {
                                dbg ("storage.automount_enabled_hint set to false on %s, not mounting\n", udi);
                        }
                }
        }
#endif

out:

        if (dbus_error_is_set (&error))
                dbus_error_free (&error);

        libhal_free_string (device);
        libhal_free_string (fsusage);
        libhal_free_string (storage_device);

        return TRUE;
}

/** Invoked when a device in the GDL emits a condition that cannot be
 *  expressed in a property (like when the processor is overheating)
 *
 *  @param  ctx                 LibHal context
 *  @param  udi                 Univerisal Device Id
 *  @param  condition_name      Name of condition
 *  @param  message             D-BUS message with parameters
 */
static void
hal_device_condition (LibHalContext *ctx __attribute__((__unused__)),
                      const char *udi __attribute__((__unused__)),
                      const char *condition_name __attribute__((__unused__)),
                      const char *condition_detail __attribute__((__unused__)))
{
}

static void
hal_device_new_capability (LibHalContext *ctx __attribute__((__unused__)),
                           const char *udi __attribute__((__unused__)),
                           const char *capability __attribute__((__unused__)))
{
}

/** Invoked when device in the Global Device List loses a capability.
 *
 *  @param  ctx                 LibHal context
 *  @param  udi                 Universal Device Id
 *  @param  capability          Name of capability
 */
static void
hal_device_lost_capability (LibHalContext *ctx __attribute__((__unused__)),
                            const char *udi __attribute__((__unused__)),
                            const char *capability __attribute__((__unused__)))
{
	g_message (G_STRFUNC);
}
#endif


