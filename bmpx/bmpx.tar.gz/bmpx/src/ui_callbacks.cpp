/*  BMPx - The Dumb Music Player
 *  Copyright (C) 2005 BMPx development team.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 *  $Id$
 *
 * The BMPx project hereby grant permission for non-gpl compatible GStreamer
 * plugins to be used and distributed together with GStreamer and BMPx. This
 * permission are above and beyond the permissions granted by the GPL license
 * BMPx is covered by.
 */

#include <config.h>

#include <cstring>
#include <string>

#include <gdk/gdkkeysyms.h>
#include <glib/gi18n.h>
#include <gtk/gtk.h>
#include <glade/glade.h>

#include <bmp/widgets/bmp_window.h>
#include <bmp/widgets/bmp_slider.h>

#include <bmp/playlist.hpp>
#include <bmp/util.h>
#include <bmp/uri++.hpp>
#include <bmp/vfs.hpp>

#include <chroma/chroma-list.h>
#include <chroma/chroma-list-selection.h>

#include <musicbrainz/mb_c.h>
#include <goa/libgoa.h>

#include "ui.hpp"
#include "ui_playlist.hpp"

#include "ui_dialog_about.hpp"
#include "ui_util.hpp"

#include "trackinfo.hpp"
#include "preferences.hpp"

#include "glade.hpp"
#include "loader.hpp"
#include "resource_manager.hpp"
#include "system_control.hpp"
#include "main.hpp"

#include "embedded-images/media-pixbufs.h"

// TODO: Remove when everything is moved into the Bmp namespace
using namespace Bmp;

void
bmp_ui_callback_mute  (GtkAction *action, gpointer data)
{
// 	gboolean active = gtk_toggle_action_get_active(GTK_TOGGLE_ACTION(action));
// 	g_object_set (bmp_play_engine, "mute", active, NULL);
}


void
bmp_ui_callback_about (GtkAction *action, gpointer data)
{
    bmp_ui_about_show (bmp_ui);
}

void
bmp_ui_trackinfo_clear (void)
{
    Bmp::TrackInfo *trackinfo;

    trackinfo = reinterpret_cast<Bmp::TrackInfo*>(RM_GET_ITEM("dialogs", "dialog-trackinfo", NOLOCK));
    trackinfo->clear ();
}

void
bmp_ui_callback_trackinfo (GtkAction *action, gpointer data)
{
    Bmp::TrackInfo *trackinfo;
    GtkListStore   *list;
    GtkTreeIter     iter;
    GtkTreePath	   *path;
    char	   *uri;

    path = chroma_list_selection_get_selected (CHROMA_LIST_SELECTION(c_tracklist));
    if (!path) return;

    list = bmp_playlist_get_playlist (bmp_playlist);
    gtk_tree_model_get_iter (GTK_TREE_MODEL(list), &iter, static_cast<GtkTreePath *>(path));
    gtk_tree_model_get (GTK_TREE_MODEL(list), &iter, COLUMN_URI, &uri, -1);
    gtk_tree_path_free (path);

    trackinfo = reinterpret_cast<Bmp::TrackInfo*>(RM_GET_ITEM("dialogs", "dialog-trackinfo", NOLOCK));
    trackinfo->show (uri);
    free (uri);
}

void
bmp_ui_callback_quit (GtkAction *action, gpointer data)
{
    bmp_system_control_quit (bmp_system_control, NULL);
}


void
bmp_ui_callback_quit_title (GtkAction *action, gpointer data)
{
#if 0
    if (g_object_get_boolean (bmp_ui, "trayicon-embedded"))
      {
	  GtkToggleAction *action = GTK_TOGGLE_ACTION(gtk_action_group_get_action (bmp_toggle_actions, BMP_TOGGLE_ACTION_SHOW_UI));
	  g_message ("Hiding UI");
	  gtk_toggle_action_set_active (action, FALSE);
      }
    else
      {
	  g_message ("Exiting");
	  bmp_system_control_quit (bmp_system_control);
      }
#endif
    bmp_system_control_quit (bmp_system_control, NULL);
}


void
bmp_ui_callback_clear_playback_history (GtkAction *action, gpointer data)
{
    bmp_system_control_clear_playback_history (bmp_system_control, NULL);
    gtk_action_set_sensitive (gtk_action_group_get_action(bmp_actions, BMP_ACTION_CLEAR_PLAYBACK_HISTORY), FALSE);
}


void
bmp_ui_callback_iconify (GtkAction *action, gpointer data)
{
    if (mcs->key_get<bool>("bmp", "ui-esc-trayconify"))
    {
        GtkToggleAction *action;

        action = GTK_TOGGLE_ACTION (gtk_action_group_get_action (bmp_toggle_actions, BMP_TOGGLE_ACTION_SHOW_UI));
        gtk_toggle_action_set_active (action, FALSE);
    }
    else
    {
        BmpWindowMain *window_main;

        window_main = BMP_WINDOW_MAIN (RM_GET_ITEM("windows", "window-main", NOLOCK));
        gtk_window_iconify (GTK_WINDOW (window_main->window));
    }
}


void
bmp_ui_callback_play (GtkAction *action, gpointer data)
{
	bmp_system_control_play	      (bmp_system_control, NULL);
}


void
bmp_ui_callback_pause (GtkAction *action, gpointer data)
{
	bmp_system_control_pause (bmp_system_control, NULL);
}


void
bmp_ui_callback_stop (GtkAction *action, gpointer data)
{
	bmp_system_control_stop  (bmp_system_control, NULL);
}


void
bmp_ui_callback_next (GtkAction *action, gpointer data)
{
	bmp_system_control_go_next  (bmp_system_control, NULL);
}


void
bmp_ui_callback_prev (GtkAction *action, gpointer data)
{
	bmp_system_control_go_prev  (bmp_system_control, NULL);
}


void
bmp_ui_callback_toggle_shuffle (GtkAction *action, gpointer data)
{
  if (gtk_toggle_action_get_active(GTK_TOGGLE_ACTION(action)))
    {
      bmp_system_control_shuffle_set (bmp_system_control, TRUE, NULL);
    }
  else
    {
      bmp_system_control_shuffle_set (bmp_system_control, FALSE, NULL);
    }
}


void
bmp_ui_callback_toggle_repeat (GtkAction *action, gpointer data)
{

 if (gtk_toggle_action_get_active(GTK_TOGGLE_ACTION(action)))
   {
      bmp_system_control_repeat_set (bmp_system_control, TRUE, NULL);
   }
  else
   {
      bmp_system_control_repeat_set (bmp_system_control, FALSE, NULL);
   }

}

void
bmp_ui_callback_toggle_pl (GtkAction *action, gpointer data)
{
    BmpWindowPlaylist *window_playlist;
    static gint x = -1, y = -1;

    window_playlist = BMP_WINDOW_PLAYLIST (RM_GET_ITEM("windows", "window-playlist", NOLOCK));

    if (!gtk_toggle_action_get_active(GTK_TOGGLE_ACTION(action)))
      {
	gtk_window_get_position (GTK_WINDOW(window_playlist->window), &x, &y);
	gtk_widget_hide (window_playlist->window);
      }
    else if ((window_playlist) && GTK_WIDGET_REALIZED(window_playlist->window))
      {
	g_object_set_data (reinterpret_cast<GObject*>(window_playlist), "shown", GINT_TO_POINTER(1));
	gtk_widget_show_all (window_playlist->window);
	gtk_window_present (GTK_WINDOW(window_playlist->window));
	if (x > 0)
	  {
	    gtk_window_move (GTK_WINDOW(window_playlist->window), x, y);
	  }
      }
}

#if 0

void
bmp_ui_callback_seek_moved (GtkWidget *widget, gpointer data)
{
    BmpWindowMain *window_main;
    gdouble position = bmp_slider_get_position (BMP_SLIDER(widget));

    window_main = RM_GET_ITEM("windows", "window-main", NOLOCK);

    bmp_window_main_set_seek_request (window_main, position);
    bmp_system_control_seek_percent (bmp_system_control, position, NULL);
}
#endif


void
bmp_ui_callback_seek_moved (GtkWidget *widget, gpointer data)
{
    BmpWindowMain *window_main;
    gint m, s, p;

    window_main = BMP_WINDOW_MAIN (RM_GET_ITEM("windows", "window-main", NOLOCK));
    bmp_window_main_get_seek_time (window_main, &m, &s);

    p = (m*60)+s;

    bmp_system_control_seek (bmp_system_control, p, NULL);
}


void
bmp_ui_callback_volume_moved(GtkWidget *widget, gpointer data)
{
    int volume;

    volume = int (bmp_slider_get_position(BMP_SLIDER(widget)));
    bmp_system_control_volume_set (bmp_system_control, volume, NULL);
}


void
bmp_ui_callback_balance_moved(GtkWidget *widget, gpointer data)
{
#if 0
    gint position = bmp_slider_get_position(BMP_SLIDER(widget));
#endif
}

/* FIXME: Make system control methods */
static gboolean
audio_files_filter (const GtkFileFilterInfo *filter_info,
		    gpointer                 data)
{
	if (bmp_play_engine->is_audio_file(filter_info->uri)) return TRUE;

	return FALSE;
}

static void
_filebrowser_play (GtkWidget *widget, GtkFileChooser *chooser)
{
    BmpWindowPlaylist *window_playlist;
    GSList *filenames;
    gchar **uri_list;
    gint new_ctr = 0;

    window_playlist = BMP_WINDOW_PLAYLIST (RM_GET_ITEM("windows", "window-playlist", NOLOCK));
    filenames = gtk_file_chooser_get_uris (GTK_FILE_CHOOSER(chooser));

    bmp_window_set_busy (GTK_WIDGET(chooser));

    mcs->key_set<std::string>(
		    "bmp",
		    "file-chooser-path",
		    gtk_file_chooser_get_current_folder (GTK_FILE_CHOOSER(chooser)));

    if (filenames)
      {
	uri_list = gslist_to_strv (filenames);
	bmp_system_control_add_uri_list (bmp_system_control,
					 (const gchar**)uri_list,
					  -1,
					  TRUE,
					  TRUE,
					  0,
					  &new_ctr,
					  NULL);
	gtk_file_chooser_unselect_all (GTK_FILE_CHOOSER(chooser));
      }

    bmp_window_set_busy (GTK_WIDGET(chooser));
}
static void
_filebrowser_add (GtkWidget *widget, GtkFileChooser *chooser)
{
    BmpWindowPlaylist *window_playlist;
    GSList *filenames;
    gchar **uri_list;
    gint new_ctr = 0;

    window_playlist = BMP_WINDOW_PLAYLIST (RM_GET_ITEM("windows", "window-playlist", NOLOCK));
    filenames =
	gtk_file_chooser_get_uris (GTK_FILE_CHOOSER(chooser));

    bmp_window_set_busy (GTK_WIDGET(chooser));

    mcs->key_set<std::string>(
		    "bmp",
		    "file-chooser-path",
		    gtk_file_chooser_get_current_folder (GTK_FILE_CHOOSER(chooser)));

    if (filenames)
      {
	uri_list = gslist_to_strv (filenames);

	bmp_system_control_add_uri_list (bmp_system_control,
					 (const gchar**)uri_list,
					 -1,
					  FALSE,
					  FALSE,
					  0,
					  &new_ctr,
					  NULL);

	gtk_file_chooser_unselect_all (GTK_FILE_CHOOSER(chooser));
	/* FIXME: Free GSlist */
      }

    bmp_window_set_idle (GTK_WIDGET(chooser));
}

static void
_filebrowser_do_hide_open (GtkWidget *w1, GtkWidget *w2)
{
    if (mcs->key_get<bool>("bmp", "file-chooser-close-on-open"))
	gtk_widget_hide (w2);
}

static void
_filebrowser_do_hide_add (GtkWidget *w1, GtkWidget *w2)
{
    if (mcs->key_get<bool>("bmp", "file-chooser-close-on-add"))
	gtk_widget_hide (w2);
}

static void
_filebrowser_check_hide_open (GtkToggleButton *button, gpointer user_data)
{
    mcs->key_set<bool>("bmp", "file-chooser-close-on-open", gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(button)));
}
static void
_filebrowser_check_hide_add (GtkToggleButton *button, gpointer user_data)
{
    mcs->key_set<bool>("bmp", "file-chooser-close-on-add",  gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(button)));
}

static void
_filebrowser_save_path (GtkButton *button, GtkFileChooser *chooser) {
    mcs->key_set<std::string>("bmp", "file-chooser-path", gtk_file_chooser_get_current_folder (GTK_FILE_CHOOSER(chooser)));
}

static gboolean
on_filebrowser_key_press_event_cb (GtkWidget	    *widget,
				   GdkEventKey	    *event,
				   gpointer	     useless_data)
{

    if (event->keyval == GDK_Escape)
	{
	    gtk_widget_hide (widget);
	    return TRUE;
	}

    return FALSE;
}


void
run_filebrowser(gboolean play_button)
{
    static GladeXML *xml = NULL;
    static GtkWidget *dialog = NULL;
    static GtkWidget *chooser = NULL;

    static GtkWidget *button_add, *button_close;
    static GtkWidget *button_select_all, *button_deselect_all;
    static GtkWidget *toggle;

    static GtkFileFilter *file_filter, *audio_filter;

    static gulong handlerid, handlerid_check, handlerid_do;
    static gulong handlerid_activate, handlerid_do_activate;

    typedef struct {
	const char *name;
	const char *glob;
    } FileFilter;

    static FileFilter filter_list[] = {
      { "FLAC", "*.[fF][lL][aA][cC]" },
      { "M4A" , "*.[mM]4[aA]" },
      { "MP3" , "*.[mM][pP]3" },
      { "MPC" , "*.[mM][pP][cC]" },
      { "OGG" , "*.[oO][gG][gG]" },
      { "WMA" , "*.[wW][mM][aA]" }
    };

    if (!xml)
      {
        GtkWidget *alignment;

        xml =
	    glade_xml_new_or_die("Add/Open Files dialog",
                                   DATA_DIR "/glade/dialog_add_files.glade",
                                   NULL, NULL);
        glade_xml_signal_autoconnect(xml);

        dialog = glade_xml_get_widget(xml, "add_files_dialog");
	gtk_window_set_type_hint (GTK_WINDOW(dialog), GDK_WINDOW_TYPE_HINT_DIALOG);

	g_signal_connect (G_OBJECT(dialog),
			  "key-press-event",
			  G_CALLBACK(on_filebrowser_key_press_event_cb),
			  NULL);


        chooser = gtk_file_chooser_widget_new(GTK_FILE_CHOOSER_ACTION_OPEN);
        gtk_file_chooser_set_select_multiple(GTK_FILE_CHOOSER(chooser), TRUE);

	/* Set Path */
	gtk_file_chooser_set_current_folder (GTK_FILE_CHOOSER(chooser), mcs->key_get<std::string>("bmp", "file-chooser-path") . c_str ());

	/* Add File Filters */
	file_filter = gtk_file_filter_new();
	gtk_file_filter_set_name (file_filter, _("All Files"));
	gtk_file_filter_add_pattern(file_filter, "*");
	gtk_file_chooser_add_filter (GTK_FILE_CHOOSER(chooser), file_filter);

	audio_filter = gtk_file_filter_new();
	gtk_file_filter_set_name (audio_filter, _("Audio Files"));
        gtk_file_filter_add_custom (audio_filter, GTK_FILE_FILTER_URI, audio_files_filter, NULL, NULL);
	gtk_file_chooser_add_filter (GTK_FILE_CHOOSER(chooser), audio_filter);

        Bmp::VFS::ExportDataList containers;
	vfs->get_containers (containers);

        for (Bmp::VFS::ExportDataList::const_iterator container = containers.begin ();
             container != containers.end ();
             container++)
	  {
            std::string glob = Util::create_glob (container->extension);
            std::string glob_suffix = std::string ("*.") + glob;

	    file_filter = gtk_file_filter_new();
	    gtk_file_filter_set_name (file_filter, container->description.c_str ());
	    gtk_file_filter_add_pattern(file_filter, glob_suffix.c_str ());
	    gtk_file_chooser_add_filter (GTK_FILE_CHOOSER(chooser), file_filter);
	  }

      for (unsigned int n = 0; n < G_N_ELEMENTS(filter_list); n++)
	{
	  file_filter = gtk_file_filter_new ();
	  gtk_file_filter_set_name (file_filter, filter_list[n].name);
	  gtk_file_filter_add_pattern (file_filter, filter_list[n].glob);
	  gtk_file_chooser_add_filter (GTK_FILE_CHOOSER(chooser), file_filter);
	}

	gtk_file_chooser_set_filter (GTK_FILE_CHOOSER(chooser), audio_filter);
        alignment = glade_xml_get_widget(xml, "alignment2");
        gtk_container_add(GTK_CONTAINER(alignment), chooser);

        toggle =
	    glade_xml_get_widget(xml, "close_on_action");
        button_select_all =
	    glade_xml_get_widget(xml, "select_all");
        button_deselect_all =
	    glade_xml_get_widget (xml, "deselect_all");
        button_add =
	    glade_xml_get_widget (xml, "action");
	button_close =
	    glade_xml_get_widget (xml, "close");

        g_signal_connect_swapped (button_select_all, "clicked",
                                 G_CALLBACK(gtk_file_chooser_select_all),
                                 chooser);

        g_signal_connect_swapped (button_deselect_all, "clicked",
                                 G_CALLBACK(gtk_file_chooser_unselect_all),
                                 chooser);

        g_signal_connect (button_close, "clicked",
                                 G_CALLBACK(_filebrowser_save_path),
                                 chooser);

        g_signal_connect_swapped (button_close, "clicked",
                                 G_CALLBACK(gtk_widget_hide),
                                 dialog);

        g_signal_connect (dialog, "key_press_event",
                         G_CALLBACK(on_filebrowser_key_press_event_cb),
                         NULL);
      }
    else
      {
        g_signal_handler_disconnect(button_add, handlerid);
        g_signal_handler_disconnect(toggle,	handlerid_check);
        g_signal_handler_disconnect(chooser,	handlerid_activate);
        g_signal_handler_disconnect(button_add, handlerid_do);
        g_signal_handler_disconnect(chooser,	handlerid_do_activate);
	gtk_file_chooser_set_current_folder (GTK_FILE_CHOOSER(chooser), mcs->key_get<std::string>("bmp", "file-chooser-path") . c_str ());
      }

    gtk_widget_show_all(dialog);
    gtk_window_set_keep_above (GTK_WINDOW(dialog), mcs->key_get<bool>("bmp", "keep-above"));

    if (play_button)
      {
        gtk_window_set_title(GTK_WINDOW(dialog), _("Open Files - BMP"));
        gtk_button_set_label(GTK_BUTTON(button_add), GTK_STOCK_OPEN);
        gtk_button_set_label(GTK_BUTTON(toggle), _("Close dialog on Open"));

        gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(toggle), mcs->key_get<bool>("bmp", "file-chooser-close-on-open"));

        handlerid_check =
	    g_signal_connect(toggle,
			"toggled",
			G_CALLBACK(_filebrowser_check_hide_open),
			NULL);

        handlerid =
	    g_signal_connect(button_add,
			"clicked",
			G_CALLBACK(_filebrowser_play),
			chooser);

        handlerid_do =
	    g_signal_connect_after(button_add,
			"clicked",
			G_CALLBACK(_filebrowser_do_hide_open),
			dialog);

        handlerid_activate =
	    g_signal_connect(chooser,
			"file-activated",
			G_CALLBACK(_filebrowser_play),
			chooser);

        handlerid_do_activate =
	    g_signal_connect_after(chooser,
			"file-activated",
			G_CALLBACK(_filebrowser_do_hide_open),
			dialog);

      }
    else
      {
        gtk_window_set_title(GTK_WINDOW(dialog), _("Add Files - BMP"));
        gtk_button_set_label(GTK_BUTTON(button_add), GTK_STOCK_ADD);
        gtk_button_set_label(GTK_BUTTON(toggle), _("Close dialog on Add"));

        gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(toggle), mcs->key_get<bool>("bmp", "file-chooser-close-on-add"));

        handlerid_check =
	    g_signal_connect(toggle,
			"toggled",
			G_CALLBACK(_filebrowser_check_hide_add),
			NULL);

        handlerid =
	    g_signal_connect(button_add,
			"clicked",
			G_CALLBACK(_filebrowser_add),
			chooser);

        handlerid_do =
	    g_signal_connect_after(button_add,
			"clicked",
			G_CALLBACK(_filebrowser_do_hide_add),
			dialog);

        handlerid_activate =
	    g_signal_connect(chooser,
			"file-activated",
			G_CALLBACK(_filebrowser_add),
			chooser);

        handlerid_do_activate =
	    g_signal_connect_after(chooser,
			"file-activated",
			G_CALLBACK(_filebrowser_do_hide_add),
			dialog);

      }

    gtk_window_present(GTK_WINDOW(dialog));
}


void
bmp_ui_callback_add_files (GtkAction *action, gpointer data)
{
    run_filebrowser (FALSE);
}


void
bmp_ui_callback_open_files (GtkAction *action, gpointer data)
{
    run_filebrowser (TRUE);
}

static gboolean
get_cdinfo (gchar **cdindex, gint *n_tracks)
{
  musicbrainz_t o;

  char error[256], data[256];
  int  ret;

  // Create the musicbrainz object, which will be needed for subsequent calls
  o = mb_New();

  mb_UseUTF8(o, 1);

  ret = mb_Query (o, MBQ_GetCDTOC);
  if (!ret)
    {
        mb_GetQueryError(o, error, 256);
        g_message("%s: Query failed: %s", G_STRLOC, error);
        mb_Delete(o);
        return FALSE;
    }

  ret = mb_GetResultData(o, MBE_TOCGetCDIndexId, data, 256);
  if (!ret)
      {
        mb_GetQueryError(o, error, 256);
        g_message ("%s: Query failed: %s", G_STRLOC, error);
        mb_Delete(o);
        return FALSE;
      }

  *cdindex = g_strdup(data);
  *n_tracks = mb_GetResultInt (o, MBE_TOCGetLastTrack);

  mb_Delete (o);

  return TRUE;
}


void
bmp_ui_callback_add_cd (GtkAction *action, gpointer user_data)
{
    char	      **uri_strv;
    int			n,
			n_tracks,
		        out;
    char	       *cdindex;

    if (!get_cdinfo(&cdindex, &n_tracks)) return;

    uri_strv = g_new0 (gchar*, n_tracks+1);
    library->cache_audiocd (std::string(cdindex));
    for (n = 1; n <= n_tracks; n++)
      {
	uri_strv[n-1] = g_strdup_printf ("cdda://%s/%d", cdindex, n);
      }
    uri_strv[n_tracks] = NULL;
    bmp_system_control_add_uri_list (bmp_system_control,
				     (const gchar**)uri_strv,
				     -1,
				     false,
				     false,
				     0,
				     &out,
				     NULL);
    // g_strfreev (uri_strv);
}


void
bmp_ui_callback_del_files (GtkAction *action, gpointer data)
{
    chroma_list_selection_remove_selected (CHROMA_LIST_SELECTION(c_tracklist));
    chroma_list_refresh (CHROMA_LIST(c_tracklist));
    bmp_system_control_update_title (bmp_system_control);
}

void
bmp_ui_callback_crop_files (GtkAction *action, gpointer data)
{
//    bmp_playlist_tracklist_remove_unselected (bmp_playlist);
}

void
bmp_ui_callback_del_files_all (GtkAction *action, gpointer data)
{
    bmp_system_control_clear_tracklist (bmp_system_control, NULL);
    gtk_action_set_sensitive (gtk_action_group_get_action(bmp_actions, BMP_ACTION_CLEAR_PLAYBACK_HISTORY), FALSE);
    bmp_ui_trackinfo_clear ();
}

void
bmp_ui_callback_select_all_files (GtkAction *action, gpointer data)
{
    chroma_list_selection_select_all (CHROMA_LIST_SELECTION(c_tracklist));
}

void
bmp_ui_callback_unselect_all_files (GtkAction *action, gpointer data)
{
    chroma_list_selection_unselect_all (CHROMA_LIST_SELECTION(c_tracklist));
}

void
bmp_ui_callback_invert_selection (GtkAction *action, gpointer data)
{
}


void
bmp_ui_callback_sort_current_list (GtkAction *action, gpointer data)
{
}


void
bmp_ui_callback_sort_current_list_artist (GtkAction *action, gpointer data)
{
}


void
bmp_ui_callback_sort_current_list_album (GtkAction *action, gpointer data)
{
}


void
bmp_ui_callback_sort_current_list_title (GtkAction *action, gpointer data)
{
}


void
bmp_ui_callback_sort_current_list_genre (GtkAction *action, gpointer data)
{
}


void
bmp_ui_callback_sort_current_list_track (GtkAction *action, gpointer data)
{
}


void
bmp_ui_callback_sort_current_list_location (GtkAction *action, gpointer data)
{
}

#if 0
static void
run_predicated_filtering (gboolean keep, BmpMetadatumId metadatum_id)
{
    BmpFileItem *item;
    gint	 _idx_item;
    GList	*paths = NULL;

    paths = chroma_list_get_selected_paths (CHROMA_LIST(chroma_widgets[BMP_CHROMA_LIST_TRACKLIST]->widget));

    if (!paths) return;
    if (g_list_length (paths) > 1)
      {
	gtk_tree_path_free (paths->data);
	return;
      }

    _idx_item =
	gtk_tree_path_get_indices(paths->data)[0];
    item =
	bmp_playlist_tracklist_get_item (bmp_playlist, _idx_item);

    if (keep)
      bmp_playlist_tracklist_keep_predicated (bmp_playlist,
					      item->tuple,
					      metadatum_id);
    else
      bmp_playlist_tracklist_remove_predicated (bmp_playlist,
					        item->tuple,
					        metadatum_id);

}
#endif


void
bmp_ui_callback_remove_artist (GtkAction *action, gpointer data)
{
//    run_predicated_filtering (FALSE, BMP_DATUM_ARTIST);
}


void
bmp_ui_callback_keep_artist (GtkAction *action, gpointer data)
{
//    run_predicated_filtering (TRUE, BMP_DATUM_ARTIST);
}


void
bmp_ui_callback_remove_album (GtkAction *action, gpointer data)
{
//    run_predicated_filtering (FALSE, BMP_DATUM_ALBUM);
}


void
bmp_ui_callback_keep_album (GtkAction *action, gpointer data)
{
//    run_predicated_filtering (TRUE, BMP_DATUM_ALBUM);
}


void
bmp_ui_callback_stop_after_current_track (GtkAction *action, gpointer data)
{
    gboolean active;

    active = gtk_toggle_action_get_active (GTK_TOGGLE_ACTION(action));
    bmp_system_control_stop_after_current_set (bmp_system_control, active, NULL);
}

static gboolean
export_select_path (GtkWidget *button, gpointer data)
{
    GladeXML *xml = (GladeXML*)data;
    GtkFileChooserDialog *dialog = GTK_FILE_CHOOSER_DIALOG(glade_xml_get_widget_warn (xml, "fc_dialog"));
    GtkWidget *widget;
    gint rv = 0;

    gtk_widget_realize (GTK_WIDGET(dialog));

    widget = glade_xml_get_widget_warn (xml, "entry_filename");
    if (std::strlen(gtk_entry_get_text (GTK_ENTRY(widget)))>0)
      {
	gchar *basename, *folder;

	basename = g_path_get_basename (gtk_entry_get_text (GTK_ENTRY(widget)));
	folder = g_path_get_dirname (gtk_entry_get_text (GTK_ENTRY(widget)));

	gtk_file_chooser_set_current_folder (GTK_FILE_CHOOSER(dialog), folder);
	gtk_file_chooser_set_current_name (GTK_FILE_CHOOSER(dialog), basename);

	g_free (basename);
	g_free (folder);
      }

    rv = gtk_dialog_run (GTK_DIALOG(dialog));

    switch (rv)
      {
	case GTK_RESPONSE_CANCEL:
	  {
	  }
	break;

	case GTK_RESPONSE_OK:
	  {
	    gchar *filename;
	    filename = gtk_file_chooser_get_filename (GTK_FILE_CHOOSER(dialog));
	    gtk_entry_set_text (GTK_ENTRY(widget), filename);
	    g_free (filename);
	  }
      }

    gtk_widget_hide (GTK_WIDGET(dialog));

    return FALSE;
}

static void
export_tree_view_cursor_changed (GtkTreeView *tree_view,
				 gpointer user_data)
{
  GtkTreeSelection *selection;
  GtkTreeModel *model;
  GtkTreeIter iter;
  GtkWidget *entry;
  GString *result;
  GladeXML *xml = (GladeXML*)user_data;
  gchar *composited = NULL, *suffix = NULL;
  gint position;

  selection =
      gtk_tree_view_get_selection (tree_view);
  entry =
      glade_xml_get_widget_warn (xml, "entry_filename");
  result =
      g_string_new (gtk_entry_get_text (GTK_ENTRY(entry)));

  position = std::strlen (result->str)-1;

  while ( (result->str[position] != '.') && position >= 0)
    {
      position--;
    }

  if (position != 0)
      g_string_truncate (result, position);

  gtk_tree_selection_get_selected (selection, &model, &iter);
  gtk_tree_model_get (model, &iter, 1, &suffix, -1);
  composited = g_strconcat (result->str, ".", suffix, NULL);

  gtk_entry_set_text (GTK_ENTRY(entry), composited);
}


void
bmp_ui_callback_export_tracklist (GtkAction *action, gpointer data)
{
  static GladeXML  *xml = NULL;
  static GtkWidget *dialog_window = NULL;

  GtkWidget	   *treeview_plugins, *entry_filename;
  GtkTreeSelection *selection;
  GtkTreeModel	   *store;
  GtkTreeIter	    iter;
  gchar		   *listname = NULL, *suffix = NULL, *suffix_fq = NULL;
  gint		    rv = 0;

  const gchar	   *glade_file = DATA_DIR "/glade/dialog_export_tracklist.glade";

   if (!dialog_window)
    {
	GtkListStore	   *store = NULL;
	GtkTreeViewColumn  *column = NULL;
	GtkCellRenderer    *renderer = NULL;
	GtkTreeIter	    iter;

	xml =
	    glade_xml_new_or_die("Dialog", glade_file, NULL, NULL);

        treeview_plugins = glade_xml_get_widget(xml, "treeview_plugins");
        entry_filename = glade_xml_get_widget_warn (xml, "entry_filename");

	dialog_window =
	    glade_xml_get_widget(xml, "export_dialog");
	column =
	    gtk_tree_view_column_new ();
	renderer =
	    gtk_cell_renderer_text_new ();

	/* Set icon to window */
	bmp_window_set_icon_list (GTK_WIDGET(dialog_window), "player");

	gtk_tree_view_column_pack_start
		(column,
		 renderer,
		 FALSE);

	gtk_tree_view_column_set_attributes
		(column,
		 renderer,
		 "text",
		  0,
		  NULL);

	gtk_tree_view_column_set_expand
		(column,
		 FALSE);

	gtk_tree_view_column_set_title
		(column,
		 N_("Export Plugin"));

	gtk_tree_view_append_column
		(GTK_TREE_VIEW (treeview_plugins),
		 GTK_TREE_VIEW_COLUMN (column));

        store = gtk_list_store_new (3, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);

        Bmp::VFS::ExportDataList containers;
	vfs->get_containers (containers);

        for (Bmp::VFS::ExportDataList::const_iterator container = containers.begin ();
             container != containers.end ();
             container++)
	  {
            gtk_list_store_append (GTK_LIST_STORE(store), &iter);
            gtk_list_store_set (GTK_LIST_STORE(store), &iter,
                                0, container->description.c_str (),
                                1, container->extension.c_str (),
                                2, container->extension.c_str (),
                                -1);
          }

	gtk_tree_view_set_model (GTK_TREE_VIEW(treeview_plugins), GTK_TREE_MODEL(store));
	gtk_widget_realize (dialog_window);
	g_object_connect (G_OBJECT(glade_xml_get_widget_warn(xml, "button_browse")), "signal::clicked", export_select_path, xml, NULL);
	g_object_connect (G_OBJECT(treeview_plugins), "signal::cursor-changed", export_tree_view_cursor_changed, xml, NULL);
    }
  else
    {
      treeview_plugins = glade_xml_get_widget(xml, "treeview_plugins");
      entry_filename = glade_xml_get_widget_warn (xml, "entry_filename");

      store = gtk_tree_view_get_model (GTK_TREE_VIEW(treeview_plugins));
      selection = gtk_tree_view_get_selection (GTK_TREE_VIEW(treeview_plugins));

      gtk_tree_model_get_iter_first (store, &iter);
      gtk_tree_selection_select_iter (selection, &iter);
    }

  store = gtk_tree_view_get_model (GTK_TREE_VIEW(treeview_plugins));

  gtk_tree_model_get_iter_first (store, &iter);
  gtk_tree_model_get (store, &iter, 1, &suffix, -1);
  suffix_fq = g_strconcat (".", suffix, NULL);

  listname = g_strconcat (g_get_home_dir(),
		          G_DIR_SEPARATOR_S,
		          "Playlist",
			  suffix_fq,
			  NULL);
  g_free (suffix_fq);
  gtk_entry_set_text (GTK_ENTRY(entry_filename), listname);

  rv = gtk_dialog_run (GTK_DIALOG(dialog_window));

  switch (rv)
    {
	case GTK_RESPONSE_CANCEL: break;

	case GTK_RESPONSE_OK:
	  {
	    GtkWidget	 *rb_options1;
	    GtkTreeModel *store;
	    GtkTreeIter	  iter;
	    gchar	  *container;
	    gboolean	  rv;

	    rb_options1 = glade_xml_get_widget_warn (xml, "rb_options1");

	    gtk_tree_selection_get_selected (gtk_tree_view_get_selection (GTK_TREE_VIEW(treeview_plugins)), &store, &iter);
	    gtk_tree_model_get (GTK_TREE_MODEL(store), &iter, 2, &container, -1);

	    rv = bmp_system_control_export_tracklist (bmp_system_control,
						      container,
						      !gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(rb_options1)),
						      gtk_entry_get_text (GTK_ENTRY(entry_filename)),
						      NULL);

	    if (!rv)
	      {
		// ERROR HERE
	      }
	  }
    }

  gtk_widget_hide (dialog_window);
}


void
bmp_ui_callback_library	    (GtkAction *action, gpointer data)
{
    bmp_ui_library_show (bmp_ui);
}

void
bmp_ui_callback_streams	    (GtkAction *action, gpointer data)
{
    bmp_ui_streams_show (bmp_ui);
}

void
bmp_ui_callback_jtt	    (GtkAction *action, gpointer data)
{
    bmp_ui_jtt_show (bmp_ui);
}

void
bmp_ui_callback_preferences (GtkAction *action, gpointer data)
{
    bmp_ui_preferences_show (bmp_ui);
}


