#ifndef ERROR_H
#define ERROR_H

G_BEGIN_DECLS

enum {
	BMP_ERROR_SUCCESS,
	BMP_ERROR_FAILURE,

	BMP_N_ERRORS
};


#if 0
gboolean /* registration success */
bmp_error_register_domain(const gchar * identifier, const gchar * description);

gint /* message ticket */
bmp_error_queue_message(const gchar * identifier, const gchar * message);

gboolean /* dequeue success */
bmp_error_unqueue_message(gint ticket);
#endif

G_END_DECLS

#endif
