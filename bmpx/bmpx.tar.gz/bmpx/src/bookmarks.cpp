/*  BMPx - The Dumb Music Player
 *  Copyright (C) 2005 BMPx development team.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *

 * The BMPx project hereby grant permission for non-gpl compatible GStreamer
 * plugins to be used and distributed together with GStreamer and BMPx. This
 * permission are above and beyond the permissions granted by the GPL license
 * BMPx is covered by.
 */

/*
 *
 * BMPx Bookmarks XBEL based backend code
 *
 * (C) 2005-2006 M. Derezynski
 *
 * XBEL: http://pyxml.sourceforge.net/topics/xbel/docs/html/xbel.html
 *
 * We use only the following structure:
 *
 * <xbel version="1.0">
 *    <folder>
 *	<title></title>
 *
 *	<bookmark href="">
 *	  <title></title>
 *	</bookmark>
 *
 *      ...
 *
 *   </folder>
 *
 */

#include <cstring>
#include <iostream>

#include <glib/gprintf.h>
#include <glibmm.h>
#include <gtkmm.h>

#include "main.hpp"
#include "paths.hpp"

#include "bookmarks.hpp"

/* XBEL 1.0 standard entities */
#define XBEL_VERSION	    "1.0"
#define XBEL_DTD_NICK	    "xbel"
#define XBEL_DTD_SYSTEM	    "+//IDN python.org//DTD XML Bookmark " \
				"Exchange Language 1.0//EN//XML"

#define XBEL_DTD_URI	    "http://www.python.org/topics/xml/dtds/xbel-1.0.dtd"

#define XBEL_ELEMENT_ROOT	    "xbel"
#define XBEL_ELEMENT_FOLDER	    "folder"
#define XBEL_ELEMENT_BOOKMARK	    "bookmark"
#define XBEL_ELEMENT_ALIAS	    "alias"
#define XBEL_ELEMENT_SEPARATOR	    "separator"
#define XBEL_ELEMENT_TITLE	    "title"
#define XBEL_ELEMENT_DESC	    "desc"
#define XBEL_ELEMENT_INFO	    "info"
#define XBEL_ELEMENT_METADATA	    "metadata"

#define XBEL_ATTRIBUTE_VERSION	    "version"
#define XBEL_ATTRIBUTE_FOLDED	    "folded"
#define XBEL_ATTRIBUTE_OWNER	    "owner"
#define XBEL_ATTRIBUTE_ADDED	    "added"
#define XBEL_ATTRIBUTE_VISITED	    "visited"
#define XBEL_ATTRIBUTE_MODIFIED	    "modified"
#define XBEL_ATTRIBUTE_ID	    "id"
#define XBEL_ATTRIBUTE_HREF	    "href"
#define XBEL_ATTRIBUTE_REF	    "ref"

#define XBEL_YES_VALUE		    "yes"
#define XBEL_NO_VALUE		    "no"

/* date and times inside XBEL entities should be expressed using ISO 8601
 * formats; we use the extended date and time format, relative to UTC
 */
#define ISO_8601_FORMAT "%Y-%m-%dT%H:%M:%SZ" /* strftime(3) format */
#define ISO_8601_LEN	21

namespace {

static int
register_namespaces (xmlXPathContextPtr xpathCtx, const xmlChar* nsList)
{
    xmlChar* nsListDup;
    xmlChar* prefix;
    xmlChar* href;
    xmlChar* next;

    nsListDup = xmlStrdup(nsList);
    if(nsListDup == NULL)
    {
        g_printerr ("Error: unable to strdup namespaces list\n");
        return -1;
    }

    next = nsListDup;

    while (next != NULL)
    {
        /* skip spaces */
        while((*next) == ' ') next++;
        if((*next) == '\0') break;

        /* find prefix */
        prefix = next;
        next = (xmlChar*)xmlStrchr(next, '=');

        if(next == NULL)
        {
            g_printerr ("Error: invalid namespaces list format\n");
            xmlFree(nsListDup);
            return -1;
        }
        *(next++) = '\0';

        /* find href */
        href = next;
        next = (xmlChar*)xmlStrchr(next, ' ');

        if(next != NULL)
        {
            *(next++) = '\0';
        }

        /* do register namespace */
        if(xmlXPathRegisterNs(xpathCtx, prefix, href) != 0)
        {
            g_printerr ("Error: unable to register NS with prefix=\"%s\" and href=\"%s\"\n", prefix, href);
            xmlFree(nsListDup);
            return -1;
        }
    }

    xmlFree(nsListDup);

    return 0;
}

static xmlXPathObjectPtr
xml_execute_xpath_expression (xmlDocPtr      doc,
                              const xmlChar *xpathExpr,
                              const xmlChar *nsList)
{

    xmlXPathContextPtr xpathCtx;
    xmlXPathObjectPtr  xpathObj;

    /*
     * Create xpath evaluation context
     */
    xpathCtx = xmlXPathNewContext (doc);

    if (xpathCtx == NULL)
    {
         return NULL;
    }

    if (nsList)
    {
        register_namespaces (xpathCtx, nsList);
    }

    /*
     * Evaluate xpath expression
     */
    xpathObj = xmlXPathEvalExpression (xpathExpr, xpathCtx);
    if (xpathObj == NULL)
     {
         xmlXPathFreeContext (xpathCtx);
         return NULL;
     }

    /*
     * Cleanup
     */
    xmlXPathFreeContext (xpathCtx);

    return xpathObj;
}


};

namespace Bmp {

  namespace Streams
  {

    bool
    Bookmarks::append_node (const Gtk::TreeModel::iterator& iter, xmlNodePtr root)
    {
      Gtk::TreeRow  row;
      xmlNodePtr    bookmark;

      row = *iter;
      bookmark = xmlNewNode (NULL, BAD_CAST XBEL_ELEMENT_BOOKMARK);
      xmlAddChild (root, bookmark);

      const Glib::ustring title(row[bookmark_columns.title]);
      const Glib::ustring descr(row[bookmark_columns.desc]);
      const Glib::ustring href(row[bookmark_columns.href]);

      xmlNewTextChild (bookmark, NULL, BAD_CAST XBEL_ELEMENT_TITLE, BAD_CAST title.c_str());
      xmlNewTextChild (bookmark, NULL, BAD_CAST XBEL_ELEMENT_DESC,  BAD_CAST descr.c_str());

      xmlSetProp (bookmark, BAD_CAST XBEL_ATTRIBUTE_HREF, BAD_CAST href.c_str());

      return false;
    }

    Bookmarks::Bookmarks ()
    {
      xmlDocPtr         doc;
      xmlXPathObjectPtr xpathobj;

      bookmarks = Gtk::ListStore::create (bookmark_columns);

      std::string filename = std::string (BMP_PATH_USER_DIR) + "/bookmarks.xbel";
      if (!Glib::file_test (filename.c_str(), Glib::FILE_TEST_EXISTS)) return;

      doc = xmlParseFile (filename.c_str());
      if  (!doc) return;

      const char *xpath = "/" XBEL_ELEMENT_ROOT "//" XBEL_ELEMENT_BOOKMARK;

      xpathobj = xml_execute_xpath_expression (doc, BAD_CAST xpath, NULL);

      if (!xpathobj) return;
      if (!xpathobj->nodesetval) return;
      if (!xpathobj->nodesetval->nodeNr) return;

      for (int n = 0; n < xpathobj->nodesetval->nodeNr; n++)
      {
	    Gtk::TreeModel::iterator model_iter;

            enum
	    {
                    STR_TITLE,
                    STR_HREF,
                    STR_DESC,
                    N_STRINGS
            };

            char            *STR[N_STRINGS];
	    xmlNodePtr	     node;
            xmlNodePtr       sibling;

            STR[STR_HREF]    = NULL;
            STR[STR_TITLE]   = NULL;
            STR[STR_DESC]    = NULL;

            node = xpathobj->nodesetval->nodeTab[n];
            sibling = node->children;

            STR[STR_HREF] = reinterpret_cast<char *> (xmlGetProp (node, BAD_CAST XBEL_ATTRIBUTE_HREF));

            while (sibling)
                {
                    if ((sibling->type == XML_ELEMENT_NODE) && (sibling->children))
                        {
                            if (!std::strcmp (reinterpret_cast<const char *> (sibling->name),
                                              reinterpret_cast<const char *> (XBEL_ELEMENT_TITLE)))
                            {
                                STR[STR_TITLE]  = reinterpret_cast<char *> (XML_GET_CONTENT (sibling->children));
                            }

                            if (!std::strcmp (reinterpret_cast<const char *> (sibling->name),
                                              reinterpret_cast<const char *> (XBEL_ELEMENT_DESC)))
                            {
			      
                                STR[STR_DESC]   = reinterpret_cast<char *> (XML_GET_CONTENT (sibling->children));
                            }
                        }

                    sibling = sibling->next;
                }

            if (STR[STR_HREF])
                {
	  	    model_iter = bookmarks->append ();

		    if (STR[STR_TITLE])
		      {
			(*model_iter)[bookmark_columns.title] = STR[STR_TITLE];
		      }

		    if (STR[STR_DESC])
		      {
			(*model_iter)[bookmark_columns.desc]  = STR[STR_DESC];
		      }


			(*model_iter)[bookmark_columns.href]  = STR[STR_HREF];

		    g_free (STR[STR_TITLE]);
		    g_free (STR[STR_HREF]);
		    g_free (STR[STR_DESC]);
                }
      }
    }

    Bookmarks::~Bookmarks ()
    {
      xmlDocPtr			 doc;
      xmlNodePtr		 root;

      doc = xmlNewDoc (BAD_CAST "1.0");
      root = xmlNewNode (NULL, BAD_CAST XBEL_ELEMENT_ROOT);
      xmlDocSetRootElement (doc, root);

      if (!bookmarks->children (). empty ())
	{
	  bookmarks->foreach_iter (sigc::bind (sigc::mem_fun (this, &Bmp::Streams::Bookmarks::append_node), root));
	}

      xmlChar *data;
      int      size;
      xmlDocDumpFormatMemoryEnc (doc, &data, &size, "UTF-8", 1);

      std::string filename = std::string (BMP_PATH_USER_DIR) +  "/bookmarks.xbel";
      g_file_set_contents (filename.c_str (), reinterpret_cast<char *>(data), size, NULL);

      xmlFreeDoc (doc);
    }

  }; // Streams

}; // Bmp
