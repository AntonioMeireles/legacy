/*  BMPx - The Dumb Music Player
 *  Copyright (C) 2005 BMPx development team.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 *  $Id$
 *
 * The BMPx project hereby grant permission for non-gpl compatible GStreamer
 * plugins to be used and distributed together with GStreamer and BMPx. This
 * permission are above and beyond the permissions granted by the GPL license
 * BMPx is covered by.
 */

#include <gtk/gtkmain.h>
#include <glib-object.h>
#include <glib/gmacros.h>
#include <gtk/gtkmarshal.h>
#include <gtk/gtkwindow.h>

#include <bmp/widgets/bmp_window.h>

/* Forward declarations */

static void
bmp_window_class_init (BmpWindowClass *class);
static void
bmp_window_init (GtkWidget *widget);

/* Local data */

static GtkWindowClass *parent_class = NULL;

GType
bmp_window_get_type ()
{
  static GType window_type = 0;

  if (!window_type)
    {
      static const GTypeInfo window_info =
      {
        sizeof (BmpWindowClass),
        NULL,           /* base_init */
        NULL,           /* base_finalize */
        (GClassInitFunc) bmp_window_class_init,
        NULL,           /* class_finalize */
        NULL,           /* class_data */
        sizeof (BmpWindow),
        0,              /* n_preallocs */
        (GInstanceInitFunc) bmp_window_init
      };

      window_type =
        g_type_register_static (GTK_TYPE_WINDOW, "BmpWindow",
                                &window_info, 0);
    }

  return window_type;
}

static gboolean
bmp_window_configure (GtkWidget *widget,
		      GdkEventConfigure *event)
{
    GtkWidgetClass *widget_class;

    widget_class = (GtkWidgetClass*) parent_class;
    widget_class->configure_event (widget, event);
    return FALSE;
}

static void
bmp_window_class_init (BmpWindowClass *class)
{
  GtkObjectClass *object_class;
  GtkWidgetClass *widget_class;

  object_class = (GtkObjectClass*) class;
  widget_class = (GtkWidgetClass*) class;

  parent_class = gtk_type_class (gtk_window_get_type ());

  widget_class->configure_event = bmp_window_configure;
}

void
bmp_window_hide (BmpWindow *window)
{
  g_return_if_fail (BMP_IS_WINDOW (window));

  gtk_window_get_position (GTK_WINDOW(window), &window->x, &window->y);
  gtk_widget_hide (GTK_WIDGET(window));
}

void
bmp_window_show (BmpWindow *window)
{
  g_return_if_fail (BMP_IS_WINDOW (window));
  
  gtk_window_move (GTK_WINDOW(window), window->x, window->y);
  gtk_widget_show_all(GTK_WIDGET(window));
}

static void
bmp_window_init(GtkWidget *widget)
{
	BmpWindow *window;
	window = BMP_WINDOW(widget);
}

GtkWidget*
bmp_window_new (GtkWindowType type)
{
 	GtkWidget * widget = g_object_new(bmp_window_get_type(), NULL);

	BMP_WINDOW(widget)->canvas = gtk_fixed_new();
	gtk_fixed_set_has_window (GTK_FIXED (BMP_WINDOW(widget)->canvas), TRUE);

	gtk_widget_add_events (BMP_WINDOW(widget)->canvas,  GDK_FOCUS_CHANGE_MASK | GDK_BUTTON_MOTION_MASK |
                          GDK_BUTTON_PRESS_MASK | GDK_BUTTON_RELEASE_MASK |
                          GDK_SCROLL_MASK | GDK_VISIBILITY_NOTIFY_MASK | GDK_KEY_PRESS_MASK | GDK_KEY_RELEASE_MASK );
 
	gtk_container_add (GTK_CONTAINER (BMP_WINDOW(widget)), BMP_WINDOW(widget)->canvas);

	gtk_widget_realize  (GTK_WIDGET(widget));	
	gtk_widget_realize  (BMP_WINDOW(widget)->canvas);	

        gtk_window_set_decorated (GTK_WINDOW (widget), FALSE);

	return widget;
}

#if 0
static void
bmp_window_destroy (GtkObject *object)
{
}

static gboolean
bmp_window_expose (GtkWidget      *widget,
		 GdkEventExpose *event)
{

   return FALSE;
}

static gboolean
bmp_window_enter_notify(GtkWidget *widget, GdkEventCrossing *event)
{

   return FALSE;
}

static gboolean
bmp_window_leave_notify(GtkWidget *widget, GdkEventCrossing *event)
{
   return FALSE;
}

static void
bmp_window_send_configure (BmpWindow *window)
{
}

static void
bmp_window_size_allocate (GtkWidget     *widget,
				GtkAllocation *allocation)
{
}
#endif

