#ifndef BMP_DND_HPP
#define BMP_DND_HPP

#include <gtkmm.h>

//Designate dropped data types that we know and care about
enum {
    BMP_DROP_PLAINTEXT,
    BMP_DROP_URLENCODED,
    BMP_DROP_STRING,
};

//Drag data format listing for gtk_drag_dest_set()
static const GtkTargetEntry bmp_drop_types[] = {
    {"text/plain",		    0, BMP_DROP_PLAINTEXT},
    {"text/uri-list",		    0, BMP_DROP_URLENCODED},
    {"STRING",			    0, BMP_DROP_STRING},
};

#define bmp_drag_dest_set(widget) \
    gtk_drag_dest_set(widget, \
		       GtkDestDefaults (GTK_DEST_DEFAULT_MOTION | GTK_DEST_DEFAULT_DROP), \
		       bmp_drop_types, 3, \
                       (GdkDragAction) (GDK_ACTION_MOVE | GDK_ACTION_COPY | GDK_ACTION_LINK | GDK_ACTION_ASK))

#endif
