/* This file contains code from the XMMS project and is licensed under the GPL
 */

#include "main.hpp"
#include <cstdlib>
#include <cstring>
#include <cmath>
#include <gtk/gtk.h>
#include <gtkmm.h>
#include <gdk/gdk.h>
#include <gdk/gdkx.h>
#include <X11/Xlib.h>
#include "ui_util.hpp"
#include <bmp/util.h>
#include <glib/gi18n.h>
#include <goa/libgoa.h>
#include "ui.hpp"
#include "paths.hpp"

#define _NET_WM_STATE_REMOVE   0
#define _NET_WM_STATE_ADD      1
#define _NET_WM_STATE_TOGGLE   2

#define _NET_WM_MOVERESIZE_SIZE_TOPLEFT      0
#define _NET_WM_MOVERESIZE_SIZE_TOP          1
#define _NET_WM_MOVERESIZE_SIZE_TOPRIGHT     2
#define _NET_WM_MOVERESIZE_SIZE_RIGHT        3
#define _NET_WM_MOVERESIZE_SIZE_BOTTOMRIGHT  4
#define _NET_WM_MOVERESIZE_SIZE_BOTTOM       5
#define _NET_WM_MOVERESIZE_SIZE_BOTTOMLEFT   6
#define _NET_WM_MOVERESIZE_SIZE_LEFT         7
#define _NET_WM_MOVERESIZE_MOVE              8

using namespace Bmp;

static char     *bmp_skin_colors[BMP_N_SKINCOLORS];
static GdkColor *bmp_skin_colors_gdk[BMP_N_SKINCOLORS];
static GQuark	 quark_popup_data;

/* Cursors */
static GdkPixbuf *bmp_cursors[CURSOR_N_CURSORS];

static std::vector<std::string> bmp_cursor_names;
static std::vector<std::string> bmp_skin_color_names;

GdkPixbuf*
bmp_pixbuf_new_simple (guint width, guint height)
{
	GdkPixbuf *pixbuf;

	pixbuf = bmp_skin_component[SKIN_COMPONENT_PLEDIT]->pixbuf;
        return gdk_pixbuf_new (gdk_pixbuf_get_colorspace(pixbuf),
                         gdk_pixbuf_get_has_alpha(pixbuf),
                         gdk_pixbuf_get_bits_per_sample(pixbuf),
                         width, height);
}


void
bmp_pixbuf_copy_area_simple(GdkPixbuf *dest, guint x, guint y, guint width, guint height)
{
	GdkPixbuf * pixbuf;

	pixbuf = bmp_skin_component[SKIN_COMPONENT_PLEDIT]->pixbuf;
	gdk_pixbuf_copy_area (pixbuf, x, y, width, height, dest, 0, 0);
}


void
bmp_draw_pixbuf_simple (cairo_t *cr, GdkPixbuf *buf, guint x, guint y)
{
    cairo_save (cr);
    gdk_cairo_set_source_pixbuf (cr,
				 buf,
				 x,
				 y);
    cairo_paint (cr);
    cairo_restore (cr);
}

/* CURSORS */

void
bmp_cursors_init ()
{
  static const char *names[] = {
   "normal.cur",
   "posbar.cur",
   "volbar.cur",
   "pnormal.cur",
   "psize.cur",
   "mainmenu.cur"
  };

  for (unsigned int i = 0; i < G_N_ELEMENTS(names); i++)
    {
      bmp_cursors[i] = NULL;
      bmp_cursor_names.push_back (names[i]);
    }
}


void
bmp_cursors_free ()
{
  gint n;

  if (bmp_cursors[0] != NULL)
	for (n = 0; n < CURSOR_N_CURSORS; n++)
	  {
	     if (bmp_cursors[n] != NULL)
	       {
        	 g_object_unref (bmp_cursors[n]);
	       }
	     bmp_cursors[n] = NULL;
	  }
}


void
bmp_cursors_set (const std::string& archive_dirname)
{
  bmp_cursor_add (archive_dirname, CURSOR_NORMAL);
  bmp_cursor_add (archive_dirname, CURSOR_POSBAR);
  bmp_cursor_add (archive_dirname, CURSOR_VOLBAR);
  bmp_cursor_add (archive_dirname, CURSOR_PLAYLIST);
  bmp_cursor_add (archive_dirname, CURSOR_PLAYLIST_SIZE);
  bmp_cursor_add (archive_dirname, CURSOR_MAINMENU);
}

static GdkPixbuf*
get_cursor_pixbuf (const std::string& archive_dirname, const std::string& cursor_filename)
{
  std::string filename;
  if (!Util::find_file (archive_dirname, cursor_filename, filename, 1))
	return NULL;

  GdkPixbufAnimation *cursor_animated =
	gdk_pixbuf_animation_new_from_file (filename.c_str(), NULL);

  GdkPixbuf *pb_aux =
	gdk_pixbuf_animation_get_static_image (cursor_animated);

  GdkPixbuf *pb_return =
	gdk_pixbuf_copy (pb_aux);

 g_object_unref (cursor_animated);
 return pb_return;
}


void
bmp_cursor_add (const std::string& archive_dirname,
	        int		   cursor_enum)
{
  bmp_cursors[cursor_enum] = get_cursor_pixbuf (archive_dirname.c_str(), bmp_cursor_names[cursor_enum].c_str());
}

GdkCursor*
bmp_cursor_get (::CursorId cursor_enum)
{
  GdkCursor * cursor;
  GdkPixbuf * pixbuf;
  const gchar *hot_x = NULL, *hot_y = NULL;
  gint hot_x_int = 0, hot_y_int = 0;

  pixbuf = bmp_cursors[cursor_enum];

  if (!mcs->key_get<bool>("bmp","use-custom-cursors")) return NULL;

  if (!pixbuf)
    {
      pixbuf = bmp_cursors[CURSOR_NORMAL];
      if (!pixbuf) return NULL;
    }

  hot_x = gdk_pixbuf_get_option(pixbuf,"x_hot");
  hot_y = gdk_pixbuf_get_option(pixbuf,"y_hot");

  if (hot_x) hot_x_int = std::atoi (hot_x);
  if (hot_y) hot_y_int = std::atoi (hot_x);

  cursor = gdk_cursor_new_from_pixbuf  (gdk_display_get_default(),
                                              pixbuf,
                                              hot_x_int,
                                              hot_y_int);
  return cursor;
}
/* END cursors */

/* XShape Masks */
static GdkBitmap*
bmp_skin_create_transparent_mask(const std::string& path,
                                 const std::string& file,
                                 const std::string& section,
                                 int width,
                                 int height)
{
    GdkBitmap	  *mask = NULL;
    GdkGC	  *gc = NULL;
    GdkPoint	  *points;
    GdkColor	   pattern;
    GArray	  *num,
		  *point;
    std::string	   filename;
    bool	   created_mask = false;

    if (!path.empty ())
      {
        Util::find_file (path, file, filename, 1);
      }

    if (filename.empty ())
      {
	return NULL;
      }

    if ((num   = (GArray*)read_ini_array (filename.c_str(), section.c_str(), "NumPoints")) == NULL)
      {
        return NULL;
      }

    if ((point = (GArray*)read_ini_array (filename.c_str(), section.c_str(), "PointList")) == NULL)
      {
        g_array_free (num, TRUE);
        return NULL;
      }

    mask = gdk_pixmap_new (NULL, width, height, 1);
    gc = gdk_gc_new (mask);

    pattern.pixel = 0;
    gdk_gc_set_foreground (gc, &pattern);
    gdk_draw_rectangle (mask, gc, TRUE, 0, 0, width, height);
    pattern.pixel = 1;
    gdk_gc_set_foreground (gc, &pattern);

    unsigned int k;
    unsigned int j = 0;

    for (unsigned int i = 0; i < num->len; i++)
    {
        if ((point->len - j) >= (g_array_index(num, gint, i) * 2))
        {
            points = g_new (GdkPoint, g_array_index(num, gint, i));
            for (k = 0; k < g_array_index(num, gint, i); k++)
	    {
                points[k].x = g_array_index(point, gint, j + k * 2);
                points[k].y = g_array_index(point, gint, j + k * 2 + 1);
            }
            j += k * 2;
            gdk_draw_polygon (mask, gc, TRUE, points, g_array_index(num, gint, i));
            g_free (points);
        }
	created_mask = true;
    }

    g_array_free (num, TRUE);
    g_array_free (point, TRUE);

    if (!created_mask)
      {
        gdk_draw_rectangle (mask, gc, TRUE, 0, 0, width, height);
      }

    gdk_gc_destroy (gc);

    return mask;
}


GdkBitmap*
bmp_get_mask_window_main (const std::string& path)
{
    return bmp_skin_create_transparent_mask(path,
                                 BMP_FILE_REGION,
                                 BMP_MASK_REGION_SECTION_MAIN_WINDOW,
                                 275,
                                 116);
}

static guint
hex_chars_to_int(gchar hi, gchar lo)
{
    /*
     * Converts a value in the range 0x00-0xFF
     * to a integer in the range 0-65535
     */
    gchar str[3];
    guint value;

    str[0] = hi;
    str[1] = lo;
    str[2] = 0;

    value = (CLAMP(strtol(str, NULL, 16), 0, 0xFF) << 8);

    return value;
}

#define PLEDIT_TEXT_SECTION_NAME "Text"

/* COLORS */
std::string
bmp_skin_get_color (const std::string&	path,
		    const std::string&  key)
{
    std::string filename, value;

    if (Util::find_file (path, BMP_FILE_PLEDIT, filename, 1))
      {
	value = read_ini_string (filename, PLEDIT_TEXT_SECTION_NAME, key);
      }

    return value;
}

GdkColor*
bmp_skin_convert_color (const std::string& value_arg)
{
    GdkColor *color = NULL;

    if (!value_arg.empty ())
      {
	  char *value = g_strdup (value_arg.c_str());
	  char *ptr   = value;
	  int	        len;

	  color = new GdkColor;
	  g_strstrip(value);

	  if (value[0] == '#') ptr++;
	  len = std::strlen(ptr);

	  /*
	   * The handling of incomplete values is done this way
           * to maximize winamp compatibility
	   */
	  if (len >= 6) {
                color->red = hex_chars_to_int(*ptr, *(ptr + 1));
                ptr += 2;
	  }
	  if (len >= 4) {
                color->green = hex_chars_to_int(*ptr, *(ptr + 1));
                ptr += 2;
	  }
	  if (len >= 2) {
                color->blue = hex_chars_to_int(*ptr, *(ptr + 1));
	  }

	  g_free (value);
    }

   return color;
}


void
bmp_colors_set_color (BmpSkinColor color, const std::string& color_hex)
{
    bmp_skin_colors[color] = g_strdup (color_hex.c_str());
}

void
bmp_colors_init(const std::string& archive_dirname)
{
  static const char *names[] = {
   "NormalBG",
   "Normal",
   "SelectedBG",
   "Current"
  };

  for (unsigned int i = 0; i < G_N_ELEMENTS(names); i++)
    {
      bmp_skin_color_names.push_back (names[i]);
    }

  ::bmp_colors_set_color (BmpSkinColor(BMP_SKINCOLOR_PL_BG_NORMAL),   ::bmp_skin_get_color (archive_dirname, ::bmp_skin_color_names[BMP_SKINCOLOR_PL_BG_NORMAL]).c_str());
  ::bmp_colors_set_color (BmpSkinColor(BMP_SKINCOLOR_PL_FG_CURRENT),  ::bmp_skin_get_color (archive_dirname, ::bmp_skin_color_names[BMP_SKINCOLOR_PL_FG_CURRENT]).c_str());
  ::bmp_colors_set_color (BmpSkinColor(BMP_SKINCOLOR_PL_FG_NORMAL),   ::bmp_skin_get_color (archive_dirname, ::bmp_skin_color_names[BMP_SKINCOLOR_PL_FG_NORMAL]).c_str());
  ::bmp_colors_set_color (BmpSkinColor(BMP_SKINCOLOR_PL_BG_SELECTED), ::bmp_skin_get_color (archive_dirname, ::bmp_skin_color_names[BMP_SKINCOLOR_PL_BG_SELECTED]).c_str());
}

void
bmp_colors_free ()
{
    for (unsigned int i = 0; i < SKIN_N_COLORS; i++)
    {
        /* gdk_color_free(bmp_skin_colors_gdk[i]); */
        bmp_skin_colors_gdk[i] = NULL;
    }
}

void
bmp_color_allocate(BmpSkinColor color, GtkWidget *widget)
{
    gdk_color_alloc (gdk_window_get_colormap(widget->window), bmp_colors_get_color(color));
}

GdkColor*
bmp_colors_get_color(BmpSkinColor color)
{
    if (!bmp_skin_colors_gdk[color])
    {
	bmp_skin_colors_gdk[color] = bmp_skin_convert_color(bmp_skin_colors[color]);
    }

    return bmp_skin_colors_gdk[color];
}


void
gdk_color_to_rgba (GdkColor *color, double *r, double *g, double *b, double *a)
{
  *r = color->red   / 65535.0;
  *g = color->green / 65535.0;
  *b = color->blue  / 65535.0;
  *a = 1;
}
/* END colors */

#define BMP_N_ICON_SIZES 5

void
bmp_window_set_icon_list (GtkWidget *window, const gchar *icon_name)
{
	static const gchar* sizes[] = {
		"16", "32", "48", "64", "128"
	};

	GdkPixbuf *pixbufs[BMP_N_ICON_SIZES];
	GError *error = NULL;
	GList *icon_list = NULL;
	const gchar *icon_theme;
	gchar *aux0, *aux1;
	gint n;

	icon_theme = mcs->key_get<std::string>("bmp", "icon-theme"). c_str ();

	for (n = 0; n < BMP_N_ICON_SIZES; n++)
	  {
		aux0 = g_strconcat("icon_", icon_name, "_", sizes[n], ".png", NULL);
		aux1 = g_build_filename (DATA_DIR, BMP_ICONS_BASENAME, icon_theme, aux0, NULL);

		pixbufs[n] = gdk_pixbuf_new_from_file (aux1, &error);

		if (error != NULL)
		  {
			g_message (error->message);
			g_error_free (error);
			error = NULL;
		  }

		icon_list = g_list_append (icon_list, pixbufs[n]);
		g_free (aux1);
		g_free (aux0);
	  }

	gtk_window_set_icon_list (GTK_WINDOW (window), icon_list);
	g_list_free (icon_list);

	for (n = 0; n < BMP_N_ICON_SIZES; n++)
		g_object_unref (pixbufs[n]);
}

#if 0
void
bmp_window_set_icon_list_pp (Gtk::Window     &window,
			     std::string     &icon_name)
{
	static const gchar* sizes[] = {
		"16", "32", "48", "64", "128"
	};

	Glib::ListHandle<Glib::RefPtr<Gdk::Pixbuf> > icons;
	Glib::ustring icon_theme;

	icon_theme = mcs->key_get<std::string>( "bmp", "icon-theme");

	for (unsigned int n = 0; n < BMP_N_ICON_SIZES; n++)
	  {
		Glib::RefPtr<Gdk::Pixbuf> pixbuf;
		std::string icon_filename;

		icon_filename = DATA_DIR +
				G_DIR_SEPARATOR_S +

				BMP_ICONS_BASENAME +
				G_DIR_SEPARATOR_S +

				icon_theme +
				G_DIR_SEPARATOR_S +

				"icon_" + icon_name + "_" + sizes[n] + ".png";


		pixbuf = Gdk::Pixbuf::create_from_file (icon_filename);
		icons. push_back (pixbuf);
	  }

      window. set_icon_list (icons);
      icons. erase ();
}
#endif

static gdouble
mm_to_inch (gdouble mm)
{
    return mm / 25.40;
}


gdouble
screen_get_resolution (GdkScreen *screen)
{
  /* NOTE: this assumes the width and height resolutions are
     equal. This is only true for video modes with aspect ratios of
     4:3 e.g. 640x480, 800x600, etc. - descender */
  return std::ceil(screen_get_y_resolution (screen));
}


gdouble
screen_get_x_resolution (GdkScreen *screen)
{
  g_return_val_if_fail (GDK_IS_SCREEN (screen), -1.0);

  return (gdouble) gdk_screen_get_width (screen) / mm_to_inch (gdk_screen_get_height_mm (screen));
}


gdouble
screen_get_y_resolution (GdkScreen *screen)
{
  g_return_val_if_fail (GDK_IS_SCREEN (screen), -1.0);

  return (gdouble) gdk_screen_get_height (screen) / mm_to_inch (gdk_screen_get_height_mm (screen));
}


GtkWidget *
ui_manager_get_popup (GtkUIManager * self,
		      const gchar * path)
{
    GtkWidget *menu_item;
    GtkWidget *submenu;

    menu_item = gtk_ui_manager_get_widget (self, path);

    if (GTK_IS_MENU_ITEM (menu_item))
	submenu = gtk_menu_item_get_submenu (GTK_MENU_ITEM (menu_item));
    else
	submenu = NULL;

    if (submenu)
	{
	    SET_CURSOR_FOR_WIDGET (CURSOR_NORMAL, GTK_WIDGET (submenu));
	}

    return submenu;
}

static void
menu_popup_pos_func (GtkMenu * menu,
		     gint * x,
		     gint * y,
		     gboolean * push_in,
		     gint * point)
{
    *x = point[0];
    *y = point[1];
    *push_in = FALSE;
}

void
bmp_menu_popup (GtkMenu * menu,
		gint x,
		gint y,
		guint button,
		guint time)
{
    gint pos[2];

    pos[0] = x;
    pos[1] = y;

    gtk_menu_popup (menu, NULL, NULL,
		    (GtkMenuPositionFunc) menu_popup_pos_func, pos,
		    button, time);
}

typedef struct {
    gint x;
    gint y;
} MenuPos;


void
util_menu_position (GtkMenu * menu,
		    gint * x,
		    gint * y,
		    gboolean * push_in,
		    gpointer data)
{
    GtkRequisition requisition;
    gint screen_width;
    gint screen_height;
    MenuPos *pos = static_cast<MenuPos *> (data);

    gtk_widget_size_request (GTK_WIDGET (menu), &requisition);

    screen_width = gdk_screen_width ();
    screen_height = gdk_screen_height ();

    *x = CLAMP (pos->x - 2, 0, MAX (0, screen_width - requisition.width));
    *y = CLAMP (pos->y - 2, 0, MAX (0, screen_height - requisition.height));
}

static void
util_menu_delete_popup_data (GtkObject * object,
                             GtkItemFactory * ifactory)
{
    gtk_signal_disconnect_by_func (object,
				   GTK_SIGNAL_FUNC
				   (util_menu_delete_popup_data), ifactory);
    gtk_object_remove_data_by_id (GTK_OBJECT (ifactory), quark_popup_data);
}

#ifdef ENABLE_NLS
gchar *
bmp_menu_translate (const gchar *message,
                    gpointer     data)
{
  gchar *translation = (gchar *) Q_(message);

  if (!translation)
    {
      g_warning ("Bad translation for message: %s", message);
      translation = (gchar *) message;
    }

  return translation;
}
#endif


void
bmp_window_set_busy (GtkWidget *widget)
{
    GdkCursor *cursor;

    cursor = gdk_cursor_new_from_name (gdk_display_get_default (), "watch");
    if (!cursor) cursor = gdk_cursor_new_for_display (gdk_display_get_default (), GDK_WATCH);
    gdk_window_set_cursor (GTK_WIDGET(widget)->window, cursor);
}

void
bmp_window_set_idle (GtkWidget *widget)
{
    gdk_window_set_cursor (GTK_WIDGET(widget)->window, NULL);
}

namespace Bmp
{
  namespace Util
  {
    void
    window_set_busy (Gtk::Window &window)
    {
        window.get_window()->set_cursor (Gdk::Cursor (Gdk::Display::get_default(), "watch"));
    }

    void
    window_set_idle (Gtk::Window &window)
    {
        window.get_window()->set_cursor ();
    }

    // NOTE: gtkmm has no binding for gdk_screen_get_rgba_visual()
    Glib::RefPtr<Gdk::Visual>
    screen_get_rgba_visual (const Glib::RefPtr<Gdk::Screen> &screen)
    {
        return Glib::wrap (gdk_screen_get_rgba_visual (screen->gobj ()), true);
    }

    // NOTE: gtkmm has no binding for gdk_screen_get_rgba_colormap()
    Glib::RefPtr<Gdk::Colormap>
    screen_get_rgba_colormap (const Glib::RefPtr<Gdk::Screen> &screen)
    {
        return Glib::wrap (gdk_screen_get_rgba_colormap (screen->gobj ()), true);
    }

  } // namespace Util

} // namespace Bmp
