/*  BMPx - The Dumb Music Player
 *  Copyright (C) 2005 BMPx development team.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * The BMPx project hereby grant permission for non-gpl compatible GStreamer
 * plugins to be used and distributed together with GStreamer and BMPx. This
 * permission are above and beyond the permissions granted by the GPL license
 * BMPx is covered by.
 */

#include <config.h>
#include <X11/X.h>
#include <X11/Xlib.h>
#include <gdk/gdk.h>
#include <gdk/gdkx.h>
#include <gtk/gtk.h>

/* Specifics for pretty printing/human readable printing of event data */
typedef struct _WindowConfiguration WindowConfiguration;
struct _WindowConfiguration {
    gint width;
    gint height;
    gint x;
    gint y;
};

typedef struct _WindowData WindowData;
struct _WindowData {
    WindowConfiguration *configuration;
    gboolean		 verbose;
    GtkWindow		*window;
};

static GHashTable *filter_data = NULL;

static GdkFilterReturn
print_event_property (XPropertyEvent *xevent, const gchar *filtername)
{
    Atom	atom = xevent->atom;
    Display    *dpy  = xevent->display;

    g_message ("\n");
    g_message ("%s: XPropertyEvent", filtername);

    g_message ("Atom: %lu", atom);
    g_message ("Atom name: %s", XGetAtomName(dpy, atom));
    g_message ("State: %s", (xevent->state == PropertyNewValue) ? "NEW" : "DELETE");

    return GDK_FILTER_CONTINUE;
}

static GdkFilterReturn
print_event_configure_req (XConfigureRequestEvent *xevent, const gchar *filtername)
{
    WindowData *wdata = static_cast<WindowData *> (g_hash_table_lookup (filter_data, filtername));

    g_assert (wdata);

    g_message ("\n");
    g_message ("%s: XConfigureRequestEvent %s", filtername, (xevent->send_event) ? "(sent)" : "");

    g_message ("Serial: %lu", xevent->serial);
    g_message ("x:%d, y:%d", xevent->x, xevent->y);
    g_message ("width:%d, height:%d", xevent->width, xevent->height);

    return GDK_FILTER_CONTINUE;
}

static GdkFilterReturn
print_event_resize_req (XResizeRequestEvent *xevent, const gchar *filtername)
{
    WindowData *wdata = static_cast<WindowData *> (g_hash_table_lookup (filter_data, filtername));

    g_assert (wdata);

    g_message ("\n");
    g_message ("%s: XResizeRequestEvent %s", filtername, (xevent->send_event) ? "(sent)" : "");

    g_message ("Serial: %lu", xevent->serial);
    g_message ("width:%d, height:%d", xevent->width, xevent->height);

    return GDK_FILTER_CONTINUE;
}
static GdkFilterReturn
print_event_configure (XConfigureEvent *xevent, const gchar *filtername)
{
    WindowData *wdata = static_cast<WindowData *> (g_hash_table_lookup (filter_data, filtername));
    WindowConfiguration *cfg = wdata->configuration;

    gboolean		 size_changed = FALSE;
    gboolean		 position_changed = FALSE;

    g_assert (wdata);

    g_message ("\n");
    g_message ("%s: XConfigureEvent %s", filtername, (xevent->send_event) ? "(sent)" : "");

    if ((cfg->x != xevent->x) || (cfg->y != xevent->y))
      {
	cfg->x = xevent->x;
	cfg->y = xevent->y;
	position_changed = TRUE;
      }

    if ((cfg->width != xevent->width) || (cfg->height != xevent->height))
      {
	cfg->width = xevent->width;
	cfg->height = xevent->height;
	size_changed = TRUE;
      }

    if (wdata->verbose)
      {
	g_message ("Serial: %lu", xevent->serial);
	g_message ("OverrideRedirect: %d", xevent->override_redirect);
	g_message ("x:%d, y:%d", xevent->x, xevent->y);
	g_message ("width:%d, height:%d", xevent->width, xevent->height);
      }
    else
      {
	if (size_changed)
	  g_message ("Size changed: width:%d, height:%d", cfg->width, cfg->height);

	if (position_changed)
	  g_message ("Position changed: x:%d, y:%d", cfg->x, cfg->y);
      }

    return GDK_FILTER_CONTINUE;
}

static GdkFilterReturn
window_filter_func (GdkXEvent *xevent,
                     GdkEvent *event,
                     gpointer data)
{
    GdkFilterReturn r_filter = GDK_FILTER_CONTINUE;
    gint	    type = ((XEvent*)xevent)->type;

    const char *str = static_cast<const char *> (data);

    switch (type)
      {
	  case PropertyNotify: r_filter = print_event_property ((XPropertyEvent*)xevent, str); break;
	  case ConfigureNotify: r_filter = print_event_configure ((XConfigureEvent*)xevent, str); break;
	  case ConfigureRequest: r_filter = print_event_configure_req ((XConfigureRequestEvent*)xevent, str); break;
	  case ResizeRequest: r_filter = print_event_resize_req ((XResizeRequestEvent*)xevent, str); break;
	  default: break;
      }

    return r_filter;
}


void
xdb_add_filter_for_window (GtkWindow   *window,
                           const gchar *filtername,
                           gboolean     verbose)
{
  WindowData *wdata;

  wdata = g_new0 (WindowData,1);

  wdata->verbose = verbose;
  wdata->window = window;

  wdata->configuration = g_new0 (WindowConfiguration,1);

  wdata->configuration->width = -1;
  wdata->configuration->height = -1;
  wdata->configuration->x = -1;
  wdata->configuration->y = -1;

  if (!filter_data)
    filter_data = g_hash_table_new (g_str_hash, g_str_equal);

  g_hash_table_insert (filter_data, g_strdup(filtername), wdata);

  gdk_window_add_filter (GTK_WIDGET(window)->window, window_filter_func, (gpointer)filtername);
}
