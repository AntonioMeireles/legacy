//  Bmp::URI (C) 2006 M. Derezynski 
//
//  Part of BMP (C) 2003-2006 BMP Project
//
//  ----
//  Based on:
//
//  GNet - Networking library
//  Copyright (C) 2000-2003  David Helder, David Bolcsfoldi, Eric Williams
//
//  ----
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
//
//  ----
//
//  The BMPx project hereby grants permission for non-GPL compatible GStreamer
//  plugins to be used and distributed together with GStreamer and BMPx. This
//  permission is above and beyond the permissions granted by the GPL license
//  BMPx is covered by.

#include <glib.h>
#include <string>
#include <bmp/uri++.hpp>

#define USERINFO_ESCAPE_MASK	0x01
#define PATH_ESCAPE_MASK	0x02
#define QUERY_ESCAPE_MASK	0x04
#define FRAGMENT_ESCAPE_MASK	0x08

namespace 
{
  char*  field_unescape (char *str);
  char*  field_escape	(char *str, guchar mask);

  guchar neednt_escape_table[] = 
  {
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
    0x00, 0x0f, 0x00, 0x00, 0x0f, 0x00, 0x0f, 0x0f, 
    0x0f, 0x0f, 0x0f, 0x0f, 0x0f, 0x0f, 0x0f, 0x0e, 
    0x0f, 0x0f, 0x0f, 0x0f, 0x0f, 0x0f, 0x0f, 0x0f, 
    0x0f, 0x0f, 0x0f, 0x0f, 0x00, 0x0f, 0x00, 0x0c, 
    0x0e, 0x0f, 0x0f, 0x0f, 0x0f, 0x0f, 0x0f, 0x0f, 
    0x0f, 0x0f, 0x0f, 0x0f, 0x0f, 0x0f, 0x0f, 0x0f, 
    0x0f, 0x0f, 0x0f, 0x0f, 0x0f, 0x0f, 0x0f, 0x0f, 
    0x0f, 0x0f, 0x0f, 0x00, 0x0f, 0x00, 0x00, 0x0f, 
    0x00, 0x0f, 0x0f, 0x0f, 0x0f, 0x0f, 0x0f, 0x0f, 
    0x0f, 0x0f, 0x0f, 0x0f, 0x0f, 0x0f, 0x0f, 0x0f, 
    0x0f, 0x0f, 0x0f, 0x0f, 0x0f, 0x0f, 0x0f, 0x0f, 
    0x0f, 0x0f, 0x0f, 0x00, 0x00, 0x00, 0x0f, 0x00, 
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
  };

#define WITHIN_ESCAPE_TABLE_SIZE(_char) ((_char >= 0) && (_char < sizeof (neednt_escape_table)))
#define ISSPACE(C) (((C) >= 9 && (C) <= 13) || (C) == ' ')

  std::string dstr (char* v)
  {
      if (!v) return std::string();
      std::string val (v);
      free (v);
      return val;
  }

  char*
  field_escape (char* str, guchar mask)
  {
	int len;
	int i;
	gboolean must_escape = FALSE;
	char* dst;
	gint j;

	if (str == NULL)
	    return NULL;

	/* Roughly calculate buffer size */
	len = 0;
	for (i = 0; str[i]; i++)
	    {
		if (WITHIN_ESCAPE_TABLE_SIZE (str[i]) && neednt_escape_table[(guint) str[i]] & mask)
		    len++;
		else
		    {
			len += 3;
			must_escape = TRUE;
		    }
	    }

	/* Don't escape if unnecessary */
	if (must_escape == FALSE)
	    return str;

	/* Allocate buffer */
	dst = (char*) g_malloc (len + 1);

	/* Copy */
	for (i = j = 0; str[i]; i++, j++)
	    {
		/* Unescaped character */
		if (WITHIN_ESCAPE_TABLE_SIZE (str[i]) && neednt_escape_table[(guint) str[i]] & mask)
		    {
			dst[j] = str[i];
		    }

		/* Escaped character */
		else
		    {
			dst[j] = '%';

			if (((str[i] & 0xf0) >> 4) < 10)
			    dst[j+1] = ((str[i] & 0xf0) >> 4) + '0';
			else
			    dst[j+1] = ((str[i] & 0xf0) >> 4) + 'a' - 10;

			if ((str[i] & 0x0f) < 10)
			    dst[j+2] = (str[i] & 0x0f) + '0';
			else
			    dst[j+2] = (str[i] & 0x0f) + 'a' - 10;

			j += 2;  /* and j is incremented in loop too */
		    }
	    }
	dst[j] = '\0';

	free (str);
	return dst;
    }

    char*
    field_unescape (char* _s)
    {
	char* s = strdup (_s);
	char* src;
	char* dst;

	for (src = dst = s; *src; ++src, ++dst)
	    {
		if (src[0] == '%' && src[1] != '\0' && src[2] != '\0')
		    {
			gint high, low;

			if ('a' <= src[1] && src[1] <= 'f')
			    high = src[1] - 'a' + 10;
			else if ('A' <= src[1] && src[1] <= 'F')
			    high = src[1] - 'A' + 10;
			else if ('0' <= src[1] && src[1] <= '9')
			    high = src[1] - '0';
			else  /* malformed */
			    goto regular_copy;

			if ('a' <= src[2] && src[2] <= 'f')
			    low = src[2] - 'a' + 10;
			else if ('A' <= src[2] && src[2] <= 'F')
			    low = src[2] - 'A' + 10;
			else if ('0' <= src[2] && src[2] <= '9')
			    low = src[2] - '0';
			else  /* malformed */
			    goto regular_copy;

			*dst = (char)((high << 4) + low);
			src += 2;
		    }
		else
		    {
	  regular_copy:
			*dst = *src;
		    }
	    }

	*dst = '\0';

	free (_s);
	return s;
    }

}

namespace Bmp
{
    bool
    URI::fragmentize (const std::string& _uri)
    {
	const char  *p;
	const char  *temp;
	char	    *uri;

	uri = strdup (_uri.c_str()); 

	/* Skip initial whitespace */
	p = uri;
	while (*p && ISSPACE ((int)*p))
	    ++p;
	if (!*p)	/* Error if it's just a string of space */
	    return false;

	/* Scheme */
	temp = p;

	 while (*p && *p != ':' && *p != '/' && *p != '?' && *p != '#')
	    ++p;
	if (*p == ':')
	    {
		this->scheme = dstr (g_strndup (temp, p - temp));
		++p;
	    }
	else	/* This char is NUL, /, ?, or # */
	    p = temp;

	/* Authority */
	if (*p == '/' && p[1] == '/')
	    {
		p += 2;

		/* Userinfo */
		temp = p;
		while (*p && *p != '@' && *p != '/' ) /* Look for @ or / */
		    ++p;
		if (*p == '@') /* Found userinfo */
		    {
			this->userinfo = dstr (g_strndup (temp, p - temp));
			++p;
		    }
		else
		    p = temp;

		/* Hostname */

		/* Check for no hostname at all (e.g. file://)  -- mderezynski */
		if (*p == '/')
		    goto path;

		/* Check for IPv6 canonical hostname in brackets */
		if (*p == '[')
		    {
			p++;  /* Skip [ */
			temp = p;
			while (*p && *p != ']') ++p;
			if ((p - temp) == 0)
			    goto error;
			this->hostname = dstr (g_strndup (temp, p - temp));
			if (*p)
			    p++;	/* Skip ] (if there) */
		    }
		else
		    {
			temp = p;
			while (*p && *p != '/' && *p != '?' && *p != '#' && *p != ':') ++p;
			if ((p - temp) == 0) 
			    goto error;
			this->hostname = dstr (g_strndup (temp, p - temp));
		    }

		/* Port */
		if (*p == ':')
		    {
			for (++p; isdigit ((int)*p); ++p)
			    this->port = this->port * 10 + (*p - '0');
		    }

	    }

    path:

	/* Path (we are liberal and won't check if it starts with /) */
	temp = p;
	while (*p && *p != '?' /* && *p != '#'*/)
	    ++p;
	if (p != temp)
	    this->path = dstr (g_strndup (temp, p - temp));

	/* Query */
	if (*p == '?')
	    {
		temp = p + 1;
		while (*p && *p != '#')
		    ++p;
		this->query = dstr (g_strndup (temp, p - temp));
	    }

	/* Fragment */
	if (*p == '#')
	    {
		++p;
		this->fragment = dstr (g_strdup (p));
	    }

	if (this->scheme.empty())
	{
	    this->scheme = std::string("file://");
	}

	free (uri);
	return true;

      error:
	return false;
    }

    URI::URI () : port (0) {}

    URI::URI (std::string str) : port (0)
    {
      if (!fragmentize (str)) throw Bmp::URI::PARSE_ERROR;
    }

    void
    URI::escape ()
    {
      this->userinfo  = dstr (field_escape (strdup (this->userinfo.c_str()), USERINFO_ESCAPE_MASK));
      this->path      = dstr (field_escape (strdup (this->path.c_str()),     PATH_ESCAPE_MASK));
      this->query     = dstr (field_escape (strdup (this->query.c_str()),    QUERY_ESCAPE_MASK));
      this->fragment  = dstr (field_escape (strdup (this->fragment.c_str()), FRAGMENT_ESCAPE_MASK));
    }

    void
    URI::unescape ()
    {
      if (!this->userinfo.empty())
	this->userinfo = dstr (field_unescape (strdup (this->userinfo.c_str())));

      if (!this->path.empty())
	this->path = dstr (field_unescape (strdup (this->path.c_str())));

      if (!this->query.empty())
	this->query = dstr (field_unescape (strdup (this->query.c_str())));

      if (!this->userinfo.empty())
	this->fragment = dstr (field_unescape (strdup (this->fragment.c_str())));
    }

    Bmp::URI::Protocol
    URI::get_protocol ()
    {

#define PR_HTTP "http"
#define PR_FILE "file"
#define PR_FTP  "ftp"
#define PR_CDDA "cdda"

	Bmp::URI::Protocol protocol = URI::PROTOCOL_UNKNOWN;

	if (!this->scheme.compare(PR_FILE))
	  {
	     protocol = URI::PROTOCOL_FILE; 
	  }
	else if (!this->scheme.compare(PR_HTTP))
	  {
	     protocol = URI::PROTOCOL_HTTP; 
	  }
	else if (!this->scheme.compare(PR_FTP))
	  {
	     protocol = URI::PROTOCOL_FTP; 
	  }
	else if (!this->scheme.compare(PR_CDDA))
	  {
	     protocol = URI::PROTOCOL_CDDA; 
	  }

	return protocol;
    }

    URI::operator std::string ()
    {
	GString* buffer = NULL;
	buffer = g_string_sized_new (16);

	if (!this->scheme.empty())
	    g_string_sprintfa (buffer, "%s:", this->scheme.c_str());

	if ((!this->scheme.compare("file")) || (!this->scheme.compare("cdda")) || (!this->scheme.compare("http")) || (!this->scheme.compare("query")))
	    g_string_append (buffer, "//");

	if (!this->userinfo.empty())
	    {
		buffer = g_string_append   (buffer,  this->userinfo.c_str());
		buffer = g_string_append_c (buffer, '@');
	    }

	/* Add brackets around the hostname if it's IPv6 */
	if (!this->hostname.empty())
	    {
		if (strchr (this->hostname.c_str(), ':') == NULL) 
		    buffer = g_string_append (buffer, this->hostname.c_str()); 
		else
		    g_string_sprintfa (buffer, "[%s]", this->hostname.c_str());
	    }

	if (this->port)
	    g_string_sprintfa (buffer, ":%d", this->port);

	if (!this->path.empty())
	    {
		if (*(this->path.c_str()) == '/' ||
		    !(!this->userinfo.empty() || !this->hostname.empty() || this->port))
		    g_string_append (buffer, this->path.c_str());
		else
		    g_string_sprintfa (buffer, "/%s", this->path.c_str());
	    }

	if (!this->query.empty())
	    g_string_sprintfa (buffer, "?%s", this->query.c_str());

	if (!this->fragment.empty())
	    g_string_sprintfa (buffer, "#%s", this->fragment.c_str());

	/* Free only GString not data contained, return the data instead */
	std::string rvstd (buffer->str);
	g_string_free (buffer, FALSE); 
	return rvstd;
    }
}

#if 0
/**
//  bmp_uri_new_fields
//  @scheme: scheme
//  @hostname: host name
//  @port: port
//  @path: path
//
//  Creates a #BmpURI from the fields.  This function uses the most
//  common fields.  Use bmp_uri_new_fields_all () to specify all
//  fields.
//
//  Returns: a new #BmpURI.
//
//*/
BmpURI*     
bmp_uri_new_fields (const char* scheme, const char* hostname, 
		     const gint port, const char* path)
{
    BmpURI* uri = NULL;

    uri = g_new0 (BmpURI, 1);
    if (scheme)
	uri->scheme = g_strdup (scheme);
    if (hostname)
	uri->hostname = g_strdup (hostname);
    uri->port = port;
    if (path)
	uri->path = g_strdup (path);

    return uri;
}


/**
//  bmp_uri_new_fields_all
//  @scheme: scheme
//  @userinfo: user info
//  @hostname: host name
//  @port: port
//  @path: path
//  @query: query
//  @fragment: fragment
//
//  Creates a #BmpURI from all fields.
//
//  Returns: a new #BmpURI.
//
//*/
BmpURI*
bmp_uri_new_fields_all (const char* scheme, const char* userinfo, 
			 const char* hostname, const gint port, 
			 const char* path, 
			 const char* query, const char* fragment)
{
    BmpURI* uri = NULL;

    uri = g_new0 (BmpURI, 1);
    if (scheme)
	uri->scheme = g_strdup (scheme);
    if (userinfo)
	uri->userinfo = g_strdup (userinfo);
    if (hostname)
	uri->hostname = g_strdup (hostname);
    uri->port = port;
    if (path)
	uri->path = g_strdup (path);
    if (query)
	uri->query = g_strdup (query);
    if (fragment)
	uri->fragment = g_strdup (fragment);

    return uri;
}

#define SAFESTRCMP(A,B) (((A)&&(B))?(strcmp ((A),(B))):((A)||(B)))
/**
//  bmp_uri_equal
//  @p1: a #BmpURI
//  @p2: another #BmpURI
//
//  Compares two #BmpURI's for equality.
//
//  Returns: TRUE if they are equal; FALSE otherwise.
//
//*/
gboolean
bmp_uri_equal (gconstpointer p1, gconstpointer p2)
{
    const BmpURI* uri1 = (const BmpURI*) p1;
    const BmpURI* uri2 = (const BmpURI*) p2;

    g_return_val_if_fail (uri1, FALSE);
    g_return_val_if_fail (uri2, FALSE);

    if (uri1->port == uri2->port &&
	!SAFESTRCMP (uri1->scheme, uri2->scheme) &&
	!SAFESTRCMP (uri1->userinfo, uri2->userinfo) &&
	!SAFESTRCMP (uri1->hostname, uri2->hostname) &&
	!SAFESTRCMP (uri1->path, uri2->path) &&
	!SAFESTRCMP (uri1->query, uri2->query) &&
	!SAFESTRCMP (uri1->fragment, uri2->fragment))
	return TRUE;

    return FALSE;
}

/**
//  bmp_uri_hash
//  @p: a #BmpURI
//
//  Creates a hash code for @p for use with GHashTable. 
//
//  Returns: hash code for @p.
//
//*/
guint
bmp_uri_hash (gconstpointer p)
{
    const BmpURI* uri = (const BmpURI*) p;
    guint h = 0;

    g_return_val_if_fail (uri, 0);

    if (uri->scheme)
	h = g_str_hash (uri->scheme);
    if (uri->userinfo)
	h ^= g_str_hash (uri->userinfo);
    if (uri->hostname)
	h ^= g_str_hash (uri->hostname);
    h ^= uri->port;
    if (uri->path)
	h ^= g_str_hash (uri->path);
    if (uri->query)
	h ^= g_str_hash (uri->query);
    if (uri->fragment)
	h ^= g_str_hash (uri->fragment);

    return h;
}

/* URI test functions */
gboolean
bmp_uri_test (const char *uri, BmpURITest test, gpointer compare)
{
    BmpURI *g_uri;

    g_return_val_if_fail (uri != NULL, FALSE);

    g_uri = 
      bmp_uri_new (uri); 

    bmp_uri_escape (g_uri);

    /* FIXME: Make use of GError */
    if (! g_uri)
	return FALSE;

    switch (test)
	{
	case BMP_URI_TEST_PROTOCOL:
		{
		    if (! strcmp (g_uri->scheme, (char*)compare))
			{ 
			    bmp_uri_delete (g_uri);
			    return TRUE;
			}
		    else
			{
			    bmp_uri_delete (g_uri);
			    return FALSE;
			}

		} break;

	case BMP_URI_TEST_HOSTNAME:
		{
		    if (! strcmp (g_uri->hostname, (char*)compare))
			{ 
			    bmp_uri_delete (g_uri);
			    return TRUE;
			}
		    else
			{
			    bmp_uri_delete (g_uri);
			    return FALSE;
			}

		} break;

	case BMP_URI_TEST_PATH:
		{
		    if (! strcmp (g_uri->path, (char*)compare))
			{
			    bmp_uri_delete (g_uri);
			    return TRUE;
			}
		    else
			{
			    bmp_uri_delete (g_uri);
			    return FALSE;
			}

		} break;

	case BMP_URI_TEST_PORT:
		{
		    if (g_uri->port == GPOINTER_TO_INT (compare))
			{ 
			    bmp_uri_delete (g_uri);
			    return TRUE;
			}
		    else
			{
			    bmp_uri_delete (g_uri);
			    return FALSE;
			}

		} break;

	default:
	    g_log (G_LOG_DOMAIN, G_LOG_LEVEL_WARNING,
		   "%s: Unknown g_uri_test () %d", G_STRFUNC, test);
	    break;

	} 

    bmp_uri_delete (g_uri);
    return FALSE;
}

#endif
