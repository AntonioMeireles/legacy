
#include <glibmm.h>

#include <bmp/database.hpp>
#include <bmp/library.hpp>
#include <bmp/uri++.hpp>

#include "tracklist.hpp"
#include "main.hpp"

namespace Bmp
{
  // class History

  PlaybackHistory::PlaybackHistory ()
      : mark (history.begin ())
  {}

  PlaybackHistory::~PlaybackHistory ()
  {}

  void
  PlaybackHistory::rewind ()
  {
      mark = history.begin ();
  }

  void
  PlaybackHistory::set (TrackGuid guid)
  {
      history.erase (mark, history.end ());
      history.push_back (guid);
  }

  void
  PlaybackHistory::append (TrackGuid guid)
  {
      history.push_back (guid);
  }

  void
  PlaybackHistory::prepend (TrackGuid guid)
  {
      history.push_front (guid);
  }

  void
  PlaybackHistory::back ()
  {
      --mark;
  }

  void
  PlaybackHistory::forward ()
  {
      ++mark;
  }

  void
  PlaybackHistory::clear ()
  {
      history.clear ();
      mark = history.begin ();
  }

  void
  PlaybackHistory::remove (TrackGuid guid)
  {
      History::iterator item = std::find (history.begin (), history.end (), guid);
      history.erase (item);
  }

  // class Tracklist

  void
  Tracklist::row_inserted (const Gtk::TreeModel::Path     &path,
                           const Gtk::TreeModel::iterator &iter)
  {
      TrackGuid guid = guid_base++;
      (*iter)[tracklist_columns.guid] = guid;

      Gtk::TreeModel::RowReference reference (playlist, path);
      guid_row_map.insert (std::make_pair (guid, reference));
  }

  unsigned int
  Tracklist::insert_rows (const UriList &uris,
                          unsigned int   index)
  {
      Gtk::TreeModel::Path path;
      path.append_index (index);
      Gtk::TreeModel::iterator model_iter = playlist->get_iter (path);

      for (UriList::const_iterator iter = uris.begin (), end = uris.end ();
           iter != end;
           ++iter)
      {
	  Bmp::URI uri (*iter);
	  if (bmp_play_engine->is_audio_file (*iter) || (uri.get_protocol () == Bmp::URI::PROTOCOL_CDDA))
	  {
	      model_iter = playlist->insert_after (model_iter);
              DB::DataRow row = library->get_metadata (*iter);
	      if (row.find (library->get_metadatum_id (Library::DATUM_ARTIST)) != row.end ())
              model_iter->set_value (tracklist_columns.artist,
                                     Glib::ustring (boost::get<std::string> (row.find (library->get_metadatum_id (Library::DATUM_ARTIST))->second)));
	      if (row.find (library->get_metadatum_id (Library::DATUM_ALBUM)) != row.end ())
              model_iter->set_value (tracklist_columns.album,
                                     Glib::ustring (boost::get<std::string> (row.find (library->get_metadatum_id (Library::DATUM_ALBUM))->second)));
	      if (row.find (library->get_metadatum_id (Library::DATUM_TRACK)) != row.end ())
              model_iter->set_value (tracklist_columns.track,
                                     boost::get<int> (row.find (library->get_metadatum_id (Bmp::Library::DATUM_TRACK))->second));
	      if (row.find (library->get_metadatum_id (Library::DATUM_TITLE)) != row.end ())
              model_iter->set_value (tracklist_columns.title,
                                     Glib::ustring (boost::get<std::string> (row.find (library->get_metadatum_id (Library::DATUM_TITLE))->second)));
	      if (row.find (library->get_metadatum_id (Library::DATUM_GENRE)) != row.end ())
              model_iter->set_value (tracklist_columns.genre,
                                     Glib::ustring (boost::get<std::string> (row.find (library->get_metadatum_id (Library::DATUM_GENRE))->second)));
	      if (row.find (library->get_metadatum_id (Library::DATUM_DATE)) != row.end ())
              model_iter->set_value (tracklist_columns.date,
                                     boost::get<int> (row.find (library->get_metadatum_id (Library::DATUM_DATE))->second));
	      if (row.find (library->get_metadatum_id (Library::DATUM_TIME)) != row.end ())
              model_iter->set_value (tracklist_columns.time,
                                     boost::get<int> (row.find (library->get_metadatum_id (Library::DATUM_TIME))->second));
	      if (row.find (library->get_metadatum_id (Library::DATUM_LOCATION)) != row.end ())
              model_iter->set_value (tracklist_columns.uri,
                                     Glib::ustring (boost::get<std::string> (row.find (library->get_metadatum_id (Library::DATUM_LOCATION))->second)));

	      ++index;
	  }
	  else
	  {
	      Bmp::VFS::Handle handle = Bmp::VFS::Handle::create (std::string(uri));
	      Bmp::Util::FileList list;

	      if (Glib::file_test (uri, Glib::FILE_TEST_IS_DIR))
	      {
		  Bmp::Util::collect_path (uri, list);
	      }
	      else
	      {
		try { vfs->read (handle, list); } catch (...) { return index; }
	      }

	      for (Bmp::Util::FileList::const_iterator i = list.begin ();
		   i != list.end (); 
		   ++i)
	      {
		  model_iter = playlist->insert_after (model_iter);
		  DB::DataRow row = library->get_metadata (*i);
		  if (row.find (library->get_metadatum_id (Library::DATUM_ARTIST)) != row.end ())
		  model_iter->set_value (tracklist_columns.artist,
					 Glib::ustring (boost::get<std::string> (row.find (library->get_metadatum_id (Library::DATUM_ARTIST))->second)));
		  if (row.find (library->get_metadatum_id (Library::DATUM_ALBUM)) != row.end ())
		  model_iter->set_value (tracklist_columns.album,
					 Glib::ustring (boost::get<std::string> (row.find (library->get_metadatum_id (Library::DATUM_ALBUM))->second)));
		  if (row.find (library->get_metadatum_id (Library::DATUM_TRACK)) != row.end ())
		  model_iter->set_value (tracklist_columns.track,
					 boost::get<int> (row.find (library->get_metadatum_id (Bmp::Library::DATUM_TRACK))->second));
		  if (row.find (library->get_metadatum_id (Library::DATUM_TITLE)) != row.end ())
		  model_iter->set_value (tracklist_columns.title,
					 Glib::ustring (boost::get<std::string> (row.find (library->get_metadatum_id (Library::DATUM_TITLE))->second)));
		  if (row.find (library->get_metadatum_id (Library::DATUM_GENRE)) != row.end ())
		  model_iter->set_value (tracklist_columns.genre,
					 Glib::ustring (boost::get<std::string> (row.find (library->get_metadatum_id (Library::DATUM_GENRE))->second)));
		  if (row.find (library->get_metadatum_id (Library::DATUM_DATE)) != row.end ())
		  model_iter->set_value (tracklist_columns.date,
					 boost::get<int> (row.find (library->get_metadatum_id (Library::DATUM_DATE))->second));
		  if (row.find (library->get_metadatum_id (Library::DATUM_TIME)) != row.end ())
		  model_iter->set_value (tracklist_columns.time,
					 boost::get<int> (row.find (library->get_metadatum_id (Library::DATUM_TIME))->second));
		  if (row.find (library->get_metadatum_id (Library::DATUM_LOCATION)) != row.end ())
		  model_iter->set_value (tracklist_columns.uri,
					 Glib::ustring (boost::get<std::string> (row.find (library->get_metadatum_id (Library::DATUM_LOCATION))->second)));

		  ++index;
	      }
	  }
      }

      return index;
  }

  Tracklist::Tracklist ()
  {
      playlist = Gtk::ListStore::create (tracklist_columns);
      playlist->signal_row_inserted ().connect (sigc::mem_fun (this, &Tracklist::row_inserted));
      map = library->get_map ();
  }

  Tracklist::~Tracklist ()
  {}

  unsigned long Tracklist::guid_base = 0;

} // Bmp namespace

