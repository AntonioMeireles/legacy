#ifndef BMP_XDB_HPP
#define BMP_XDB_HPP

#include <gdk/gdk.h>
#include <gdk/gdkx.h>
#include <gtk/gtk.h>

void
xdb_add_filter_for_window (GtkWindow *window, const gchar *filtername, gboolean verbose);


#endif // BMP_XDB_HPP
