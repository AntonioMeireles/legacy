/*  BMPx - The Dumb Music Player
 *  Copyright (C) 2005 BMPx development team.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 *  $Id$
 *
 * The BMPx project hereby grant permission for non-gpl compatible GStreamer
 * plugins to be used and distributed together with GStreamer and BMPx. This
 * permission are above and beyond the permissions granted by the GPL license
 * BMPx is covered by.
 */


#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>

#include <SDL/SDL.h>
#include <SDL/SDL_thread.h>

#include <gtk/gtk.h>
#include <libvisual/libvisual.h>

#include <config.h>

typedef struct {

	const gchar *last_plugin;	/**< Name of the last plugin runned,
				  with length < OPTIONS_MAX_NAME_LEN. */

	gchar *morph_plugin; /**< */
	
	gchar *icon_file;	/**< Absolute path of the icon file,
				  with length < OPTIONS_MAX_ICON_PATH_LEN. */
	int width;		/**< Width in pixels. */
	int height;		/**< Height in pixels. */
	int fps;		/**< Maximum frames per second. */
	int depth;		/**< Color depth. */
	gboolean fullscreen;	/**< Say if we are in fullscreen or not. */

	gboolean gl_plugins_only;	/**< Only Gl plugins must be showed */
	gboolean non_gl_plugins_only;	/**< Only non GL plugins must be showed */
	gboolean all_plugins_enabled;	/**< All plugins must be showed */
	gboolean random_morph;		/**< Morph plugin will be selected randomly on
					  every switch. */

} Options;

/* SDL variables */
static SDL_Surface *screen = NULL;
static SDL_Color sdlpal[256];
static SDL_Thread *render_thread;
static SDL_mutex *pcm_mutex;
static SDL_Surface *icon;

/* Libvisual and visualisation variables */
static VisVideo *video;
static VisPalette *pal;

static char song_name[1024];
static const char *cur_lv_plugin = NULL;

static VisBin *bin = NULL;
static VisSongInfo *songinfo;
static Options *options;
static int gl_plug = 0;
static int16_t xmmspcm[2][512];

/* Thread state variables */
static int visual_running = 0;
static int visual_stopped = 1;

static GTimer *fpstimer = NULL;

/* Public API */
void lv_bmp_init (void);
void lv_bmp_run (void);
void lv_bmp_stop (void);
void lv_bmp_cleanup (void);
void lv_bmp_render_pcm (int16_t data[2][512]);

static int sdl_quit (void);
static void sdl_set_pal (void);
static void sdl_draw (SDL_Surface *screen);
static int sdl_create (int width, int height);
static int sdl_event_handle (void);

static int visual_upload_callback (VisInput *input, VisAudio *audio, void *private);
static int visual_resize (int width, int height);
static int visual_initialize (int width, int height);
static int visual_render (void*);

void
lv_bmp_init (void)
{
        char	 **argv;
        int	   argc;
	int	   ret;
	gchar	  *msg;
	GtkWidget *msgwin;

	options = g_new0 (Options,1);
	//Temporarily:
	options->last_plugin = g_strdup("madspin");
	options->depth = gdk_visual_get_best_depth();
	options->fps = 15;
	options->width = 320;
	options->height = 240;

	fpstimer = g_timer_new ();

	if (!visual_is_initialized ()) {
	        argv = g_malloc (sizeof(char*));
	        argv[0] = g_strdup ("BMPx lv module");
        	argc = 1;

		visual_init (&argc, &argv);

        	g_free (argv[0]);
	        g_free (argv);
	}

	if (SDL_Init (SDL_INIT_VIDEO) < 0) {
		return;
	}

	pcm_mutex = SDL_CreateMutex ();

	cur_lv_plugin = options->last_plugin;
	if (!(visual_actor_valid_by_name (cur_lv_plugin))) {
		return;
	}

	SDL_WM_SetCaption ("BMPx Visualisation", "BMPx Visualisation");

	if (!cur_lv_plugin)
		return;
}

void
lv_bmp_run (void)
{
	SDL_WM_SetCaption ("BMPx Visualisation", "BMPx Visualisation");
	render_thread = SDL_CreateThread ((void *) visual_render, NULL);
}

void
lv_bmp_stop (void)
{
	if (!visual_running)
	    return;

	SDL_KillThread (render_thread);
	sdl_quit ();
	visual_running = 0;
	visual_stopped = 1;
}

void
lv_bmp_toggle (GtkToggleAction *action, gpointer data)
{
	if (gtk_toggle_action_get_active (action))
	      lv_bmp_run ();
	else
	      lv_bmp_stop ();
}

void
lv_bmp_cleanup (void)
{
	visual_log (VISUAL_LOG_DEBUG, "entering cleanup...");
	visual_running = 0;

	SDL_WaitThread (render_thread, NULL);

	render_thread = NULL;
	visual_stopped = 1;

	visual_log (VISUAL_LOG_DEBUG, "calling SDL_DestroyMutex()");
	SDL_DestroyMutex (pcm_mutex);
	
	pcm_mutex = NULL;

	/*
	 * WARNING This must be synchronized with config module.
	 */

	options->last_plugin = cur_lv_plugin;

	if (icon != NULL)
		SDL_FreeSurface (icon);

	visual_log (VISUAL_LOG_DEBUG, "destroying VisBin...");
	visual_object_unref (VISUAL_OBJECT (bin));

	visual_log (VISUAL_LOG_DEBUG, "calling sdl_quit()");
	sdl_quit ();
	
	visual_log (VISUAL_LOG_DEBUG, "calling visual_quit()");
	visual_quit ();
}

void
lv_bmp_render_pcm (int16_t data[2][512])
{
	if (visual_running == 1) {
		SDL_mutexP (pcm_mutex);
                memcpy (xmmspcm, data, sizeof(int16_t)*2*512);
		strncpy (song_name, "DUMMY", 6);
		SDL_mutexV (pcm_mutex);
	}
}

static int sdl_quit ()
{
	visual_log (VISUAL_LOG_DEBUG, "Calling SDL_FreeSurface()");
	if (screen != NULL)
		SDL_FreeSurface (screen);

	screen = NULL;

	visual_log (VISUAL_LOG_DEBUG, "sdl_quit: calling SDL_Quit()");
	/*
	 * FIXME this doesn't work!
	 */
	SDL_Quit ();
	
	visual_log (VISUAL_LOG_DEBUG, "Leaving...");
	return 0;
}

static void sdl_set_pal ()
{
	int i;

	visual_log_return_if_fail (screen != NULL);

	if (pal != NULL) {
		for (i = 0; i < 256; i ++) {
			sdlpal[i].r = pal->colors[i].r;
			sdlpal[i].g = pal->colors[i].g;
			sdlpal[i].b = pal->colors[i].b;
		}
		SDL_SetColors (screen, sdlpal, 0, 256);
	}
}

static void sdl_draw (SDL_Surface *screen)
{
	visual_log_return_if_fail (screen != NULL);
	SDL_Flip (screen);
}

static int sdl_create (int width, int height)
{
	const SDL_VideoInfo *videoinfo;
	int videoflags;

	if (screen != NULL)
		SDL_FreeSurface (screen);

        visual_log (VISUAL_LOG_DEBUG, "sdl_create video->bpp %d", video->bpp);
        visual_log (VISUAL_LOG_DEBUG, gl_plug ? "OpenGl plugin at create: yes" : "OpenGl plugin at create: no");

	if (gl_plug == 1) {
		videoinfo = SDL_GetVideoInfo ();

		if (videoinfo == 0) {
			visual_log (VISUAL_LOG_CRITICAL, ("Could not get video info"));
			return -1;
		}

		videoflags = SDL_OPENGL | SDL_GL_DOUBLEBUFFER | SDL_HWPALETTE | SDL_RESIZABLE;

		if (videoinfo->hw_available)
			videoflags |= SDL_HWSURFACE;
		else
			videoflags |= SDL_SWSURFACE;

		if (videoinfo->blit_hw)
			videoflags |= SDL_HWACCEL;

		SDL_GL_SetAttribute (SDL_GL_DOUBLEBUFFER, 1);

		visual_log (VISUAL_LOG_DEBUG, "Setting video mode %dx%d", width, height);
		screen = SDL_SetVideoMode (width, height, 16, videoflags);
	} else {
		visual_log (VISUAL_LOG_DEBUG, "Setting video mode %dx%d", width, height);
		screen = SDL_SetVideoMode (width, height, video->bpp * 8, SDL_RESIZABLE);
	}

	SDL_EnableKeyRepeat (SDL_DEFAULT_REPEAT_DELAY / 4, SDL_DEFAULT_REPEAT_INTERVAL / 4);

	visual_video_set_buffer (video, screen->pixels);
        visual_log (VISUAL_LOG_DEBUG, "pointer to the pixels: %p", screen->pixels);

	visual_video_set_pitch (video, screen->pitch);
        visual_log (VISUAL_LOG_DEBUG, "pitch: %d", video->pitch);

	return 0;
}

static int visual_initialize (int width, int height)
{
	VisInput *input;
	VisVideoDepth depth;
        int ret;

	bin = visual_bin_new ();
	visual_bin_set_supported_depth (bin, VISUAL_VIDEO_DEPTH_ALL);
//	visual_bin_set_preferred_depth (bin, VISUAL_BIN_DEPTH_LOWEST);

	depth = visual_video_depth_enum_from_value (options->depth);
	if (depth == VISUAL_VIDEO_DEPTH_ERROR)
		depth = VISUAL_VIDEO_DEPTH_24BIT;
	options->depth = depth;

	video = visual_video_new ();

	ret = visual_video_set_depth (video, depth);
        if (ret < 0) {
                visual_log (VISUAL_LOG_CRITICAL, ("Cannot set video depth"));
                return -1;
        }
	visual_video_set_dimension (video, width, height);

        ret = visual_bin_set_video (bin, video);
	if (ret < 0) {
                visual_log (VISUAL_LOG_CRITICAL, ("Cannot set video"));
                return -1;
        }
	/*visual_bin_connect_by_names (bin, cur_lv_plugin, NULL);*/
	visual_bin_connect_by_names (bin, cur_lv_plugin, "none");

	if (visual_bin_get_depth (bin) == VISUAL_VIDEO_DEPTH_GL) {
		visual_video_set_depth (video, VISUAL_VIDEO_DEPTH_GL);
		gl_plug = 1;
	} else {
		gl_plug = 0;
	}

	visual_log (VISUAL_LOG_DEBUG, gl_plug ? "OpenGl plugin: yes" : "OpenGl plugin: no");
	ret = sdl_create (width, height);
	if (ret < 0) {
                return -1;
        }
	
	/* Called so the flag is set to FALSE, seen we create the initial environment here */
	visual_bin_depth_changed (bin);
	
	input = visual_bin_get_input (bin);
	ret = visual_input_set_callback (input, visual_upload_callback, NULL);
	if (ret < 0) {
                visual_log (VISUAL_LOG_CRITICAL, ("Cannot set input plugin callback"));
                return -1;
        }        
	
	visual_bin_switch_set_style (bin, VISUAL_SWITCH_STYLE_MORPH);
	visual_bin_switch_set_automatic (bin, TRUE);
	visual_bin_switch_set_mode (bin, VISUAL_MORPH_MODE_TIME);
	visual_bin_switch_set_time (bin, 4, 0);

	visual_bin_realize (bin);
	visual_bin_sync (bin, FALSE);

	return 0;
}

static int visual_upload_callback (VisInput *input, VisAudio *audio, void *private_data)
{
	int i;

	visual_log_return_val_if_fail (audio != NULL, -1);

	for (i = 0; i < 512; i++) {
		audio->plugpcm[0][i] = xmmspcm[0][i];
		audio->plugpcm[1][i] = xmmspcm[1][i];
	}

	visual_audio_analyze (audio);

	return 0;
}

static int visual_resize (int width, int height)
{
	visual_video_set_dimension (video, width, height);

	sdl_create (width, height);
	
	options->width = width;
	options->height = height;

	visual_bin_sync (bin, FALSE);

	return 0;
}

static int visual_render (void *arg)
{
	visual_running = 1;
	visual_stopped = 0;
        long render_time, now;
        long frame_length;
        long idle_time;
	long frames;
	int ret;

	ret = visual_initialize (options->width, options->height);
        if (ret < 0) {
                visual_log (VISUAL_LOG_CRITICAL, ("Cannot initialize plugin's visual stuff"));
		return -1;
	}

        frame_length = (1.0 / options->fps) * 1000;
	frames = 0;
	while (visual_running == 1) {

		gulong  ms;
		gdouble sec;

		/* Update songinfo */
		songinfo = visual_actor_get_songinfo (visual_bin_get_actor (bin));
		visual_songinfo_set_type (songinfo, VISUAL_SONGINFO_TYPE_SIMPLE);
		visual_songinfo_set_simple_name (songinfo, song_name);

		if (g_timer_elapsed (fpstimer, &ms) < 0.04)
		  {
		      usleep (1000);
		      continue;
		  }

		g_timer_reset (fpstimer);
		  	    		

		if ((SDL_GetAppState () & SDL_APPACTIVE) == FALSE) {
			usleep (100000);
		} else {
			/* On depth change */
			if (visual_bin_depth_changed (bin) == TRUE) {
				if (SDL_MUSTLOCK (screen) == SDL_TRUE)
					SDL_LockSurface (screen);

				visual_video_set_buffer (video, screen->pixels);
				if (visual_bin_get_depth (bin) == VISUAL_VIDEO_DEPTH_GL)
					gl_plug = 1;
				else
					gl_plug = 0;
			
				sdl_create (options->width, options->height);
				visual_bin_sync (bin, TRUE);

				if (SDL_MUSTLOCK (screen) == SDL_TRUE)
					SDL_UnlockSurface (screen);
			}
                        
			render_time = SDL_GetTicks ();
			if (gl_plug == 1) {
				visual_bin_run (bin);

				SDL_GL_SwapBuffers ();
			} else {
				if (SDL_MUSTLOCK (screen) == SDL_TRUE)
					SDL_LockSurface (screen);

				visual_video_set_buffer (video, screen->pixels);
				visual_bin_run (bin);

				if (SDL_MUSTLOCK (screen) == SDL_TRUE)
					SDL_UnlockSurface (screen);

				pal = visual_bin_get_palette (bin);
				sdl_set_pal ();

				sdl_draw (screen);
			}

			now = SDL_GetTicks ();
//                        if ((idle_time = (now - render_time)) < frame_length)
//			    usleep (idle_time*900);
		}

		sdl_event_handle ();

		if (options->fullscreen && !(screen->flags & SDL_FULLSCREEN))
                        SDL_WM_ToggleFullScreen (screen);
		frames++;
		/*
		 * Sometime we actualize the frame_length, because we let user
		 * choose maximum FPS dinamically.
		 */
#if 0
		if (frames > options->fps) {
			frames = 0;
	        	frame_length = (1.0 / options->fps) * 1000;
		}
#endif
	}

	visual_stopped = 1;
	return 0;
}

static int sdl_event_handle ()
{
	SDL_Event event;
	VisEventQueue *vevent;
	const char *next_plugin;

	while (SDL_PollEvent (&event)) {
		vevent = visual_plugin_get_eventqueue (visual_actor_get_plugin (visual_bin_get_actor (bin)));
		
		switch (event.type) {

			case SDL_VIDEORESIZE:
				visual_resize (event.resize.w, event.resize.h);
				break;

			case SDL_MOUSEMOTION:
				visual_event_queue_add_mousemotion (vevent, event.motion.x, event.motion.y);
				break;

			case SDL_MOUSEBUTTONDOWN:
				visual_event_queue_add_mousebutton (vevent, event.button.button, VISUAL_MOUSE_DOWN,
						event.button.x, event.button.y);
				break;

			case SDL_MOUSEBUTTONUP:
				visual_event_queue_add_mousebutton (vevent, event.button.button, VISUAL_MOUSE_UP,
						event.button.x, event.button.y);
				break;

			case SDL_QUIT:
				GDK_THREADS_ENTER ();
				// gtk_idle_add (disable_func, NULL);
				GDK_THREADS_LEAVE ();
				break;
						
			default: /* to avoid warnings */ /* hah synap -- deadchip */
				break;
		}
	}

	return 0;
}
