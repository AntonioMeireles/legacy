#ifndef _LIBVISUAL_H_
#define _LIBVISUAL_H_

#include <gtk/gtk.h>

/* Public API */
void lv_bmp_init (void);
void lv_bmp_run (void);
void lv_bmp_stop (void);

void lv_bmp_toggle (GtkToggleAction *action, gpointer data);

void lv_bmp_cleanup (void);
void lv_bmp_render_pcm (int16_t data[2][512]);

#endif /* _LIBVISUAL_H_ */


