//  BMPx - The Dumb Music Player
//  Copyright (C) 2005-2006 BMPx development team.
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
//
//  --
//
//  The BMPx project hereby grants permission for non GPL-compatible GStreamer
//  plugins to be used and distributed together with GStreamer and BMPx. This
//  permission is above and beyond the permissions granted by the GPL license
//  BMPx is covered by.

#include <config.h>
#include "ui_dialog_about.hpp"

#include <glib/gi18n.h>
#include <gdk/gdk.h>
#include <gdk/gdkkeysyms.h>

#include "main.hpp"

#include "ui_util.hpp"
#include "wm.hpp"

namespace Bmp
{

  AboutDialog::AboutDialog ()
      : has_alpha (false)
  {
      set_title (_("About BMPx"));
      bmp_window_set_icon_list (GTK_WIDGET (gobj ()), "player");

      set_position (Gtk::WIN_POS_CENTER);
      set_resizable (false);

      set_type_hint (Gdk::WINDOW_TYPE_HINT_DIALOG);
      set_decorated (false);

      set_app_paintable (true);
      add_events (Gdk::ALL_EVENTS_MASK);

      Glib::RefPtr<Gdk::Screen> screen = Gdk::Screen::get_default ();
      Glib::RefPtr<Gdk::Colormap> colormap;

      Glib::RefPtr<Gdk::Visual> visual = Util::screen_get_rgba_visual (screen);
      if (visual)
      {
          colormap = Util::screen_get_rgba_colormap (screen);
          has_alpha = true;
      }
      else
      {
          has_alpha = false;
      }

      const gchar *filename = DATA_DIR G_DIR_SEPARATOR_S "images" G_DIR_SEPARATOR_S "about-logo.png";
      image = Gdk::Pixbuf::create_from_file (filename);

      set_size_request (image->get_width (), image->get_height ());

      if (has_alpha)
      {
          set_colormap (colormap);
      }
      else
      {
          Glib::RefPtr<Gdk::Pixmap> mask_pixmap_window1, mask_pixmap_window2;
          Glib::RefPtr<Gdk::Bitmap> mask_bitmap_window1, mask_bitmap_window2;

          image->render_pixmap_and_mask (mask_pixmap_window1, mask_bitmap_window1, 0);
          image->render_pixmap_and_mask (mask_pixmap_window2, mask_bitmap_window2, 128);

          shape_combine_mask (mask_bitmap_window2, 0, 0);
      }
  }

  bool
  AboutDialog::on_key_press_event (GdkEventKey *event)
  {
      if (event->keyval == GDK_Escape)
          hide ();

      return false;
  }

  bool
  AboutDialog::on_button_press_event (GdkEventButton *event)
  {
      if (event->button == 1)
          hide ();

      return false;
  }

  bool
  AboutDialog::on_expose_event (GdkEventExpose *event)
  {
      cairo_t *cr = gdk_cairo_create (get_window ()->gobj ());

      cairo_set_operator (cr, CAIRO_OPERATOR_SOURCE);

      if (has_alpha)
      {
          cairo_set_source_rgba (cr, .0, .0, .0, .0);
          cairo_paint (cr);
      }

      gdk_cairo_set_source_pixbuf (cr, image->gobj (), 0, 0);
      cairo_paint (cr);

      cairo_destroy (cr);

      return false;
  }

  bool
  AboutDialog::on_delete_event (GdkEventAny *event)
  {
      hide ();
      return true;
  }

} // namespace Bmp
