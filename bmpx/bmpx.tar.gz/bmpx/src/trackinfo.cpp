//  BMPx - The Dumb Music Player
//  Copyright (C) 2005 BMPx development team.
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
//
//  --
//
//  The BMPx project hereby grants permission for non-GPL compatible GStreamer
//  plugins to be used and distributed together with GStreamer and BMPx. This
//  permission is above and beyond the permissions granted by the GPL license
//  BMPx is covered by.

#include <config.h>

#include <glibmm.h>
#include <gtkmm.h>
#include <libglademm.h>
#include <cstring>

#include <iostream>
#include <string>
#include <boost/format.hpp>

#include <sys/time.h>
#include <sys/types.h>
#include <unistd.h>

#include <bmp/util.h>
#include <bmp/uri++.hpp>
#include <bmp/database.hpp>
#include <bmp/library.hpp>

#include <bmp/file_utils.hpp>

#include "ui_util.hpp"
#include "trackinfo.hpp"
#include "amazon.hpp"

#include "main.hpp"
#include "paths.hpp"

namespace Bmp
{

  TrackInfo *
  TrackInfo::create ()
  {
      const std::string path = DATA_DIR "/glade/dialog_track_info.glade";

      Glib::RefPtr<Gnome::Glade::Xml> glade_xml = Gnome::Glade::Xml::create (path);

      TrackInfo *track_info = 0;
      glade_xml->get_widget_derived ("dialog_file_information", track_info);

      return track_info;
  }

  TrackInfo::TrackInfo (BaseObjectType                        *cobject,
                        const Glib::RefPtr<Gnome::Glade::Xml> &xml)
      : Gtk::Window (cobject),
        fi_ok (0),
        fi_image (0),
        path_image_default (DATA_DIR "/images/audio.png"),
        ref_xml (xml)
  {

#if 0
      bmp_window_set_icon_list (GTK_WIDGET(self->window), "player");
#endif

      ref_xml->get_widget ("fi_ok", fi_ok);
      fi_ok->signal_clicked ().connect (sigc::mem_fun (this, &Bmp::TrackInfo::ok_clicked));

      ref_xml->get_widget ("fi_image", fi_image);
      fi_image->set (path_image_default);

  }

  void
  TrackInfo::ok_clicked ()
  {
      hide ();
  }

  void
  TrackInfo::entry_clear (const std::string &widget)
  {
      Gtk::Entry *entry = 0;

      ref_xml->get_widget (widget, entry);
      entry->set_text ("");
  }

  void
  TrackInfo::label_clear (const std::string &widget)
  {
      Gtk::Label *label = 0;

      ref_xml->get_widget (widget, label);
      label->set_text ("");
  }

  void
  TrackInfo::entry_set_text (Bmp::DB::DataRow	  &tuple,
                             const std::string	  &widget,
                             Bmp::Library::Datum  datum)
  {
      const Bmp::DB::ValueVariant& variant = tuple[library->get_metadatum_id (datum)];
      Gtk::Entry  *entry = 0;
      std::stringstream  text;

      ref_xml->get_widget (widget, entry);
      switch (Bmp::DB::ValueType(variant.which()))
      {
          case Bmp::DB::VALUE_TYPE_INT:
              text << boost::get<int>(variant); 
              break;

          case Bmp::DB::VALUE_TYPE_STRING:
	      text << boost::get<std::string>(variant);
	      break;
      }

      entry->set_sensitive (text.str().length () > 0);

      if (datum == Bmp::Library::DATUM_LOCATION)
      {
	  Bmp::URI uri (text.str());
	  uri.unescape ();
          entry->set_text (std::string(uri));
      }
      else
      {
          entry->set_text (text.str());
      }
  }

  void
  TrackInfo::label_set_text (Bmp::DB::DataRow     &tuple,
                             const std::string    &widget,
                             Bmp::Library::Datum  datum,
                             const std::string    &append)
  {
      const Bmp::DB::ValueVariant& variant = tuple[library->get_metadatum_id (datum)];
      Gtk::Label	*label;
      std::stringstream  text;

      ref_xml->get_widget (widget, label);

      switch (Bmp::DB::ValueType(variant.which()))
      {
          case Bmp::DB::VALUE_TYPE_INT:
              text << boost::get<int>(variant); 
              break;

          case Bmp::DB::VALUE_TYPE_STRING:
	      text << boost::get<std::string>(variant);
	      break;
      }

      label->set_sensitive (text.str().length () > 0);
      label->set_text (text.str() + " " + append);
  }

  void
  TrackInfo::clear ()
  {
      entry_clear ("entry_file");
      entry_clear ("entry_artist");
      entry_clear ("entry_album");
      entry_clear ("entry_title");
      entry_clear ("entry_genre");
      entry_clear ("entry_date");
      entry_clear ("entry_comment");
      entry_clear ("entry_track");

      label_clear ("label_bitrate");

      fi_image->set (path_image_default);
  }

  void
  TrackInfo::show (std::string uri)
  {
      clear ();

      Bmp::DB::DataRow row;

      try { row = library->get_metadata (uri); }
      catch (...) { return; }

      if (row.empty()) return;

      set_size_request (600, -1);
      set_keep_above (mcs->key_get<bool>("bmp","keep-above"));
      set_sensitive (false);

      // NOTE: gcc have problems with just 'show ();'
      Gtk::Window::show ();

      entry_set_text (row, "entry_file",    Bmp::Library::DATUM_LOCATION);
      entry_set_text (row, "entry_artist",  Bmp::Library::DATUM_ARTIST);
      entry_set_text (row, "entry_album",   Bmp::Library::DATUM_ALBUM);
      entry_set_text (row, "entry_title",   Bmp::Library::DATUM_TITLE);
      entry_set_text (row, "entry_genre",   Bmp::Library::DATUM_GENRE);
      entry_set_text (row, "entry_date",    Bmp::Library::DATUM_DATE);
      entry_set_text (row, "entry_comment", Bmp::Library::DATUM_COMMENT);
      entry_set_text (row, "entry_track",   Bmp::Library::DATUM_TRACK);
      label_set_text (row, "label_bitrate", Bmp::Library::DATUM_BITRATE, "kbit/s");

#ifdef USE_AMAZON
      Glib::RefPtr<Gdk::Pixbuf> cover;

      try {
	cover = Bmp::get_cover (uri);
	fi_image->set (cover);
      } catch (...) {}
#endif

      set_sensitive (true);
  }

} // namespace Bmp
