#include <config.h>
#include "ui_splash.hpp"

#include <glib/gi18n.h>
#include <gdk/gdk.h>

#include "main.hpp"
#include "ui_util.hpp"

#if 0
#define BAR_X		(10)
#define BAR_Y		(splash_height - 38)
#define BAR_WIDTH	(splash_width - 20)
#define BAR_HEIGHT	(15)
#endif

namespace Bmp
{

  SplashWindow::SplashWindow ()
      : has_alpha (false)
  {
      set_title (_("BMP Starting..."));
      bmp_window_set_icon_list (GTK_WIDGET (gobj ()), "player");

      set_position (Gtk::WIN_POS_CENTER);
      set_resizable (false);

      set_type_hint (Gdk::WINDOW_TYPE_HINT_SPLASHSCREEN);
      set_decorated (false);

      set_app_paintable (true);
      add_events (Gdk::ALL_EVENTS_MASK);

      Glib::RefPtr<Gdk::Screen> screen = Gdk::Screen::get_default ();
      Glib::RefPtr<Gdk::Colormap> colormap;

      Glib::RefPtr<Gdk::Visual> visual = Util::screen_get_rgba_visual (screen);
      if (visual)
      {
          colormap = Util::screen_get_rgba_colormap (screen);
          has_alpha = true;
      }
      else
      {
          has_alpha = false;
      }

      const gchar *filename = DATA_DIR G_DIR_SEPARATOR_S "images" G_DIR_SEPARATOR_S "splash.png";
      image = Gdk::Pixbuf::create_from_file (filename);

      set_size_request (image->get_width (), image->get_height ());

      if (has_alpha)
      {
          set_colormap (colormap);
      }
      else
      {
          Glib::RefPtr<Gdk::Pixmap> mask_pixmap_window1, mask_pixmap_window2;
          Glib::RefPtr<Gdk::Bitmap> mask_bitmap_window1, mask_bitmap_window2;

          image->render_pixmap_and_mask (mask_pixmap_window1, mask_bitmap_window1, 0);
          image->render_pixmap_and_mask (mask_pixmap_window2, mask_bitmap_window2, 128);

          shape_combine_mask (mask_bitmap_window2, 0, 0);
      }
  }

  void
  SplashWindow::on_realize ()
  {
      Gtk::Window::on_realize ();

      get_window ()->raise ();
  }

  bool
  SplashWindow::on_expose_event (GdkEventExpose *event)
  {
      cairo_t *cr;

      cr = gdk_cairo_create (get_window ()->gobj ());

      cairo_set_operator (cr, CAIRO_OPERATOR_SOURCE);

      if (has_alpha)
      {
          cairo_set_source_rgba (cr, .0, .0, .0, .0);
          cairo_paint (cr);
      }

      gdk_cairo_set_source_pixbuf (cr, image->gobj (), 0, 0);
      cairo_paint (cr);

      cairo_destroy (cr);

      return false;
  }

} // namespace Bmp
