#ifndef _XML_H_
#define _XML_H_

#include <glib.h>
#include <libxml/tree.h>
#include <libxml/parser.h>
#include <libxml/xmlreader.h>
#include <libxml/xpath.h>
#include <libxml/xpathInternals.h>

G_BEGIN_DECLS

xmlXPathObjectPtr
xml_execute_xpath_expression (xmlDocPtr doc, const xmlChar * xpathExpr,
                              const xmlChar * nsList);

G_END_DECLS

#endif /* _XML_H */
