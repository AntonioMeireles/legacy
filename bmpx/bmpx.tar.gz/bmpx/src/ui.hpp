/*  BMPx - The Dumb Music Player
 *  Copyright (C) 2005 BMPx development team.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 * The BMPx project hereby grant permission for non-gpl compatible GStreamer
 * plugins to be used and distributed together with GStreamer and BMPx. This
 * permission are above and beyond the permissions granted by the GPL license
 * BMPx is covered by.
 */


#ifndef BMP_UI_HPP
#define BMP_UI_HPP

#include <gtk/gtk.h>
#include <glib-object.h>
#include "ui_main.hpp"
#include "ui_playlist.hpp"
#include "ui_callbacks.hpp"

#include <bmp/widgets/bmp_window.h>


#define BMP_TYPE_UI		  (bmp_ui_get_type ())
#define BMP_UI(obj)		  (G_TYPE_CHECK_INSTANCE_CAST ((obj), BMP_TYPE_UI, BmpUI))
#define BMP_UI_CLASS(klass)	  (G_TYPE_CHECK_CLASS_CAST ((klass), BMP_TYPE_UI, BmpUIClass))
#define BMP_IS_UI(obj)	  	  (G_TYPE_CHECK_INSTANCE_TYPE ((obj), BMP_TYPE_UI))
#define BMP_IS_UI_CLASS(klass)    (G_TYPE_CHECK_CLASS_TYPE ((klass), BMP_TYPE_UI))
#define BMP_UI_GET_CLASS(obj)     (G_TYPE_INSTANCE_GET_CLASS ((obj), BMP_TYPE_UI, BmpUIClass))

typedef struct _BmpUIPrivate BmpUIPrivate;

struct BmpUIClass
{
    GObjectClass parent;
};


struct BmpUI
{
    GObject parent;
    BmpUIPrivate *priv;
};

#define SET_CURSOR_FOR_WIDGET(cursor_enum,widget) \
  { \
    GdkCursor *cursor; \
      if (!GTK_WIDGET_REALIZED(widget)) gtk_widget_realize(GTK_WIDGET(widget)); \
      cursor = bmp_cursor_get (CursorId(cursor_enum)); \
      gdk_window_set_cursor (GTK_WIDGET(widget)->window, cursor); \
      if (cursor) \
	gdk_cursor_destroy (cursor); \
  }

/* FIXME: All these defines need a thorough audit and proper renaming */

#define BMP_DEFAULT_FONT		"Sans 10"
#define BMP_DEFAULT_SKIN		"default"

#define BMP_MAIN_ACTION_GROUP		"action_group"
#define BMP_MAIN_ACTION_GROUP_TOGGLE    "action_group_toggle"

#define BMP_TOGGLE_ACTION_MUTE		     "bmp_toggle_action_mute"
#define BMP_TOGGLE_ACTION_VIS		     "bmp_toggle_action_vis"
#define BMP_TOGGLE_ACTION_SHOW_UI	     "bmp_toggle_action_show_ui"
#define BMP_TOGGLE_ACTION_SHUFFLE	     "bmp_toggle_action_shuffle"
#define BMP_TOGGLE_ACTION_REPEAT	     "bmp_toggle_action_repeat"
#define BMP_TOGGLE_ACTION_EQ		     "bmp_toggle_action_eq"
#define BMP_TOGGLE_ACTION_PL		     "bmp_toggle_action_pl"
#define BMP_TOGGLE_ACTION_SCROLL	     "bmp_toggle_action_scroll"
#define BMP_TOGGLE_ACTION_STOP_AFTER_CURRENT "bmp_toggle_action_stop_after_current"
#define BMP_TOGGLE_ACTION_KEEP_ABOVE	     "keep-above"
#define BMP_TOGGLE_ACTION_FOLLOW_CURRENT     "follow-current-track"

#define        BMP_ACTION_PREV  "bmp_action_prev"
#define        BMP_ACTION_PLAY  "bmp_action_play"
#define        BMP_ACTION_PAUSE "bmp_action_pause"
#define        BMP_ACTION_STOP  "bmp_action_stop"
#define        BMP_ACTION_NEXT  "bmp_action_next"

#define	       BMP_ACTION_SORT_VISIBLE  "bmp_sort_visible"
#define	       BMP_ACTION_SORT_ARTIST   "bmp_sort_artist"
#define	       BMP_ACTION_SORT_ALBUM    "bmp_sort_album"
#define	       BMP_ACTION_SORT_TITLE    "bmp_sort_title"
#define	       BMP_ACTION_SORT_GENRE    "bmp_sort_genre"
#define	       BMP_ACTION_SORT_TRACK    "bmp_sort_track"
#define	       BMP_ACTION_SORT_LOCATION "bmp_sort_location"

#define        BMP_ACTION_PREFERENCES "bmp_action_preferences"
#define        BMP_ACTION_LIBRARY     "bmp_action_library"
#define        BMP_ACTION_STREAMS     "bmp_action_streams"
#define        BMP_ACTION_JTT	      "bmp_action_jtt"
#define	       BMP_ACTION_FILEINFO    "bmp_action_trackinfo"

#define	       BMP_ACTION_CLEAR_PLAYBACK_HISTORY "bmp_action_clear_playback_history"

#define	       BMP_ACTION_ICONIFY	"bmp_action_iconify"
#define	       BMP_ACTION_QUIT		"bmp_action_quit"
#define	       BMP_ACTION_QUIT_TITLE    "bmp_action_quit_title"
#define	       BMP_ACTION_ABOUT		"bmp_action_about"

#define        BMP_ACTION_TRACKLIST_EXPORT	    "tracklist_export"
#define        BMP_ACTION_TRACKLIST_LIBRARY	    "tracklist_library"
#define        BMP_ACTION_TRACKLIST_STREAMS	    "tracklist_streams"

#define	       BMP_ACTION_TRACKLIST_ADD_CD	    "tracklist_add_cd"
#define	       BMP_ACTION_TRACKLIST_ADD_TO_NEW	    "tracklist_add_to_new"
#define        BMP_ACTION_TRACKLIST_ADD		    "tracklist_add_files"
#define        BMP_ACTION_TRACKLIST_ADD_LIB_NEW	    "tracklist_add_library_new"
#define        BMP_ACTION_TRACKLIST_OPEN	    "tracklist_open_files"

#define	       BMP_ACTION_TRACKLIST_DEL		    "tracklist_files_remove"
#define	       BMP_ACTION_TRACKLIST_CROP	    "tracklist_files_crop"
#define        BMP_ACTION_TRACKLIST_DEL_ALL	    "tracklist_files_remove_all"


#define	       BMP_ACTION_TRACKLIST_KEEP_ARTIST	    "tracklist_keep_artist"
#define	       BMP_ACTION_TRACKLIST_KEEP_ALBUM	    "tracklist_keep_album"

#define	       BMP_ACTION_TRACKLIST_REMOVE_ARTIST   "tracklist_remove_artist"
#define	       BMP_ACTION_TRACKLIST_REMOVE_ALBUM    "tracklist_remove_album"

#define	       BMP_ACTION_TRACKLIST_SELECT_ALL	    "tracklist_select_all"
#define	       BMP_ACTION_TRACKLIST_SELECT_NONE	    "tracklist_select_none"
#define	       BMP_ACTION_TRACKLIST_SELECT_INVERT   "tracklist_select_invert"

/* New Playlist... */
#define	       BMP_TOGGLE_ACTION_LIBRARY_PLAYLIST_NEW_POPUP "playlist_new_popup"

#define	       BMP_ACTION_LIBRARY_PLAYLIST_NEW_FROM_FILE    "playlist_new_from_file"
#define	       BMP_ACTION_LIBRARY_PLAYLIST_NEW_FROM_LIBRARY "playlist_new_from_library"


/* Non-action defines */
#define        BMP_FILE_REGION  "region.txt"
#define	       BMP_FILE_PLEDIT  "pledit.txt"

#define        BMP_MASK_REGION_SECTION_MAIN_WINDOW "normal"
#define        BMP_MASK_REGION_SECTION_EQUALIZER   "equalizer"

enum BmpSkinComponent
{
    SKIN_COMPONENT_MAIN,
    SKIN_COMPONENT_SHUFREP,
    SKIN_COMPONENT_CBUTTONS,
    SKIN_COMPONENT_POSBAR,
    SKIN_COMPONENT_VOLUME,
    SKIN_COMPONENT_TITLEBAR,
    SKIN_COMPONENT_BALANCE,
    SKIN_COMPONENT_PLEDIT,
    SKIN_COMPONENT_MONOSTER,
    SKIN_COMPONENT_NUMBERS,
    SKIN_COMPONENT_PLAYPAUSE,

    N_SKIN_COMPONENTS
};

struct BmpTooltipEntry
{
    char *widget_name;
    char *tooltip_text;
    char *stock_id;
};

#ifndef DOXYGEN_SHOULD_SKIP_THIS
struct BmpButtonNormalT
{
    char *action_id;
    char *tooltip;
    int pixmap_id;             /* id of used pixmap */
    int img_x;
    int img_y;
    int img_x_pressed;
    int img_y_pressed;
    int width;
    int height;
    int pos_x;
    int pos_y;
};

struct BmpButtonToggleT
{
    char *action_id;
    char *tooltip;
    int pixmap_id;             /* id of used pixmap */
    int img_x;
    int img_y;
    int img_x_pressed;
    int img_y_pressed;
    int img_x_active;
    int img_y_active;
    int width;                 /* width in .bmp file */
    int height;                /* height in .bmp file */
    int pos_x;                 /* x position in skin when displayed */
    int pos_y;                 /* y position in skin when displayed */
    gboolean clickable;         /* is it clickable? */
};

struct BmpSkinComponentT
{
    BmpSkinComponent   identifier;
    char	      *filename;
    GdkPixbuf	      *pixbuf;
    gpointer	       user_data;
};

struct BmpWindowT
{
    GtkWidget *window;
};

struct BmpPosbarT
{
    BmpSkinComponent   identifier;
    char	      *filename;
    GdkPixbuf	      *pixbuf;
    int	       x_slider;
    gboolean	       dragging;
};

struct BmpVolumeT
{
    BmpSkinComponent   identifier;
    char	      *filename;
    GdkPixbuf	      *pixbuf;
    int		       x_slider;
    int		       height;
    gboolean	       dragging;
    gboolean	       has_button;
};
#endif

#define BMP_WINDOW_MAIN_WIDTH 275
#define BMP_WINDOW_MAIN_HEIGHT 116

enum BmpSkinType
{
    BMP_SKIN_ARCHIVE,
    BMP_SKIN_DIR
};

enum BmpWinamp2Window
{
    BMP_WINDOW_MAIN,
    BMP_WINDOW_PLEDIT,
    BMP_WINDOW_EQ
};

extern GtkWidget *c_tracklist;
extern GtkWidget *c_tracklist_scrollbar;

extern GtkUIManager    *bmp_ui_manager;
extern GtkActionGroup  *bmp_actions;
extern GtkActionGroup  *bmp_toggle_actions;

extern BmpPosbarT *bmp_posbar;
extern BmpVolumeT *bmp_volume;
extern BmpVolumeT *bmp_balance;
extern BmpSkinComponentT *bmp_skin_component[N_SKIN_COMPONENTS];
extern BmpSkinComponentT *bmp_default_skin_component[N_SKIN_COMPONENTS];

GType
bmp_ui_get_type		    (void);
BmpUI*
bmp_ui_new		    (void);
int
bmp_ui_finalize_init	    (BmpUI *ui);


void
bmp_ui_set_trayicon_text    (BmpUI *ui, const char *text);
void
bmp_ui_set_trayicon_exit    (BmpUI *ui);


void
bmp_ui_jtt_show		    (BmpUI *ui);
void
bmp_ui_library_show	    (BmpUI *ui);
void
bmp_ui_preferences_show	    (BmpUI *ui);
void
bmp_ui_streams_show	    (BmpUI *ui);
void
bmp_ui_about_show           (BmpUI *ui);

void
bmp_ui_raise_windows	    (BmpUI *ui);

void
bmp_ui_column_set_active    (BmpUI *ui, int column, gboolean active);
GdkBitmap*
bmp_ui_get_mask_window_main (BmpUI *ui);


#endif // BMP_UI_HPP
