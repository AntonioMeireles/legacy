//  BMPx - The Dumb Music Player
//  Copyright (C) 2005-2006 BMPx development team.
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
//
//  --
//
//  The BMPx project hereby grants permission for non GPL-compatible GStreamer
//  plugins to be used and distributed together with GStreamer and BMPx. This
//  permission is above and beyond the permissions granted by the GPL license
//  BMPx is covered by.

#ifndef BMP_UI_SKIN_VIEW_HPP
#define BMP_UI_SKIN_VIEW_HPP

#include <vector>
#include <map>
#include <string>
#include <gtkmm.h>
#include <libglademm.h>

namespace Bmp
{
  class SkinView
      : public Gtk::TreeView
  {
  public:

      typedef sigc::signal<void> RefreshSignal;
      typedef sigc::signal<void> RefreshEndSignal;

      SkinView (BaseObjectType                        *cobject,
                const Glib::RefPtr<Gnome::Glade::Xml> &xml);

      std::string
      get_selected_skin_path ();

      RefreshSignal
      signal_refresh ();

      RefreshEndSignal
      signal_refresh_end ();

  protected:

      virtual void
      on_realize ();

      virtual void
      on_cursor_changed ();

  private:

      // Skins columns record
      class ColumnRecord
          : public Gtk::TreeModel::ColumnRecord
      {
      public:

          Gtk::TreeModelColumn<Glib::RefPtr<Gdk::Pixbuf> > icon;
          Gtk::TreeModelColumn<Glib::ustring>              name;
          Gtk::TreeModelColumn<std::string>                path;

          ColumnRecord ()
          {
              add (icon);
              add (name);
              add (path);
          }
      };

      typedef std::map<std::string, Gtk::TreeModel::RowReference> PositionMap;

      Glib::RefPtr<Gtk::ListStore> list_store;
      ColumnRecord                 columns;
      PositionMap                  pos_map;

      RefreshSignal                refresh_signal;
      RefreshEndSignal             refresh_end_signal;

      bool
      on_skin_added_idle (const std::string &path);

      void
      on_skin_added (const std::string &path);

      bool
      on_skin_removed_idle (const std::string &path);

      void
      on_skin_removed (const std::string &path);

      int
      compare_skin (const Gtk::TreeModel::iterator &iter_a,
                    const Gtk::TreeModel::iterator &iter_b);
  };

} // Bmp namespace

#endif // BMP_UI_SKIN_VIEW_HPP
