#ifndef BMP_HREL_SQLITE_CONNECTOR_H
#define BMP_HREL_SQLITE_CONNECTOR_H

#include <glib.h>
#include <glib-object.h>

#include <libhrel/types.h>
#include <libhrel/relation.h>
#include <libhrel/relation_base.h>

#define BMP_TYPE_HREL_SQLITE_CONNECTOR		  (bmp_hrel_sqlite_connector_get_type ())
#define BMP_HREL_SQLITE_CONNECTOR(obj)		  (G_TYPE_CHECK_INSTANCE_CAST ((obj), BMP_TYPE_HREL_SQLITE_CONNECTOR, BmpHRelSQLiteConnector))
#define BMP_HREL_SQLITE_CONNECTOR_CLASS(klass)	  (G_TYPE_CHECK_CLASS_CAST ((klass), BMP_TYPE_HREL_SQLITE_CONNECTOR, BmpHRelSQLiteConnectorClass))
#define BMP_IS_HREL_SQLITE_CONNECTOR(obj)	  (G_TYPE_CHECK_INSTANCE_TYPE ((obj), BMP_TYPE_HREL_SQLITE_CONNECTOR))
#define BMP_IS_HREL_SQLITE_CONNECTOR_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass), BMP_TYPE_HREL_SQLITE_CONNECTOR))
#define BMP_HREL_SQLITE_CONNECTOR_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj), BMP_TYPE_HREL_SQLITE_CONNECTOR, BmpHRelSQLiteConnectorClass))

typedef struct _BmpHRelSQLiteConnector BmpHRelSQLiteConnector;
typedef struct _BmpHRelSQLiteConnectorClass BmpHRelSQLiteConnectorClass;
typedef struct _BmpHRelSQLiteConnectorPrivate BmpHRelSQLiteConnectorPrivate;

struct _BmpHRelSQLiteConnector {
    GObject parent;

    BmpHRelSQLiteConnectorPrivate *private;
};

struct _BmpHRelSQLiteConnectorClass {
    GObjectClass  parent;
};

GType
bmp_hrel_sqlite_connector_get_type (void);

BmpHRelSQLiteConnector*
bmp_hrel_sqlite_connector_new	    (HRelation			*relation,
				    const gchar			*name);

gboolean 
bmp_hrel_sqlite_connector_open	    (BmpHRelSQLiteConnector	*connector);

gint 
bmp_hrel_sqlite_connector_close	    (BmpHRelSQLiteConnector	*connector);


HTuple*
bmp_hrel_sqlite_connector_read	     (BmpHRelSQLiteConnector	*connector,
				      const gchar		*uri);

void
bmp_hrel_sqlite_connector_read_all    (BmpHRelSQLiteConnector	*connector);
			         
#endif                          /* BMP_HREL_SQLITE_CONNECTOR_H */
