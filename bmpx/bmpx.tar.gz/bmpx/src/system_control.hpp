//-*- Mode: C++; indent-tabs-mode: nil; -*-

/*  BMPx - The Dumb Music Player
 *  Copyright (C) 2005 BMPx development team.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 *  $Id$
 *
 * The BMPx project hereby grant permission for non-gpl compatible GStreamer
 * plugins to be used and distributed together with GStreamer and BMPx. This
 * permission are above and beyond the permissions granted by the GPL license
 * BMPx is covered by.
 */

#ifndef BMP_SYSTEM_CONTROL_HPP
#define BMP_SYSTEM_CONTROL_HPP

/*
 * Potentially, include other headers on which this header depends.
 */
#include <glib-object.h>
#include <bmp/playlist.hpp>
#include <play.hpp>

G_BEGIN_DECLS

#define BMP_TYPE_SYSTEM_CONTROL		  (bmp_system_control_get_type ())
#define BMP_SYSTEM_CONTROL(obj)		  (G_TYPE_CHECK_INSTANCE_CAST ((obj), BMP_TYPE_SYSTEM_CONTROL, BmpSystemControl))
#define BMP_SYSTEM_CONTROL_CLASS(klass)	  (G_TYPE_CHECK_CLASS_CAST ((klass), BMP_TYPE_SYSTEM_CONTROL, BmpSystemControlClass))
#define BMP_IS_SYSTEM_CONTROL(obj)	  (G_TYPE_CHECK_INSTANCE_TYPE ((obj), BMP_TYPE_SYSTEM_CONTROL))
#define BMP_IS_SYSTEM_CONTROL_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass), BMP_TYPE_SYSTEM_CONTROL))
#define BMP_SYSTEM_CONTROL_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj), BMP_TYPE_SYSTEM_CONTROL, BmpSystemControlClass))

typedef struct _BmpSystemControl BmpSystemControl;
typedef struct _BmpSystemControlClass BmpSystemControlClass;
typedef struct _BmpSystemControlPrivate BmpSystemControlPrivate;

struct _BmpSystemControl {
    GObject parent;

    BmpSystemControlPrivate *priv;
};

struct _BmpSystemControlClass {

    GObjectClass parent;

    /* Signals */
    void     (*track_change)		    (BmpSystemControl *self);

    void     (*app_busy)		    (BmpSystemControl *self);
    void     (*app_idle)		    (BmpSystemControl *self);

    void     (*set_stop_after_current)	    (BmpSystemControl *self, gboolean stop);
    void     (*seek_event)		    (BmpSystemControl *self, gint stream_pos);
    void     (*set_stream_pos)		    (BmpSystemControl *self, gint stream_pos);
    void     (*set_playstatus)		    (BmpSystemControl *self, gint playstatus);

    void     (*set_uri)			    (BmpSystemControl *self, char* uri); 
    void     (*set_title)		    (BmpSystemControl *self, char* title); 
    void     (*set_bitrate)		    (BmpSystemControl *self, int bitrate); 
    void     (*set_samplerate)		    (BmpSystemControl *self, int samplerate); 

    void     (*set_volume)		    (BmpSystemControl *self, gint volume);
    void     (*set_eq)			    (BmpSystemControl *self, gint eq_id, gint value);
    void     (*set_shuffle)		    (BmpSystemControl *self, gboolean shuffle);
    void     (*set_repeat)		    (BmpSystemControl *self, gboolean repeat);

    void     (*tracklist_list_sorted)	    (BmpSystemControl *self, gint column);

    void     (*tracklist_items_removed)	    (BmpSystemControl *self, gpointer array, gint n_items);
    void     (*tracklist_items_added)	    (BmpSystemControl *self, gpointer array, gint n_items);
    void     (*tracklist_rows_swapped)	    (BmpSystemControl *self, gint row_a, gint row_b);

    void     (*startup_complete)	    (BmpSystemControl *self);
    void     (*shutdown_complete)	    (BmpSystemControl *self);

    gboolean (*shutdown_request)	    (BmpSystemControl *self);
};

typedef enum {
    BMP_SYSTEM_MESSAGE_TRACK_CHANGE,
    BMP_SYSTEM_MESSAGE_CURRENT,
    BMP_SYSTEM_MESSAGE_NEXT,
    BMP_SYSTEM_MESSAGE_PREV,
    BMP_SYSTEM_MESSAGE_STOP,
    BMP_SYSTEM_MESSAGE_PAUSE,
    BMP_SYSTEM_MESSAGE_SEEK,
    BMP_SYSTEM_MESSAGE_SEEK_PERCENT,
    BMP_SYSTEM_MESSAGE_PLAY_TRACK,
    BMP_SYSTEM_MESSAGE_STOP_AFTER_CURRENT,
    BMP_SYSTEM_MESSAGE_VOLUME,
    BMP_SYSTEM_MESSAGE_EQ,
    BMP_SYSTEM_MESSAGE_REPEAT,
    BMP_SYSTEM_MESSAGE_SHUFFLE,
#ifdef HAVE_GUI
    BMP_SYSTEM_MESSAGE_UI_START,
    BMP_SYSTEM_MESSAGE_UI_STOP,
#endif
    BMP_SYSTEM_MESSAGE_UPDATE_TITLE,
    BMP_SYSTEM_MESSAGE_QUIT
} BmpSystemMessageType;

typedef struct {
    BmpSystemMessageType message_type;
    gpointer		 data;
    GDestroyNotify       data_destroy;
} BmpSystemMessage;

GType
bmp_system_control_get_type (void);

BmpSystemControl*
bmp_system_control_new (gboolean no_remote);

void
bmp_system_control_init_finalize (BmpSystemControl *self);

void bmp_system_message_send (BmpSystemControl	       *self,
			      BmpSystemMessageType	message_type,
			      gpointer		        data,
			      GDestroyNotify	        data_destroy);

void bmp_system_control_update_title	(BmpSystemControl *self);

void bmp_system_control_app_busy	(BmpSystemControl   *self);

void bmp_system_control_app_idle	(BmpSystemControl   *self);

#ifdef HAVE_GUI
gboolean
bmp_system_control_ui_start		(BmpSystemControl   *self,
					 gchar		    *display_name,
					 GError		   **error);

gboolean
bmp_system_control_ui_stop		(BmpSystemControl   *self,
					 GError		   **error);
gboolean
bmp_system_control_ui_raise		(BmpSystemControl   *self,
					 GError		   **error);
#endif

gboolean
bmp_system_control_quit			(BmpSystemControl   *self,
				         GError		   **error);

gboolean
bmp_system_control_seek_percent		(BmpSystemControl   *self,
					 gdouble	     position,
					 GError		   **error);

gboolean
bmp_system_control_play_track		(BmpSystemControl   *self,
					 gint		     index,
					 GError		   **error);

void
bmp_system_control_rows_swapped		(BmpSystemControl  *self,
					 gint		    row_a,
					 gint		    row_b);

gboolean
bmp_system_control_export_tracklist (BmpSystemControl	*self,
				     const gchar	*container_plugin,
				     gboolean	         all,
				     const gchar	*filename,
				     GError	       **error);

gboolean
bmp_system_control_volume_set	    (BmpSystemControl	*self,
				     gint		 volume,
				     GError	       **error);

#if 0
gboolean
bmp_system_control_eq_set (BmpSystemControl *self,
			   BmpEqEnum	     eq,
			   gint		     value,
			   GError	   **error);
#endif

gboolean
bmp_system_control_go_prev	(BmpSystemControl *self, GError **error);

gboolean
bmp_system_control_go_next	(BmpSystemControl *self, GError **error);

gboolean
bmp_system_control_pause	(BmpSystemControl *self, GError **error);

gboolean
bmp_system_control_play	        (BmpSystemControl *self, GError **error);

gboolean
bmp_system_control_stop		(BmpSystemControl *self, GError **error);

gboolean
bmp_system_control_startup	(BmpSystemControl *self, GError **error);

gboolean
bmp_system_control_add_uri_list (BmpSystemControl  *self,
				 const gchar	  **uri_list,
				 gint		    position,
				 gboolean	    clear,
				 gboolean	    start_playback,
				 gint		    start_payback_position,
				 gint		   *position_out,
				 GError		  **error);

gboolean
bmp_system_control_clear_playback_history (BmpSystemControl	*self,
					   GError	       **error);

gboolean
bmp_system_control_stop_after_current_set (BmpSystemControl   *self,
					   gboolean	       stop,
					   GError	     **error);

gboolean
bmp_system_control_repeat_set	  (BmpSystemControl   *self,
				   gboolean	       repeat,
				   GError	     **error);

gboolean
bmp_system_control_repeat_get	  (BmpSystemControl   *self,
				   gboolean	      *repeat,
				   GError	     **error);

gboolean
bmp_system_control_shuffle_set	  (BmpSystemControl   *self,
				   gboolean	       shuffle,
				   GError	     **error);

gboolean
bmp_system_control_shuffle_get	  (BmpSystemControl *self,
				   gboolean	    *shuffle,
				   GError	   **error);

gboolean
bmp_system_control_identity (BmpSystemControl  *self,
			     gchar	      **name,
			     GError	      **error);


gboolean
bmp_system_control_clear_tracklist		(BmpSystemControl      *self,
						 GError		      **error);

gboolean
bmp_system_control_get_tracklist		(BmpSystemControl	*self,
						 char		      ***array,
						 GError		       **error);

gboolean
bmp_system_control_get_current_title		(BmpSystemControl  *self,
						 gchar		  **title,
						 GError		  **error);
gboolean
bmp_system_control_get_current_uri		(BmpSystemControl	*self,
						 gchar		       **uri,
						 GError		       **error);
gboolean
bmp_system_control_get_current_track		(BmpSystemControl	*self,
						 gint		        *idx,
						 GError		       **error);

gboolean
bmp_system_control_get_current_samplerate (BmpSystemControl  *control,
					   int		     *samplerate,
					   GError	    **error);
 
gboolean
bmp_system_control_get_current_bitrate    (BmpSystemControl  *control,
					   int		     *bitrate,
					   GError	    **error);
 

gboolean
bmp_system_control_get_metadata_for_list_item	(BmpSystemControl	  *self,
						 gint			   item,
					         GHashTable		 **value,
					         GError			 **error);

gboolean
bmp_system_control_get_metadata_for_uri      	(BmpSystemControl	  *self,
						 char			  *uri,
					         GHashTable		 **value,
					         GError			 **error);

gboolean
bmp_system_control_send_status	(BmpSystemControl    *self,
			 	 GError		   **error);

gboolean
bmp_system_control_volume_get	(BmpSystemControl   *self,
				 gint		    *volume,
				 GError		   **error);

gboolean
bmp_system_control_volume_set   (BmpSystemControl   *self,
			         gint		     volume,
			         GError		   **error);

gboolean
bmp_system_control_eq_get	(BmpSystemControl   *self,
				 gint		     eq,
				 gint		    *value,
				 GError		   **error);

gboolean
bmp_system_control_seek		(BmpSystemControl   *self,
				 gint		     position,
				 GError		   **error);

/* Misc */
BmpPlaybackHistory*
bmp_system_control_get_history		      (BmpSystemControl *self);

void
bmp_system_control_initialize_dbus_connection (BmpSystemControl *self);

void
bmp_system_control_register_dispose_object    (BmpSystemControl	    *self,
					       GObject		    *object);

/* System startup/shutdown stuff */
typedef GThreadFunc SystemShutdownFunc;
typedef GThreadFunc SystemStartupFunc;
void
bmp_system_control_register_shutdown_func     (BmpSystemControl	    *self,
					       SystemShutdownFunc    shutdown_func,
					       gpointer		     shutdown_data);

void
bmp_system_control_register_startup_func      (BmpSystemControl	    *self,
					       SystemStartupFunc     startup_func,
					       gpointer		     startup_data);

void
bmp_system_control_application_run	      (BmpSystemControl	    *self);

/* END System startup/shutdown stuff */

/* User Messaging system */
gint
bmp_system_control_message_domain_register (BmpSystemControl	    *self,
					    const gchar		    *id,
					    const gchar		    *description);

gint
bmp_system_control_message_dispatch	    (BmpSystemControl	    *self,
					     gint		     domain_id,
					     GtkMessageType	     msgtype,
					     const gchar	    *text);

G_END_DECLS


#endif // BMP_SYSTEM_CONTROL_HPP
