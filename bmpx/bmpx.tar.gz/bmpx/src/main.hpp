#ifndef MAIN_HPP
#define MAIN_HPP

#include <config.h>

#include <bmp/library.hpp>
extern Bmp::Library::Library	  *library;

#include <bmp/vfs.hpp>
extern Bmp::VFS::VFS		  *vfs;

#ifndef BMP_PLUGIN_COMPILATION

#include <mcs/mcs.h>
extern Mcs::Mcs			  *mcs;

#include "resource_manager.hpp"
extern BmpResourceManager	  *bmp_rm;

#include <bmp/playlist.hpp>
extern BmpPlaylist		  *bmp_playlist;

#include "play.hpp"
extern Bmp::Play		  *bmp_play_engine;

#include "system_control.hpp"
extern BmpSystemControl		  *bmp_system_control;

#include "file_monitor.hpp"
extern Bmp::FileMonitor::Monitor  *bmp_file_monitor;

#include "scrobbler.hpp"
extern Bmp::Scrobbler		  *bmp_scrobbler;

#ifdef HAVE_HAL
#include <bmp/hal.h>
extern BmpHal			  *bmp_hal;
#endif

#ifdef HAVE_GUI
#include "ui.hpp"
#include <mcs/gtk-bind.h>
extern Mcs::Bind	  *mcs_bind;
extern BmpUI              *bmp_ui;
extern gboolean		   progress_running;
extern gboolean		   use_xdb;
extern gboolean		   run_headless;
extern gboolean		   ui_initialized;
#else
extern GMainLoop	  *mainloop;
#endif

#endif
#endif
