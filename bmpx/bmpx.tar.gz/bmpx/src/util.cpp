/*  This file contains code from the XMMS project and is licensed under the GPL
 */

#include <config.h>

#include "main.hpp"

#ifdef HAVE_GUI
#include <gdk/gdkprivate.h>
#include <gtk/gtkimage.h>
#include <gdk/gdkx.h>
#include <gdk/gdkkeysyms.h>
#include <X11/Xlib.h>
#include "ui.hpp"
#include "ui_util.hpp"
#endif

#include <cstdlib>
#include <cstring>
#include <cctype>

#include <strings.h>

#include <glib/gstdio.h>
#include <glib/gi18n.h>

#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

#include <bmp/uri++.hpp>
#include <bmp/util.h>

struct _BmpUniqueList
{
  GList *list;
  GHashTable *hash;
};

static GArray *string_to_garray (const gchar *str);

std::string
read_ini_string_buffer (const char        *_buffer,
		        const std::string& section,
			const std::string& key)
{
    gchar *ret_buffer = NULL;
    unsigned int  off = 0;
    int		  len = 0;
    bool	  found_section = false;
    gsize	  filesize;
    
    gchar *buffer = NULL;

    if (!_buffer)
	return NULL;

    buffer = g_strdup (_buffer);
    filesize = std::strlen (buffer);

    while (!ret_buffer && off < filesize)
	{
	    while (off < filesize &&
		   (buffer[off] == '\r' || buffer[off] == '\n' ||
		    buffer[off] == ' ' || buffer[off] == '\t'))
		off++;
	    if (off >= filesize)
		break;
	    if (buffer[off] == '[')
		{
		    int slen = std::strlen (section.c_str());
		    off++;
		    found_section = false;
		    if (off + slen + 1 < filesize &&
			!strncasecmp (section.c_str(), &buffer[off], slen))
			{
			    off += slen;
			    if (buffer[off] == ']')
				{
				    off++;
				    found_section = true; 
				}
			}
		}
	    else if (found_section && ((off + key.length()) < filesize) &&
		     !strncasecmp (key.c_str(), &buffer[off], key.length()))
		{
		    off += key.length(); 
		    while (off < filesize &&
			   (buffer[off] == ' ' || buffer[off] == '\t'))
			off++;
		    if (off >= filesize)
			break;
		    if (buffer[off] == '=')
			{
			    off++;
			    while (off < filesize &&
				   (buffer[off] == ' ' || buffer[off] == '\t'))
				off++;
			    if (off >= filesize)
				break;
			    len = 0;
			    while (off + len < filesize &&
				   buffer[off + len] != '\r' &&
				   buffer[off + len] != '\n' &&
				   buffer[off + len] != ';')
				len++;
			    ret_buffer = g_strndup (&buffer[off], len);
			    off += len;
			}
		}
	    while (off < filesize &&
		   buffer[off] != '\r' && buffer[off] != '\n')
		off++;
	}
   
    if (ret_buffer) 
    {
      std::string ret_buffer_std = ret_buffer;
      free (ret_buffer);
      return ret_buffer_std;
    }
  
    return std::string();
}

std::string
read_ini_string (const std::string& filename,
		 const std::string& section,
		 const std::string& key)
{
    char		*buffer,
			*ret_buffer = NULL;
    unsigned int	 off = 0;
    bool		 found_section = false;
    int			 len = 0;
    gsize		 filesize;

    if (filename.empty ())
	return NULL;

    if (!g_file_get_contents (filename.c_str(), &buffer, &filesize, NULL))
	return NULL;

    while (! ret_buffer && off < filesize)
	{
	    while (off < filesize &&
		   (buffer[off] == '\r' || buffer[off] == '\n' ||
		    buffer[off] == ' ' || buffer[off] == '\t'))
		off++;
	    if (off >= filesize)
		break;
	    if (buffer[off] == '[')
		{
		    int slen = section.length();
		    off++;
		    found_section = false;
		    if (off + slen + 1 < filesize &&
			! strncasecmp (section.c_str(), &buffer[off], slen))
			{
			    off += slen;
			    if (buffer[off] == ']')
				{
				    off++;
				    found_section = true;
				}
			}
		}
	    else if (found_section && ((off + key.length()) < filesize) &&
		     ! strncasecmp (key.c_str(), &buffer[off], key.length()))
		{
		    off += key.length(); 
		    while (off < filesize &&
			   (buffer[off] == ' ' || buffer[off] == '\t'))
			off++;
		    if (off >= filesize)
			break;
		    if (buffer[off] == '=')
			{
			    off++;
			    while (off < filesize &&
				   (buffer[off] == ' ' || buffer[off] == '\t'))
				off++;
			    if (off >= filesize)
				break;
			    len = 0;
			    while (off + len < filesize &&
				   buffer[off + len] != '\r' &&
				   buffer[off + len] != '\n' &&
				   buffer[off + len] != ';')
				len++;
			    ret_buffer = g_strndup (&buffer[off], len);
			    off += len;
			}
		}
	    while (off < filesize &&
		   buffer[off] != '\r' && buffer[off] != '\n')
		off++;
	}

    g_free (buffer);
    std::string ret_buffer_std = ret_buffer;
    g_free (ret_buffer);

    return ret_buffer_std;
}

static GArray*
string_to_garray (const gchar * str)
{
    GArray *array;
    gint temp;
    const gchar *ptr = str;
    gchar *endptr;

    array = g_array_new (FALSE, TRUE, sizeof (gint));
    for (;;)
	{
	    temp = strtol (ptr, &endptr, 10);
	    if (ptr == endptr)
		break;
	    g_array_append_val (array, temp);
	    ptr = endptr;
	    while (! isdigit (*ptr) && (*ptr) != '\0')
		ptr++;
	    if (*ptr == '\0')
		break;
	}
    return (array);
}

GArray *
read_ini_array (const std::string& filename,
                const std::string& section,
                const std::string& key)
{
    GArray	 *array;
    std::string	  temp;

    temp = read_ini_string (filename, section, key);
    if (temp.empty ())
        return NULL;

    array = string_to_garray (temp.c_str());
    return array;
}

void
glist_movedown (GList * list)
{
    gpointer temp;

    if (g_list_next (list))
	{
	    temp = list->data;
	    list->data = list->next->data;
	    list->next->data = temp;
	}
}


void
glist_moveup (GList * list)
{
    gpointer temp;

    if (g_list_previous (list))
	{
	    temp = list->data;
	    list->data = list->prev->data;
	    list->prev->data = temp;
	}
}


void
glist_swap (GList * list1, GList * list2)
{
    gpointer aux;

    aux = list1->data;

    list1->data = list2->data;
    list2->data = aux;
}

/* counts number of digits in a gint */

guint
gint_count_digits (gint n)
{
    guint count = 0;

    n = ABS (n);
    do {
	count++;
	n /= 10;
    } while (n > 0);

    return count;
}


gchar *
str_replace_char (gchar *str,
                  gchar  old_char,
                  gchar  new_char)
{
    gchar *match;

    g_return_val_if_fail (str != NULL, NULL);

    match = str;
    while ((match = strchr (match, old_char)))
	*match = new_char;

    return str;
}


gchar *
str_replace (gchar *str,
	     gchar *new_str)
{
    g_free (str);
    return new_str;
}


gboolean
str_has_prefix_nocase (const gchar *str, const gchar *prefix)
{
    if ((!str) || (!prefix)) return FALSE;
    return (strncasecmp (str, prefix, std::strlen (prefix)) == 0);
}


gboolean
str_has_suffix_nocase (const gchar *str, const gchar *_suffix)
{
    gchar *suffix_fq;
    gboolean rv;

    if ((!str) || (!_suffix)) return FALSE;

    suffix_fq = g_strconcat (".", _suffix, NULL);
    rv = (strcasecmp (str + std::strlen (str) - std::strlen (suffix_fq), suffix_fq) == 0);
    g_free (suffix_fq);

    return rv;
}


gboolean
str_has_suffixes_nocase (const gchar * str,
			 gchar * const *suffixes)
{
    gchar *const *suffix;

    g_return_val_if_fail (str != NULL, FALSE);
    g_return_val_if_fail (suffixes != NULL, FALSE);

    for (suffix = suffixes; *suffix; suffix++)
	if (str_has_suffix_nocase (str, *suffix))
	    return TRUE;

    return FALSE;
}


gboolean
bmp_detach (void)
{
  pid_t child_pid;
  int dev_null_fd;

  if (g_chdir ("/") < 0)
    {
      g_message ("Could not change into root directory");
      return FALSE;
    }

  switch ((child_pid = fork ()))
    {
      case -1:
        g_message ("fork failed\n");
        return FALSE;
        break;

      case 0:
        /* silently ignore failures here, if someone
         * doesn't have /dev/null we may as well try
         * to continue anyhow
         */

        dev_null_fd = g_open ("/dev/null", O_RDWR);
        if (dev_null_fd >= 0)
          {
            dup2 (dev_null_fd, 0);
            dup2 (dev_null_fd, 1);
            dup2 (dev_null_fd, 2);
          }

        /* Get a predictable umask */
        umask (022);
        break;

      default:
        exit (0);
        break;
    }

  if (setsid () == -1)
    g_error ("setsid () failed");

  return TRUE;
}

/* NOTE: This is a shallow copy, it only copies the pointers, not the strings themselves */

gchar **
gslist_to_strv (GSList *list)
{
    gchar **strv;
    gint length, n = 0;

    length =
      g_slist_length (list)+1;
    strv =
      g_new (gchar *, length);

    while (list)
	{
	    strv[n] = static_cast<char *> (list->data);
	    n++;
	    list = list->next;
	}

    strv[n] = NULL;

    return strv;
}

/* NOTE: This is a shallow copy, it only copies the pointers, not the strings themselves */

gchar **
glist_to_strv (GList *list)
{
  gchar **strv;
  gint length, n = 0;

  length = g_list_length (list)+1;
  strv = g_new (gchar *, length);

  while (list)
    {
      strv[n] = static_cast<char *> (list->data);
      n++;
      list = list->next;
    }

  strv[n] = NULL;

  return strv;
}


BmpUniqueList *
bmp_unique_list_new (GType type)
{
  BmpUniqueList *ulist = g_new (BmpUniqueList, 1);

  ulist->list = NULL;

  ulist->hash = (type == G_TYPE_STRING) ?
    g_hash_table_new (g_str_hash, g_str_equal) :
    g_hash_table_new (g_direct_hash, g_direct_equal);

  return ulist;
}


void
bmp_unique_list_free (BmpUniqueList *ulist)
{
  g_list_free (ulist->list);
  g_hash_table_destroy (ulist->hash);
  g_free (ulist);
}


void
bmp_unique_list_insert (BmpUniqueList *ulist,
                        gconstpointer  key)
{
  if (!g_hash_table_lookup (ulist->hash, key))
    {
      ulist->list = g_list_append (ulist->list, (gpointer) key);
      g_hash_table_insert (ulist->hash, (gpointer) key, g_list_last (ulist->list));
    }
}


void
bmp_unique_list_remove (BmpUniqueList *ulist,
                        gconstpointer  key)
{
    GList *llink = static_cast<GList *> (g_hash_table_lookup (ulist->hash, key));

    if (llink) {
	g_hash_table_remove (ulist->hash, key);
	ulist->list = g_list_remove_link (ulist->list, llink);
    }
}


GList*
bmp_unique_list_to_glist (BmpUniqueList *ulist)
{
  return ulist->list;
}


GHashTable*
bmp_unique_list_to_hashtable (BmpUniqueList *ulist)
{
  return ulist->hash;
}

//Attribute-to-Row map
GHashTable*
attr_row_map_new (void)
{
    return g_hash_table_new_full (g_str_hash, g_str_equal, g_free, (GDestroyNotify)gtk_tree_row_reference_free);
}

void
attr_row_map_mapping_insert (GHashTable *map, const gchar *key, GtkTreeModel *model, GtkTreeIter *iter)
{
    GtkTreeRowReference *row_reference;
    GtkTreePath *tree_path;

    tree_path =
      gtk_tree_model_get_path (model, iter);
    if (!tree_path)
      return;

    row_reference =
      gtk_tree_row_reference_new (model, tree_path);
    if (!row_reference)
      return;

    gtk_tree_path_free (tree_path);

    g_hash_table_insert (map, g_strdup (key), row_reference);
}


gboolean
attr_row_map_mapping_get (GHashTable *map, const gchar *key, GtkTreeModel *model, GtkTreeIter *iter)
{
    GtkTreeRowReference *row_reference;
    GtkTreePath *tree_path;

    row_reference = static_cast<GtkTreeRowReference *> (g_hash_table_lookup (map, key));
    if (!row_reference)
      return FALSE;

    tree_path =
      gtk_tree_row_reference_get_path (row_reference);
    if (!tree_path)
      return FALSE;

    gtk_tree_model_get_iter (model, iter, tree_path);
    gtk_tree_path_free (tree_path);

    return TRUE;
}


gboolean
attr_row_map_mapping_exists (GHashTable *map, const gchar *key)
{
    GtkTreeRowReference *row_reference;

    row_reference = static_cast<GtkTreeRowReference *> (g_hash_table_lookup (map, key));
    if (!row_reference)
      return FALSE;

    return TRUE;
}


gboolean
attr_row_map_mapping_remove (GHashTable *map, const gchar *key)
{
    GtkTreeRowReference *row_reference;

    row_reference = static_cast<GtkTreeRowReference *> (g_hash_table_lookup (map, key));

    if (!row_reference) return FALSE;

    gtk_tree_row_reference_free (row_reference);
    g_hash_table_remove (map, key);

    return TRUE;
}


gboolean
attr_row_map_mapping_remove_nodestroy (GHashTable *map, const gchar *key)
{
    GtkTreeRowReference *row_reference;

    row_reference = static_cast<GtkTreeRowReference *> (g_hash_table_lookup (map, key));
    if (!row_reference) return FALSE;

    g_hash_table_steal (map, key);

    return TRUE;
}


gboolean
match_keys (const gchar *check,
	    const gchar *key_string)
{
    gchar  *key_string_lc,
	   *check_lc;

    gchar **keys;
    gint    i;

    key_string_lc = g_utf8_strdown (key_string, -1);
    check_lc = g_utf8_strdown (check, -1);

    keys = g_strsplit (key_string_lc, " ", -1);

    i = 0;
    while (keys[i])
      {
        if (!g_strrstr_len(check_lc, std::strlen(check_lc), keys[i]))
	  {
            g_free(key_string_lc);
            g_free(check_lc);
	    g_strfreev (keys);
            return FALSE;
	  }
        i++;
    }

    g_free(key_string_lc);
    g_free(check_lc);
    g_strfreev (keys);

    return TRUE;
}


#if defined (__FreeBSD__)
#include <sys/param.h>
#include <sys/ucred.h>
#include <sys/mount.h>
#include <stdio.h>


GList*
get_mount_entries (void)
{
	struct statfs  *filesystems;
	gint	        n_filesystems, n = 0;
	GList	       *entries = NULL;

	n_filesystems = getmntinfo (&filesystems, MNT_WAIT);

	for (n = 0; n < n_filesystems; n++)
	  {
		if (!(filesystems[n].f_flags && MNT_ROOTFS))
		  entries = g_list_append (entries, g_strdup (filesystems[n].f_mntonname));
	  }

	return entries;
}
#endif

#if defined (__linux__)
#include <stdio.h>
#include <mntent.h>


GList*
get_mount_entries (void)
{
    GList      *entries = NULL;
    FILE       *fp;
    gboolean    run = TRUE;

    fp = setmntent("/proc/mounts","r");
    if (fp)
      goto get_entries;

    fp = setmntent("/etc/mtab","r");
    if (fp)
      goto get_entries;

    fp = setmntent("/etc/fstab","r");
    if (fp)
      goto get_entries;

    return NULL;

    get_entries:

    while (run)
      {
	struct mntent *mentry;

	mentry = getmntent (fp);

	if (!mentry)
	  {
	      run = FALSE;
	      break;
	  }

	if (!(std::strlen(mentry->mnt_dir)==1))
	  entries = g_list_append (entries, g_strdup (mentry->mnt_dir));
      }

    return entries;
}
#endif
