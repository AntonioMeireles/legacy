/*  BMPx - The Dumb Music Player
 *  Copyright (C) 2005 BMPx development team.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 *  $Id$
 *
 * The BMPx project hereby grant permission for non-gpl compatible GStreamer
 * plugins to be used and distributed together with GStreamer and BMPx. This
 * permission are above and beyond the permissions granted by the GPL license
 * BMPx is covered by.
 */

#include <gtk/gtkmain.h>
#include <glib-object.h>
#include <glib/gmacros.h>
#include <gtk/gtkmarshal.h>

#include <bmp/widgets/bmp_slider.h>

/* Forward declarations */

static void bmp_slider_class_init               (BmpSliderClass    *klass);
static void bmp_slider_init                     (BmpSlider         *slider);
static void bmp_slider_destroy                  (GtkObject        *object);
static void bmp_slider_realize                  (GtkWidget        *widget);
static gint bmp_slider_expose                   (GtkWidget        *widget,
						GdkEventExpose   *event);
static gint bmp_slider_slider_press             (GtkWidget        *widget,
						GdkEventButton   *event);
static gint bmp_slider_slider_release           (GtkWidget        *widget,
						GdkEventButton   *event);
static gint bmp_slider_enter_notify		(GtkWidget	 *widget,
						GdkEventCrossing *event);
static gint bmp_slider_leave_notify		(GtkWidget	 *widget,
						GdkEventCrossing *event);
static gint bmp_slider_motion_notify            (GtkWidget *widget,
						GdkEventMotion *event);
static gint bmp_slider_scroll			(GtkWidget *widget,
						GdkEventScroll *event);

/* Local data */

enum {
	BMP_SLIDER_MOVED,
	BMP_SLIDER_MOTION_HINT,
    
	SLIDER_N_SIGNALS
};

static GtkDrawingAreaClass *parent_class = NULL;
static guint signals[SLIDER_N_SIGNALS] = { 0 };

GType
bmp_slider_get_type ()
{
  static GType slider_type = 0;

  if (!slider_type)
    {
      static const GTypeInfo slider_info =
      {
        sizeof (BmpSliderClass),
        NULL,           /* base_init */
        NULL,           /* base_finalize */
        (GClassInitFunc) bmp_slider_class_init,
        NULL,           /* class_finalize */
        NULL,           /* class_data */
        sizeof (BmpSlider),
        0,              /* n_preallocs */
        (GInstanceInitFunc) bmp_slider_init
      };

      slider_type =
        g_type_register_static (GTK_TYPE_DRAWING_AREA, "BmpSlider",
                                &slider_info, 0);
    }

  return slider_type;
}


static void
bmp_slider_class_init (BmpSliderClass *class)
{
  GtkObjectClass *object_class;
  GtkWidgetClass *widget_class;

  object_class = (GtkObjectClass*) class;
  widget_class = (GtkWidgetClass*) class;

  parent_class = gtk_type_class (gtk_widget_get_type ());

  object_class->destroy = bmp_slider_destroy;

  widget_class->realize = bmp_slider_realize;
  widget_class->expose_event = bmp_slider_expose;
  widget_class->enter_notify_event = bmp_slider_enter_notify;
  widget_class->leave_notify_event = bmp_slider_leave_notify;
  widget_class->motion_notify_event = bmp_slider_motion_notify;
  widget_class->button_press_event = bmp_slider_slider_press;
  widget_class->button_release_event = bmp_slider_slider_release;
  widget_class->scroll_event = bmp_slider_scroll;

  signals[BMP_SLIDER_MOVED] =
  g_signal_new ("moved",
                  G_OBJECT_CLASS_TYPE (object_class),
                  G_SIGNAL_RUN_FIRST,
                  G_STRUCT_OFFSET (BmpSliderClass, moved),
                  NULL, NULL,
                  g_cclosure_marshal_VOID__VOID,
                  G_TYPE_NONE, 0);

  signals[BMP_SLIDER_MOTION_HINT] =
  g_signal_new ("motion_hint",
                  G_OBJECT_CLASS_TYPE (object_class),
                  G_SIGNAL_RUN_FIRST,
                  G_STRUCT_OFFSET (BmpSliderClass, motion_hint),
                  NULL, NULL,
                  g_cclosure_marshal_VOID__VOID,
                  G_TYPE_NONE, 0);
}

static void
bmp_slider_init (BmpSlider *slider)
{
	slider->width = 0;
	slider->height = 0;
	slider->pb_normal = NULL;
	slider->pb_pressed = NULL;
	slider->constructed = 0;
	slider->in_slider = 0;
	slider->state = BMP_SLIDER_STATE_IDLE;
	slider->position = 0;
	slider->button_yoffset = 0;
	slider->on_motion = FALSE;
	slider->scroll_step = 1; 
	slider->max_adjust = 0;
}


GtkWidget*
bmp_slider_new (void)
{
  BmpSlider *slider;

  slider = gtk_type_new (bmp_slider_get_type ());
  return GTK_WIDGET (slider);
}


GtkWidget*
bmp_slider_new_with_pixbufs(GdkPixbuf *sliderbg, GdkPixbuf *normal, GdkPixbuf *pressed)
{
  BmpSlider *slider;
  slider = gtk_type_new (bmp_slider_get_type ());

  slider->pb_normal = normal;
  g_object_ref(normal);

  slider->pb_pressed = pressed;
  g_object_ref(pressed);

  slider->pb_sliderbg = sliderbg;
  g_object_ref(sliderbg);

  return GTK_WIDGET (slider);
}

void
bmp_slider_set_pixbufs(BmpSlider *slider, GdkPixbuf *sliderbg, GdkPixbuf *normal, GdkPixbuf *pressed, gboolean has_button)
{

  if (G_IS_OBJECT(slider->pb_normal))
    {
	g_object_unref(slider->pb_normal);
    }
  slider->pb_normal = normal;
  g_object_ref(normal);

  if (G_IS_OBJECT(slider->pb_normal))
    {
	g_object_unref(slider->pb_pressed);
    }
  slider->pb_pressed = pressed;
  g_object_ref(pressed);


  if (G_IS_OBJECT(slider->pb_sliderbg))
    {
	g_object_unref(slider->pb_sliderbg);
    }
  slider->pb_sliderbg = sliderbg;
  g_object_ref(sliderbg);

  slider->has_button = has_button;
}

void
bmp_slider_set_from_table (BmpSlider	   *slider,
			  const GdkPixbuf  *src,
			  guint		    width,
			  guint		    height,
			  guint		    width_button,
			  guint		    height_button,
			  guint		    x_sliderbg,
			  guint		    y_sliderbg,
			  guint		    x_normal,
			  guint		    y_normal,
			  guint		    x_pressed,
			  guint		    y_pressed,
			  gboolean	    has_button)
{
  g_return_if_fail (GDK_IS_PIXBUF (src));

  slider->pb_sliderbg = gdk_pixbuf_new (gdk_pixbuf_get_colorspace(src),
                                            gdk_pixbuf_get_has_alpha(src),
                                            gdk_pixbuf_get_bits_per_sample(src),
                                            width, height);

  gdk_pixbuf_copy_area (src, x_sliderbg, y_sliderbg, width, height,slider->pb_sliderbg, 0, 0);
                        
  if (height_button > 15)
    {
      has_button = FALSE;
    }

  if (has_button)
    {

	slider->pb_normal = gdk_pixbuf_new (gdk_pixbuf_get_colorspace(src),
						gdk_pixbuf_get_has_alpha(src),
						gdk_pixbuf_get_bits_per_sample(src),
						width_button, height_button);
	slider->pb_pressed = gdk_pixbuf_new (gdk_pixbuf_get_colorspace(src),
						gdk_pixbuf_get_has_alpha(src),
						gdk_pixbuf_get_bits_per_sample(src),
						width_button, height_button);

	if (x_normal < gdk_pixbuf_get_width (src))
	  {
	    gdk_pixbuf_copy_area (src, x_normal, y_normal, width_button, height_button,
	    			  slider->pb_normal, 0, 0);

  	    gdk_pixbuf_copy_area (src, x_pressed, y_pressed, width_button, height_button,
				  slider->pb_pressed, 0, 0);

	    slider->has_button = TRUE;
	  }
        else
	  {
	    slider->has_button = FALSE;
	  }

    }
  else
    {
	slider->has_button = FALSE;
    }

  slider->width = width;
  slider->height = height;

  slider->width_button = width_button;
  slider->height_button = height_button;

  if (slider->position < width_button/2)
      slider->position = width_button/2;

  slider->slider_max = 1.*slider->width - ((slider->width_button-1)/2.) - 1.*slider->max_adjust;
  slider->slider_min = slider->width_button/2.;
}

static void
bmp_slider_destroy (GtkObject *object)
{
  BmpSlider *slider;

  g_return_if_fail (object != NULL);
  g_return_if_fail (BMP_IS_SLIDER (object));

  slider = BMP_SLIDER(object);

  if (GTK_OBJECT_CLASS (parent_class)->destroy)
    (*GTK_OBJECT_CLASS (parent_class)->destroy) (object);
}

static void
bmp_slider_realize (GtkWidget *widget)
{
  BmpSlider *slider;
  GdkWindowAttr attributes;
  gint attributes_mask;

  g_return_if_fail (widget != NULL);
  g_return_if_fail (BMP_IS_SLIDER (widget));

  GTK_WIDGET_SET_FLAGS (widget, GTK_REALIZED);
  slider = BMP_SLIDER (widget);

  attributes.x = widget->allocation.x;
  attributes.y = widget->allocation.y;
  attributes.width = widget->allocation.width;
  attributes.height = widget->allocation.height;
  attributes.wclass = GDK_INPUT_OUTPUT;
  attributes.window_type = GDK_WINDOW_CHILD;
  attributes.event_mask = gtk_widget_get_events (widget) |
    GDK_EXPOSURE_MASK | GDK_BUTTON_PRESS_MASK |
    GDK_BUTTON_RELEASE_MASK | GDK_LEAVE_NOTIFY_MASK | GDK_ENTER_NOTIFY_MASK |
    GDK_POINTER_MOTION_MASK | GDK_BUTTON_MOTION_MASK | GDK_SCROLL_MASK;
  attributes.visual = gtk_widget_get_visual (widget);
  attributes.colormap = gtk_widget_get_colormap (widget);

  attributes_mask = GDK_WA_X | GDK_WA_Y | GDK_WA_VISUAL | GDK_WA_COLORMAP;
  widget->window = gdk_window_new (widget->parent->window, &attributes, attributes_mask);

  widget->style = gtk_style_attach (widget->style, widget->window);

  gdk_window_set_user_data (widget->window, widget);

  gtk_style_set_background (widget->style, widget->window, GTK_STATE_ACTIVE);
}

static gboolean
bmp_slider_expose (GtkWidget      *widget,
		 GdkEventExpose *event)
{
  BmpSlider *slider;
  GdkPixbuf *buf;
  gint slice_offset, slice_height, pos, step;

  g_return_val_if_fail (widget != NULL, FALSE);
  g_return_val_if_fail (BMP_IS_SLIDER (widget), FALSE);
  g_return_val_if_fail (event != NULL, FALSE);

  if (event->count > 0)
    return FALSE;

  slider = BMP_SLIDER (widget);

  buf = slider->pb_normal;

  if ((slider->state == BMP_SLIDER_STATE_ACTIVE) && (slider->in_slider)) buf = slider->pb_pressed;

  if (slider->sliced)
    {
          pos  =  (slider->position) - (slider->width_button/2);
          step =  slider->width / slider->num_slices;
	  slice_offset = (pos/step) * slider->slice_size;
          slice_height = BMP_SLIDER(slider)->slice_size;

	  if ( (slice_height + slice_offset) > 419) slice_height--;

	  if (slice_offset <= gdk_pixbuf_get_height(BMP_SLIDER(slider)->pb_sliderbg))
	  gdk_draw_pixbuf(GTK_WIDGET(slider)->window,
		 	NULL,	
			BMP_SLIDER(slider)->pb_sliderbg,
			0,
		        slice_offset,
			0,
			0,
			BMP_SLIDER(slider)->width,
		 	slice_height,	
			GDK_RGB_DITHER_NONE,
			0,
			0);
    }
  else
  if (GDK_IS_PIXBUF (BMP_SLIDER(slider)->pb_sliderbg))
    {
	  gdk_draw_pixbuf(GTK_WIDGET(slider)->window,
		 	NULL,	
			BMP_SLIDER(slider)->pb_sliderbg,
			0,
		        0,
			0,
			0,
			BMP_SLIDER(slider)->width,
			BMP_SLIDER(slider)->height,
			GDK_RGB_DITHER_NONE,
			0,
			0);
    }

  if (slider->has_button)
    {
	gdk_draw_pixbuf(GTK_WIDGET(slider)->window,
				NULL,	
				buf,
				0,
				0,
				(slider->position)-(slider->width_button/2),
				slider->button_yoffset,
				-1,
				-1,
				GDK_RGB_DITHER_NONE,
				0,
				0);
    }
  
  return FALSE;
}

static gboolean
bmp_slider_slider_press (GtkWidget      *widget,
		       GdkEventButton *event)
{
  BmpSlider *slider;

  g_return_val_if_fail (widget != NULL, FALSE);
  g_return_val_if_fail (BMP_IS_SLIDER (widget), FALSE);
  g_return_val_if_fail (event != NULL, FALSE);

  if (event->button != 1) return FALSE;

  slider = BMP_SLIDER (widget);

  if (event->type == GDK_BUTTON_PRESS)
    {

		slider->state = BMP_SLIDER_STATE_ACTIVE;

		slider->position = event->x;

		if (slider->position < slider->slider_min) slider->position = slider->slider_min;
		if (slider->position > slider->slider_max) slider->position = slider->slider_max;

		gtk_widget_queue_draw(widget);
    }

  return TRUE;
}

static gboolean
bmp_slider_scroll (GtkWidget      *widget,
	           GdkEventScroll *event)
{
	BmpSlider *slider;

	slider = BMP_SLIDER(widget);

	if (event->direction == GDK_SCROLL_UP)
	{
		slider->position += slider->scroll_step;
	} 
	else
	if (event->direction == GDK_SCROLL_DOWN)
	{
		slider->position -= slider->scroll_step;
	}

	if (slider->position < slider->slider_min) slider->position = slider->slider_min;
	if (slider->position > slider->slider_max) slider->position = slider->slider_max;

  	g_signal_emit (slider, signals[BMP_SLIDER_MOVED], 0);
	gtk_widget_queue_draw (widget);

        return TRUE;
}

static gboolean
bmp_slider_slider_release (GtkWidget      *widget,
			  GdkEventButton *event)
{
  BmpSlider *slider;

  g_return_val_if_fail (widget != NULL, FALSE);
  g_return_val_if_fail (BMP_IS_SLIDER (widget), FALSE);
  g_return_val_if_fail (event != NULL, FALSE);

  slider = BMP_SLIDER (widget);

  slider->state = BMP_SLIDER_STATE_IDLE;

  g_signal_emit(slider, signals[BMP_SLIDER_MOVED], 0);
  gtk_widget_queue_draw(widget);

  return TRUE;
}

static gboolean
bmp_slider_enter_notify (GtkWidget *widget, GdkEventCrossing *event)
{
  BmpSlider *slider;

  slider = BMP_SLIDER(widget);
  slider->in_slider = TRUE;
  gtk_widget_queue_draw(widget);
  return TRUE;
}


static gboolean
bmp_slider_leave_notify (GtkWidget *widget, GdkEventCrossing *event)
{
  BmpSlider *slider;
  slider = BMP_SLIDER(widget);
  slider->in_slider = FALSE;
  gtk_widget_queue_draw(widget);
  return TRUE;
}


static gboolean
bmp_slider_motion_notify (GtkWidget *widget, GdkEventMotion *event)
{

  BmpSlider *slider;

  slider = BMP_SLIDER(widget);

  if (slider->state == BMP_SLIDER_STATE_ACTIVE)
    {
		slider->position = event->x; 

		if (slider->position < slider->slider_min) slider->position = slider->slider_min;
		if (slider->position > slider->slider_max) slider->position = slider->slider_max;

  		if (slider->on_motion)
		  {
		    g_signal_emit (slider, signals[BMP_SLIDER_MOVED], 0);
		  }

		g_signal_emit (slider, signals[BMP_SLIDER_MOTION_HINT], 0);
		gtk_widget_queue_draw(widget);
    }
  
  return TRUE;
}

gdouble
bmp_slider_get_position (BmpSlider  *slider)
{
  g_return_val_if_fail (slider != NULL, -1);
  g_return_val_if_fail (BMP_IS_SLIDER (slider), -1);

  return ((1.*slider->position) - (slider->width_button/2.)) / ((slider->width - slider->width_button)/100.); 
}

void
bmp_slider_set_position (BmpSlider    *slider,
			 gdouble       position)
{
  gdouble     percent, 
	      total;

  g_return_if_fail (slider != NULL);
  g_return_if_fail (BMP_IS_SLIDER (slider));

  total = slider->width - slider->width_button - 0.5; 
  percent = total / 100.;
  slider->position = (position * percent) + (slider->width_button/2); 

  gtk_widget_queue_draw (GTK_WIDGET(slider));
}

void
bmp_slider_set_slice_data (BmpSlider	*slider,
			   gboolean	 sliced,
			   guint	 slice_size,  
			   guint	 num_slices,
			   gboolean	 has_button)
{
  g_return_if_fail (slider != NULL);
  g_return_if_fail (BMP_IS_SLIDER (slider));

  slider->sliced = sliced;
  slider->slice_size = slice_size;
  slider->num_slices = num_slices;
  slider->has_button = has_button;
}

void
bmp_slider_set_report_on_motion (BmpSlider    *slider,
			         gboolean      flag)
{
  g_return_if_fail (slider != NULL);
  g_return_if_fail (BMP_IS_SLIDER (slider));
  slider->on_motion = flag;
}

void
bmp_slider_set_scroll_step  (BmpSlider	  *slider,
			     guint	   step)
{
  g_return_if_fail (slider != NULL);
  g_return_if_fail (BMP_IS_SLIDER (slider));
  slider->scroll_step = step;
}






