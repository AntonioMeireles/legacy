#ifndef BMP_BOOKMARKS_HPP
#define BMP_BOOKMARKS_HPP

#include <glibmm.h>
#include <gtkmm.h>

#include <libxml/tree.h>
#include <libxml/parser.h>
#include <libxml/xmlreader.h>
#include <libxml/xpath.h>
#include <libxml/xpathInternals.h>

namespace Bmp {

  namespace Streams
  {

    class Bookmarks {

      public:

	Bookmarks ();
	~Bookmarks();

	class BookmarkColumns
	  : public Gtk::TreeModelColumnRecord
	{
	  public:

	    Gtk::TreeModelColumn<Glib::ustring> title;
	    Gtk::TreeModelColumn<Glib::ustring> desc;
	    Gtk::TreeModelColumn<Glib::ustring> href;

	    BookmarkColumns ()
	    {
	      add (title);
	      add (desc);
	      add (href);
	    };
	};

	BookmarkColumns bookmark_columns;

	Glib::RefPtr<Gtk::ListStore>
	get_store ()
	{
	  return bookmarks;
	};

      private:

	Glib::RefPtr<Gtk::ListStore> bookmarks;

        bool  
	append_node (const Gtk::TreeModel::iterator& iter, xmlNodePtr root);

    }; // Bookmarks

  }; // Streams

}; // Bmp

#endif // BMP_BOOKMARKS_HPP
