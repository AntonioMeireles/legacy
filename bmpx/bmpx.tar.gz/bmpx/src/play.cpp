/*  BMPx - The Dumb Music Player
 *  Copyright (C) 2005 BMPx development team.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 *  $Id$
 *
 * The BMPx project hereby grant permission for non-gpl compatible GStreamer
 * plugins to be used and distributed together with GStreamer and BMPx. This
 * permission are above and beyond the permissions granted by the GPL license
 * BMPx is covered by.
 */

#include <config.h>
#include <string.h>

#include <glibmm.h>
#include <glib/gi18n.h>

#include <gst/gst.h>
#include <gst/gstelement.h>
#include <gst/interfaces/mixer.h>
#include <gst/interfaces/mixertrack.h>
#include <gst/interfaces/mixeroptions.h>

#include <bmp/uri++.hpp>
#include <bmp/util.h>

#include <goa/libgoa.h>

#include "play.hpp"
#include "main.hpp"

#include <boost/shared_ptr.hpp>

#define BMP_GST_BUFFER_TIME   ((gint64) 50000)
#define BMP_GST_PLAY_TIMEOUT  ((gint64) 3000000000)

namespace Bmp {

    //ctor
    Play::Play () 
		: Glib::ObjectBase (typeid(Play)),
		  property_stream_   (*this, "stream", ""),
		  property_volume_   (*this, "volume", 50),
		  property_position_ (*this, "position", 0),
		  property_status_   (*this, "playstatus", PLAYSTATUS_STOPPED),
		  property_mute_     (*this, "mute"),
		  property_sane_     (*this, "sane"),
		  property_length_   (*this, "length"), 
		  property_has_cdda_ (*this, "has_cdda"), 
		  property_has_http_ (*this, "has_http"), 

		  current_pipe	 (P_FILE),
		  source         (sigc::connection())
    {
	int volume;

	bmp_system_control_volume_get (bmp_system_control, &volume, 0);
	property_volume() = volume;

	this->message_domain_id = bmp_system_control_message_domain_register (bmp_system_control,
									      "play",
				  					      _("BMP: Audio"));

	property_volume().signal_changed().connect(sigc::mem_fun(*this, &Bmp::Play::on_volume_changed));
	property_stream().signal_changed().connect(sigc::mem_fun(*this, &Bmp::Play::on_stream_changed));
	property_position().signal_changed().connect(sigc::mem_fun(*this, &Bmp::Play::on_position_changed));
	property_status().signal_changed().connect(sigc::mem_fun(*this, &Bmp::Play::on_playstatus_changed));

	for (int n = 0; n < N_ELEMENTS; n++)
	{
	  elements[P_FILE][n] = 0;
	  elements[P_HTTP][n] = 0;
	  elements[P_CDDA][n] = 0;
	}

	reset ();

        //Check supported extensions
	{ 
	  GList  *factories;
	  gchar	**list;
	  gint    n, k;

          k = 0;
	  factories = gst_type_find_factory_get_list ();
	  for (;factories;factories=factories->next)
	    {
	      list = gst_type_find_factory_get_extensions (static_cast<GstTypeFindFactory *> (factories->data));
	      if (!list) continue;
	      for (n = 0; list[n]; n++)
		{
		  Glib::ustring ext = list[n];
		  ext.lowercase ();
		  extensions[ext] = true;
		}
	      g_strfreev (list);
	    }
	}
    }

    //dtor
    Play::~Play ()
    {
	pipelines_destroy ();
    }

    gboolean
    Play::foreach_structure (GQuark	    field_id,
			     const GValue  *value,
			      gpointer	    data)
    {
      Bmp::Play *play;
      play = reinterpret_cast<Bmp::Play*>(data);

      if (field_id == g_quark_from_string ("rate"))
      {
	int samplerate = g_value_get_int (value);
	if (samplerate) play->signal_samplerate_.emit (samplerate);
	return FALSE;
      }
      return TRUE;
    }

    bool
    Play::timeout_handler ()
    {
      GstQuery       *query;
      GstFormat       format = GST_FORMAT_TIME;
      gint64          time_in_nanoseconds;
      gint            time_in_seconds;

      if (!(GST_STATE (elements[current_pipe][PIPELINE]) == GST_STATE_PLAYING))
	{
	  return false;
	}

      query = gst_query_new_position (format);
      gst_element_query (elements[current_pipe][SINK], query);
      gst_query_parse_position (query, &format, &time_in_nanoseconds);
      time_in_seconds = time_in_nanoseconds / GST_SECOND;
      gst_query_unref (query);

      if ((time_in_seconds >= 0) && (GST_STATE(elements[current_pipe][PIPELINE]) >= GST_STATE_PLAYING))
	{
	  signal_position_.emit(time_in_seconds);
	  return true;
	}
      else
	{
	  signal_position_.emit(0);
	  return false;
	}

      return false;
    }

    bool
    Play::is_audio_file (const Glib::ustring& uri)
    {
	Glib::ustring ext;
	size_t position;

	position = uri.rfind ('.');
	ext = uri.substr (position+1);
	ext = ext.lowercase ();

	return (extensions.find (ext) != extensions.end());
    }

    void 
    Play::stop_stream ()
    {
        gst_element_set_state (elements[current_pipe][PIPELINE], GST_STATE_NULL);
		  source.disconnect ();	
		  signal_position_.emit (0);
		  signal_bitrate_.emit (0);
		  signal_samplerate_.emit (0);

    }
    
    void 
    Play::play_stream ()
    {
	Bmp::URI uri (property_stream().get_value());

        if ((uri.get_protocol() == Bmp::URI::PROTOCOL_HTTP) && (!elements[P_HTTP][PIPELINE]))
            {
		property_status() = PLAYSTATUS_STOPPED;
		return;
            }
	else 
        if ((uri.get_protocol() == Bmp::URI::PROTOCOL_CDDA) && (!elements[P_CDDA][PIPELINE]))
            {
		property_status() = PLAYSTATUS_STOPPED;
		return;
            }
        
        if (gst_element_set_state (elements[current_pipe][PIPELINE], GST_STATE_PLAYING) == GST_STATE_CHANGE_FAILURE)
            {
		gst_element_set_state (elements[current_pipe][PIPELINE], GST_STATE_READY);
		return;
            }
        
        g_object_set (elements[current_pipe][VOLUME], "mute", property_mute().get_value() ? TRUE : FALSE, NULL);
        g_object_set (elements[current_pipe][VOLUME], "volume", property_volume().get_value()/100. , NULL);
    }
    
    void 
    Play::pause_stream ()
    {
        if (GST_STATE (elements[current_pipe][PIPELINE]) == GST_STATE_PAUSED)
	  {
	      property_status() = PLAYSTATUS_PLAYING;
	  }
        
        gst_element_set_state (elements[current_pipe][PIPELINE], GST_STATE_PAUSED);
    }

    void
    Play::on_volume_changed () 
    {
      gdouble _volume;

      _volume = property_volume().get_value()/100.; 
      g_object_set (elements[current_pipe][VOLUME], "volume", _volume, NULL);
    }

    void
    Play::on_stream_changed () 
    {
      if (property_sane().get_value() == false) return;
      Bmp::URI uri (property_stream().get_value());

      switch (uri.get_protocol())
      {
		  case Bmp::URI::PROTOCOL_FILE:
		  { 
		    current_pipe = P_FILE;
		    Glib::ustring filename = g_filename_from_uri (property_stream().get_value().c_str(), NULL, NULL);
		    g_object_set (elements[current_pipe][SRC], "location", filename.c_str(), NULL);
		    break;
		  }
  
		  case Bmp::URI::PROTOCOL_HTTP:
		  {
		    current_pipe = P_HTTP;
		    g_object_set (elements[current_pipe][SRC], "location", property_stream().get_value().c_str(), NULL);
		    break;
		  }
		   
		  case Bmp::URI::PROTOCOL_CDDA:
		  {
		    unsigned int track;
		    current_pipe = P_CDDA;
		    Bmp::URI uri (property_stream().get_value());
		    track = (unsigned int)atoi((uri.path.c_str())+1);
		    g_object_set (elements[current_pipe][SRC], "track", track, NULL);
		    break;
		  }

	      default: return;
	  }
    }

    void
    Play::on_playstatus_changed () 
    {
      if (property_status().get_value() & PLAYSTATUS_SEEKING)
	{ 
	  pause_stream (); 
	  return;
	}

      if (property_status().get_value() & PLAYSTATUS_STOPPED)
	{
	  stop_stream ();
	  return;
	}

      if (property_status().get_value() & PLAYSTATUS_WAITING)
	{
	  stop_stream ();
	  return;
	}

      if (property_status().get_value() & PLAYSTATUS_PAUSED)
	{
	  pause_stream (); 
	  return;
	}

      if (property_status().get_value() & PLAYSTATUS_PLAYING)
	{
	  play_stream ();
	  return;
	}
    }

    void
    Play::on_position_changed () 
    {
      GstEvent	 *seek_event;
      guint64	  seek_offset;

      seek_offset = (property_position().get_value() * GST_SECOND);
      seek_event = gst_event_new_seek (1.0, GST_FORMAT_TIME, GST_SEEK_FLAG_FLUSH,
			GST_SEEK_TYPE_SET, seek_offset, GST_SEEK_TYPE_NONE, 0);

      if (gst_element_send_event (elements[current_pipe][PIPELINE], seek_event))
	{
	  gst_pipeline_set_new_stream_time (GST_PIPELINE(elements[current_pipe][PIPELINE]), 0);
	  gst_element_get_state (GST_ELEMENT(elements[current_pipe][PIPELINE]), 0, 0, 50 * GST_MSECOND);
	  signal_seek_.emit(property_position().get_value());
	}
    }

    void
    Play::pipelines_destroy ()    
    {
      if (elements[P_FILE][PIPELINE])
	{
	  gst_element_set_state (elements[P_FILE][PIPELINE], GST_STATE_NULL);
	  gst_object_unref (elements[P_FILE][PIPELINE]);
	}

      if (elements[P_HTTP][PIPELINE])
	{
	  gst_element_set_state (elements[P_HTTP][PIPELINE], GST_STATE_NULL);
	  gst_object_unref (elements[P_HTTP][PIPELINE]);
    	}

      if (elements[P_CDDA][PIPELINE])
	{
	  gst_element_set_state (elements[P_CDDA][PIPELINE], GST_STATE_NULL);
	  gst_object_unref (elements[P_CDDA][PIPELINE]);
	}

	for (int n = 0; n < N_ELEMENTS; n++)
	{
	  elements[P_FILE][n] = 0;
	  elements[P_HTTP][n] = 0;
	  elements[P_CDDA][n] = 0;
	}
    }

    void
    Play::link_pad (GstElement *element,
		    GstPad     *pad,
		    gboolean    last,
		    gpointer	data) 
    {
	Bmp::Play   *play;
	GstPad	    *sinkpad;

	play = reinterpret_cast<Bmp::Play*>(data);
	if (play->current_pipe != P_HTTP)
	{
	  sinkpad = gst_element_get_pad (play->elements[play->current_pipe][CONVERT], "sink");
	  gst_pad_link (pad, sinkpad);
	}
	else
	{
	  sinkpad = gst_element_get_pad (play->elements[play->current_pipe][TEE], "sink");
	  gst_pad_link (pad, sinkpad);
	}
    }

    gboolean
    Play::bus_watch (GstBus     *bus,
                     GstMessage *message,
                     gpointer    data)
    {
	static GstState old_state=GstState (0), new_state=GstState(0), pending_state=GstState(0);
	Bmp::Play *play; 
	play = reinterpret_cast<Bmp::Play*>(data);
        
        switch (GST_MESSAGE_TYPE (message))
	{
	    case GST_MESSAGE_TAG:
	    {
		if ((old_state == GST_STATE_PLAYING) && (new_state < GST_STATE_PLAYING)) break; 

		GstTagList *tag_list;
		gst_message_parse_tag (message, &tag_list);
		if (tag_list)
		{
		  char *title = 0;
		  unsigned int bitrate = 0;

		  if (gst_tag_list_get_string (tag_list, GST_TAG_TITLE, &title));
		  {
		      if ((title) && (play->current_pipe == P_HTTP))
		      {
			play->signal_title_.emit (title);
		      }
		  }

		  if (gst_tag_list_get_uint (tag_list, GST_TAG_BITRATE, &bitrate));
		  {
		    if (bitrate)
		    {
			play->signal_bitrate_.emit (bitrate/1000);
		    }
		  }

		}
	    }
	    break;

            case GST_MESSAGE_STATE_CHANGED:
            {
                gst_message_parse_state_changed (message,
						 &old_state,
                                                 &new_state,
						 &pending_state);
       
                if (new_state == GST_STATE_PLAYING)
                {
		  if (message->src == GST_OBJECT(play->elements[play->current_pipe][PIPELINE]))
		  {
		    if (!play->source.connected())
		    {
		      play->source = Glib::signal_timeout().connect( sigc::mem_fun (play, &Bmp::Play::timeout_handler ), 250);
		    }

		    GstPad *pad = gst_element_get_pad (play->elements[play->current_pipe][SINK], "sink");
		    GstCaps *caps = gst_pad_get_negotiated_caps (pad);
		    gst_object_unref (pad);

		    for (unsigned int n = 0; n < gst_caps_get_size (caps); ++n)
		    {
		      gst_structure_foreach (gst_caps_get_structure (caps, n),
					     GstStructureForeachFunc (Bmp::Play::foreach_structure),
					     play);
		    }
		  }
                }
#if 0
		else
		if ((new_state < GST_STATE_PAUSED) && (message->src == GST_OBJECT(play->elements[play->current_pipe][PIPELINE])))
		{
		  play->source.disconnect ();	
		  play->signal_position_.emit (0);
		  play->signal_bitrate_.emit (0);
		  play->signal_samplerate_.emit (0);
		}
#endif
            }
            break;

            case GST_MESSAGE_ERROR:
            {
                GstElement    *element;
                GError	      *error = 0;
                Glib::ustring  name,
			       location,
			       message_str;
		char	      *debug_string;
        
                element = GST_ELEMENT(GST_MESSAGE_SRC (message));
                name = gst_object_get_name (GST_OBJECT(element));
        
                if (play->elements[play->current_pipe][SRC])
                {
                    location = g_object_get_string (play->elements[play->current_pipe][SRC], "location");
                }
                else
                {
                    location = "URI/Location could not be determined.";
                }
        
                message_str = "<b>ERROR [Element: <i>"+name+"</i>]</b>\n";
        
                gst_message_parse_error	(message,
                                        &error,
                                        &debug_string);
        
                if (error->domain == GST_CORE_ERROR)
                {
                            switch (error->code)
                                {
                                    case GST_CORE_ERROR_MISSING_PLUGIN:
                                    {
					message_str += "(E101) There is no plugin available to play this track\n";
                                        break;
                                    }
        
                                    case GST_CORE_ERROR_SEEK:
                                    {
                                        message_str += "(E102) An error occured during seeking\n";
                                        break;
                                    }
        
                                    case GST_CORE_ERROR_STATE_CHANGE:
                                    {
                                        typedef struct _StringPairs StringPairs;
                                        struct _StringPairs {
                                            Glib::ustring   state_pre;
                                            Glib::ustring   state_post;
                                        };
        
                                        static StringPairs string_pairs[] = {
                                            {"0",	  "READY"},
                                            {"READY",	  "PAUSED"},
                                            {"PAUSED",	  "PLAYING"},
                                            {"PLAYING",	  "PAUSED"},
                                            {"PAUSED",	  "READY"},
                                            {"READY",	  "0"},
                                        };
       
                                        message_str += "(E103) An error occured during changing the state from "+string_pairs[GST_STATE_PENDING(message->src)].state_pre+" to "+string_pairs[GST_STATE_PENDING(message->src)].state_post+" (note that these are internal states and don't neccesarily reflect what you might understand by e.g. 'play' or 'pause'\n";
                                        break;
                                    }
        
                                    case GST_CORE_ERROR_PAD:
                                    {
                                        message_str += "(E104) An error occured during pad linking/unlinking\n";
                                        break;
                                    }
        
                                    case GST_CORE_ERROR_NEGOTIATION:
                                    {
                                        message_str =+ "(E105) An error occured during element(s) negotiation\n";
                                        break;
                                    }
        
                                    default: break;
                                }
                }
                else if (error->domain == GST_RESOURCE_ERROR)
                {
                            switch (error->code)
                                {
        
                                    case GST_RESOURCE_ERROR_SEEK:
                                    {
                                        message_str += "(E201) An error occured during seeking\n";
                                        break;
                                    }
        
                                    case GST_RESOURCE_ERROR_NOT_FOUND:
                                    case GST_RESOURCE_ERROR_OPEN_READ:
                                    {
                                        message_str += "(E202) Couldn't open the stream/track\n";
                                        break;
                                    }
        
                                    default: break;
                                }
                    }
                else if (error->domain == GST_STREAM_ERROR)
                    {
                            switch (error->code)
                                {
                                    case GST_STREAM_ERROR_CODEC_NOT_FOUND:
                                    {
                                        message_str += "(E301) There is no codec installed to handle this stream\n";
                                        break;
                                    }
        
                                    case GST_STREAM_ERROR_DECODE:
                                    {
                                        message_str += "(E302) There was an error decoding the stream\n";
                                        break;
                                    }
        
                                    case GST_STREAM_ERROR_DEMUX:
                                    {
                                        message_str += "(E303) There was an error demultiplexing the stream\n";
                                        break;
                                    }
        
                                    case GST_STREAM_ERROR_FORMAT:
                                    {
                                        message_str += "(E304) There was an error parsing the format of the stream\n";
                                        break;
                                    }
        
                                    default: break;
                                }
                    }
        
		message_str += "\n<b>Current URI:</b>\n"+location+"\n\n<b>Detailed debugging information:</b>\n"+debug_string; 
		g_free (debug_string);
                g_error_free (error);
        
                bmp_system_control_message_dispatch (bmp_system_control,
                                                     play->message_domain_id,
                                                     GTK_MESSAGE_ERROR,
                                                     message_str.c_str());
       
		play->property_status() = PLAYSTATUS_STOPPED; 
                play->pipelines_destroy();
        
                if (name.compare("sink"))
		  {
                    play->pipeline_create (P_FILE);
                    play->pipeline_create (P_HTTP);
                    play->pipeline_create (P_CDDA);
		  }
                else
		  {
                    play->property_sane_ = false;
		  }
        
                break;
            }
        
            case GST_MESSAGE_WARNING:
            {
                GError  *error = 0;
                gchar   *debug;
        
                gst_message_parse_warning (message, &error, &debug);
                g_print ("%s WARNING: %s (%s)\n", G_STRLOC, error->message, debug);
                g_error_free (error);
            }
            break;
        
            case GST_MESSAGE_EOS:
                {
                    /* end-of-stream */
		    play->signal_eos_.emit();
                }
                break;
        
            default:
                /* unhandled message */
                break;
            }
        
            return TRUE;
    }


    void
    Play::pipeline_create (Pipeline pipeline)
    {
      Glib::ustring	     device, sink, device_propname;
      guint64		     buffer_time;
      bool		     set_buffer_time;

      sink = mcs->key_get<std::string>( "audio", "sink");

      set_buffer_time = false;
      buffer_time = 200000;

#ifdef HAVE_ALSA
      if (!sink.compare("alsasink"))
	{
	  set_buffer_time = true;
	  buffer_time = mcs->key_get<int>("audio", "alsa-buffer-time");
	  device_propname = "device";
	  device = mcs->key_get<std::string>( "audio", "device-alsa");
	}
      else
#endif
      if (!sink.compare("osssink"))
	{
	  set_buffer_time = true;
	  buffer_time = mcs->key_get<int>("audio", "oss-buffer-time");
	  device_propname = "device";
	  device = mcs->key_get<std::string>( "audio", "device-oss");
	}
      else
      if (!sink.compare("esdsink"))
	{
	  set_buffer_time = true;
	  buffer_time = mcs->key_get<int>("audio", "esd-buffer-time");
	  device_propname = "host";
	  device = mcs->key_get<std::string>( "audio", "device-esd");
	}
#ifdef HAVE_SUN
      else
      if (!sink.compare("sunaudiosink"))
	{
	  set_buffer_time = true;
	  buffer_time = mcs->key_get<int>("audio", "sun-buffer-time");
	  device_propname = "device";
	  device = mcs->key_get<std::string>( "audio", "device-sun");
	}
#endif

      if (pipeline == P_FILE)
	{
	  //Create FILE pipeline
		elements[P_FILE][SRC] =
			gst_element_factory_make ("filesrc", "src");
		elements[P_FILE][DECODER] =
			gst_element_factory_make ("decodebin", "decoder");
		elements[P_FILE][CONVERT] =
			gst_element_factory_make ("audioconvert", "audioconvert");
		elements[P_FILE][VOLUME] =
			gst_element_factory_make ("volume", "volume");
		elements[P_FILE][SINK] =
			gst_element_factory_make (sink.c_str(), "sink");
		
		g_object_set (G_OBJECT(elements[P_FILE][SINK]),
				device_propname.c_str(),
				device.c_str(),
				NULL);
		
		if (set_buffer_time)
			{
			  g_object_set (G_OBJECT(elements[P_FILE][SINK]),
				"buffer-time",
				 buffer_time,
				 NULL);
			}
		
		elements[P_FILE][PIPELINE] = gst_pipeline_new ("pipeline_file");
		
		gst_bin_add_many (GST_BIN (elements[P_FILE][PIPELINE]),
				elements[P_FILE][SRC],
				elements[P_FILE][DECODER],
				elements[P_FILE][CONVERT],
				elements[P_FILE][VOLUME],
				elements[P_FILE][SINK],
				NULL);
		
		gst_element_link_many (elements[P_FILE][SRC],
					elements[P_FILE][DECODER], NULL);
		
		gst_element_link_many (elements[P_FILE][CONVERT],
					elements[P_FILE][VOLUME],
					elements[P_FILE][SINK], NULL);
	
		g_signal_connect (G_OBJECT(elements[P_FILE][DECODER]),
					"new-decoded-pad",
					 G_CALLBACK (Bmp::Play::link_pad),
					 (gpointer) this); 
		
		gst_bus_add_watch (gst_pipeline_get_bus (GST_PIPELINE(elements[P_FILE][PIPELINE])),
				   GstBusFunc (Bmp::Play::bus_watch), (gpointer) this);
	}
	else if (pipeline == P_HTTP)
	{
		//Create HTTP pipeline
		elements[P_HTTP][SRC] = gst_element_factory_make ("neonhttpsrc",  "src");

		if (!elements[P_HTTP][SRC])
		{
		    g_log (G_LOG_DOMAIN, G_LOG_LEVEL_INFO, "%s: neonhttpsrc not available, trying gnomevfssrc", G_STRLOC);
		    elements[P_HTTP][PIPELINE] = 0;
		    elements[P_HTTP][SRC] = gst_element_factory_make ("gnomevfssrc",  "src");
		    if (!elements[P_HTTP][SRC])
		    {
		      g_log (G_LOG_DOMAIN, G_LOG_LEVEL_INFO, "%s: No HTTP support available!", G_STRLOC);
		      elements[P_HTTP][PIPELINE] = 0;
		      return; 
		    }
		}

		g_object_set (G_OBJECT(elements[P_HTTP][SRC]), "iradio-mode", TRUE, NULL);
		property_has_http_ = true;

		elements[P_HTTP][DECODER]  = gst_element_factory_make ("decodebin", "decoder");
		elements[P_HTTP][CONVERT]  = gst_element_factory_make ("audioconvert", "audioconvert");
		elements[P_HTTP][VOLUME]   = gst_element_factory_make ("volume", "volume");
		elements[P_HTTP][TEE]	   = gst_element_factory_make ("tee", "tee0");
		elements[P_HTTP][SINK]	   = gst_element_factory_make (sink.c_str(), "sink");
		elements[P_HTTP][QUEUE]	   = gst_element_factory_make ("queue", "queue");
		
		g_object_set (G_OBJECT(elements[P_HTTP][SINK]),
				device_propname.c_str(),
				device.c_str(),
				NULL);
		
		if (set_buffer_time)
		  {
			g_object_set (G_OBJECT(elements[P_HTTP][SINK]),
				"buffer-time",
				buffer_time,
				NULL);
		  }
		
		elements[P_HTTP][PIPELINE] = gst_pipeline_new ("pipeline_http");
		
		gst_bin_add_many (GST_BIN (elements[P_HTTP][PIPELINE]),
				elements[P_HTTP][SRC],
				elements[P_HTTP][DECODER],
				elements[P_HTTP][TEE],
				elements[P_HTTP][QUEUE],
				elements[P_HTTP][CONVERT],
				elements[P_HTTP][VOLUME],
				elements[P_HTTP][SINK],
				NULL);
	
		gst_element_link_many (elements[P_HTTP][SRC],
				       elements[P_HTTP][DECODER],
				       NULL);
		
		gst_element_link_many (elements[P_HTTP][TEE],
				       elements[P_HTTP][QUEUE],
				       elements[P_HTTP][CONVERT],
				       elements[P_HTTP][VOLUME],
				       elements[P_HTTP][SINK],
				       NULL);

		g_signal_connect (G_OBJECT(elements[P_HTTP][DECODER]),
					"new-decoded-pad",
					 G_CALLBACK (Bmp::Play::link_pad),
					 (gpointer) this); 
		
		gst_bus_add_watch (gst_pipeline_get_bus (GST_PIPELINE(elements[P_HTTP][PIPELINE])),
				   (GstBusFunc) Bmp::Play::bus_watch, (gpointer) this);

	}
	else if (pipeline == P_CDDA)
	{
		//Create CDDA pipeline
		elements[P_CDDA][SRC] = gst_element_factory_make ("cdparanoiasrc",  "src");
		
		if (!elements[P_CDDA][SRC])
		{
			g_log (G_LOG_DOMAIN, G_LOG_LEVEL_INFO, "%s: No CDDA support available!", G_STRLOC);
			elements[P_CDDA][PIPELINE] = 0;
		}
		else
		{
			property_has_cdda_ = true;
		
			elements[P_CDDA][CONVERT] = gst_element_factory_make ("audioconvert", "audioconvert");
			elements[P_CDDA][VOLUME]  = gst_element_factory_make ("volume",	    "volume");
			elements[P_CDDA][SINK]	  = gst_element_factory_make (sink.c_str(), "sink");
		
	
			g_object_set (G_OBJECT(elements[P_CDDA][SINK]),
				device_propname.c_str(),
				device.c_str(),
				NULL);
		
			if (set_buffer_time)
			{
			  g_object_set (G_OBJECT(elements[P_CDDA][SINK]),
				"buffer-time",
				 buffer_time,
				 NULL);
			}
		
			elements[P_CDDA][PIPELINE] = gst_pipeline_new ("pipeline_cdda");
		
			gst_bin_add_many (GST_BIN (elements[P_CDDA][PIPELINE]),
				elements[P_CDDA][SRC],
				elements[P_CDDA][CONVERT],
				elements[P_CDDA][VOLUME],
				elements[P_CDDA][SINK],
				NULL);
		
			gst_element_link_many (elements[P_CDDA][SRC],
					elements[P_CDDA][CONVERT],
					elements[P_CDDA][VOLUME],
					elements[P_CDDA][SINK],
					NULL);

		gst_bus_add_watch (gst_pipeline_get_bus (GST_PIPELINE(elements[P_CDDA][PIPELINE])),
				   (GstBusFunc) Bmp::Play::bus_watch, (gpointer) this);

	      }
	}
	
    }

    void
    Play::reset ()
    {
      GstElement	  *element;
      Glib::ustring	   sink;

      pipelines_destroy ();

      //We check if the sink can be created
      sink = mcs->key_get<std::string>( "audio", "sink");
      element = gst_element_factory_make (sink.c_str(), "sinktest0");

      if (!element)
	{
	  bmp_system_control_message_dispatch (bmp_system_control,
					       message_domain_id,
					       GTK_MESSAGE_ERROR,
					       _("BMP was not able to initialize the playback system. Please check the audio settings in the Preferences panel."));
	  property_sane_ = false;
	  return;
	}

	//FIXME: Possibly even more sanity checks
        property_sane_ = true; 

	pipeline_create (P_FILE);
	pipeline_create (P_HTTP);
	pipeline_create (P_CDDA);
    }

    //properties
    Glib::PropertyProxy<Glib::ustring> Bmp::Play::property_stream() {
      return property_stream_.get_proxy();
    }

    Glib::PropertyProxy<int> Bmp::Play::property_volume() {
      return property_volume_.get_proxy();
    }

    Glib::PropertyProxy<int> Bmp::Play::property_position() {
      return property_position_.get_proxy();
    }

    Glib::PropertyProxy<int> Bmp::Play::property_status() {
      return property_status_.get_proxy();
    }

    Glib::PropertyProxy<bool> Bmp::Play::property_mute() {
      return property_mute_.get_proxy();
    }

    Glib::PropertyProxy<bool> Bmp::Play::property_sane() {
	return property_sane_.get_proxy();
    }

    Glib::PropertyProxy<int> Bmp::Play::property_length() {
	  GstQuery       *query;
	  GstFormat       format = GST_FORMAT_TIME;
	  gint64          length_in_nanoseconds;
	  gint		  value = 0;

	  query = gst_query_new_duration (format);
	  gst_element_query (elements[current_pipe][PIPELINE], query);
	  gst_query_parse_duration (query, &format, &length_in_nanoseconds);
	  value = length_in_nanoseconds / GST_SECOND;
	  gst_query_unref (query);

	  property_length_ = value;
          return property_length_.get_proxy();
    }

    Glib::PropertyProxy<bool> Bmp::Play::property_has_cdda() {
	  return property_has_cdda_.get_proxy();
    }

    Glib::PropertyProxy<bool> Bmp::Play::property_has_http() {
	  return property_has_http_.get_proxy();
    }


    //Signals
    Bmp::Play::SignalSamplerate& Bmp::Play::signal_samplerate ()
    {
      return signal_samplerate_;
    }

    Bmp::Play::SignalBitrate& Bmp::Play::signal_bitrate ()
    {
      return signal_bitrate_;
    }

    Bmp::Play::SignalTitle& Bmp::Play::signal_title ()
    {
      return signal_title_;
    }

    Bmp::Play::SignalEos& Bmp::Play::signal_eos ()
    { 
      return signal_eos_;
    }

    Bmp::Play::SignalSeek& Bmp::Play::signal_seek ()
    {
      return signal_seek_;
    }

    Bmp::Play::SignalPosition& Bmp::Play::signal_position ()
    {
      return signal_position_;
    }

};


