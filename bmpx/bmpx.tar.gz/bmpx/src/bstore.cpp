/*
 * BStore (C) 2005 M.Derezynski
 *
 * based on AeonFilestore, (C) 2004 M.Derezynski
 *
 *  BMPx - The Dumb Music Player
 *  Copyright (C) 2005 BMPx development team.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 *  $Id$
 *
 * The BMPx project hereby grant permission for non-gpl compatible GStreamer
 * plugins to be used and distributed together with GStreamer and BMPx. This
 * permission are above and beyond the permissions granted by the GPL license
 * BMPx is covered by.
 *
 */

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <assert.h>
#include <signal.h>
#include <getopt.h>
#include <pthread.h>
#include <sys/time.h>
#include <sys/select.h>
#include <sys/types.h>
#include <unistd.h>
#include <time.h>

#include <gtk/gtk.h>
#include <glib.h>
#include <glib-object.h>

#include "main.h"

#include <bmp/metadata.h>

#include <libhrel/types.h>
#include <libhrel/tuple.h>
#include <libhrel/relation.h>

#include "bstore.h"

#define B_STORE_IS_SORTED (store) (B_STORE (store)->private->sort_column_id != GTK_TREE_SORTABLE_UNSORTED_SORT_COLUMN_ID)

typedef enum {
    B_STORE_N_SIGNALS
} BStoreSignal;

typedef enum {
    B_STORE_N_PROPS
} BStoreProperty;

typedef struct _BStoreSortData BStoreSortData;

struct _BStoreSortData {
    GtkTreeIterCompareFunc compare_func;
    gpointer		   user_data;
    GtkDestroyNotify	   destroy;
};

struct _BStorePrivate {
    gboolean dispose_has_run;

    BStoreSortData *sort_data[BMP_DATUM_NONE + 2];
    BStoreSortData *sort_data_default;

    /* Store stuff */
    GPtrArray	      *rows;
    gint	       rows_head;
    gint	       current_index;

    /* TreeModel stuff */
    GType		    column_headers;
    GtkTreeIterCompareFunc  default_sort_func;
    GtkSortType		    order;

    gint  stamp;
    gint  n_columns;
    gint  sort_column_id;
    gint  length;
    gint *new_order;

    time_t  time_;
    gchar*  name;

    guint   guid_counter;
};

/* StoreRow */
BStoreRow*
b_store_row_new (HTuple *tuple)
{
    BStoreRow *row;
    RowGUID *row_guid;

    row =
        g_new0 (BStoreRow, 1);
    row_guid =
      g_new0(RowGUID,1);

    row->tuple = tuple;

    row_guid->counter =
	self->private->guid_counter++;
    row_guid->hash =
	g_str_hash(uri);

    row->guid = row_guid;

    return row;
}

BStoreRow*
b_store_row_copy (BStoreRow *store_row)
{
    BStoreRow *_copy;

    _copy =
        g_new0 (BStoreRow, 1);

    return _copy;
}

void
b_store_row_free (BStoreRow *store_row)
{
    if (!store_row)
        return;
}

GType
b_store_row_get_type (void)
{
    static GType our_type = 0;

    if (our_type == 0)
        our_type = g_boxed_type_register_static ("BStoreRow",
                                                 (GBoxedCopyFunc)
                                                 b_store_row_copy,
                                                 (GBoxedFreeFunc)
                                                 b_store_row_free);
    return our_type;
}

/* StoreRow END */
static GObject *b_store_constructor (GType		    type,
				     guint		    n_construct_properties,
                                     GObjectConstructParam *construct_properties);


static void
b_store_init (BStore * store)
{
    gint n;

    store->private = g_new0 (BStorePrivate, 1);

    store->private->dispose_has_run = FALSE;

    store->private->rows = NULL;
    store->private->rows_head = -1;

    B_STORE (store)->private->sort_column_id = GTK_TREE_SORTABLE_UNSORTED_SORT_COLUMN_ID;

    for (n = 0; n < BMP_DATUM_NONE; store->private->sort_data[n++] = NULL);

    store->private->sort_data_default = g_new0 (BStoreSortData, 1);
    store->private->sort_data_default->compare_func = NULL;

    store->private->n_columns = BMP_DATUM_NONE;
}

static void
b_store_set_property (GObject * object,
                          guint property_id, const GValue * value,
                          GParamSpec * pspec)
{
    BStore *store = B_STORE (object);
    switch (property_id)
     {
	default: break;
     }
}

static void
b_store_get_property (GObject * object,
                          guint property_id, GValue * value,
                          GParamSpec * pspec)
{
    BStore *store = B_STORE (object);
    switch (property_id)
     {
	default: break;
     }
}

static void
b_store_dispose (GObject * obj)
{
    BStore *store = (BStore *) obj;

    if (B_STORE (store)->private->dispose_has_run)
     {
         return;
     }
    B_STORE (store)->private->dispose_has_run = TRUE;
}

static void
b_store_finalize (GObject * obj)
{
    BStore *store = (BStore *) obj;

    g_free (B_STORE (store)->private);
}

time_t
b_store_get_time (BStore *self)
{
  return self->private->time_;
}

const gchar*
b_store_get_name (BStore *self)
{
  return self->private->name;
}


BStore *
b_store_new (const gchar *name)
{
    BStore *store;

    store = g_object_new (B_TYPE_STORE, NULL);

    store->private->time_ = time (NULL);
    store->private->name  = g_strdup (name);

    return store;
}

void
b_store_remove_rows (BStore *self, gint *rows)
{
    GPtrArray *new;
    gint n = 0;

    g_return_if_fail (B_IS_STORE(self));

    iter = self->private->rows;

    while (iter)
      {
	  if (*rows != n)
	    {
	      if (new == NULL)
	          new = g_node_copy_deep (iter, (GCopyFunc)b_store_row_copy, NULL);
	      else
		  g_node_append (new, g_node_copy_deep (iter, (GCopyFunc)b_store_row_copy, NULL));
	    }
	  else
	    {
		GtkTreePath *tree_path;

		tree_path = gtk_tree_path_new_from_indices (n, -1);
		gtk_tree_model_row_deleted (GTK_TREE_MODEL(self), tree_path);
		gtk_tree_path_free (tree_path);

		b_store_row_free (iter->data);
	    }

	if (*rows != -1) rows++;
	iter = iter->next;
	n++;
      }

    self->private->rows = new;
#endif
}

static GObject *
b_store_constructor (GType type,
                         guint n_construct_properties,
                         GObjectConstructParam * construct_properties)
{
    GObject *obj;

    {
        BStoreClass *klass;
        GObjectClass *parent_class;
        klass =
            B_STORE_CLASS (g_type_class_peek
                                    (B_TYPE_STORE));
        parent_class = G_OBJECT_CLASS (g_type_class_peek_parent (klass));
        obj = parent_class->constructor (type,
                                         n_construct_properties,
                                         construct_properties);
    }

    return obj;
}

gint
b_store_n_rows (BStore *self)
{
    g_return_val_if_fail (B_IS_STORE (self), -1);

    return self->private->rows_head+1;
}

BStoreRow*
b_store_row_get_by_index (BStore *self, gint _index)
{
    g_return_val_if_fail (B_IS_STORE (self), NULL);

    if (_index > self->private->rows_head)
        return NULL;

    return B_STORE_ROW(g_ptr_array_index (B_STORE(self)->private->rows, _index));
}

BStoreRow*
b_store_row_get_current (BStore * store)
{
    g_return_val_if_fail (B_IS_STORE (store), NULL);

    return g_ptr_array_index (store->private->rows,
                              store->private->current_index);
}

void
b_store_row_add (BStore *self, BStoreRow *row)
{
    GtkTreePath *path;
    GtkTreeIter  iter;

    g_return_if_fail (B_IS_STORE (self));

    g_ptr_array_array_add (self->private->rows, row);
    self->private->rows_head++;

    iter.user_data = GINT_TO_POINTER (self->private->rows_head);

    path = gtk_tree_model_get_path (GTK_TREE_MODEL(self), &iter);
    gtk_tree_model_row_inserted (GTK_TREE_MODEL(self), path, &iter);
}

BStoreRow*
b_store_row_get (BStore *store, GtkTreeIter *iter)
{
    BStoreRow *row;

    g_return_val_if_fail (B_IS_STORE (store), NULL);

    return g_ptr_array_index (self->private->rows, GPOINTER_TO_INT (iter->user_data));
}

#if 0
gboolean
b_store_store_row_remove (BStore      *store,
			  GtkTreeIter *iter)
{
    g_return_val_if_fail (B_IS_STORE (store), FALSE);

    gtk_list_store_remove (B_STORE (store)->private->store,
                           iter);

    return TRUE;
}

gboolean
b_store_store_row_move_down (BStore	  *store,
                             GtkTreeIter  *iter)
{
    GtkTreeIter iter_swap;

    g_return_val_if_fail (B_IS_STORE (store), FALSE);

    iter_swap = *iter;
    b_store_get_iter_next (store, &iter_swap);
    gtk_list_store_swap (B_STORE (store)->private->store,
                         iter, &iter_swap);

    return TRUE;
}

gboolean
b_store_store_row_move_up (BStore * store,
                               GtkTreeIter * iter)
{
    GtkTreeIter iter_swap;
    g_return_val_if_fail (B_IS_STORE (store), FALSE);

    iter_swap = *iter;
    b_store_get_iter_prev (store, &iter_swap);
    gtk_list_store_swap (B_STORE (store)->private->store,
                         iter, &iter_swap);

    return TRUE;
}
#endif

static void
b_store_class_init (BStoreClass * klass)
{
    GObjectClass *gobject_class = G_OBJECT_CLASS (klass);

    GParamSpec *pspec;

    gobject_class->set_property = b_store_set_property;
    gobject_class->get_property = b_store_get_property;
    gobject_class->dispose	= b_store_dispose;
    gobject_class->finalize	= b_store_finalize;
    gobject_class->constructor	= b_store_constructor;

}

static GtkTreeModelFlags
b_store_get_flags (GtkTreeModel * store)
{
    return GTK_TREE_MODEL_LIST_ONLY;
}

static gint
b_store_get_n_columns (GtkTreeModel * store)
{
    g_return_val_if_fail (GTK_IS_TREE_MODEL (store), -1);

    return B_STORE (store)->private->n_columns;
}

static GType
b_store_get_column_type (GtkTreeModel * store, gint _index)
{
    g_return_val_if_fail (GTK_IS_TREE_MODEL (store), G_TYPE_NONE);

    return bmp_metadata_get_type (_index);
}

static gboolean
b_store_get_iter (GtkTreeModel *store,
                  GtkTreeIter  *iter,
		  GtkTreePath  *path)
{
    gint _index;

    g_return_val_if_fail (B_IS_STORE (store), FALSE);
    g_return_val_if_fail ((iter != NULL), FALSE);
    g_return_val_if_fail ((path != NULL), FALSE);
    g_return_val_if_fail (gtk_tree_path_get_depth (path) > 0, FALSE);

    _index = gtk_tree_path_get_indices (path)[0];

    if (_index > B_STORE (store)->private->rows_head)
        return FALSE;

    iter->stamp = B_STORE (store)->private->stamp;

    /* user_data  is _index */
    iter->user_data = GINT_TO_POINTER(_index);

    return TRUE;
}

static gboolean
b_store_get_iter_from_string (GtkTreeModel *store,
			      GtkTreeIter  *iter,
                              const gchar  *path_string)
{
    gint _index;

    g_return_val_if_fail (B_IS_STORE (store), FALSE);
    g_return_val_if_fail ((iter != NULL), FALSE);
    g_return_val_if_fail ((path_string != NULL), FALSE);

    _index = strtol (path_string, (char **) NULL, 10);

    if (_index > B_STORE (store)->private->rows_head)
        return FALSE;

    iter->stamp = B_STORE (store)->private->stamp;

    /* user_data  is _index */
    iter->user_data = GINT_TO_POINTER(_index);

    return TRUE;
}

static gboolean
b_store_get_iter_first (GtkTreeModel * store, GtkTreeIter * iter)
{
    g_return_val_if_fail (GTK_IS_TREE_MODEL (store), FALSE);
    g_return_val_if_fail (B_IS_STORE (store), FALSE);

    return b_store_get_iter_from_string (store, iter, "0");
}

static GtkTreePath *
b_store_get_path (GtkTreeModel * store, GtkTreeIter * iter)
{
    GtkTreePath *path;
    gint _index;

    g_return_val_if_fail (GTK_IS_TREE_MODEL (store), NULL);
    g_return_val_if_fail (B_IS_STORE (store), NULL);
    g_return_val_if_fail ((iter != NULL), NULL);

    _index = GPOINTER_TO_INT (iter->user_data);

    g_return_val_if_fail ((_index >= 0), NULL);

    path = gtk_tree_path_new ();
    gtk_tree_path_append_index (path, GPOINTER_TO_INT (iter->user_data));

    return path;
}

static void
b_store_get_value (GtkTreeModel  *store,
		   GtkTreeIter   *iter,
		   gint	          _index,
		   GValue	 *value)
{
    HTuple    *tuple;
    BStoreRow *row;

    g_return_if_fail (GTK_IS_TREE_MODEL (store));
    g_return_if_fail (B_IS_STORE (store));

    row = iter->user_data;
    tuple = bmp_metadata_cache_get_metadata (bmp_metadata_cache, row->uri);

    g_value_init (value, bmp_metadata_get_type (_index));
    g_value_set_instance (value, h_tuple_get_value (tuple, bmp_metadata_get_id (_index)));
}

static gboolean
b_store_iter_next (GtkTreeModel * store, GtkTreeIter * iter)
{
    gint _index;

    g_return_val_if_fail (GTK_IS_TREE_MODEL (store), FALSE);
    g_return_val_if_fail (B_IS_STORE (store), FALSE);

    _index = GPOINTER_TO_INT (iter->user_data);

    if (_index + 1 > B_STORE (store)->private->rows_head)
        return FALSE;

    _index++;
    iter->user_data = GINT_TO_POINTER(_index);

    return TRUE;
}

static gboolean
b_store_iter_children (GtkTreeModel *store,
                       GtkTreeIter  *iter,
		       GtkTreeIter  *parent)
{
    g_return_val_if_fail (GTK_IS_TREE_MODEL (store), FALSE);
    g_return_val_if_fail (B_IS_STORE (store), FALSE);

    if (parent)
        return FALSE;

    return b_store_get_iter_first (store, iter);
}

static gint
b_store_iter_n_children (GtkTreeModel * store, GtkTreeIter * iter)
{
    g_return_val_if_fail (GTK_IS_TREE_MODEL (store), FALSE);
    g_return_val_if_fail (B_IS_STORE (store), FALSE);

    return B_STORE (store)->private->rows_head + 1;
}

static gboolean
b_store_iter_nth_child (GtkTreeModel *store,
                        GtkTreeIter  *iter,
                        GtkTreeIter  *parent,
			gint	      _index)
{
    g_return_val_if_fail (GTK_IS_TREE_MODEL (store), FALSE);
    g_return_val_if_fail (B_IS_STORE (store), FALSE);

    if (parent)
        return FALSE;

    if (_index > B_STORE (store)->private->rows_head)
        return FALSE;

    iter->user_data = GINT_TO_POINTER (_index);
    iter->stamp = B_STORE (store)->private->stamp;

    return TRUE;
}

gboolean
b_store_iter_parent (GtkTreeModel *store,
                     GtkTreeIter  *iter,
		     GtkTreeIter * child)
{
    return FALSE;
}

gboolean
b_store_iter_has_child (GtkTreeModel * store, GtkTreeIter * iter)
{
    return FALSE;
}

static void
b_store_tree_model_init (GtkTreeModelIface * iface)
{
    iface->get_flags	    = b_store_get_flags;
    iface->get_n_columns    = b_store_get_n_columns;
    iface->get_column_type  = b_store_get_column_type;
    iface->get_iter	    = b_store_get_iter;
    iface->get_path	    = b_store_get_path;
    iface->get_value	    = b_store_get_value;
    iface->iter_next	    = b_store_iter_next;
    iface->iter_children    = b_store_iter_children;
    iface->iter_has_child   = b_store_iter_has_child;
    iface->iter_n_children  = b_store_iter_n_children;
    iface->iter_nth_child   = b_store_iter_nth_child;
    iface->iter_parent	    = b_store_iter_parent;
}

static gint
b_store_compare_data_func (gconstpointer a,
			   gconstpointer b,
			   BStore * store)
{
    GtkTreeIterCompareFunc func;
    GtkTreeIter iter_a;
    GtkTreeIter iter_b;
    gint rv;
    gint v_a, v_b;
    gpointer data;

    if (B_STORE (store)->private->sort_column_id == -1)
        return 0;

    if (!a)
        return 0;

    if (!b)
        return 0;

    v_a = *(int *) a;

    v_b = *(int *) b;

    iter_a.stamp = B_STORE (store)->private->stamp;
    iter_a.user_data = GINT_TO_POINTER (v_a);

    iter_b.stamp = B_STORE (store)->private->stamp;
    iter_b.user_data = GINT_TO_POINTER (v_b);

    data =
        B_STORE (store)->private->
        sort_data[B_STORE (store)->private->sort_column_id]->
        user_data;

    func =
        B_STORE (store)->private->
        sort_data[B_STORE (store)->private->sort_column_id]->
        compare_func;

    rv = (*func) (GTK_TREE_MODEL (store), &iter_a, &iter_b, data);

    if (B_STORE (store)->private->order == GTK_SORT_DESCENDING)
     {
         if (rv > 0)
             rv = -1;
         else if (rv < 0)
             rv = 1;
     }

    return rv;
}

void
b_store_sort (BStore * store)
{
#if 0
    BStoreRow   *row;
    GtkTreePath *path;
    GPtrArray   *array_sort;
    GNode       *rows_sorted;
    gint sort_column_id;
    gint n_rows;
    gint n;

    GTimer *timer;

    g_return_if_fail (B_IS_STORE (store));

    timer = g_timer_new ();

    sort_column_id = B_STORE (store)->private->sort_column_id;

    n_rows =
        gtk_tree_model_iter_n_children (GTK_TREE_MODEL (store), NULL);

    /* Nothing to do... */
    if (!n_rows)
        return;

    store->private->new_order = g_new (int, n_rows + 1);    /* FIXME: Do we really need +1? If so, why? 42? */

    array_sort = g_ptr_array_new ();

    for (n = 0; n < n_rows;
         g_ptr_array_add (array_sort, GINT_TO_POINTER (n++)));

    g_ptr_array_sort_with_data (array_sort, (GCompareDataFunc)
                                b_store_compare_data_func, store);

    store->private->new_order[0] =
	GPOINTER_TO_INT (g_ptr_array_index (array_sort, 0));
    row =
	B_STORE_ROW(g_node_nth_child (store->private->rows,
			  store->private->new_order[0]));
    rows_sorted =
	g_node_new (row);

    for (n = 1; n < n_rows; ++n)
      {
         store->private->new_order[n] =
             GPOINTER_TO_INT (g_ptr_array_index (array_sort, n));

         row =
             B_STORE_ROW(g_node_nth_child (store->private->rows,
                               store->private->new_order[n]));
         g_node_append_data (rows_sorted, row);
      }

    store->private->rows = rows_sorted;

    path =
        gtk_tree_path_new ();
    gtk_tree_model_rows_reordered (GTK_TREE_MODEL (store),
                                   path,
                                   NULL,
                                   B_STORE (store)->private->new_order);
    gtk_tree_path_free (path);
#endif
}

static gboolean
b_store_get_sort_column_id (GtkTreeSortable *store,
                            gint	    *sort_column_id,
			    GtkSortType	    *order)
{
    if (sort_column_id)
        *sort_column_id =
            B_STORE (store)->private->sort_column_id;

    if (order)
        *order = B_STORE (store)->private->order;

    if ((B_STORE (store)->private->sort_column_id ==
         GTK_TREE_SORTABLE_DEFAULT_SORT_COLUMN_ID) ||
        (B_STORE (store)->private->sort_column_id ==
         GTK_TREE_SORTABLE_UNSORTED_SORT_COLUMN_ID))
        return FALSE;

    return TRUE;
}

static void
b_store_set_sort_column_id (GtkTreeSortable * store,
                                gint sort_column_id, GtkSortType order)
{
    g_return_if_fail (GTK_IS_TREE_SORTABLE (store));
    g_return_if_fail (B_IS_STORE (store));


    if ((sort_column_id ==
         B_STORE (store)->private->sort_column_id) &&
        (order == B_STORE (store)->private->order))
        return;

    if (sort_column_id > 0)
     {
         if (!B_STORE (store)->private->
             sort_data[sort_column_id])
             return;
     }

    B_STORE (store)->private->sort_column_id = sort_column_id;
    B_STORE (store)->private->order = order;

    gtk_tree_sortable_sort_column_changed (store);
    b_store_sort (B_STORE (store));
}

static void
b_store_set_sort_func (GtkTreeSortable * store,
                           gint sort_column_id,
                           GtkTreeIterCompareFunc compare_func,
                           gpointer user_data, GtkDestroyNotify destroy)
{
    BStoreSortData *sort_data;

    g_return_if_fail (GTK_IS_TREE_SORTABLE (store));
    g_return_if_fail (B_IS_STORE (store));

    if (sort_column_id > B_STORE (store)->private->n_columns)
        return;

    if (!B_STORE (store)->private->sort_data[sort_column_id])
     {
         sort_data = g_new0 (BStoreSortData, 1);
         sort_data->compare_func = compare_func;
         sort_data->user_data = user_data;
         sort_data->destroy = destroy;

         B_STORE (store)->private->sort_data[sort_column_id] = sort_data;
     }
    else
     {
         if (B_STORE (store)->private->
             sort_data[sort_column_id]->destroy)
          {
              GtkDestroyNotify d =
                  B_STORE (store)->private->
                  sort_data[sort_column_id]->destroy;

              d (B_STORE (store)->private->
                 sort_data[sort_column_id]->user_data);
          }

     }

    if (B_STORE (store)->private->sort_column_id ==
        sort_column_id)
        b_store_sort (B_STORE (store));
}

static void
b_store_set_default_sort_func (GtkTreeSortable * store,
                                   GtkTreeIterCompareFunc compare_func,
                                   gpointer user_data,
                                   GtkDestroyNotify destroy)
{
    g_return_if_fail (GTK_IS_TREE_SORTABLE (store));
    g_return_if_fail (B_IS_STORE (store));

    B_STORE (store)->private->sort_data_default->compare_func =
        compare_func;

    B_STORE (store)->private->sort_data_default->user_data =
        user_data;

    B_STORE (store)->private->sort_data_default->destroy =
        destroy;

    if (B_STORE (store)->private->sort_column_id ==
        GTK_TREE_SORTABLE_DEFAULT_SORT_COLUMN_ID)
        b_store_sort (B_STORE (store));
}

static gboolean
b_store_has_default_sort_func (GtkTreeSortable * store)
{
    g_return_val_if_fail (GTK_IS_TREE_SORTABLE (store), FALSE);

    if (B_STORE (store)->private->sort_data_default->
        compare_func)
        return TRUE;

    return FALSE;
}


static void
b_store_tree_sortable_init (GtkTreeSortableIface * iface)
{
    iface->get_sort_column_id = b_store_get_sort_column_id;
    iface->set_sort_column_id = b_store_set_sort_column_id;
    iface->set_sort_func = b_store_set_sort_func;
    iface->set_default_sort_func = b_store_set_default_sort_func;
    iface->has_default_sort_func = b_store_has_default_sort_func;
}

GType
b_store_get_type (void)
{
    static GType store_type = 0;

    if (!store_type)
     {
         static const GTypeInfo store_info = {
             sizeof (BStoreClass),
             NULL,
             NULL,
             (GClassInitFunc) b_store_class_init,
             NULL,
             NULL,
             sizeof (BStore),
             0,
             (GInstanceInitFunc) b_store_init,
         };

         static const GInterfaceInfo tree_model_info = {
             (GInterfaceInitFunc) b_store_tree_model_init,
             NULL,
             NULL
         };

         static const GInterfaceInfo tree_sortable_info = {
             (GInterfaceInitFunc) b_store_tree_sortable_init,
             NULL,
             NULL
         };

         store_type =
             g_type_register_static (G_TYPE_OBJECT, "BStore",
                                     &store_info, 0);

         g_type_add_interface_static (store_type,
                                      GTK_TYPE_TREE_MODEL, &tree_model_info);

         g_type_add_interface_static (store_type,
                                      GTK_TYPE_TREE_SORTABLE,
                                      &tree_sortable_info);
     }

    return store_type;
}
