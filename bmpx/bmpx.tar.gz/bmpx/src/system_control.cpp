//-*- Mode: C++; indent-tabs-mode: nil; -*-

/*  BMPx - The Dumb Music Player
 *  Copyright (C) 2005 BMPx development team.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 *  $Id$
 *
 * The BMPx project hereby grant permission for non-gpl compatible GStreamer
 * plugins to be used and distributed together with GStreamer and BMPx. This
 * permission are above and beyond the permissions granted by the GPL license
 * BMPx is covered by.
 */

#include <config.h>

#ifdef HAVE_GUI
#  include <gtk/gtk.h>
#  include <gdkmm/wrap_init.h>
#  include <gtkmm/wrap_init.h>
#  include <chroma/chroma-list.h>
#  include <chroma/chroma-list-selection.h>
#  include "ui.hpp"
#  include "ui_util.hpp"
#endif

#include <glib/gi18n.h>
#include <cstring>

#include <dbus/dbus-glib.h>

#include <bmp/dbus.h>
#include <bmp/playlist.hpp>
#include <bmp/plugin.h>
#include <bmp/plugin_interfaces.h>
#include <bmp/util.h>
#include <bmp/vfs.hpp>

#include <goa/libgoa.h>

#include "error.hpp"
#include "loader.hpp"
#include "play.hpp"
#include "resource_manager.hpp"
#include "system_control.hpp"

#include "bmp-marshalers.h"

G_DEFINE_TYPE (BmpSystemControl, bmp_system_control, G_TYPE_OBJECT)

#include "main.hpp"

#define MPRIS_IDENTITY "BMPx"

using namespace Bmp;

static gboolean proceed = TRUE;

typedef enum {
    BMP_SYSTEM_CONTROL_SIGNAL_TRACK_CHANGE,
    BMP_SYSTEM_CONTROL_SIGNAL_APP_BUSY,
    BMP_SYSTEM_CONTROL_SIGNAL_APP_IDLE,
    BMP_SYSTEM_CONTROL_SIGNAL_SEEK_EVENT,


    BMP_SYSTEM_CONTROL_SIGNAL_SET_URI,
    BMP_SYSTEM_CONTROL_SIGNAL_SET_TITLE,
    BMP_SYSTEM_CONTROL_SIGNAL_SET_BITRATE,
    BMP_SYSTEM_CONTROL_SIGNAL_SET_SAMPLERATE,

    BMP_SYSTEM_CONTROL_SIGNAL_SET_STREAM_POS,
    BMP_SYSTEM_CONTROL_SIGNAL_SET_PLAYSTATUS,
    BMP_SYSTEM_CONTROL_SIGNAL_SET_VOLUME,
    BMP_SYSTEM_CONTROL_SIGNAL_SET_SHUFFLE,
    BMP_SYSTEM_CONTROL_SIGNAL_SET_REPEAT,
    BMP_SYSTEM_CONTROL_SIGNAL_SET_EQ,
    BMP_SYSTEM_CONTROL_SIGNAL_LIST_DELETED,
    BMP_SYSTEM_CONTROL_SIGNAL_LIST_ADDED,
    BMP_SYSTEM_CONTROL_SIGNAL_LIST_RENAMED,
    BMP_SYSTEM_CONTROL_SIGNAL_TRACKLIST_LIST_SORTED,
    BMP_SYSTEM_CONTROL_SIGNAL_TRACKLIST_ITEMS_REMOVED,
    BMP_SYSTEM_CONTROL_SIGNAL_TRACKLIST_ITEMS_ADDED,
    BMP_SYSTEM_CONTROL_SIGNAL_TRACKLIST_ROWS_SWAPPED,
    BMP_SYSTEM_CONTROL_SIGNAL_SET_STOP_AFTER_CURRENT,
    BMP_SYSTEM_CONTROL_SIGNAL_STARTUP_COMPLETE,
    BMP_SYSTEM_CONTROL_SIGNAL_SHUTDOWN_COMPLETE,
    BMP_SYSTEM_CONTROL_SIGNAL_SHUTDOWN_REQUEST,
    BMP_SYSTEM_CONTROL_N_SIGNALS
} BmpSystemControlSignals;

static guint signals[BMP_SYSTEM_CONTROL_N_SIGNALS] = { 0 };

typedef enum {
    BMP_SYSTEM_CONTROL_PROPERTY_VOLUME = 1,
    BMP_SYSTEM_CONTROL_PROPERTY_BITRATE,
    BMP_SYSTEM_CONTROL_PROPERTY_SAMPLERATE,
    BMP_SYSTEM_CONTROL_PROPERTY_REPEAT,
    BMP_SYSTEM_CONTROL_PROPERTY_SHUFFLE,
    BMP_SYSTEM_CONTROL_PROPERTY_CURRENT_TITLE,
    BMP_SYSTEM_CONTROL_PROPERTY_CURRENT_URI,
    BMP_SYSTEM_CONTROL_PROPERTY_CURRENT_INDEX,
    BMP_SYSTEM_CONTROL_PROPERTY_STOP_AFTER_CURRENT,
    BMP_SYSTEM_CONTROL_N_PROPERTIES
} BmpSystemControlProperties;

struct _BmpSystemControlPrivate {
    gboolean dispose_has_run;

    GList		*message_domains;
    gint		 msg_domain_id;

    GAsyncQueue		*message_queue;
    guint		 message_queue_source_id;

    BmpPlaybackHistory  *playback_history;
    GObject		*flow_plugin;

    GHashTable		*remote_queries;
    guint		 ticket_id;

    gint		 sc_msg_domain_id;

    GList		*dispose_objects;

    SystemShutdownFunc	 shutdown_func;
    gpointer		 shutdown_data;

    SystemStartupFunc	 startup_func;
    gpointer		 startup_data;

    /* Properties */
    char        *current_uri;
    char	*current_title;
    gint	 current_index;

    gint	 bitrate;
    gint	 playlist;
    gint	 samplerate;
    gint	 stream_pos;
    gint	 volume;

    gboolean	 moving;
    gboolean	 repeat;
    gboolean	 shuffle;
    gboolean	 stop_after_current;

    /*< private >*/
    gboolean	 anonymous;
};

typedef struct {
    gint list;
    gint track;
} bmp_message_list_track_t;

#if 0
typedef struct {
    BmpEqEnum eq;
    gint value;
} bmp_message_eq_t;

static gint eq_values[BMP_N_EQ_PARAMS];

static gchar *eq_configuration_keynames[] = {
    "eq-30",
    "eq-60",
    "eq-125",
    "eq-250",
    "eq-500",
    "eq-1000",
    "eq-2000",
    "eq-4000",
    "eq-8000",
    "eq-16000"
};
static gint n_eq_configuration_keynames = G_N_ELEMENTS (eq_configuration_keynames);
#endif

static gboolean _no_remote = FALSE;
#include "system_control_glue.h"

static gboolean
play_track	  (BmpSystemControl	    *control,
		   gint			     position);

static void
play_seek	  (BmpSystemControl	    *control,
		   gint			     position);


gboolean
bmp_system_control_identity (BmpSystemControl  *control,
			     gchar	      **name,
			     GError	   **error)
{
  *name = g_strdup(MPRIS_IDENTITY);

   return TRUE;
}

static gboolean
send_shutdown_complete	(BmpSystemControl *control)
{
    g_return_val_if_fail (BMP_IS_SYSTEM_CONTROL(control), FALSE);

    g_signal_emit (G_OBJECT (control),
		   signals[BMP_SYSTEM_CONTROL_SIGNAL_SHUTDOWN_COMPLETE], 0);

    return TRUE;
}

static gboolean
send_startup_complete	(BmpSystemControl *control)
{
    g_return_val_if_fail (BMP_IS_SYSTEM_CONTROL(control), FALSE);

    g_signal_emit (G_OBJECT (control),
		   signals[BMP_SYSTEM_CONTROL_SIGNAL_STARTUP_COMPLETE], 0);

    if (mcs->key_get<bool>("bmp", "resume-on-startup"))
      {
	  gint	  track,
		  time;

	  time  = mcs->key_get<int>("bmp", "resume-on-startup-time");
	  track = mcs->key_get<int>("bmp", "resume-on-startup-track");

	  if ((time != -1) && (track != -1))
	    {
	      gint n;
	      play_track (control, track);

	      for (n = 0; n < 50; n++)
		{
		  while (g_main_context_pending(NULL)) g_main_context_iteration (NULL, TRUE);
		  g_usleep (250);
		}

	      play_seek  (control, time);
	    }
      }

    return FALSE;
}

gboolean
bmp_system_control_add_uri_list (BmpSystemControl   *control,
				 const gchar	   **uri_list,
				 gint		     position,
				 gboolean	     clear,
				 gboolean	     start_playback,
				 gint		     index,
				 gint		    *position_out,
				 GError		   **error)
{
    g_return_val_if_fail (BMP_IS_SYSTEM_CONTROL (control), TRUE);

    gtk_tree_sortable_set_sort_column_id (GTK_TREE_SORTABLE(bmp_playlist_get_playlist(bmp_playlist)),
					  GTK_TREE_SORTABLE_UNSORTED_SORT_COLUMN_ID,
					  GTK_SORT_ASCENDING);
    bmp_system_control_app_busy (control);

    if (clear) bmp_playlist_tracklist_remove_rows_all (bmp_playlist);

    index = (index == -1) ? bmp_playlist_get_length (bmp_playlist) : index;

    *position_out = (position == -1) ? bmp_playlist_insert_tracklist_items (bmp_playlist, uri_list) :
				       bmp_playlist_insert_tracklist_items_position (bmp_playlist, uri_list, position);

    if (start_playback) bmp_system_control_play_track (control, index, NULL);

    bmp_system_control_app_idle (control);

    return TRUE;
}

gboolean
bmp_system_control_get_metadata_for_list_item (BmpSystemControl	  *control,
					       gint		   item_idx,
					       GHashTable	 **metadata,
					       GError		 **error)
{
#if 0
    char	    *uri;
    uri = bmp_playlist_get_uri_by_index (bmp_playlist, item_idx);
    *metadata = bmp_metadata_cache_get_hash_value_table (bmp_metadata_cache, uri); 
    g_free (uri);
    return TRUE;
#endif
}

gboolean
bmp_system_control_get_metadata_for_uri       (BmpSystemControl	  *control,
					       char		  *uri,
					       GHashTable	 **metadata,
					       GError		 **error)
{
#if 0
    *metadata = bmp_metadata_cache_get_hash_value_table (bmp_metadata_cache, uri); 
    return TRUE;
#endif
}

gboolean
bmp_system_control_send_status (BmpSystemControl *control, GError ** error)
{
    g_signal_emit (G_OBJECT (control),
		   signals[BMP_SYSTEM_CONTROL_SIGNAL_SET_PLAYSTATUS],
		   0, bmp_play_engine->property_status().get_value());

    return TRUE;
}

gboolean
bmp_system_control_eq_get (BmpSystemControl *control,
			   gint eq, gint * value, GError ** error)
{
    //*value = eq_values[eq];

    return TRUE;
}

gboolean
bmp_system_control_volume_get (BmpSystemControl  *control,
			       gint		 *volume,
			       GError		**error)
{
    *volume = control->priv->volume;

    return TRUE;
}


gboolean
bmp_system_control_get_current_title (BmpSystemControl *control,
				      gchar ** title, GError ** error)
{
    *title = g_strdup (control->priv->current_title);

    return TRUE;
}

gboolean
bmp_system_control_get_current_bitrate (BmpSystemControl *control,
				      int * bitrate, GError ** error)
{
    *bitrate = control->priv->bitrate;
    return TRUE;
}

gboolean
bmp_system_control_get_current_samplerate (BmpSystemControl *control,
				      int * samplerate, GError ** error)
{
    *samplerate = control->priv->samplerate;
    return TRUE;
}



gboolean
bmp_system_control_get_current_uri (BmpSystemControl	*control,
				    gchar	       **uri,
				    GError	       **error)
{
    if (!control->priv->current_uri)
      {
          *error = g_error_new (g_quark_from_static_string (BMP_DBUS_INTERFACE), 0, "No current URI");
          return FALSE;
      }

    *uri = g_strdup (control->priv->current_uri);

    return TRUE;
}


gboolean
bmp_system_control_get_current_track (BmpSystemControl  *control,
				      gint	        *idx,
				      GError	       **error)
{
    *idx = g_object_get_int (control, "current_index");

    return TRUE;
}


gboolean
bmp_system_control_clear_tracklist		(BmpSystemControl      *control,
						 GError		      **error)
{
    bmp_playlist_tracklist_remove_rows_all (bmp_playlist);
    bmp_system_control_clear_playback_history (control, NULL);
    bmp_system_control_update_title (bmp_system_control);

    g_object_set (G_OBJECT(control), "current_index", (gint)-1, NULL);

    return TRUE;
}


gboolean
bmp_system_control_get_tracklist (BmpSystemControl *control,
				  char ***array,
				  GError ** error)
{
    GtkListStore      *list;
    GtkTreeIter	       iter;
    gint	       n, l;
    gboolean	       loop;

    list = bmp_playlist_get_playlist (bmp_playlist);
    l = gtk_tree_model_iter_n_children (GTK_TREE_MODEL(list), NULL);
    *array = g_new0 (gchar*, l+1);
    loop = gtk_tree_model_get_iter_first (GTK_TREE_MODEL(list), &iter);
    n = 0;

    //FIXME: This is not completely safe because rows might get removed while we're doing this.
    while (loop)
      {
	    char *uri;
	    gtk_tree_model_get (GTK_TREE_MODEL(list), &iter, COLUMN_URI, &uri, -1);
	    (*array)[n] = uri; 
	    loop = gtk_tree_model_iter_next (GTK_TREE_MODEL(list), &iter);
	    n++;
      }

    (*array)[l] = NULL;
    return TRUE;
}


gboolean
bmp_system_control_export_tracklist (BmpSystemControl *control,
				     const gchar      *container,
				     gboolean	       all,
				     const gchar      *filename,
				     GError	     **error)
{
    GtkListStore        *list;
    GtkTreeIter	         iter;
    bool  	         loop;
    Bmp::Util::FileList  uri_list;

    Bmp::VFS::Handle handle = Bmp::VFS::Handle::create (filename);
    list = bmp_playlist_get_playlist (bmp_playlist);

#ifdef HAVE_GUI
    if ((all) || (!bmp_ui))
#else
    if (1)
#endif
      {
	loop = gtk_tree_model_get_iter_first (GTK_TREE_MODEL(list), &iter);

	while (loop)
	{
	    char *uri;
	    gtk_tree_model_get (GTK_TREE_MODEL(list), &iter, COLUMN_URI, &uri, -1);
	    uri_list.push_back (std::string(uri));
	    free (uri);
	    loop = gtk_tree_model_iter_next (GTK_TREE_MODEL(list), &iter);
	}
      }
#ifdef HAVE_GUI
    else
      {
	  GList	*paths;
	  paths = chroma_list_selection_get_selected_paths (CHROMA_LIST_SELECTION (c_tracklist));
	  for ( ; paths ; paths = paths->next )
	  {
		GtkTreeIter	 iter;
		char	        *uri;

		gtk_tree_model_get_iter (GTK_TREE_MODEL(list), &iter, (GtkTreePath*)paths->data);
		gtk_tree_model_get (GTK_TREE_MODEL(list), &iter, COLUMN_URI, &uri, -1);
		uri_list.push_back (std::string(uri));
		free (uri);
	  }
	  g_list_foreach (g_list_first (paths), (GFunc)gtk_tree_path_free, NULL);
      }
#endif

    vfs->write (uri_list, std::string(Glib::filename_to_uri(std::string(filename))), container);
    return TRUE;
}

/* Our stuff */
static void
emit_row_changed_on_index	(BmpSystemControl   *control,
				 gint		     index)
{
    GtkListStore *model = bmp_playlist_get_playlist (bmp_playlist);
    GtkTreePath	 *path;
    GtkTreeIter   iter;

    if (index < 0) return;

    path = gtk_tree_path_new_from_indices (index, -1);
    gtk_tree_model_get_iter (GTK_TREE_MODEL(model), &iter, path);
    gtk_tree_model_row_changed (GTK_TREE_MODEL(model), path, &iter);
    gtk_tree_path_free (path);
}

#define CHANGE_CURRENT_ROW(); \
    list = bmp_playlist_get_playlist (bmp_playlist);\
    data = g_object_get_data (G_OBJECT (list), "current");\
    g_object_set_data (G_OBJECT (list), "current", NULL);\
    if (data)\
      {\
	path = gtk_tree_row_reference_get_path ((GtkTreeRowReference*)(data));\
	if (path)\
	  {\
	    emit_row_changed_on_index (control, gtk_tree_path_get_indices (path)[0]);\
	    g_object_set_data (G_OBJECT (list), "current", data);\
	    gtk_tree_path_free (path);\
	  }\
	else\
	    gtk_tree_row_reference_free ((GtkTreeRowReference*)data);\
      }

static gboolean
play_track (BmpSystemControl	    *control,
	    gint		     position)
{
    GtkListStore      *list;
    GtkTreePath	      *path;
    gpointer	       data;
    char	      *uri;

    uri = bmp_playlist_get_uri_by_index (bmp_playlist, position);

    if (!uri) return FALSE;

    CHANGE_CURRENT_ROW();

    g_object_set (G_OBJECT(control), "current_index", position, NULL);
    bmp_playback_history_set (control->priv->playback_history, position);

    bmp_play_engine->property_status() = PLAYSTATUS_WAITING;
    bmp_play_engine->property_stream() = uri; 
    bmp_play_engine->property_status() = PLAYSTATUS_PLAYING;

    free (uri);

    control->priv->anonymous = FALSE;
    emit_row_changed_on_index (control, position);
    bmp_system_message_send (control, BMP_SYSTEM_MESSAGE_TRACK_CHANGE, NULL, NULL);
    bmp_system_message_send (control, BMP_SYSTEM_MESSAGE_UPDATE_TITLE, NULL, NULL);

    return TRUE;
}

static void
play_current (BmpSystemControl *control)
{
#ifdef HAVE_GUI
    if (c_tracklist)
      {
	GtkTreePath  *path;
	gint	      current;

	path = chroma_list_selection_get_selected (CHROMA_LIST_SELECTION(c_tracklist));

	if (!path)
	  {
	    GtkTreeRowReference *reference;

	    reference = static_cast<GtkTreeRowReference *> (g_object_get_data (G_OBJECT(bmp_playlist_get_playlist(bmp_playlist)), "current"));
	    if (reference)
	      {
		GtkTreePath *path;

		path = gtk_tree_row_reference_get_path (reference);
		if (path)
		  {
		    current = gtk_tree_path_get_indices (path)[0];
		    gtk_tree_path_free (path);
		  }
		else
		  {
		    gtk_tree_row_reference_free (reference);
		    g_object_set_data (G_OBJECT(bmp_playlist_get_playlist(bmp_playlist)), "current", NULL);
		    return;
		  }
	      }
	    else
	      {
		  current = 0; 
	      }
	  }
	else
	  {
            current = gtk_tree_path_get_indices (path)[0];
	    gtk_tree_path_free (path);
	  }

	play_track (control, current);
      }
#else
    GList		*list;
    GtkTreeRowReference *reference;
    gint		 current;

    if (bmp_play_engine->property_playstatus() == PLAYSTATUS_PLAYING)
      {
	play_track (control, control->priv->current_index);
      }

    reference = g_object_get_data (G_OBJECT(bmp_playlist_get_playlist(bmp_playlist)), "current");
    if (reference)
      {
	  GtkTreePath *path;

	  path = gtk_tree_row_reference_get_path (reference);
	  if (path)
	    {
		current = gtk_tree_path_get_indices (path)[0];
		gtk_tree_path_free (path);
	    }
	  else
	    {
		gtk_tree_row_reference_free (reference);
		g_object_set_data (G_OBJECT(bmp_playlist_get_playlist(bmp_playlist)), "current", NULL);
		return;
	    }
      }
    else
      {
	  current = 0; 
      }

    play_track (control, current);
#endif
}

static void
play_next (BmpSystemControl *control)
{
    GtkListStore  *list;
    GtkTreePath	  *path;
    gboolean	   repeat;
    gint	   position;
    gpointer	   data;
    char	  *uri;

    if (control->priv->stop_after_current)
      {
	bmp_play_engine->property_status() = PLAYSTATUS_STOPPED;
	g_object_set (G_OBJECT (control), "stop_after_current", FALSE, NULL);
	return;
      }

    CHANGE_CURRENT_ROW();

    repeat = g_object_get_boolean (control, "repeat");
    position = bmp_playback_history_next (control->priv->playback_history,
					  (BmpPluginFlowInterface*)control->priv->flow_plugin);
    if (position < 0)
      {
	if (!repeat)
	  {
	    bmp_play_engine->property_status() = PLAYSTATUS_STOPPED;
	    g_message ("repeat not set");
	    return;
	  }
	g_message ("rewinding");
	position = bmp_playback_history_rewind (control->priv->playback_history);
      }

    uri = bmp_playlist_get_uri_by_index (bmp_playlist, position);
    if (!uri) return;

    bmp_play_engine->property_status() = PLAYSTATUS_WAITING;
    bmp_play_engine->property_stream() = uri; 
    bmp_play_engine->property_status() = PLAYSTATUS_PLAYING;

    control->priv->anonymous = FALSE;
    g_object_set (G_OBJECT(control), "current_index", position, NULL);
    emit_row_changed_on_index (control, position);

    bmp_system_message_send (control, BMP_SYSTEM_MESSAGE_TRACK_CHANGE, NULL, NULL);
    bmp_system_message_send (control, BMP_SYSTEM_MESSAGE_UPDATE_TITLE, NULL, NULL);
}

static void
play_prev (BmpSystemControl *control)
{
    GtkListStore  *list;
    GtkTreePath	  *path;
    gboolean	   repeat;
    gint	   position;
    gpointer	   data;
    char	  *uri;

    if (control->priv->stop_after_current)
      {
	g_object_set (G_OBJECT (control), "stop_after_current", FALSE, NULL);
	return;
      }

    CHANGE_CURRENT_ROW();

    repeat = g_object_get_boolean (G_OBJECT (control), "repeat");
    position = bmp_playback_history_prev (control->priv->playback_history,
					  (BmpPluginFlowInterface *) (control->priv->flow_plugin));
    if (position < 0)
      {
	if (!repeat) return;
	position = bmp_playback_history_rewind (control->priv->playback_history);
      }

    uri = bmp_playlist_get_uri_by_index (bmp_playlist, position);
    if (!uri)
      {
	bmp_play_engine->property_status() = PLAYSTATUS_STOPPED;
	return;
      }

    bmp_play_engine->property_status() = PLAYSTATUS_WAITING;
    bmp_play_engine->property_stream() = uri;
    bmp_play_engine->property_status() = PLAYSTATUS_PLAYING;

    free (uri);

    control->priv->anonymous = FALSE;
    g_object_set (G_OBJECT(control), "current_index", position, NULL);
    emit_row_changed_on_index (control, position);

    bmp_system_message_send (control, BMP_SYSTEM_MESSAGE_TRACK_CHANGE, NULL, NULL);
    bmp_system_message_send (control, BMP_SYSTEM_MESSAGE_UPDATE_TITLE, NULL, NULL);
}

static void
play_pause (BmpSystemControl *control)
{
    g_return_if_fail (BMP_IS_SYSTEM_CONTROL (control));

    bmp_play_engine->property_status() = PLAYSTATUS_PAUSED;
}

static void
play_stop (BmpSystemControl *control)
{
    g_return_if_fail (BMP_IS_SYSTEM_CONTROL (control));
    bmp_play_engine->property_status() = PLAYSTATUS_STOPPED;
}

static void
play_seek	  (BmpSystemControl	*control,
		   gint		         position)
{
    g_return_if_fail (BMP_IS_SYSTEM_CONTROL (control));
    bmp_play_engine->property_position() = position; 
}

static void
play_seek_percent (BmpSystemControl	*control,
		   gdouble		 position)
{
    gdouble percent,
	    length;
    gint    position_new;

    g_return_if_fail (BMP_IS_SYSTEM_CONTROL (control));

    length = bmp_play_engine->property_length();
    percent = length / 100.;

    position_new = int (position * percent);

    bmp_play_engine->property_position() = position_new; 
}

static void
play_volume (BmpSystemControl *control, gint volume)
{
    g_return_if_fail (BMP_IS_SYSTEM_CONTROL (control));

    g_object_set (control, "volume", volume, NULL);
}

#if 0
static void
play_eq (BmpSystemControl *control, BmpEqEnum eq, gint value)
{
    g_return_if_fail (BMP_IS_SYSTEM_CONTROL (control));
    bmp_play_set_eq (bmp_play_engine, eq, value);
    eq_values[eq] = value;
    g_signal_emit (G_OBJECT (control),
		   signals[BMP_SYSTEM_CONTROL_SIGNAL_SET_EQ],
		   0, eq, value);
}
#endif

static void
configuration_save (BmpSystemControl *control)
{
    /* SAVE CONFIGURATION */
    mcs->key_set<int>("bmp", "volume", control->priv->volume);
}

static gboolean
process_messages (BmpSystemControl *control)
{
    BmpSystemMessage *message;
    gint queue_length;

    g_return_val_if_fail (BMP_IS_SYSTEM_CONTROL (control), FALSE);

    message = static_cast<BmpSystemMessage *> (g_async_queue_try_pop (control->priv->message_queue));

    if (!message)
      {
	control->priv->message_queue_source_id = 0;
	return FALSE;
      }

    switch (message->message_type)
	{
	case BMP_SYSTEM_MESSAGE_PAUSE:
		{
		    play_pause (control);
		}
	    break;

	case BMP_SYSTEM_MESSAGE_STOP:
		{
		    play_stop (control);
		}
	    break;

	case BMP_SYSTEM_MESSAGE_NEXT:
		{
		    play_next (control);
		}
	    break;

	case BMP_SYSTEM_MESSAGE_CURRENT:
		{
		    play_current (control);
		}
	    break;

	case BMP_SYSTEM_MESSAGE_PREV:
		{
		    play_prev (control);
		}
	    break;

	case BMP_SYSTEM_MESSAGE_PLAY_TRACK:
		{
		    play_track (control, GPOINTER_TO_INT (message->data));
		}
	    break;

	case BMP_SYSTEM_MESSAGE_TRACK_CHANGE:
		{
		    g_signal_emit (control, signals[BMP_SYSTEM_CONTROL_SIGNAL_TRACK_CHANGE], 0);
		}
	    break;

	case BMP_SYSTEM_MESSAGE_SEEK:
		{
		    play_seek (control, GPOINTER_TO_INT (message->data));
		}
	    break;

	case BMP_SYSTEM_MESSAGE_SEEK_PERCENT:
		{
		    play_seek_percent (control, GPOINTER_TO_INT (message->data));
		}
	    break;

	case BMP_SYSTEM_MESSAGE_VOLUME:
		{
		    play_volume (control, GPOINTER_TO_INT (message->data));
		}
	    break;

	case BMP_SYSTEM_MESSAGE_EQ:
		{
                    //bmp_message_eq_t *message_eq = static_cast<bmp_message_eq_t *> (message->data);
		    //play_eq (control, message_eq->eq, message_eq->value);
		}
	    break;

	case BMP_SYSTEM_MESSAGE_UPDATE_TITLE:
	    {
	        GtkListStore	    *tracklist;
		GtkTreeRowReference *reference;
		GtkTreePath	    *path;
		GtkTreeIter	     iter;
		char		    *title;
		char		    *uri;
	  	int		     current;

		if (bmp_play_engine->property_status() == PLAYSTATUS_WAITING) break;
		if (bmp_play_engine->property_status() == PLAYSTATUS_PAUSED) break;

		tracklist = bmp_playlist_get_playlist (bmp_playlist);
		path = 0;

		if (bmp_play_engine->property_status() == PLAYSTATUS_PLAYING)
		  {
		      reference = static_cast<GtkTreeRowReference *> (g_object_get_data (G_OBJECT(tracklist), "current"));
		      if ((reference) && (path = gtk_tree_row_reference_get_path (reference)))
			{
			  current = gtk_tree_path_get_indices (path)[0];
			}
		      else
			{
			  gtk_tree_row_reference_free (reference);
			  g_object_set_data (G_OBJECT(tracklist), "current", NULL);
			  control->priv->anonymous = TRUE;
			  break;
			}
		  }
		else if (bmp_play_engine->property_status() == PLAYSTATUS_STOPPED)
		  {
//FIXME: This all here should be GUI-agnostic in ServiceCore in any case
#ifdef HAVE_GUI
		      if (bmp_ui)
			{
			    path = chroma_list_selection_get_selected (CHROMA_LIST_SELECTION(c_tracklist));
			}
#endif
		      if (!path)
			{
			    reference = static_cast<GtkTreeRowReference *> (g_object_get_data (G_OBJECT(tracklist), "current"));
			    if ((reference) && (path = gtk_tree_row_reference_get_path (reference)))
			      {
				current = gtk_tree_path_get_indices (path)[0];
			      }
			    else
			      {
				if (control->priv->current_title)
				  g_free (control->priv->current_title);

				if (control->priv->current_uri)
				  g_free (control->priv->current_uri);

				control->priv->current_title = NULL;
				g_object_notify (G_OBJECT (control), "current-title");
				g_signal_emit (G_OBJECT (control), signals[BMP_SYSTEM_CONTROL_SIGNAL_SET_TITLE],
				      0,
				      control->priv->current_title);

				control->priv->current_uri = NULL;
				g_object_notify (G_OBJECT (control), "current-uri");
				g_signal_emit (G_OBJECT (control), signals[BMP_SYSTEM_CONTROL_SIGNAL_SET_URI],
				      0,
				      control->priv->current_uri);

				control->priv->bitrate = 0;
			        g_object_notify (G_OBJECT (control), "bitrate");

				control->priv->samplerate = 0;
				g_object_notify (G_OBJECT (control), "samplerate");

				break;
			      }
			}
		  }

		if (!path) 
		  {
		    break;
		  }

		current = gtk_tree_path_get_indices (path)[0];
		title = bmp_playlist_get_title_nth (bmp_playlist, current);
		gtk_tree_model_get_iter (GTK_TREE_MODEL(tracklist), &iter, path);
		gtk_tree_path_free (path);

		if (title)
		  {
                        if (control->priv->current_title && (!std::strcmp(title, control->priv->current_title)))
			  {
			      g_free (title);
			      break;
			  }


			if ((bmp_play_engine->property_status() == PLAYSTATUS_PLAYING) && control->priv->anonymous)
			  {
			      g_free (title);
			      break;
			  }
		  }

		gtk_tree_model_get (GTK_TREE_MODEL(tracklist), &iter, COLUMN_URI, &uri, -1);

		if (control->priv->current_title) g_free (control->priv->current_title);
		if (control->priv->current_uri)   g_free (control->priv->current_uri);

		control->priv->current_title = title;
		g_object_notify (G_OBJECT (control), "current-title");
		g_signal_emit (G_OBJECT (control), signals[BMP_SYSTEM_CONTROL_SIGNAL_SET_TITLE],
				      0,
				      control->priv->current_title);


		control->priv->current_uri = uri;
		g_object_notify (G_OBJECT (control), "current-uri");
		g_signal_emit (G_OBJECT (control), signals[BMP_SYSTEM_CONTROL_SIGNAL_SET_TITLE],
				      0,
				      control->priv->current_title);

		Bmp::DB::DataRow row = library->get_metadata (uri);

		if (!row.empty ())
		  {
		      int	   bitrate    = 0,
				   samplerate = 0;

		      Bmp::DB::DataRow::iterator i = row.find (library->get_metadatum_id(Bmp::Library::DATUM_BITRATE));
		      if (i != row.end ())
		      {
			bitrate = boost::get<int>(i->second);
			g_signal_emit (G_OBJECT (control), signals[BMP_SYSTEM_CONTROL_SIGNAL_SET_BITRATE],
				      0, bitrate);
				      
		      }

		      i = row.find (library->get_metadatum_id(Bmp::Library::DATUM_SAMPLERATE));
		      if (i != row.end ())
		      {
			samplerate = boost::get<int>(i->second);
			g_signal_emit (G_OBJECT (control), signals[BMP_SYSTEM_CONTROL_SIGNAL_SET_SAMPLERATE],
				      0, samplerate);
				      
		      }

		      control->priv->bitrate = bitrate;
		      g_object_notify (G_OBJECT (control), "bitrate");

		      control->priv->samplerate = samplerate;
		      g_object_notify (G_OBJECT (control), "samplerate");
		  }
	      }
	    break;

	case BMP_SYSTEM_MESSAGE_STOP_AFTER_CURRENT:
		{
		    gboolean stop;

		    stop = GPOINTER_TO_INT (message->data);

		    g_object_set (G_OBJECT (control), "stop_after_current", stop, NULL);
		}
	    break;

	case BMP_SYSTEM_MESSAGE_REPEAT:
		{
		    gboolean repeat;

		    repeat = GPOINTER_TO_INT (message->data);

		    g_object_set (G_OBJECT (control), "repeat", repeat, NULL);
		}
	    break;

	case BMP_SYSTEM_MESSAGE_SHUFFLE:
		{
		    gboolean shuffle;

		    shuffle = GPOINTER_TO_INT (message->data);
		    g_object_set (G_OBJECT (control), "shuffle", shuffle, NULL);
		}
	    break;

	case BMP_SYSTEM_MESSAGE_QUIT:
		{
		    gboolean rval;

		    rval = FALSE;
		    g_signal_emit (G_OBJECT(control), signals[BMP_SYSTEM_CONTROL_SIGNAL_SHUTDOWN_REQUEST], 0, &rval);

		    if (!rval)
		      {
			  g_log (G_LOG_DOMAIN, G_LOG_LEVEL_INFO, "SHUTTING DOWN");

			  if ((mcs->key_get<bool>("bmp", "resume-on-startup") && (!control->priv->anonymous)) &&
			    (bmp_play_engine->property_status() == PLAYSTATUS_PLAYING))
			    {
			      mcs->key_set<int>("bmp", "resume-on-startup-time", control->priv->stream_pos);
			      mcs->key_set<int>("bmp", "resume-on-startup-track", control->priv->current_index);
			    }
			  else
			    {
			      mcs->key_set<int>("bmp", "resume-on-startup-time", -1);
			      mcs->key_set<int>("bmp", "resume-on-startup-track", -1);
			    }

			  configuration_save (control);
			  control->priv->shutdown_func (control->priv->shutdown_data);

			  for ( ; control->priv->dispose_objects; control->priv->dispose_objects = control->priv->dispose_objects->next)
			    {
				g_message (g_type_name (G_TYPE_FROM_INSTANCE(control->priv->dispose_objects->data)));
				g_object_unref (G_OBJECT(control->priv->dispose_objects->data));
			    }
		      }
		}
	    break;

#ifdef HAVE_GUI
#  include "bmp_system_control_ui_messages.c"
#endif

	}
    g_free (message);

    queue_length = g_async_queue_length (control->priv->message_queue);

    if (queue_length == 0)
      {
	control->priv->message_queue_source_id = 0;
	return FALSE;
      }

    return TRUE;
}

typedef gpointer SystemMessageData;

/* Public API */

void
bmp_system_message_send (BmpSystemControl	*control,
			 BmpSystemMessageType    message_type,
			 SystemMessageData	 data,
		         GDestroyNotify          data_destroy)
{
    BmpSystemMessage *message;

    g_return_if_fail (BMP_IS_SYSTEM_CONTROL (control));

    message = g_new0 (BmpSystemMessage, 1);
    message->message_type = message_type;
    message->data = data;
    message->data_destroy = data_destroy;

    g_async_queue_push (control->priv->message_queue, message);

    if (control->priv->message_queue_source_id != 0) return;
    control->priv->message_queue_source_id = g_idle_add ((GSourceFunc) process_messages, control);
}


void
bmp_system_control_update_title (BmpSystemControl *control)

{
    bmp_system_message_send (control, BMP_SYSTEM_MESSAGE_UPDATE_TITLE, NULL, NULL);
}

static void
update_title_changed (MCS_CB_DEFAULT_SIGNATURE, BmpSystemControl *control)
{
    bmp_system_control_update_title (control);
}

gboolean
bmp_system_control_startup	(BmpSystemControl *control, GError **error)
{

    return TRUE;
}


gboolean
bmp_system_control_stop_after_current_set (BmpSystemControl *control, gboolean stop, GError **error)
{
    bmp_system_message_send (control,
			     BMP_SYSTEM_MESSAGE_STOP_AFTER_CURRENT,
			     (SystemMessageData)GINT_TO_POINTER(stop),
			     NULL);

    return TRUE;
}


gboolean
bmp_system_control_repeat_set (BmpSystemControl *control, gboolean repeat, GError **error)
{
    bmp_system_message_send (control,
			     BMP_SYSTEM_MESSAGE_REPEAT,
			     (SystemMessageData)GINT_TO_POINTER(repeat),
			     NULL);

    return TRUE;
}


gboolean
bmp_system_control_repeat_get (BmpSystemControl *control, gboolean *repeat, GError **error)
{
    *repeat = control->priv->repeat;

    return TRUE;
}



gboolean
bmp_system_control_shuffle_set (BmpSystemControl *control, gboolean shuffle, GError **error)
{
    bmp_system_message_send (control,
			     BMP_SYSTEM_MESSAGE_SHUFFLE,
			     (SystemMessageData)GINT_TO_POINTER(shuffle),
			     NULL);
    return TRUE;
}


gboolean
bmp_system_control_shuffle_get (BmpSystemControl *control, gboolean *shuffle, GError **error)
{
    *shuffle = control->priv->shuffle;
    return TRUE;
}

#ifdef HAVE_GUI
gboolean
bmp_system_control_ui_start (BmpSystemControl	*control,
			     gchar		*display,
			     GError	       **error)
{
    bmp_system_message_send (control, BMP_SYSTEM_MESSAGE_UI_START, display, NULL);
    return TRUE;
}


gboolean
bmp_system_control_ui_stop  (BmpSystemControl	*control,
			     GError	       **error)
{
    bmp_system_message_send (control, BMP_SYSTEM_MESSAGE_UI_STOP, NULL, NULL);

    return TRUE;
}


gboolean
bmp_system_control_ui_raise (BmpSystemControl	*control,
			     GError	       **error)
{
    bmp_ui_raise_windows (bmp_ui);

    return TRUE;
}
#endif


gboolean
bmp_system_control_quit	    (BmpSystemControl	*control,
			     GError	       **error)
{
    bmp_system_message_send (control, BMP_SYSTEM_MESSAGE_QUIT, NULL, NULL);

    return TRUE;
}


gboolean
bmp_system_control_volume_set (BmpSystemControl *control, gint volume, GError **error)
{
    g_object_set (control, "volume", volume, NULL);
    return TRUE;
}


#if 0
gboolean
bmp_system_control_eq_set (BmpSystemControl *control, BmpEqEnum eq, gint value, GError **error)
{
    bmp_message_eq_t *message;

#define MAX_EQ_BANDS 10

    if (eq > MAX_EQ_BANDS)
      {
      }

    message = g_new0 (bmp_message_eq_t, 1);

    message->eq = eq;
    message->value = value;

    bmp_system_message_send (control,
			     BMP_SYSTEM_MESSAGE_EQ,
			     message,
			     (GDestroyNotify)g_free);

    return TRUE;
}
#endif

static gboolean
check_playback_sanity	     (BmpSystemControl	      *control,
			      GError		     **error)
{
  if (bmp_play_engine->property_sane().get_value() == false)
	{
	  bmp_system_control_message_dispatch (bmp_system_control,
				       control->priv->sc_msg_domain_id,
				       GTK_MESSAGE_ERROR,
				       ("The audio system is not properly initialized. Please check the audio settings in the Preferences panel."));
	  if (error != NULL)
	    {
	      *error = g_error_new (g_quark_from_static_string (BMP_DBUS_INTERFACE),
				    0,
				    "Unable to initiate playback: check audio settings");
	    }
	  return FALSE;
	}

    return TRUE;
}



gboolean
bmp_system_control_play_track (BmpSystemControl	      *control,
			       gint		       index,
			       GError		     **error)
{
    if (!check_playback_sanity (control, error)) return FALSE;

    bmp_system_message_send (control,
			     BMP_SYSTEM_MESSAGE_PLAY_TRACK,
			     (SystemMessageData)GINT_TO_POINTER(index),
			     NULL);
    return TRUE;
}


gboolean
bmp_system_control_seek (BmpSystemControl	      *control,
			 gint			       position,
			 GError			     **error)
{
#if 0
    bmp_system_message_send (control,
			     BMP_SYSTEM_MESSAGE_SEEK,
			     (SystemMessageData)GINT_TO_POINTER(position),
			     NULL);
#endif

    if (!check_playback_sanity (control, error)) return FALSE;

    play_seek (control, position);
    return TRUE;
}


gboolean
bmp_system_control_seek_percent (BmpSystemControl     *control,
			         gdouble	       position,
				 GError		     **error)
{
#if 0
    bmp_system_message_send (control,
			     BMP_SYSTEM_MESSAGE_SEEK_PERCENT,
			     (SystemMessageData)GINT_TO_POINTER(position),
			     NULL);
#endif

    if (!check_playback_sanity (control, error)) return FALSE;

    play_seek_percent (control, position);
    return TRUE;
}


gboolean
bmp_system_control_pause      (BmpSystemControl	      *control,
			       GError		     **error)
{
    if (!check_playback_sanity (control, error)) return FALSE;

    bmp_system_message_send (control, BMP_SYSTEM_MESSAGE_PAUSE, NULL, NULL);
    return TRUE;
}


gboolean
bmp_system_control_stop      (BmpSystemControl	      *control,
			      GError		     **error)
{
    if (!check_playback_sanity (control, error)) return FALSE;

    bmp_system_message_send (control, BMP_SYSTEM_MESSAGE_STOP, NULL, NULL);
    return TRUE;
}


gboolean
bmp_system_control_go_prev   (BmpSystemControl	      *control,
			      GError		     **error)
{
    if (!check_playback_sanity (control, error)) return FALSE;

    bmp_system_message_send (control, BMP_SYSTEM_MESSAGE_PREV, NULL, NULL);
    return TRUE;
}


gboolean
bmp_system_control_go_next   (BmpSystemControl	      *control,
			      GError		     **error)
{
    if (!check_playback_sanity (control, error)) return FALSE;

    bmp_system_message_send (control, BMP_SYSTEM_MESSAGE_NEXT, NULL, NULL);
    return TRUE;
}


gboolean
bmp_system_control_play	     (BmpSystemControl     *control,
			      GError		  **error)
{
    if (!check_playback_sanity (control, error)) return FALSE;

    bmp_system_message_send (control, BMP_SYSTEM_MESSAGE_CURRENT, NULL, NULL);
    return TRUE;
}

/* BmpPlay callbacks/handlers */

static void
on_play_eos (BmpSystemControl *control)
{
    bmp_system_message_send (control, BMP_SYSTEM_MESSAGE_NEXT, NULL, NULL);
}

static void
on_play_playstatus (BmpSystemControl *control)
{
    bmp_system_control_update_title (control);

    g_signal_emit (G_OBJECT (control),
		   signals[BMP_SYSTEM_CONTROL_SIGNAL_SET_PLAYSTATUS],
		   0, bmp_play_engine->property_status().get_value());
}

static void
on_play_position (int		       position,
		  BmpSystemControl    *control)
{
    control->priv->stream_pos = position; 
    g_signal_emit (control,
		   signals[BMP_SYSTEM_CONTROL_SIGNAL_SET_STREAM_POS],
		   0,
		   control->priv->stream_pos);
}

static void
on_play_seek	  (int		       offset,
		   BmpSystemControl   *control)
{
    g_signal_emit (G_OBJECT (control),
		   signals[BMP_SYSTEM_CONTROL_SIGNAL_SEEK_EVENT],
		   0,
		   offset);
}

static void
on_play_title	  (char		      *title,
		   BmpSystemControl   *control)
{
    if (control->priv->current_title) free (control->priv->current_title);
    control->priv->current_title = strdup (title); 

    g_object_notify (G_OBJECT (control), "current-title");
    g_signal_emit (G_OBJECT (control), signals[BMP_SYSTEM_CONTROL_SIGNAL_SET_TITLE],
				      0,
				      control->priv->current_title); 
}

static void
on_play_bitrate	  (unsigned int	       bitrate,
		   BmpSystemControl   *control)
{
    control->priv->bitrate = bitrate;
    g_message ("bitrate: %u", bitrate);
    g_object_notify (G_OBJECT (control), "bitrate");
    g_signal_emit (G_OBJECT (control), signals[BMP_SYSTEM_CONTROL_SIGNAL_SET_BITRATE],
				      0,
				      control->priv->bitrate); 
}

static void
on_play_samplerate  (unsigned int	samplerate,
		     BmpSystemControl   *control)
{
    control->priv->samplerate = samplerate;
    g_message ("samplerate: %u", samplerate);
    g_object_notify (G_OBJECT (control), "samplerate");
    g_signal_emit (G_OBJECT (control), signals[BMP_SYSTEM_CONTROL_SIGNAL_SET_SAMPLERATE],
				      0,
				      control->priv->samplerate); 
}

void
bmp_system_control_app_busy (BmpSystemControl *control)
{
  g_signal_emit (G_OBJECT (control),
                 signals[BMP_SYSTEM_CONTROL_SIGNAL_APP_BUSY],
                 0);
}


void
bmp_system_control_app_idle (BmpSystemControl *control)
{
  g_signal_emit (G_OBJECT (control),
                 signals[BMP_SYSTEM_CONTROL_SIGNAL_APP_IDLE],
                 0);
}

/* GObject stuff */

/* Proxy BmpPlaylist signals */
static void
playlist_callback_tracklist_list_sorted (BmpPlaylist	    *playlist,
					 gint		     column,
					 BmpSystemControl   *control)
{
    /* FIXME: Why do we need this? */
    if (signals[BMP_SYSTEM_CONTROL_SIGNAL_TRACKLIST_LIST_SORTED] > 0)
        g_signal_emit (G_OBJECT (control),
                   signals[BMP_SYSTEM_CONTROL_SIGNAL_TRACKLIST_LIST_SORTED], 0, column);
}

static void
playlist_callback_tracklist_items_removed (BmpPlaylist	    *playlist,
					   GArray	    *removed_rows,
					   gint		     n_removed_rows,
					   BmpSystemControl *control)
{
    /* FIXME: Why do we need this? */
    if (signals[BMP_SYSTEM_CONTROL_SIGNAL_TRACKLIST_ITEMS_REMOVED] > 0)
      {
        g_signal_emit (G_OBJECT (control),
                   signals[BMP_SYSTEM_CONTROL_SIGNAL_TRACKLIST_ITEMS_REMOVED],
                   0, removed_rows, n_removed_rows);

	if (gtk_tree_model_iter_n_children (reinterpret_cast<GtkTreeModel*>(bmp_playlist_get_playlist (playlist)), NULL) == 0)
	  {
	    bmp_system_control_clear_playback_history (control, NULL); 
	  }

	bmp_system_control_update_title (control);
      }
}

static void
playlist_callback_tracklist_items_added (BmpPlaylist	  *playlist,
					 GArray		  *added_rows,
				         gint		   n_added_rows,
					 BmpSystemControl *control)
{

    /* FIXME: Why do we need this? */
    if (signals[BMP_SYSTEM_CONTROL_SIGNAL_TRACKLIST_ITEMS_ADDED] > 0)
      {
	gint offset;

        g_signal_emit (G_OBJECT (control),
                   signals[BMP_SYSTEM_CONTROL_SIGNAL_TRACKLIST_ITEMS_ADDED],
                   0, added_rows, n_added_rows);
#ifdef HAVE_GUI
	if (c_tracklist)
	  {
	    g_object_get (G_OBJECT(c_tracklist), "offset", &offset, NULL);
	    if (offset > 0)
	      chroma_list_scroll_to_offset (CHROMA_LIST(c_tracklist), offset);
	  }
#endif
      }
}


gboolean
bmp_system_control_clear_playback_history (BmpSystemControl *control, GError **error)
{
    g_return_val_if_fail (BMP_IS_SYSTEM_CONTROL (control), FALSE);

    bmp_playback_history_free (control->priv->playback_history);
    control->priv->playback_history = bmp_playback_history_new();

    bmp_plugin_flow_reset_state (BMP_PLUGIN_FLOW(control->priv->flow_plugin));
    return TRUE;
}

/* User Messaging system */
typedef struct _BmpUserMessageDomain BmpUserMessageDomain;

struct _BmpUserMessageDomain {
	gint	 id;
	gchar	*name_id;
	gchar   *description;
};


gint
bmp_system_control_message_domain_register (BmpSystemControl	    *control,
					    const gchar		    *id,
					    const gchar		    *description)
{
    BmpUserMessageDomain *domain;
    gint new_id;

    new_id = control->priv->msg_domain_id;
    control->priv->msg_domain_id++;

    domain = g_new0 (BmpUserMessageDomain, 1);

    domain->id = new_id;
    domain->name_id = g_strdup (id);
    domain->description = g_strdup (description);

    control->priv->message_domains = g_list_append (control->priv->message_domains, domain);

    return new_id;
}


gint
bmp_system_control_message_dispatch	    (BmpSystemControl	    *control,
					     gint		     domain_id,
					     GtkMessageType	     msgtype,
					     const gchar	    *text)
{
    BmpUserMessageDomain *domain;

#ifdef HAVE_GUI
    GtkWidget		 *dialog;
    gint		  response;
#endif

    domain = static_cast<BmpUserMessageDomain *> (g_list_nth_data (control->priv->message_domains, domain_id));

#ifdef HAVE_GUI
    if (msgtype == GTK_MESSAGE_QUESTION)
	{
	    dialog = gtk_message_dialog_new (NULL,
					     GTK_DIALOG_MODAL,
					     msgtype,
					     GTK_BUTTONS_YES_NO,
					     NULL);
	}
    else
	{
	    dialog = gtk_message_dialog_new (NULL,
					     GTK_DIALOG_MODAL,
					     msgtype,
					     GTK_BUTTONS_OK,
					     NULL);
	}

    gtk_message_dialog_set_markup (GTK_MESSAGE_DIALOG(dialog), text);
    gtk_widget_realize (dialog);

    gtk_window_set_title (GTK_WINDOW(dialog), domain->description);
    gtk_window_set_position (GTK_WINDOW(dialog), GTK_WIN_POS_CENTER);

    response = gtk_dialog_run (GTK_DIALOG(dialog));
    gtk_widget_destroy (dialog);

    if (msgtype != GTK_MESSAGE_QUESTION) // Pointless if the GUI isn't running
	{
#endif

	    static gchar *m_strings[] = {
		"INFO",
		"WARNING",
		"QUESTION",
		"ERROR"
	    };

	    g_log (G_LOG_DOMAIN, G_LOG_LEVEL_INFO, "%s: [%s] from '%s': %s",
						    G_STRLOC,
						    m_strings[msgtype],
						    domain->description,
						    text);
#ifdef HAVE_GUI
	}

    return response;
#else
    return 0;
#endif
}


void
bmp_system_control_rows_swapped (BmpSystemControl *control,
				 gint row_a,
				 gint row_b)
{
    g_return_if_fail (BMP_IS_SYSTEM_CONTROL (control));

    if (_no_remote) return;

    g_signal_emit (G_OBJECT (control),
		   signals[BMP_SYSTEM_CONTROL_SIGNAL_TRACKLIST_ROWS_SWAPPED],
		   0, row_a, row_b);
}

static void
bmp_system_control_init (BmpSystemControl *control)
{
    control->priv = g_new (BmpSystemControlPrivate, 1);
    control->priv->dispose_has_run = FALSE;

    control->priv->message_queue = g_async_queue_new ();
    control->priv->message_queue_source_id = 0;
    control->priv->dispose_objects = NULL;
    control->priv->volume = mcs->key_get<int>("bmp", "volume");

    control->priv->bitrate = 0;
    control->priv->samplerate = 0;
    control->priv->current_title = NULL;
    control->priv->current_uri = NULL;

    control->priv->repeat   = FALSE;
    control->priv->shuffle  = FALSE;
    control->priv->current_index  = -1;

    control->priv->stop_after_current = FALSE;
    control->priv->anonymous	      = FALSE;
    control->priv->playback_history   = bmp_playback_history_new();
    control->priv->flow_plugin	      = G_OBJECT (g_hash_table_lookup (Plugins::table[Plugins::TYPE_FLOW], "linear"));

    control->priv->remote_queries = g_hash_table_new (g_direct_hash, g_direct_equal);
    control->priv->ticket_id	  = 0;

    control->priv->message_domains  = NULL;
    control->priv->msg_domain_id    = 0;

    g_assert (control->priv->flow_plugin != NULL);

    control->priv->sc_msg_domain_id =
	bmp_system_control_message_domain_register (control,
						    "bmp",
						    "BMP");

    g_message ("running: %s", G_OBJECT_TYPE_NAME(control));
}


void
bmp_system_control_initialize_dbus_connection	(BmpSystemControl *control)
{
    DBusGConnection *bus;
    DBusGProxy *bus_proxy;
    gboolean connected = FALSE;
    guint request_name_result;
    GError *error = NULL;

    bus = dbus_g_bus_get (DBUS_BUS_SESSION, &error);
    if (!bus)
	{
	    g_message ("running: %s (DBUS Error: '%s')", G_OBJECT_TYPE_NAME(control), error->message);
	    g_error_free (error);
	    return;
	}

    bus_proxy =
      dbus_g_proxy_new_for_name (bus,
				 "org.freedesktop.DBus",
				 "/org/freedesktop/DBus",
				 "org.freedesktop.DBus");

    if (!dbus_g_proxy_call (bus_proxy, "RequestName", &error,
			    G_TYPE_STRING, BMP_DBUS_INTERFACE,
			    G_TYPE_UINT, 0,
			    G_TYPE_INVALID,
			    G_TYPE_UINT, &request_name_result,
			    G_TYPE_INVALID))
	{
	    g_error ("%s: Failed RequestName request: %s", G_STRFUNC, error->message);
	    g_error_free (error);
	    error = NULL;
	}

    switch (request_name_result)
	{
	case DBUS_REQUEST_NAME_REPLY_PRIMARY_OWNER:
		{
		    dbus_g_connection_register_g_object (bus, BMP_DBUS_PATH,
							 G_OBJECT (control));
		    connected = TRUE;
		}
	    break;

	case DBUS_REQUEST_NAME_REPLY_EXISTS:
		{
		    g_message
		      ("%s: BMPx session already running, not registering SystemControl object to DBus.",
		       G_STRFUNC);
		    connected = FALSE;
		    proceed = FALSE;
		}
	    break;
	}

    if (connected)
	{
	    g_message ("%s (DBus:%s)", G_OBJECT_TYPE_NAME(control), BMP_DBUS_INTERFACE);
	}
}

static void
bmp_system_control_set_property (GObject * object,
				 guint property_id,
				 const GValue * value, GParamSpec * pspec)
{
    BmpSystemControl *control = BMP_SYSTEM_CONTROL (object);

    switch (property_id)
	{

	case BMP_SYSTEM_CONTROL_PROPERTY_CURRENT_INDEX:
		{
		    GtkListStore	  *list;
		    GtkTreePath		  *path;
		    GtkTreeRowReference	  *reference;
		    gint		   index = g_value_get_int (value);

		    list = bmp_playlist_get_playlist (bmp_playlist);
		    control->priv->current_index = index;

		    reference = static_cast<GtkTreeRowReference *> (g_object_get_data (G_OBJECT(list), "current"));
		    gtk_tree_row_reference_free (reference);
		    g_object_set_data (G_OBJECT(list), "current", NULL);

		    if (index != -1)
		      {
			path = gtk_tree_path_new_from_indices (index, -1);
			reference = gtk_tree_row_reference_new (GTK_TREE_MODEL(list), path);
		  	g_object_set_data (G_OBJECT(list), "current", reference);
		      }
		}
	    break;

	case BMP_SYSTEM_CONTROL_PROPERTY_VOLUME:
		{
		    control->priv->volume = g_value_get_int (value);
		    bmp_play_engine->property_volume() = control->priv->volume;
		    g_signal_emit (control,
				   signals[BMP_SYSTEM_CONTROL_SIGNAL_SET_VOLUME],
				   0, control->priv->volume);
		}
	    break;

	case BMP_SYSTEM_CONTROL_PROPERTY_STOP_AFTER_CURRENT:
		{
		    control->priv->stop_after_current = g_value_get_boolean (value);
#ifdef HAVE_GUI
		    GtkToggleAction *action;

		    action =
		      GTK_TOGGLE_ACTION (gtk_action_group_get_action
					 (bmp_toggle_actions,
					  BMP_TOGGLE_ACTION_STOP_AFTER_CURRENT));

		    if (gtk_toggle_action_get_active (action) !=
			control->priv->stop_after_current)
			gtk_toggle_action_set_active (action,
						      control->priv->stop_after_current);
#endif

		    g_signal_emit (control,
				   signals[BMP_SYSTEM_CONTROL_SIGNAL_SET_STOP_AFTER_CURRENT],
				   0, control->priv->stop_after_current);
		}
	    break;


	case BMP_SYSTEM_CONTROL_PROPERTY_REPEAT:
		{
		    if (mcs->key_get<bool>("bmp","repeat") == g_value_get_boolean (value)) return;

		    control->priv->repeat = g_value_get_boolean (value);
#ifdef HAVE_GUI
		    GtkToggleAction *action;

		    action =
		      GTK_TOGGLE_ACTION (gtk_action_group_get_action
					 (bmp_toggle_actions,
					  BMP_TOGGLE_ACTION_REPEAT));

		    gtk_toggle_action_set_active (action, control->priv->repeat);
#endif
		    mcs->key_set<bool>("bmp", "repeat", control->priv->repeat);
		    g_signal_emit (control,
				   signals[BMP_SYSTEM_CONTROL_SIGNAL_SET_REPEAT],
				   0, control->priv->repeat);
		}
	    break;

	case BMP_SYSTEM_CONTROL_PROPERTY_SHUFFLE:
		{
		    if (mcs->key_get<bool>("bmp","shuffle") == g_value_get_boolean (value)) return;

		    control->priv->shuffle = g_value_get_boolean (value);
#ifdef HAVE_GUI
		    GtkToggleAction *action;

		    action =
		      GTK_TOGGLE_ACTION (gtk_action_group_get_action
					 (bmp_toggle_actions,
					  BMP_TOGGLE_ACTION_SHUFFLE));

		    gtk_toggle_action_set_active (action, control->priv->shuffle);

#endif
		    control->priv->flow_plugin = G_OBJECT (g_hash_table_lookup (Plugins::table[Plugins::TYPE_FLOW],
                                                                                control->priv->shuffle ? "shuffle" : "linear"));

		    mcs->key_set<bool>("bmp", "shuffle", control->priv->shuffle);

		    g_signal_emit (control,
				   signals[BMP_SYSTEM_CONTROL_SIGNAL_SET_SHUFFLE],
				   0, control->priv->shuffle);
		}
	    break;

	default:
	    /* We don't have any other property... */
	    g_assert (FALSE);
	    break;
	}
}

static void
bmp_system_control_get_property (GObject * object,
				 guint property_id,
				 GValue * value, GParamSpec * pspec)
{
    BmpSystemControl *control = BMP_SYSTEM_CONTROL (object);

    switch (property_id)
	{

	case BMP_SYSTEM_CONTROL_PROPERTY_CURRENT_INDEX:
		{
		    g_value_set_int (value, control->priv->current_index);
		}
	    break;

	case BMP_SYSTEM_CONTROL_PROPERTY_BITRATE:
		{
		    g_value_set_int (value, control->priv->bitrate);
		}
	    break;

	case BMP_SYSTEM_CONTROL_PROPERTY_SAMPLERATE:
		{
		    g_value_set_int (value, control->priv->samplerate);
		}
	    break;


	case BMP_SYSTEM_CONTROL_PROPERTY_VOLUME:
		{
		    g_value_set_int (value, control->priv->volume);
		}
	    break;

	case BMP_SYSTEM_CONTROL_PROPERTY_REPEAT:
		{
		    g_value_set_boolean (value, control->priv->repeat);
		}
	    break;

	case BMP_SYSTEM_CONTROL_PROPERTY_SHUFFLE:
		{
		    g_value_set_boolean (value, control->priv->shuffle);
		}
	    break;

	case BMP_SYSTEM_CONTROL_PROPERTY_CURRENT_TITLE:
		{
		    g_value_set_string (value, control->priv->current_title);
		}
	    break;

	default:
	    /* We don't have any other property... */
	    g_assert (FALSE);
	    break;
	}
}

static GObject *
bmp_system_control_constructor (GType type,
				guint n_construct_properties,
				GObjectConstructParam * construct_properties)
{
    GObject *obj;

	{
	    /* Invoke parent constructor. */
	    BmpSystemControlClass *klass;
	    GObjectClass *parent_class;
	    klass =
	      BMP_SYSTEM_CONTROL_CLASS (g_type_class_peek
					(BMP_TYPE_SYSTEM_CONTROL));
	    parent_class = G_OBJECT_CLASS (g_type_class_peek_parent (klass));
	    obj = parent_class->constructor (type,
					     n_construct_properties,
					     construct_properties);
	}

    /* do stuff. */

    return obj;
}

static void
bmp_system_control_dispose (GObject *obj)
{
    BmpSystemControl *control = (BmpSystemControl*) obj;

    if (control->priv->dispose_has_run) return;
    control->priv->dispose_has_run = TRUE;

    send_shutdown_complete (control);
    g_message ("stopped: %s", G_OBJECT_TYPE_NAME(control));
}

static void
bmp_system_control_finalize (GObject * obj)
{
    BmpSystemControl *control = (BmpSystemControl *) obj;

    /*
     * Here, complete object destruction.
     * You might not need to do much...
     */
    g_free (control->priv);
}

BmpSystemControl *
bmp_system_control_new (gboolean no_remote)
{
    BmpSystemControl *control;

    if (!no_remote)
	dbus_g_object_type_install_info (BMP_TYPE_SYSTEM_CONTROL,
					 &dbus_glib_bmp_system_control_object_info);
    _no_remote = no_remote;

    control = static_cast<BmpSystemControl *> (g_object_new (bmp_system_control_get_type (), NULL));

    /* Proxy BmpPlaylist signals */
    g_object_connect(G_OBJECT(bmp_playlist),
		"signal::tracklist-list-sorted",
		G_CALLBACK(playlist_callback_tracklist_list_sorted),
	 	control,
		"signal::tracklist-items-removed",
		G_CALLBACK(playlist_callback_tracklist_items_removed),
		control,
		"signal::tracklist-items-added",
		G_CALLBACK(playlist_callback_tracklist_items_added),
		control,
		NULL);

    if (!proceed)
	return NULL;
    else
	return control;
}


void
bmp_system_control_init_finalize (BmpSystemControl *control)
{
    /* BmpPlay stuff */
    bmp_play_engine->signal_eos().connect( sigc::bind (&on_play_eos, control));
    bmp_play_engine->signal_position().connect(sigc::bind(&on_play_position, control));
    bmp_play_engine->signal_seek().connect(sigc::bind(&on_play_seek, control));


    bmp_play_engine->signal_title().connect(sigc::bind(&on_play_title, control));
    bmp_play_engine->signal_bitrate().connect(sigc::bind(&on_play_bitrate, control));
    bmp_play_engine->signal_samplerate().connect(sigc::bind(&on_play_samplerate, control));

    bmp_play_engine->property_status().signal_changed().connect(sigc::bind(&on_play_playstatus, control));
}

static void
bmp_system_control_class_init (BmpSystemControlClass * g_class)
{
    GObjectClass *gobject_class = G_OBJECT_CLASS (g_class);

    gobject_class->set_property = bmp_system_control_set_property;
    gobject_class->get_property = bmp_system_control_get_property;
    gobject_class->dispose = bmp_system_control_dispose;
    gobject_class->finalize = bmp_system_control_finalize;
    gobject_class->constructor = bmp_system_control_constructor;

    g_object_class_install_property (gobject_class,
				     BMP_SYSTEM_CONTROL_PROPERTY_BITRATE,
			             g_param_spec_int ("bitrate",
						       "bitrate",
						       "Current stream's bitrate.",
                                                       0, G_MAXINT, 0, GParamFlags (G_PARAM_READABLE)));

    g_object_class_install_property (gobject_class,
				     BMP_SYSTEM_CONTROL_PROPERTY_SAMPLERATE,
			             g_param_spec_int ("samplerate",
						       "samplerate",
						       "Current stream's samplerate.",
                                                       0, G_MAXINT, 0, GParamFlags (G_PARAM_READABLE)));

    g_object_class_install_property (gobject_class,
				     BMP_SYSTEM_CONTROL_PROPERTY_CURRENT_TITLE,
				     g_param_spec_string ("current-title",
							  "current-title",
							  "Current title",
							   NULL, GParamFlags (G_PARAM_READABLE)));

    g_object_class_install_property (gobject_class,
				     BMP_SYSTEM_CONTROL_PROPERTY_CURRENT_URI,
			             g_param_spec_string ("current-uri",
							  "current-uri",
							  "Current URI",
							   NULL, GParamFlags (G_PARAM_READABLE)));


    g_object_class_install_property (gobject_class,
				     BMP_SYSTEM_CONTROL_PROPERTY_VOLUME,
				     g_param_spec_int ("volume",
						       "volume",
						       "Current volume.",
                                                       0, 100, 0, GParamFlags (G_PARAM_READWRITE)));

    g_object_class_install_property (gobject_class,
				     BMP_SYSTEM_CONTROL_PROPERTY_CURRENT_INDEX,
			             g_param_spec_int    ("current_index",
							  "current_index",
							  "Current track index",
							   -1, G_MAXINT, 0, GParamFlags (G_PARAM_READWRITE)));

    g_object_class_install_property (gobject_class,
				     BMP_SYSTEM_CONTROL_PROPERTY_REPEAT,
			             g_param_spec_boolean ("repeat",
							   "repeat",
							   "Player repeat state",
							   FALSE, GParamFlags (G_PARAM_READWRITE)));

    g_object_class_install_property (gobject_class,
				     BMP_SYSTEM_CONTROL_PROPERTY_STOP_AFTER_CURRENT,
				     g_param_spec_boolean ("stop_after_current",
							   "stop_after_current",
							   "Stop after current track",
						           FALSE, GParamFlags (G_PARAM_READWRITE)));

    g_object_class_install_property (gobject_class,
				     BMP_SYSTEM_CONTROL_PROPERTY_SHUFFLE,
				     g_param_spec_boolean ("shuffle",
							   "shuffle",
							   "Player shuffle state",
							   FALSE, GParamFlags (G_PARAM_READWRITE)));
    signals[BMP_SYSTEM_CONTROL_SIGNAL_SET_URI] =
      g_signal_new ("set-uri",
		    G_OBJECT_CLASS_TYPE (gobject_class),
		    GSignalFlags (G_SIGNAL_RUN_FIRST | G_SIGNAL_DETAILED),
		    G_STRUCT_OFFSET (BmpSystemControlClass, set_uri),
		    NULL, NULL, g_cclosure_marshal_VOID__STRING,
		    G_TYPE_NONE, 1, G_TYPE_STRING);

    signals[BMP_SYSTEM_CONTROL_SIGNAL_SET_TITLE] =
      g_signal_new ("set-title",
		    G_OBJECT_CLASS_TYPE (gobject_class),
		    GSignalFlags (G_SIGNAL_RUN_FIRST | G_SIGNAL_DETAILED),
		    G_STRUCT_OFFSET (BmpSystemControlClass, set_title),
		    NULL, NULL, g_cclosure_marshal_VOID__STRING,
		    G_TYPE_NONE, 1, G_TYPE_STRING);

    signals[BMP_SYSTEM_CONTROL_SIGNAL_SET_BITRATE] =
      g_signal_new ("set-bitrate",
		    G_OBJECT_CLASS_TYPE (gobject_class),
		    GSignalFlags (G_SIGNAL_RUN_FIRST | G_SIGNAL_DETAILED),
		    G_STRUCT_OFFSET (BmpSystemControlClass, set_bitrate),
		    NULL, NULL, g_cclosure_marshal_VOID__INT,
		    G_TYPE_NONE, 1, G_TYPE_INT);

    signals[BMP_SYSTEM_CONTROL_SIGNAL_SET_SAMPLERATE] =
      g_signal_new ("set-samplerate",
		    G_OBJECT_CLASS_TYPE (gobject_class),
		    GSignalFlags (G_SIGNAL_RUN_FIRST | G_SIGNAL_DETAILED),
		    G_STRUCT_OFFSET (BmpSystemControlClass, set_samplerate),
		    NULL, NULL, g_cclosure_marshal_VOID__INT,
		    G_TYPE_NONE, 1, G_TYPE_INT);

    signals[BMP_SYSTEM_CONTROL_SIGNAL_APP_BUSY] =
      g_signal_new ("app-busy",
		    G_OBJECT_CLASS_TYPE (gobject_class),
		    GSignalFlags (G_SIGNAL_RUN_FIRST | G_SIGNAL_DETAILED),
		    G_STRUCT_OFFSET (BmpSystemControlClass, app_busy),
		    NULL, NULL, g_cclosure_marshal_VOID__VOID,
		    G_TYPE_NONE, 0);

    signals[BMP_SYSTEM_CONTROL_SIGNAL_APP_IDLE] =
      g_signal_new ("app-idle",
		    G_OBJECT_CLASS_TYPE (gobject_class),
		    GSignalFlags (G_SIGNAL_RUN_FIRST | G_SIGNAL_DETAILED),
		    G_STRUCT_OFFSET (BmpSystemControlClass, app_idle),
		    NULL, NULL, g_cclosure_marshal_VOID__VOID,
		    G_TYPE_NONE, 0);

    signals[BMP_SYSTEM_CONTROL_SIGNAL_SEEK_EVENT] =
      g_signal_new ("seek-event",
		    G_OBJECT_CLASS_TYPE (gobject_class),
		    GSignalFlags (G_SIGNAL_RUN_FIRST | G_SIGNAL_DETAILED),
		    G_STRUCT_OFFSET (BmpSystemControlClass, seek_event),
		    NULL, NULL, g_cclosure_marshal_VOID__INT,
		    G_TYPE_NONE, 1, G_TYPE_INT);

    signals[BMP_SYSTEM_CONTROL_SIGNAL_STARTUP_COMPLETE] =
      g_signal_new ("startup-complete",
		    G_OBJECT_CLASS_TYPE (gobject_class),
		    GSignalFlags (G_SIGNAL_RUN_FIRST | G_SIGNAL_DETAILED),
		    G_STRUCT_OFFSET (BmpSystemControlClass, startup_complete),
		    NULL, NULL, g_cclosure_marshal_VOID__VOID,
		    G_TYPE_NONE, 0);

    signals[BMP_SYSTEM_CONTROL_SIGNAL_SHUTDOWN_COMPLETE] =
      g_signal_new ("shutdown-complete",
		    G_OBJECT_CLASS_TYPE (gobject_class),
		    GSignalFlags (G_SIGNAL_RUN_FIRST | G_SIGNAL_DETAILED),
		    G_STRUCT_OFFSET (BmpSystemControlClass, shutdown_complete),
		    NULL, NULL, g_cclosure_marshal_VOID__VOID,
		    G_TYPE_NONE, 0);

    signals[BMP_SYSTEM_CONTROL_SIGNAL_SHUTDOWN_REQUEST] =
      g_signal_new ("shutdown-request",
		    G_OBJECT_CLASS_TYPE (gobject_class),
		    GSignalFlags (0),
		    G_STRUCT_OFFSET (BmpSystemControlClass, shutdown_request),
		    NULL, NULL, bmpx_BOOLEAN__VOID,
		    G_TYPE_BOOLEAN, 0);

    signals[BMP_SYSTEM_CONTROL_SIGNAL_SET_VOLUME] =
      g_signal_new ("set-volume",
		    G_OBJECT_CLASS_TYPE (gobject_class),
		    GSignalFlags (G_SIGNAL_RUN_FIRST | G_SIGNAL_DETAILED),
		    G_STRUCT_OFFSET (BmpSystemControlClass, set_volume),
		    NULL, NULL, g_cclosure_marshal_VOID__INT,
		    G_TYPE_NONE, 1, G_TYPE_INT);

    signals[BMP_SYSTEM_CONTROL_SIGNAL_SET_SHUFFLE] =
      g_signal_new ("set-shuffle",
		    G_OBJECT_CLASS_TYPE (gobject_class),
		    GSignalFlags (G_SIGNAL_RUN_FIRST | G_SIGNAL_DETAILED),
		    G_STRUCT_OFFSET (BmpSystemControlClass, set_shuffle),
		    NULL, NULL, g_cclosure_marshal_VOID__BOOLEAN,
		    G_TYPE_NONE, 1, G_TYPE_BOOLEAN);

    signals[BMP_SYSTEM_CONTROL_SIGNAL_SET_EQ] =
      g_signal_new ("set-eq",
		    G_OBJECT_CLASS_TYPE (gobject_class),
		    GSignalFlags (G_SIGNAL_RUN_FIRST | G_SIGNAL_DETAILED),
		    G_STRUCT_OFFSET (BmpSystemControlClass, set_eq),
		    NULL, NULL, bmpx_VOID__INT_INT,
		    G_TYPE_NONE, 2, G_TYPE_INT, G_TYPE_INT);

    signals[BMP_SYSTEM_CONTROL_SIGNAL_SET_REPEAT] =
      g_signal_new ("set-repeat",
		    G_OBJECT_CLASS_TYPE (gobject_class),
		    GSignalFlags (G_SIGNAL_RUN_FIRST | G_SIGNAL_DETAILED),
		    G_STRUCT_OFFSET (BmpSystemControlClass, set_repeat),
		    NULL, NULL, g_cclosure_marshal_VOID__BOOLEAN,
		    G_TYPE_NONE, 1, G_TYPE_BOOLEAN);

    signals[BMP_SYSTEM_CONTROL_SIGNAL_SET_PLAYSTATUS] =
      g_signal_new ("set-playstatus",
		    G_OBJECT_CLASS_TYPE (gobject_class),
		    GSignalFlags (G_SIGNAL_RUN_FIRST | G_SIGNAL_DETAILED),
		    G_STRUCT_OFFSET (BmpSystemControlClass, set_playstatus),
		    NULL, NULL, g_cclosure_marshal_VOID__INT,
		    G_TYPE_NONE, 1, G_TYPE_INT);

    signals[BMP_SYSTEM_CONTROL_SIGNAL_TRACK_CHANGE] =
      g_signal_new ("track-change",
		    G_OBJECT_CLASS_TYPE (gobject_class),
		    GSignalFlags (G_SIGNAL_RUN_FIRST | G_SIGNAL_DETAILED),
		    G_STRUCT_OFFSET (BmpSystemControlClass, track_change),
		    NULL, NULL, g_cclosure_marshal_VOID__VOID,
		    G_TYPE_NONE, 0);


    signals[BMP_SYSTEM_CONTROL_SIGNAL_SET_STREAM_POS] =
      g_signal_new ("set-stream-pos",
		    G_OBJECT_CLASS_TYPE (gobject_class),
		    GSignalFlags (G_SIGNAL_RUN_FIRST | G_SIGNAL_DETAILED),
		    G_STRUCT_OFFSET (BmpSystemControlClass, set_stream_pos),
		    NULL, NULL, g_cclosure_marshal_VOID__INT,
		    G_TYPE_NONE, 1, G_TYPE_INT);

    signals[BMP_SYSTEM_CONTROL_SIGNAL_SET_STOP_AFTER_CURRENT] =
      g_signal_new ("set-stop-after-current",
		    G_OBJECT_CLASS_TYPE (gobject_class),
		    GSignalFlags (G_SIGNAL_RUN_FIRST | G_SIGNAL_DETAILED),
		    G_STRUCT_OFFSET (BmpSystemControlClass,
				     set_stop_after_current), NULL, NULL,
		    g_cclosure_marshal_VOID__BOOLEAN, G_TYPE_NONE, 1,
		    G_TYPE_BOOLEAN);

    signals[BMP_SYSTEM_CONTROL_SIGNAL_TRACKLIST_LIST_SORTED] =
        g_signal_new ("tracklist-list-sorted",
                      G_OBJECT_CLASS_TYPE (gobject_class),
                      G_SIGNAL_RUN_FIRST,
                      G_STRUCT_OFFSET (BmpSystemControlClass, tracklist_list_sorted),
                      NULL, NULL, g_cclosure_marshal_VOID__INT, G_TYPE_NONE,
                      1, G_TYPE_INT);

    signals[BMP_SYSTEM_CONTROL_SIGNAL_TRACKLIST_ROWS_SWAPPED] =
        g_signal_new ("tracklist-rows-swapped",
                      G_OBJECT_CLASS_TYPE (gobject_class),
                      G_SIGNAL_RUN_FIRST,
                      G_STRUCT_OFFSET (BmpSystemControlClass, tracklist_rows_swapped),
                      NULL, NULL, bmpx_VOID__INT_INT, G_TYPE_NONE,
                      2, G_TYPE_INT, G_TYPE_INT);

    if (_no_remote)
     {
	signals[BMP_SYSTEM_CONTROL_SIGNAL_TRACKLIST_ITEMS_REMOVED] =
	    g_signal_new ("tracklist-items-removed",
                      G_OBJECT_CLASS_TYPE (gobject_class),
                      G_SIGNAL_RUN_FIRST,
                      G_STRUCT_OFFSET (BmpSystemControlClass, tracklist_items_removed),
                      NULL, NULL, bmpx_VOID__POINTER_INT, G_TYPE_NONE,
                      2, G_TYPE_POINTER, G_TYPE_INT);


	signals[BMP_SYSTEM_CONTROL_SIGNAL_TRACKLIST_ITEMS_ADDED] =
	    g_signal_new ("tracklist-items-added",
                      G_OBJECT_CLASS_TYPE (gobject_class),
                      G_SIGNAL_RUN_FIRST,
                      G_STRUCT_OFFSET (BmpSystemControlClass, tracklist_items_added),
                      NULL, NULL, bmpx_VOID__POINTER_INT, G_TYPE_NONE,
                      2, G_TYPE_POINTER, G_TYPE_INT);
    }
  else
    {
	signals[BMP_SYSTEM_CONTROL_SIGNAL_TRACKLIST_ITEMS_REMOVED] =
	    g_signal_new ("tracklist-items-removed",
                      G_OBJECT_CLASS_TYPE (gobject_class),
                      G_SIGNAL_RUN_FIRST,
                      G_STRUCT_OFFSET (BmpSystemControlClass, tracklist_items_removed),
                      NULL, NULL, bmpx_VOID__POINTER_INT, G_TYPE_NONE,
                      2, DBUS_TYPE_G_INT_ARRAY, G_TYPE_INT);


	signals[BMP_SYSTEM_CONTROL_SIGNAL_TRACKLIST_ITEMS_ADDED] =
	    g_signal_new ("tracklist-items-added",
                      G_OBJECT_CLASS_TYPE (gobject_class),
                      G_SIGNAL_RUN_FIRST,
                      G_STRUCT_OFFSET (BmpSystemControlClass, tracklist_items_added),
                      NULL, NULL, bmpx_VOID__POINTER_INT, G_TYPE_NONE,
                      2, DBUS_TYPE_G_INT_ARRAY, G_TYPE_INT);
    }
}


BmpPlaybackHistory*
bmp_system_control_get_history (BmpSystemControl *control)
{
    return control->priv->playback_history;
}


void
bmp_system_control_register_dispose_object    (BmpSystemControl	    *control,
					       GObject		    *object)
{
    g_return_if_fail (BMP_IS_SYSTEM_CONTROL (control));
    g_return_if_fail (object != NULL);
    g_return_if_fail (G_IS_OBJECT(object));

    control->priv->dispose_objects = g_list_append (control->priv->dispose_objects, (gpointer)object);
}


void
bmp_system_control_register_shutdown_func    (BmpSystemControl	    *control,
					      SystemShutdownFunc     shutdown_func,
					      gpointer		     shutdown_data)
{
    g_return_if_fail (BMP_IS_SYSTEM_CONTROL (control));

    control->priv->shutdown_func = shutdown_func;
    control->priv->shutdown_data = shutdown_data;
}


void
bmp_system_control_register_startup_func      (BmpSystemControl	    *control,
					       SystemStartupFunc     startup_func,
					       gpointer		     startup_data)
{
    g_return_if_fail (BMP_IS_SYSTEM_CONTROL (control));

    control->priv->startup_func = startup_func;
    control->priv->startup_data = startup_data;
}


void
bmp_system_control_application_run	      (BmpSystemControl	    *control)
{
    g_return_if_fail (BMP_IS_SYSTEM_CONTROL (control));

    send_startup_complete (bmp_system_control);
    control->priv->startup_func (control->priv->startup_data);
}
