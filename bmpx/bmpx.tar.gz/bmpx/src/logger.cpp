//#include <config.h>

#include <iostream>
#include <fstream>
#include <ctime>
#include <sys/stat.h>
#include <glibmm.h>
#include <boost/shared_ptr.hpp>
#include "paths.hpp"
#include "logger.hpp"

namespace
{
  struct LogHandler
  {
    gchar	   *domain;
    gchar          *file;
    GLogLevelFlags  level;
    guint	    id;
  };

  LogHandler log_handlers[] = {
    {G_LOG_DOMAIN,		      "system.log",   LOG_ALL_LEVELS},
    {"Glib",			      "glib.log",     LOG_ALL_LEVELS},
    {"Gtk",			      "gtk.log",      LOG_ALL_LEVELS},
    {BMPX_SCROBBLER_LOG_DOMAIN,	      "lastfm.log",   LOG_ALL_LEVELS}
  };

  guint log_handler_count = G_N_ELEMENTS (log_handlers);

  std::size_t
  get_filesize (const Glib::ustring &filename)
  {
    struct stat info;

    if (stat (filename.c_str (), &info))
      return 0;

    return info.st_size;
  }

  Glib::ustring
  get_timestamp_str ()
  {
    std::time_t current_time = std::time (0);

    struct tm current_tm;
    localtime_r (&current_time, &current_tm);

    char buffer[256];
    std::size_t len = strftime (buffer, sizeof (buffer) - 1, "%F %T", &current_tm);
    buffer[len] = 0;
    g_strstrip (buffer);

    return Glib::ustring (buffer);
  }

} // anonymous

namespace Bmp
{

  Log::Log (const Glib::ustring &domain_,
	    const Glib::ustring &filename,
	    GLogLevelFlags       flags)
    : domain (domain_)
  {
    if (get_filesize (filename) < BMP_LOGGER_FILE_MAX_SIZE)
      logfile.open (filename.c_str(), std::ios::app);
    else
      logfile.open (filename.c_str(), std::ios::out | std::ios::trunc);

#ifdef DEBUG
    std::cerr << "Installing log handler for domain '" << domain << "' on filename '" << filename << "'\n";
#endif

    id = g_log_set_handler (domain.c_str(),
			    (GLogLevelFlags) (flags | BMP_LOGGER_DEFAULT_LOG_LEVEL),
			    log_to_file_wrap,
			    this);

    g_log (domain.c_str(), G_LOG_LEVEL_INFO,
	   "Logging started for [%s] at [%s], PID[%d]",
	   domain.c_str(), get_timestamp_str().c_str (), getpid ());
  }

  Log::~Log ()
  {
    g_log_remove_handler (domain.c_str (), id);
  }

  void
  Log::log_to_file (const char*     domain,
		    GLogLevelFlags  flags,
		    const char*     message)
  {
    Glib::Mutex::Lock file_lock (file_mutex);

    logfile << get_timestamp_str ();

    if (domain)
      logfile << " " << domain << ": ";

    logfile << (message ? message : "(null)") << "\n";

    logfile.flush();
  }

  void
  Log::log_to_file_wrap (const char*     domain,
			 GLogLevelFlags  flags,
			 const char*     message,
			 void*           data)

  {
    Bmp::Log* log = static_cast<Bmp::Log*> (data);
    log->log_to_file (domain, flags, message);
  }


  Logger::Logger ()
  {
    for (unsigned int i = 0; i < log_handler_count; i++)
      {
	add_log (log_handlers[i].domain,
		 log_handlers[i].file,
		 log_handlers[i].level);
      }
  }

  void
  Logger::add_log (const Glib::ustring &domain, const Glib::ustring &filename, GLogLevelFlags flags)
  {
    Glib::ustring path = BMP_PATH_LOGS_DIR;

    path += "/" + filename;
    logs[domain] = boost::shared_ptr<Bmp::Log> (new Bmp::Log (domain, path, flags));
  }

} // Bmp
