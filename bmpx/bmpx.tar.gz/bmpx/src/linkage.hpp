#ifndef LINKAGE_HPP
#define LINKAGE_HPP

#define C_FUNCTION extern "C"

#endif // LINKAGE_HPP
