#ifndef __BMP_BUTTON_TOGGLE_H__
#define __BMP_BUTTON_TOGGLE_H__
  
#include <gdk/gdk.h>
#include <gtk/gtkwidget.h>
#include <gtk/gtk.h>

G_BEGIN_DECLS

#define BMP_BUTTON_TOGGLE_STATE_IDLE	0
#define BMP_BUTTON_TOGGLE_STATE_ACTIVE 1

#define BMP_BUTTON_TOGGLE(obj)          GTK_CHECK_CAST (obj, bmp_button_toggle_get_type (), BmpButtonToggle)
#define BMP_BUTTON_TOGGLE_CLASS(klass)  GTK_CHECK_CLASS_CAST (klass, bmp_button_toggle_get_type (), BmpButtonToggleClass)
#define BMP_IS_BUTTON_TOGGLE(obj)       GTK_CHECK_TYPE (obj, bmp_button_toggle_get_type ())
#define	BMP_TYPE_BUTTON_TOGGLE		 (bmp_button_toggle_get_type())

typedef struct _BmpButtonToggle BmpButtonToggle;
typedef struct _BmpButtonToggleClass BmpButtonToggleClass;

typedef enum 
{
	BMP_BUTTON_TOGGLE_NORMAL,
	BMP_BUTTON_TOGGLE_PRESSED,
	BMP_BUTTON_TOGGLE_ACTIVE,

	BMP_BUTTON_TOGGLE_N_STATES
} BmpButtonToggleStates;

struct _BmpButtonToggle
{
  GtkToggleButton button; 

  gboolean constructed;
  gboolean in_button;

  GdkGC *gc;
 
  GdkPixbuf *state_pb[BMP_BUTTON_TOGGLE_N_STATES];
  
  guint state;

  guint width;
  guint height;

};

struct _BmpButtonToggleClass
{
  GtkToggleButtonClass        parent_class;
};

GType
bmp_button_toggle_get_type          (void) G_GNUC_CONST;

BmpButtonToggle*
bmp_button_toggle_new               (void);

GtkWidget*
bmp_button_toggle_new_with_pixbufs  (GdkPixbuf *normal, GdkPixbuf *pressed, GdkPixbuf *active);

void
bmp_button_toggle_set_pixbufs	    (BmpButtonToggle *button, GdkPixbuf *normal, GdkPixbuf *pressed, GdkPixbuf *active );

void
bmp_button_toggle_set_from_table (BmpButtonToggle *arg_button, const GdkPixbuf *src, 
                guint            width, 
                guint            height,
                guint            x_normal,
                guint            y_normal,
                guint            x_pressed,
                guint            y_pressed,
		guint		 x_active,
		guint		 y_active);

void	       bmp_button_toggle_toggled	   (BmpButtonToggle      *button);

#if 0
void           bmp_button_toggle_pressed           (BmpButtonToggle      *button_toggle);
void           bmp_button_toggle_released          (BmpButtonToggle      *button_toggle);
void           bmp_button_toggle_clicked           (BmpButtonToggle      *button_toggle);
void           bmp_button_toggle_enter             (BmpButtonToggle      *button_toggle);
void           bmp_button_toggle_leave             (BmpButtonToggle      *button_toggle);
#endif

G_END_DECLS

#endif
