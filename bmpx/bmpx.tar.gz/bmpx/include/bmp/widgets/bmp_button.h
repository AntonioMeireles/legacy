#ifndef __BMP_BUTTON_H__
#define __BMP_BUTTON_H__
  
#include <gdk/gdk.h>
#include <gtk/gtkwidget.h>
#include <gtk/gtk.h>

G_BEGIN_DECLS

#define BMP_BUTTON_STATE_IDLE	0
#define BMP_BUTTON_STATE_ACTIVE 1

#define BMP_BUTTON(obj)          GTK_CHECK_CAST (obj, bmp_button_get_type (), BmpButton)
#define BMP_BUTTON_CLASS(klass)  GTK_CHECK_CLASS_CAST (klass, bmp_button_get_type (), BmpButtonClass)
#define BMP_IS_BUTTON(obj)       GTK_CHECK_TYPE (obj, bmp_button_get_type ())
#define	BMP_TYPE_BUTTON		 (bmp_button_get_type())

typedef struct _BmpButton BmpButton;
typedef struct _BmpButtonClass BmpButtonClass;

struct _BmpButton
{
  GtkButton button; 

  gboolean constructed;
  gboolean in_button;

  GdkGC *gc;
 
  GdkPixbuf *pb_normal;
  GdkPixbuf *pb_pressed;
  
  guint state;

  guint width;
  guint height;

  gpointer draw_data;

  gboolean passtrough;
};

struct _BmpButtonClass
{
  GtkButtonClass        parent_class;
};

GType
bmp_button_get_type          (void) G_GNUC_CONST;

BmpButton*
bmp_button_new               (gboolean passtrough);

GtkWidget*
bmp_button_new_with_pixbufs  (GdkPixbuf *normal, GdkPixbuf *pressed);

void
bmp_button_set_pixbufs	     (BmpButton *button, GdkPixbuf *normal, GdkPixbuf *pressed);

void
bmp_button_set_from_table (BmpButton* arg_button, const GdkPixbuf *src, 
                guint            width, 
                guint            height,
                guint            x_normal,
                guint            y_normal,
                guint            x_pressed,
                guint            y_pressed);
/*
void           bmp_button_pressed           (BmpButton      *button);
void           bmp_button_released          (BmpButton      *button);
void           bmp_button_clicked           (BmpButton      *button);
void           bmp_button_enter             (BmpButton      *button);
void           bmp_button_leave             (BmpButton      *button);
*/

G_END_DECLS

#endif
