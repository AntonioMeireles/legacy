/* GTK - The GIMP Toolkit
 * Copyright (C) 1995-1997 Peter Mattis, Spencer Kimball and Josh MacDonald
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.	 See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the
 * Free Software Foundation, Inc., 59 Temple Place - Suite 330,
 * Boston, MA 02111-1307, USA.
 */

/*
 * Modified by the GTK+ Team and others 1997-2000.  See the AUTHORS
 * file for a list of people on the GTK+ Team.  See the ChangeLog
 * files for a list of changes.  These files are distributed with
 * GTK+ at ftp://ftp.gtk.org/pub/gtk/. 
 */

#ifndef __BMP_TOOLTIPS_H__
#define __BMP_TOOLTIPS_H__

#include <gtk/gtkwidget.h>
#include <gtk/gtkwindow.h>


G_BEGIN_DECLS

#define BMP_TYPE_TOOLTIPS                  (bmp_tooltips_get_type ())
#define BMP_TOOLTIPS(obj)                  (G_TYPE_CHECK_INSTANCE_CAST ((obj), BMP_TYPE_TOOLTIPS, BmpTooltips))
#define BMP_TOOLTIPS_CLASS(klass)          (G_TYPE_CHECK_CLASS_CAST ((klass), BMP_TYPE_TOOLTIPS, BmpTooltipsClass))
#define BMP_IS_TOOLTIPS(obj)               (G_TYPE_CHECK_INSTANCE_TYPE ((obj), BMP_TYPE_TOOLTIPS))
#define BMP_IS_TOOLTIPS_CLASS(klass)       (G_TYPE_CHECK_CLASS_TYPE ((klass), BMP_TYPE_TOOLTIPS))
#define BMP_TOOLTIPS_GET_CLASS(obj)        (G_TYPE_INSTANCE_GET_CLASS ((obj), BMP_TYPE_TOOLTIPS, BmpTooltipsClass))


typedef struct _BmpTooltips	 BmpTooltips;
typedef struct _BmpTooltipsClass BmpTooltipsClass;
typedef struct _BmpTooltipsData	 BmpTooltipsData;

struct _BmpTooltipsData
{
  BmpTooltips *tooltips;
  GtkWidget *widget;
  gchar *tip_text;
  gchar *tip_private;
  gchar *tip_icon_stock_id;
  gboolean rectangular;
  gboolean hide_timeout;
};

struct _BmpTooltips
{
  GtkObject parent_instance;

  GtkWidget *tip_window;
  GtkWidget *tip_hbox;
  GtkWidget *tip_image;
  GtkWidget *tip_label;
  GtkWidget *tip_alignment;
  BmpTooltipsData *active_tips_data;
  GList *tips_data_list;

  guint   delay : 30;
  guint	  enabled : 1;
  guint   have_grab : 1;
  guint   use_sticky_delay : 1;
  gint	  timer_tag;
  GTimeVal last_popdown;

  gboolean draw_hotspot;
};

struct _BmpTooltipsClass
{
  GtkObjectClass parent_class;

  /* Padding for future expansion */
  void (*_gtk_reserved1) (void);
  void (*_gtk_reserved2) (void);
  void (*_gtk_reserved3) (void);
  void (*_gtk_reserved4) (void);
};

GType		 bmp_tooltips_get_type	   (void) G_GNUC_CONST;
BmpTooltips*	 bmp_tooltips_new	   (void);

void		 bmp_tooltips_enable	   (BmpTooltips   *tooltips);
void		 bmp_tooltips_disable	   (BmpTooltips   *tooltips);
void             bmp_tooltips_set_draw_hotspot (BmpTooltips *tooltips,
		                                gboolean     draw_hotspot);
void		 bmp_tooltips_set_tip	   (BmpTooltips   *tooltips,
					    GtkWidget	  *widget,
					    const gchar   *icon_stock_id,
					    const gchar   *tip_text,
					    const gchar   *tip_private,
					    gboolean rectangular);

void		 bmp_tooltips_set_tip_hide_timeout_enable (BmpTooltips *tooltips,  
							    GtkWidget	*widget,
							    gboolean	 enable);

void             bmp_tooltips_set_text	   (BmpTooltips *tooltips,
					    GtkWidget   *widget,
					    const gchar *tip_text);

void		 bmp_tooltips_set_icon	   (BmpTooltips *tooltips,
					    GtkWidget   *widget,
					    const gchar *icon_stock_id);

BmpTooltipsData* bmp_tooltips_data_get	   (GtkWidget	  *widget);

void             bmp_tooltips_force_window (BmpTooltips   *tooltips);


void             _bmp_tooltips_toggle_keyboard_mode (GtkWidget *widget);

gboolean         bmp_tooltips_get_info_from_tip_window (GtkWindow    *tip_window,
                                                        BmpTooltips **tooltips,
                                                        GtkWidget   **current_widget);

G_END_DECLS

#endif /* __BMP_TOOLTIPS_H__ */
