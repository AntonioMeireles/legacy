#ifndef __BMP_WINDOW_H__
#define __BMP_WINDOW_H__

#include <gdk/gdk.h>
#include <gtk/gtkwidget.h>
#include <gtk/gtk.h>

G_BEGIN_DECLS

#define BMP_WINDOW(obj)          GTK_CHECK_CAST (obj, bmp_window_get_type (), BmpWindow)
#define BMP_WINDOW_CLASS(klass)  GTK_CHECK_CLASS_CAST (klass, bmp_window_get_type (), BmpWindowClass)
#define BMP_IS_WINDOW(obj)       GTK_CHECK_TYPE (obj, bmp_window_get_type ())
#define	BMP_TYPE_WINDOW		 (bmp_window_get_type())

typedef struct _BmpWindow BmpWindow;
typedef struct _BmpWindowClass BmpWindowClass;

struct _BmpWindow
{
  GtkWindow window;

  GtkWidget *canvas;
  gint x,y;
};

struct _BmpWindowClass
{
  GtkWindowClass        parent_class;
};

GType
bmp_window_get_type          (void) G_GNUC_CONST;

GtkWidget*
bmp_window_new               (GtkWindowType type);

void
bmp_window_hide		     (BmpWindow *window);

void
bmp_window_show		     (BmpWindow *window);

G_END_DECLS

#endif
