#ifndef __BMP_SLIDER_H__
#define __BMP_SLIDER_H__
  
#include <gtk/gtk.h>
#include <gdk/gdk.h>
#include <gtk/gtkwidget.h>

G_BEGIN_DECLS

#define BMP_SLIDER_STATE_IDLE	0
#define BMP_SLIDER_STATE_ACTIVE 1

#define BMP_SLIDER(obj)          GTK_CHECK_CAST (obj, bmp_slider_get_type (), BmpSlider)
#define BMP_SLIDER_CLASS(klass)  GTK_CHECK_CLASS_CAST (klass, bmp_slider_get_type (), BmpSliderClass)
#define BMP_IS_SLIDER(obj)       GTK_CHECK_TYPE (obj, bmp_slider_get_type ())
#define	BMP_TYPE_SLIDER		 (bmp_slider_get_type())

typedef struct _BmpSlider BmpSlider;
typedef struct _BmpSliderClass BmpSliderClass;

struct _BmpSlider
{
  GtkDrawingArea area;

  gboolean constructed;
  gboolean in_slider;
  gboolean in_button;

  GdkPixbuf *pb_sliderbg;
  GdkPixbuf *pb_normal;
  GdkPixbuf *pb_pressed;
  
  gint button_yoffset;

  guint state;

  gdouble position;

  gdouble width;
  gdouble height;
  gdouble width_button;
  gdouble height_button;

  gboolean sliced;
  gboolean has_button;
  gboolean on_motion;

  guint slice_size;
  guint num_slices;
  guint scroll_step;
  gdouble slider_max;
  gdouble slider_min;
  gdouble max_adjust;
};

struct _BmpSliderClass
{
  GtkDrawingAreaClass        parent_class;

  void (* moved)	(BmpSlider *slider);
  void (* motion_hint)	(BmpSlider *slider);

};

GType
bmp_slider_get_type          (void) G_GNUC_CONST;

GtkWidget*
bmp_slider_new               (void);

GtkWidget*
bmp_slider_new_with_pixbufs  (GdkPixbuf *sliderbg, GdkPixbuf *normal, GdkPixbuf *pressed);

void
bmp_slider_set_pixbufs	      (BmpSlider      *slider,
			       GdkPixbuf      *sliderbg,
			       GdkPixbuf      *normal,
			       GdkPixbuf      *pressed,
			       gboolean	       has_button);

gdouble
bmp_slider_get_position	      (BmpSlider      *slider);

void
bmp_slider_set_position	      (BmpSlider      *slider,
			       gdouble	       position);

void
bmp_slider_set_slice_data     (BmpSlider      *slider,
			       gboolean	       sliced,
			       guint	       slice_size,
			       guint	       num_slices,
			       gboolean	       has_button);

void
bmp_slider_set_from_table (BmpSlider *arg_slider, const GdkPixbuf *src,
                guint            width,
                guint            height,
		guint		 width_button,
		guint		 height_button,
		guint		 x_sliderbg,
		guint		 y_sliderbg,
                guint            x_normal,
                guint            y_normal,
                guint            x_pressed,
                guint            y_pressed,
		gboolean	 has_button);

void
bmp_slider_set_report_on_motion	  (BmpSlider	*slider,
				   gboolean	 on_motion);

void
bmp_slider_set_scroll_step	  (BmpSlider	*slider,
				   guint	 step);

G_END_DECLS

#endif
