#ifndef BMP_PLUGIN_FLOW__BASE_HPP 
#define BMP_PLUGIN_FLOW__BASE_HPP 

#include <glibmm.h>
#include <gtkmm.h>

namespace Bmp {

    namespace Plugin {

      class FlowBase {

	public:

	  FlowBase () {};
	  virtual ~FlowBase () = 0;

	  virtual bool 
	  next (Gtk::ListStore& store, Gtk::TreeModel::iterator& iter) = 0;
	  virtual bool 
	  prev (Gtk::ListStore& store, Gtk::TreeModel::iterator& iter) = 0;

	  virtual void
	  reset () = 0; 

      }; // FlowBase 

    } // Plugin

} // Bmp
  

#endif // BMP_PLUGIN_FLOW__BASE.HPP 
