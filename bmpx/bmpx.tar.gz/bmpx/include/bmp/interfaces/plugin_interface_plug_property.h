#ifndef _PLUG_PROPERTY_H
#define _PLUG_PROPERTY_H_

#include <glib.h>
#include <glib-object.h>

G_BEGIN_DECLS

#define BMP_TYPE_PLUG_PROPERTY             (bmp_plug_property_iface_get_type ())
#define BMP_PLUG_PROPERTY(obj)             (G_TYPE_CHECK_INSTANCE_CAST ((obj), BMP_TYPE_PLUG_PROPERTY, BmpPlugPropertyInterface))
#define BMP_IS_PLUG_PROPERTY(obj)          (G_TYPE_CHECK_INSTANCE_TYPE ((obj), BMP_TYPE_PLUG_PROPERTY))
#define BMP_PLUG_PROPERTY_GET_IFACE(inst)  (G_TYPE_INSTANCE_GET_INTERFACE ((inst), BMP_TYPE_PLUG_PROPERTY, BmpPlugPropertyInterface))

typedef struct _BmpPlugProperty BmpPlugProperty;
typedef struct _BmpPlugPropertyInterface BmpPlugPropertyInterface;

struct _BmpPlugPropertyInterface
{
  GTypeInterface parent;

  GList*    (*get_props)  (BmpPlugPropertyInterface *self);

  gboolean  (*set_prop)   (BmpPlugPropertyInterface *self,
                           GQuark                    property,
                           GValue                   *value);

};

#define BMP_PLUG_PROPERTY_PARAM_FLAGS (GParamFlags(G_PARAM_STATIC_NICK | G_PARAM_STATIC_NAME | G_PARAM_STATIC_BLURB))

GType
bmp_plug_property_iface_get_type (void);

/* A GList of GParamSpecs */
GList*
bmp_plug_property_get_props (BmpPlugPropertyInterface *self);

gboolean
bmp_plug_property_set_prop (BmpPlugPropertyInterface *self,
                            GQuark                    property,
                            GValue                   *value);

G_END_DECLS

#endif /* _PLUG_PROPERTY_H_ */
