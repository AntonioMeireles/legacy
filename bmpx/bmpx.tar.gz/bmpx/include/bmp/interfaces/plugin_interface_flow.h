#ifndef _PLUGIN_INTERFACE_FLOW_H
#define _PLUGIN_INTERFACE_FLOW_H_

#include <glib-object.h>
#include <gtk/gtk.h>

G_BEGIN_DECLS

#define BMP_TYPE_PLUGIN_FLOW                   (bmp_plugin_flow_iface_get_type ())
#define BMP_PLUGIN_FLOW(obj)                   (G_TYPE_CHECK_INSTANCE_CAST ((obj), BMP_TYPE_PLUGIN_FLOW, BmpPluginFlowInterface))
#define BMP_IS_PLUGIN_FLOW(obj)                (G_TYPE_CHECK_INSTANCE_TYPE ((obj), BMP_TYPE_PLUGIN_FLOW))
#define BMP_PLUGIN_FLOW_GET_IFACE(inst)        (G_TYPE_INSTANCE_GET_INTERFACE ((inst), BMP_TYPE_PLUGIN_FLOW, BmpPluginFlowInterface))

typedef struct _BmpPluginFlow BmpPluginFlow;
typedef struct _BmpPluginFlowInterface BmpPluginFlowInterface;

struct _BmpPluginFlowInterface
{
  GTypeInterface parent;

  gboolean (*item_next)   (BmpPluginFlowInterface *self, GtkListStore *list, GtkTreeIter *iter);
  gboolean (*item_prev)   (BmpPluginFlowInterface *self, GtkListStore *list, GtkTreeIter *iter);

  void     (*reset_state) (BmpPluginFlowInterface *self);
};

GType
bmp_plugin_flow_iface_get_type (void);

gboolean
bmp_plugin_flow_item_prev (BmpPluginFlowInterface *self, GtkListStore *list, GtkTreeIter *iter);

gboolean
bmp_plugin_flow_item_next (BmpPluginFlowInterface *self, GtkListStore *list, GtkTreeIter *iter);

void
bmp_plugin_flow_reset_state (BmpPluginFlowInterface *self);

G_END_DECLS

#endif /* _PLUGIN_INTERFACE_FLOW_H_ */
