#ifndef _PLUG_METADATA_H
#define _PLUG_METADATA_H_

#include <glib.h>
#include <glib-object.h>

G_BEGIN_DECLS

#define BMP_TYPE_PLUG_METADATA             (bmp_plug_metadata_iface_get_type ())
#define BMP_PLUG_METADATA(obj)             (G_TYPE_CHECK_INSTANCE_CAST ((obj), BMP_TYPE_PLUG_METADATA, BmpPlugMetadataInterface))
#define BMP_IS_PLUG_METADATA(obj)          (G_TYPE_CHECK_INSTANCE_TYPE ((obj), BMP_TYPE_PLUG_METADATA))
#define BMP_PLUG_METADATA_GET_IFACE(inst)  (G_TYPE_INSTANCE_GET_INTERFACE ((inst), BMP_TYPE_PLUG_METADATA, BmpPlugMetadataInterface))

typedef enum
{
  METADATA_FIELD_NAME,
  METADATA_FIELD_AUTHOR,
  METADATA_FIELD_COPYRIGHT,
  METADATA_FIELD_WEBURL,
  METADATA_FIELD_EMAIL,

  METADATA_N_FIELDS
}
BmpPlugMetadataFields;


typedef struct _BmpPlugMetadata BmpPlugMetadata;
typedef struct _BmpPlugMetadataInterface BmpPlugMetadataInterface;

struct _BmpPlugMetadataInterface
{
  GTypeInterface parent;

  const gchar** (*get_metadata)  (BmpPlugMetadataInterface *self);
};

GType
bmp_plug_metadata_iface_get_type (void);

const gchar**
bmp_plug_metadata_get (BmpPlugMetadataInterface *self);

G_END_DECLS

#endif /* _PLUG_METADATA_H_ */
