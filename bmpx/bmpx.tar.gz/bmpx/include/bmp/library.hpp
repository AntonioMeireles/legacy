#ifndef BMP_LIBRARY_CLASS_HPP
#define BMP_LIBRARY_CLASS_HPP

#include <bmp/database.hpp>
#include <musicbrainz/musicbrainz.h>
#include <gtkmm.h>
#include <glibmm/i18n.h>

namespace Bmp
{
  namespace Library
  {
    enum Exception
    {
      NO_METADATA,
      INVALID_PATH,
    }; 

    enum Datum
    {
        DATUM_LOCATION,
        DATUM_ARTIST,
        DATUM_ALBUM,
        DATUM_TITLE,
        DATUM_TRACK,
        DATUM_TIME,
        DATUM_GENRE,
        DATUM_COMMENT,
        DATUM_RATING,
        DATUM_DATE,
        DATUM_MTIME,
        DATUM_BITRATE,
        DATUM_SAMPLERATE,
        DATUM_COUNT,
        DATUM_HAL_VOLUME_UDI,
        DATUM_HAL_DEVICE_UDI,

	DATUM_LAST
    };

    struct DatumDefine
    {
          const char    *title;
          const char    *title_plural;
          const char    *description;
          const char    *id;
          DB::ValueType  type;
          bool           filter;

          int            default_int;
          char          *default_char;
    };

    class Library
    {
      public:
        typedef sigc::signal<void> SignalProcessing;
        SignalProcessing& signal_processing_start ();
        SignalProcessing& signal_processing_end   ();

        enum
        {
            MB_FAILURE,
            MB_OK,
            MB_OFFLINE
        };

        Library ();
        ~Library ();

	DB::DataRowVector
	query		(const DB::AttributeList &attrs);

	void
	del		(const DB::AttributeList &attrs);

	DB::DataRowVector
	project		(std::string		   p_col,
			 const DB::AttributeList  &attrs = DB::AttributeList ());
 
	
        DB::DataRow
        get_metadata	(const std::string	  &pkey);

	DB::DataRow
	cache_metadata	(const std::string	  &uri,
			 const std::string	  &path);

        bool
        cache_audiocd	(const std::string        &cdindex_id);

        const std::string
        get_metadatum_id	(Datum metadatum) const;

	const DatumDefine 
	get_metadatum_define	(Datum metadatum) const;

	std::string
	get_titlestring		(const std::string& uri);
 
        const Bmp::DB::ValueMap &
        get_map () const;

    private:

	SignalProcessing signal_processing_start_;
	SignalProcessing signal_processing_end_;

        DB::ValueMap  map;
        DB::DB       *db;

        DB::DataRow
        metadata_get_taglib (const Glib::ustring &uri);

        DB::DataRow
        metadata_get_gst    (const Glib::ustring &uri);

        // MusicBrainz/Audio CD stuff
        DB::DataRowVector
        get_audiocd_metadata_offline (MusicBrainz& o);

        DB::DataRowVector
        get_audiocd_metadata (int &status);

    }; // class Library

  } // Library namespace

} // Bmp namespace

#endif // BMP_LIBRARY_CLASS_HPP
