#ifndef BMP_GUID_HPP
#define BMP_GUID_HPP

#include <glibmm.h>
#include <glib.h>

G_BEGIN_DECLS

struct RowGUID
{
  guint   counter;
  guint   hash;
};

bool
row_guid_equal_func   (RowGUID *guid_a, RowGUID *guid_b);

unsigned int
row_guid_hash_func    (RowGUID *guid);

RowGUID*
bmp_row_guid_copy     (RowGUID *guid);

void
bmp_row_guid_free     (RowGUID *guid);

GType
bmp_row_guid_get_type (void);

RowGUID*
bmp_row_guid_new      (const char *uri);

#define BMP_TYPE_ROW_GUID (bmp_row_guid_get_type ())
#define ROW_GUID(guid) ((RowGUID*)(guid))

G_END_DECLS

#endif
