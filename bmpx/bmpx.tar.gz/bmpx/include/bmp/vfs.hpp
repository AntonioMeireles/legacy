#ifndef BMP_VFS_H
#define BMP_VFS_H

#include <iostream>
#include <sstream>
#include <glibmm.h>
#include <boost/shared_ptr.hpp>
#include <bmp/file_utils.hpp>

namespace Bmp
{
      namespace VFS
      {
	enum Exception
	{
	  UNABLE_TO_PROCESS
	};

	struct ExportData
	{
	  std::string description;
	  std::string extension;

	  ExportData () {};
	  ExportData (std::string description, std::string extension) : description (description), extension (extension) {};
	};

	class Handle 
	{
	  public:

	    ~Handle ()
	    {
	      free (buffer);
	    }

	    const unsigned char*
	    get_buffer () const
	    {
	      return buffer;
	    }
  
	    size_t 
	    get_buffer_size () const
	    {
	      return buffer_size;
	    }

	    void
	    set_buffer (const unsigned char* buffer_a, size_t buffer_size_a)
	    {
	      this->buffer = reinterpret_cast<unsigned char*>(malloc(buffer_size_a));
	      this->buffer_size = buffer_size_a;
	      memcpy (this->buffer, buffer_a, buffer_size_a);
	    }

	    const std::string
	    get_uri () const
	    {
	      return uri;
	    }

	    static Handle
	    create (const std::string& uri)
	    {
		return Handle (uri);
	    }

	  private:

	    Handle (const std::string& uri) : uri (uri), buffer (0), buffer_size (0) {};
	    Handle () {};
	    
	    std::string     uri;
	    unsigned char  *buffer;
	    size_t	    buffer_size;

	}; // struct Handle

	class PluginTransportBase
	{
	  public:

	    PluginTransportBase () {};
	    virtual ~PluginTransportBase () {}; 

	    virtual bool
	    can_process	  (const std::string& str) = 0;
  
	    virtual bool
	    handle_read	  (Bmp::VFS::Handle& handle) = 0;

	    virtual bool
	    handle_write  (const Bmp::VFS::Handle& handle) = 0;
	};

	class PluginContainerBase
	{
	  public:

	    PluginContainerBase () {};
	    virtual ~PluginContainerBase () {}; 

	    virtual bool
	    can_process (const std::string& str) = 0;
  
	    virtual bool 
	    handle_read	(Bmp::VFS::Handle& handle, Util::FileList& list) = 0;

	    virtual bool
	    can_write	() = 0;

	    virtual bool
	    handle_write  (Bmp::VFS::Handle& handle, const Util::FileList& list) = 0; 

	    virtual Bmp::VFS::ExportData
	    get_export_data () = 0;
	};


	typedef std::map<std::string, PluginContainerBase*> ContainerPlugins;
	typedef std::map<std::string, PluginTransportBase*> TransportPlugins;
	typedef std::vector<ExportData>			    ExportDataList;	

	class VFS
	{
	  public:

	    VFS ();
	    ~VFS ();

	    void
	    get_containers (ExportDataList& list);

	    bool 
	    read  (Bmp::VFS::Handle    &handle,
		   Util::FileList      &list);

	    bool 
	    read_no_container (Bmp::VFS::Handle &handle);

	    bool
	    write (const Util::FileList&    list,
		   const std::string&	    uri,
		   const std::string&	    container);

	  private:
  
	    ContainerPlugins  container_plugins;
	    TransportPlugins  transport_plugins;

	    bool
	    load_plugins_transport (const std::string& entry,
				    const std::string& type);

	    bool
	    load_plugins_container (const std::string& entry,
				    const std::string& type);

	}; // class VFS
      } // namespace VFS
}// namespace Bmp
	    
#endif //BMP_VFS_H 
