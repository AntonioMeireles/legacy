#ifndef BMP_URI_HPP
#define BMP_URI_HPP

#include <string>
#include <gtkmm.h>

namespace Bmp
{
    class URI
    {
      public:

	enum Exceptions
	{
	  PARSE_ERROR
	};

	enum Protocol
	{
	  PROTOCOL_UNKNOWN = -1,
	  PROTOCOL_FILE,
	  PROTOCOL_CDDA,
	  PROTOCOL_HTTP,
	  PROTOCOL_FTP,
	};

	URI   (std::string uri);
	URI   ();
	~URI  () {};

	void escape ();
	void unescape ();
	Protocol get_protocol ();
    
	operator std::string ();

	std::string	scheme;
	std::string	userinfo;
	std::string	hostname;
	int		port;
	std::string	path;
	std::string	query;
	std::string	fragment;

      private:

	bool 
	fragmentize (const std::string& uri);

    };
}

#endif
