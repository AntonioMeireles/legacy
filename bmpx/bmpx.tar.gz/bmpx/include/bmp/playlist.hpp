//  BMPx - The Dumb Music Player
//  Copyright (C) 2005-2006 BMPx development team.
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
//
//  --
//
//  The BMPx project hereby grants permission for non GPL-compatible GStreamer
//  plugins to be used and distributed together with GStreamer and BMPx. This
//  permission is above and beyond the permissions granted by the GPL license
//  BMPx is covered by.

#ifndef BMP_PLAYLIST_HPP
#define BMP_PLAYLIST_HPP

#include <glib-object.h>
#include <gtk/gtk.h>

#include <time.h>

#include <bmp/plugin_interfaces.h>
#include <bmp/library.hpp>
#include <bmp/database.hpp>
#include <bmp/guid.hpp>

#define BMP_TYPE_PLAYLIST                 (bmp_playlist_get_type ())
#define BMP_PLAYLIST(obj)                 (G_TYPE_CHECK_INSTANCE_CAST ((obj), BMP_TYPE_PLAYLIST, BmpPlaylist))
#define BMP_PLAYLIST_CLASS(klass)         (G_TYPE_CHECK_CLASS_CAST ((klass), BMP_TYPE_PLAYLIST, BmpPlaylistClass))
#define BMP_IS_PLAYLIST(obj)              (G_TYPE_CHECK_INSTANCE_TYPE ((obj), BMP_TYPE_PLAYLIST))
#define BMP_IS_PLAYLIST_CLASS(klass)      (G_TYPE_CHECK_CLASS_TYPE ((klass), BMP_TYPE_PLAYLIST))
#define BMP_PLAYLIST_GET_CLASS(obj)       (G_TYPE_INSTANCE_GET_CLASS ((obj), BMP_TYPE_PLAYLIST, BmpPlaylistClass))

typedef struct _BmpPlaylist BmpPlaylist;
typedef struct _BmpPlaylistClass BmpPlaylistClass;
typedef struct _BmpPlaylistPrivate BmpPlaylistPrivate;

struct _BmpPlaylist {
        GObject parent;

        BmpPlaylistPrivate *priv;
};

struct _BmpPlaylistClass {
        GObjectClass parent;

        void (*tracklist_list_sorted)    (BmpPlaylist *self, int i, gpointer array, int n_items);
        void (*tracklist_items_removed)  (BmpPlaylist *self, int i, gpointer array, int n_items);
        void (*tracklist_items_added)    (BmpPlaylist *self, int i, gpointer array, int n_items);
};

unsigned int
vcolumns_get_n_items  (void);

Bmp::Library::Datum
vcolumns_get_item_nth (unsigned int n);

#define COLUMN_GUID  7
#define COLUMN_URI   8

struct BmpPlaybackHistory
{
    GQueue        *history;
    int            mark;
    bool           dirty;
    Glib::Mutex    lock;
};

BmpPlaybackHistory*
bmp_playback_history_new                (void);

void
bmp_playback_history_free               (BmpPlaybackHistory         *history);

void
bmp_playback_history_set                (BmpPlaybackHistory         *history,
                                         int                         position);

int
bmp_playback_history_prev               (BmpPlaybackHistory         *history,
                                         BmpPluginFlowInterface     *flow_plugin);

int
bmp_playback_history_next               (BmpPlaybackHistory         *history,
                                         BmpPluginFlowInterface     *flow_plugin);


int
bmp_playback_history_rewind             (BmpPlaybackHistory *history);

/* END BMPx Playback History Stuff */
GType
bmp_playlist_get_type                   (void);

BmpPlaylist*
bmp_playlist_new                        (void);

void
bmp_playlist_setup                      (BmpPlaylist *self);

GtkListStore*
bmp_playlist_get_playlist               (BmpPlaylist *self);

int
bmp_playlist_get_row_by_guid            (BmpPlaylist *self,
                                         RowGUID     *guid);

bool
bmp_playlist_get_row_by_index           (BmpPlaylist  *self,
                                         int           item,
                                         GtkTreeIter  *iter);

char*
bmp_playlist_get_uri_by_index           (BmpPlaylist  *self,
                                         int           index);

gchar*
bmp_playlist_get_title_nth              (BmpPlaylist  *self,
                                         int          index);
gchar*
bmp_playlist_get_current_title          (BmpPlaylist  *self);


gchar*
bmp_playlist_get_uri_nth                (BmpPlaylist      *self,
                                         int              index);
gchar*
bmp_playlist_get_current_uri            (BmpPlaylist      *self);



int
bmp_playlist_get_length                 (BmpPlaylist      *self);



bool
bmp_playlist_tracklist_remove           (BmpPlaylist      *self,
                                         int              item);

int
bmp_playlist_insert_tracklist_items     (BmpPlaylist      *self,
                                         const gchar     **uri_list);

int
bmp_playlist_insert_tracklist_items_position (BmpPlaylist     *self,
                                              const gchar    **uri_list,
                                              int             _idx);

void
bmp_playlist_tracklist_remove_selected      (BmpPlaylist      *self,
                                             GList            *path);

void
bmp_playlist_tracklist_remove_unselected    (BmpPlaylist      *self);

void
bmp_playlist_tracklist_remove_rows_all      (BmpPlaylist      *self);

void
bmp_playlist_tracklist_remove_rows          (BmpPlaylist      *self,
                                             GArray           *rows,
                                             int              n_rows);
void
bmp_playlist_load_playlist     (BmpPlaylist *self);

#endif // BMP_PLAYLIST_HPP
