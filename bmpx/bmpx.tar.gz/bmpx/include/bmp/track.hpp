#ifndef BMP_TRACK_HPP
#define BMP_TRACK_HPP

#include <bmp/database.hpp>
#include <bmp/library.hpp>

namespace Bmp
{
    template <typename T> 
    class TrackValue
    {
	public:
	  TrackValue (const T& value) : valid (true), value (value)
	  {}

	  TrackValue () : valid (false)
	  {}

	  operator bool ()
	  {
	    return valid;
	  }

	  operator T ()
	  {
	    return value;
	  }

	private:
	  bool	      valid;
	  T	      value;
    }; 

    class Track
    {
      private:
	  Track	 (const Bmp::DB::DataRow& row);
	  Track  ();
      public:

	  static Track
	  create (const Bmp::DB::DataRow& row)
	  {
	    return Track (row);
	  }

	  ~Track ();

#if 0
	  const	TrackValue location;
	  const TrackValue artist;
	  const TrackValue album;
	  const TrackValue title;
	  const TrackValue tracknumber;
	  const TrackValue duration;
	  const TrackValue genre;
	  const TrackValue comment;
	  const TrackValue rating;
	  const TrackValue date;
	  const	TrackValue mtime;    //FIXME: int is too short for mtime
	  const TrackValue bitrate;
	  const TrackValue samplerate;
	  const TrackValue count;
	  const TrackValue volume_udi;
	  const TrackValue device_udi;
#endif

    };
}

#endif
