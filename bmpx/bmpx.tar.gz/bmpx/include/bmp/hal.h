/*  BMPx - The Dumb Music Player
 *  Copyright (C) 2005 BMPx development team.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 *  $Id$
 *
 * The BMPx project hereby grant permission for non-gpl compatible GStreamer
 * plugins to be used and distributed together with GStreamer and BMPx. This
 * permission are above and beyond the permissions granted by the GPL license
 * BMPx is covered by.
 *
 */

/* -*- Mode: C; tab-width: 8; indent-tabs-mode: nil; c-basic-offset: 8 -*- */

#ifndef BMP_HAL_H
#define BMP_HAL_H

/*
 * Potentially, include other headers on which this header depends.
 */
#include <glib-object.h>
#include <dbus/dbus.h>
#include <dbus/dbus-glib.h>
#include <libhal.h>
#include <libhal-storage.h>

#define BMP_TYPE_HAL		    (bmp_hal_get_type ())
#define BMP_HAL(obj)		    (G_TYPE_CHECK_INSTANCE_CAST ((obj), BMP_TYPE_HAL, BmpHal))
#define BMP_HAL_CLASS(klass)	    (G_TYPE_CHECK_CLASS_CAST ((klass), BMP_TYPE_HAL, BmpHalClass))
#define BMP_IS_HAL(obj)	  	    (G_TYPE_CHECK_INSTANCE_TYPE ((obj), BMP_TYPE_HAL))
#define BMP_IS_HAL_CLASS(klass)	    (G_TYPE_CHECK_CLASS_TYPE ((klass), BMP_TYPE_HAL))
#define BMP_HAL_GET_CLASS(obj)	    (G_TYPE_INSTANCE_GET_CLASS ((obj), BMP_TYPE_HAL, BmpHalClass))

typedef struct _BmpHal BmpHal;
typedef struct _BmpHalClass BmpHalClass;
typedef struct _BmpHalPrivate BmpHalPrivate;

struct _BmpHal {
	GObject parent;

        BmpHalPrivate *priv;
};

struct _BmpHalClass {
	GObjectClass parent;

	void (*volume_added)   (BmpHal *self);
	void (*volume_removed) (BmpHal *self);
};

typedef struct _BmpHalVolumeData BmpHalVolumeData;
struct _BmpHalVolumeData {
	char	      *volume_udi;    
	char	      *mount_path;

	char	      *device_udi;

	dbus_bool_t    is_disc;

	//XXX: Not sure were going to use those
	char	      *device_serial;
};
#define BMP_HAL_VOLUME_DATA(data) ((BmpHalVolumeData*)data)

BmpHalVolumeData*
bmp_hal_volume_data_copy (BmpHalVolumeData *item);

void
bmp_hal_volume_data_free (BmpHalVolumeData *item);

GType
bmp_hal_volume_data_get_type (void);


GType
bmp_hal_get_type (void);

BmpHal*
bmp_hal_new (void);

gboolean
bmp_hal_find_volume_data_for_path (BmpHal	     *self,
				   const gchar	     *path,
				   BmpHalVolumeData **v_data); //The returned v_data is CONST!!

gboolean
bmp_hal_volume_is_present (BmpHal	*self,
			   const gchar	*udi);

#endif /* BMP_HAL_H */



