/*  BMPx - The Dumb Music Player
 *  Copyright (C) 2005 BMPx development team.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 *  $Id: main.c 336 2005-10-08 13:49:42Z mderezynski $
 */

#ifndef UTIL_H
#define UTIL_H

#include <config.h>
#include <bmp/file_utils.hpp>

#ifdef HAVE_GUI
#  include <gtk/gtk.h>
#  include <gdk/gdk.h>
#  include <gtkmm.h>
#else
#  include <glib.h>
#  include <glib-object.h>
#  include <glibmm.h>
#endif

#define NO_PLAY_BUTTON  FALSE
#define PLAY_BUTTON     TRUE

#define SWAP (a, b)      { a^=b; b^=a; a^=b; }

typedef struct _BmpUniqueList BmpUniqueList;

/* INI functions */
std::string read_ini_string (const std::string& filename,
			     const std::string& section,
			     const std::string& key);

std::string read_ini_string_buffer (const char	      *buffer,
				    const std::string& section,
				    const std::string& key);

GArray *read_ini_array (const std::string& filename,
			const std::string& section,
			const std::string& key);

/* GList functions */
void glist_movedown (GList *list);
void glist_moveup   (GList *list);
void glist_swap     (GList *list_1,
		     GList *list_2);

GList *glist_make_shuffle_index (GList * list);

/* string functions */

gboolean str_has_prefix_nocase (const gchar * str, const gchar * prefix);
gboolean str_has_suffix_nocase (const gchar * str, const gchar * suffix);
gboolean str_has_suffixes_nocase (const gchar * str, gchar * const *suffixes);

/* UI functions */

gboolean
bmp_detach (void);

gchar*
bmp_get_titlestring (GHashTable *metadata);

/* Miscellaneous */

guint
gint_count_digits (gint n);

gchar**
glist_to_strv (GList *list);

gchar**
gslist_to_strv (GSList *list);

gboolean
match_keys (const gchar *haystack, const gchar *needle);

gboolean
bmp_become_daemon (void);

GList*
get_mount_entries (void);

/* BmpUniqueList */

BmpUniqueList*
bmp_unique_list_new (GType type);

void
bmp_unique_list_free   (BmpUniqueList *ulist);

void
bmp_unique_list_insert (BmpUniqueList *ulist, gconstpointer key);

void
bmp_unique_list_remove (BmpUniqueList *ulist, gconstpointer key);

GList*
bmp_unique_list_to_glist (BmpUniqueList *ulist);

/* Attribute-to-Row map */

GHashTable*
attr_row_map_new (void);

void
attr_row_map_mapping_insert		(GHashTable *map, const gchar *key, GtkTreeModel *model, GtkTreeIter *iter);

gboolean
attr_row_map_mapping_remove		(GHashTable *map, const gchar *key);

gboolean
attr_row_map_mapping_remove_nodestroy	(GHashTable *map, const gchar *key);

gboolean
attr_row_map_mapping_get		(GHashTable *map, const gchar *key, GtkTreeModel *model, GtkTreeIter *iter);

gboolean
attr_row_map_mapping_exists (GHashTable *map, const gchar *key);

#endif
