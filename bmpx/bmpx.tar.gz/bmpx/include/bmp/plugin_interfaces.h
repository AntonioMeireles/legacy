#ifndef BMP_PLUGIN_INTERFACES_H
#define BMP_PLUGIN_INTERFACES_H

#include <glib-object.h>

#include "bmp/interfaces/plugin_interface_flow.h"
#include "bmp/interfaces/plugin_interface_plug_meta.h"
#include "bmp/interfaces/plugin_interface_plug_property.h"

#endif /* _PLUGIN_INTERFACES_H_ */










