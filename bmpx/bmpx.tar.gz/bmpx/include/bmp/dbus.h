#ifndef _BMP_DBUS_H
#define _BMP_DBUS_H

#ifdef __cplusplus
extern "C" {
#endif

#define BMP_DBUS_SERVICE            "org.beepmediaplayer.bmp"
#define BMP_DBUS_INTERFACE          BMP_DBUS_SERVICE
#define BMP_DBUS_PATH		    "/SystemControl"

typedef enum {

	BMP_DBUS_ERROR_INVALID_URI,

	BMP_DBUS_ERROR_QUERY_INVALID_TICKET_ID,
	BMP_DBUS_ERROR_QUERY_INVALID_ATOM_TYPE,

	BMP_DBUS_ERROR_INTERNAL_ERROR

} BmpDBusError;

#ifdef __cplusplus
}
#endif

#endif /* _BMP_BUS_H */
