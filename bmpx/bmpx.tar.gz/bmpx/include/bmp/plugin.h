#ifndef __BMP_THEMES_H__
#define __BMP_THEMES_H__

#include <config.h>

#include <glib.h>
#include <glib-object.h>
#include <glibmm.h>

G_BEGIN_DECLS

#define BMP_TYPE_PLUGIN             (bmp_plugin_get_type ())
#define BMP_PLUGIN(plugin)	    (G_TYPE_CHECK_INSTANCE_CAST ((plugin), BMP_TYPE_PLUGIN, BmpPlugin))
#define BMP_IS_PLUGIN(plugin)	    (G_TYPE_CHECK_INSTANCE_TYPE ((plugin), BMP_TYPE_PLUGIN))

typedef struct _BmpPlugin BmpPlugin;

GType           bmp_plugin_get_type        (void) G_GNUC_CONST;

BmpPlugin*	bmp_plugin_new		   (const gchar *path);
gboolean	bmp_plugin_valid	   (BmpPlugin *plugin);
GObject*	bmp_plugin_create_instance (BmpPlugin *plugin);

 
G_END_DECLS

#endif
