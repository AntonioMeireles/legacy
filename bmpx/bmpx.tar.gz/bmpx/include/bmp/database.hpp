#ifndef BMP_DATABASE_HPP
#define BMP_DATABASE_HPP

#include <glibmm.h>
#include <sqlite3.h>

#include <boost/variant.hpp>
#include <boost/tuple/tuple.hpp>

namespace Bmp {

      namespace DB {

	  enum Exception
	  {
		  DB_EXISTS,
		  IO_ERROR,
		  SQL_EXEC_ERROR //FIXME: We need an exception type that carries the sqlite error message
	  };

	  enum ValueType
	  {
	      VALUE_TYPE_BOOL,
	      VALUE_TYPE_INT,
	      VALUE_TYPE_REAL,	//We use "REAL" here as it's sqlite3's notation, see: http://www.sqlite.org/datatype3.html
	      VALUE_TYPE_STRING  
	  }; 

	  typedef boost::variant<bool, int, double, std::string> ValueVariant;

	  typedef std::map<std::string,  ValueType>      ValueMap;
	  typedef std::pair<std::string, ValueType>      ValueMapPair;

	  typedef std::map<std::string,  ValueVariant>   DataRow;
	  typedef std::pair<std::string, ValueVariant>   DataRowPair;

	  typedef std::vector<DataRow>			 DataRowVector;

	  /** Tuple for performing queries
            *
            * bool field denotes whether it must be an exact match or not
	    * std::string field denotes the column name
	    * ValueVariant field holds the to-be-matched value
	    */
	  typedef boost::tuple<bool, std::string, ValueVariant> Attribute;

	  /** Tuple for performing project
            *
	    * std::string field denotes the column name
	    * ValueVariant field holds the to-be-matched value
	    */
	  typedef boost::tuple<std::string, ValueType> AttributeProject;


	  /** A vector of Attributes 
	    *
	    */
	  typedef std::vector<Attribute> AttributeList;

	  //Class "DB"
	  class DB
	  {
	    public:


	      DB (std::string name, std::string path, bool truncate = true);
	      ~DB ();

	      void
	      create_table    (std::string	  name,
			       std::string	  pkey,
			       const ValueMap&	  map);

	      void
	      drop_table      (std::string	  name);


	      DataRowVector
	      project	      (std::string		    name,
			       std::string		    p_column, 
			       const ValueMap&		    map,
			       const AttributeList&	    attributes = AttributeList ());

	      DataRowVector 
	      get	      (std::string	      name,
			       const ValueMap&	      map,
			       const AttributeList&   attributes = AttributeList ()); 
			       
	      void
	      add	      (std::string	      name,
			       const DataRow&	      row,
			       const ValueMap&	      map);

	      void
	      del	      (std::string	      name,
			       const ValueMap&	      map,
			       const AttributeList&   attributes = AttributeList ()); 

	    private:

	      void
	      sqlite_exec_simple (std::string sql);
	      std::string  name;
	      std::string  path; //sqlite3 filename = path+name+".mlib";
	      sqlite3	  *sqlite;
      
	  };

      } // DB

}; // Bmp

#endif // BMP_DATABASE_HPP
