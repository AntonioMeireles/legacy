#!/bin/sh

templatedir="${2:-.}"
destdir="${3:-.}"

TEMPLATE_C="${templatedir}/goa.in.c"
export TEMPLATE_C
TEMPLATE_H="${templatedir}/goa.in.h"
export TEMPLATE_H
TYPES="$1"
export TYPES

rm -f ${destdir}/libgoa.c
rm -f ${destdir}/libgoa.h

echo "#include <libgoa.h>"    >> ${destdir}/libgoa.c
echo "#include <glib-object.h>"     >> ${destdir}/libgoa.c

echo "#ifndef __AUX_G_OBJECT_GET_H" >> ${destdir}/libgoa.h 
echo "#define __AUX_G_OBJECT_GET_H" >> ${destdir}/libgoa.h 

echo "#include <glib-object.h>"     >> ${destdir}/libgoa.h
echo "G_BEGIN_DECLS"     >> ${destdir}/libgoa.h

for Line in `cat $TYPES`; do

   G_TYPE=`echo $Line|cut -d: -f1`
   export G_TYPE
   C_TYPE=`echo $Line|cut -d: -f2`
   export C_TYPE
   NAME=`echo $Line|cut -d: -f3`
   export NAME
   RVAL=`echo $Line|cut -d: -f4`
   export RVAL

   cat $TEMPLATE_C | sed s:\@TYPE_CTYPE\@:$C_TYPE:g \
                   | sed s:\@TYPE_GTYPE_BASE\@:$G_TYPE:g \
                   | sed s:\@TYPE_GTYPE_FULL\@:G_TYPE_$G_TYPE:g \
                   | sed s:\@NAME\@:$NAME:g \
                   | sed s:\@RVAL\@:$RVAL:g \
                   >> ${destdir}/libgoa.c
   
   cat $TEMPLATE_H | sed s:\@TYPE_CTYPE\@:$C_TYPE:g \
                   | sed s:\@TYPE_GTYPE_BASE\@:$G_TYPE:g \
                   | sed s:\@TYPE_GTYPE_FULL\@:G_TYPE_$G_TYPE:g \
                   | sed s:\@NAME\@:$NAME:g \
                   | sed s:\@RVAL\@:$RVAL:g \
                   >> ${destdir}/libgoa.h
done

echo "G_END_DECLS"     >> ${destdir}/libgoa.h

echo "#endif /*__AUX_G_OBJECT_GET_H*/"  >> ${destdir}/libgoa.h

