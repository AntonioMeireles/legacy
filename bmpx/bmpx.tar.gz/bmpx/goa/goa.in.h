@TYPE_CTYPE@ g_object_get_@NAME@_R (GObject * object,
                                       const gchar * prop_name);
#define g_object_get_@NAME@(object, prop_name) g_object_get_@NAME@_R(G_OBJECT(object), prop_name)


