@TYPE_CTYPE@
    g_object_get_@NAME@_R (GObject * gobject, const gchar * prop_name)
{
    @TYPE_CTYPE@ _@TYPE_GTYPE_BASE@;

    GParamSpec *pspec;

    pspec =
        g_object_class_find_property (G_OBJECT_GET_CLASS (gobject),
                                      prop_name);

    if (!pspec)
     {
         g_log (G_LOG_DOMAIN, G_LOG_LEVEL_WARNING,
                "%s: GObject of type '%s' has no property '%s'", G_STRFUNC,
                G_OBJECT_TYPE_NAME (gobject), prop_name);
         return @RVAL@;
     }

    if (pspec->value_type != @TYPE_GTYPE_FULL@)
     {
         g_log (G_LOG_DOMAIN, G_LOG_LEVEL_WARNING,
                "%s: Property '%s' of GObject type '%s' is not of type @TYPE_GTYPE_BASE@",
                G_STRFUNC, prop_name, G_OBJECT_TYPE_NAME (gobject));
         return @RVAL@;
     }

    g_object_get (gobject, prop_name, &_@TYPE_GTYPE_BASE@, NULL);

    return _@TYPE_GTYPE_BASE@;
}
