#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <config.h>
#include <revision.h>
#include <build.h>

#include <locale.h>

#include <glib.h>
#include <glib/gi18n.h>
#include <glib-object.h>
#include <glib/gprintf.h>

#include <dbus/dbus-glib.h>
#include <dbus/dbus-glib-lowlevel.h>
#include <dbus/dbus.h>
#include <bmp/dbus.h>

static gboolean show_version = FALSE;

/* Commands */

static gboolean quit            = FALSE;

static gboolean add_files       = FALSE;
static gboolean play_files      = FALSE;

static gboolean add_uris        = FALSE;
static gboolean play_uris       = FALSE;

static gboolean play_stop       = FALSE;
static gboolean play_next       = FALSE;
static gboolean play_prev       = FALSE;
static gboolean play_pause      = FALSE;
static gboolean play            = FALSE;

static gchar *display		= NULL;

#if 0
static gboolean repeat          = FALSE;
static gboolean shuffle         = FALSE;

static gboolean volume_set      = FALSE;
#endif

static GOptionEntry bmp_options[] =
  {
    {"version",     'v', 0, G_OPTION_ARG_NONE, &show_version, N_("Display version"), NULL},

    {"quit",        'q', 0, G_OPTION_ARG_NONE, &quit,         N_("Make a running BMPx terminate"), NULL},

    {"add-files",   'a', 0, G_OPTION_ARG_NONE, &add_files,    N_("Add Files to playlist"), NULL},
    {"add-uris",    'u', 0, G_OPTION_ARG_NONE, &add_uris,     N_("Add URIs to playlist"), NULL},

    {"play-files",   0, 0,  G_OPTION_ARG_NONE, &play_files,   N_("Add Files to playlist and start playback"), NULL},
    {"play-uris",    0, 0,  G_OPTION_ARG_NONE, &play_uris,    N_("Add URIs to playlist and start playback"), NULL},

    {"next",         0, 0,   G_OPTION_ARG_NONE, &play_next,   N_("Skip to next Track"), NULL},
    {"prev",         0, 0,   G_OPTION_ARG_NONE, &play_prev,   N_("Skip to previous Track"), NULL},
    {"stop",         0, 0,   G_OPTION_ARG_NONE, &play_stop,   N_("Stop Playback"), NULL},
    {"play",         0, 0,   G_OPTION_ARG_NONE, &play_pause,  N_("Start Playback"), NULL},
    {"pause",        0, 0,   G_OPTION_ARG_NONE, &play_pause,  N_("Pause Playback"), NULL},
    {"ui-start",     0,	0,   G_OPTION_ARG_STRING, &display,   N_("Start the BMP UI on the specified X display"), NULL},
  
#if 0
    {"repeat",       0, 0,   G_OPTION_ARG_NONE, &repeat,      N_("Change Repeat Mode"), NULL},
    {"shuffle",      0, 0,   G_OPTION_ARG_NONE, &shuffle,     N_("Set Repeat"), NULL},
    {"volume_set",   0, 0,   G_OPTION_ARG_NONE, &volume_set,  N_("Set Repeat"), NULL},
#endif

    { NULL }
  };


static const char *features[] =
    {
#ifdef HAVE_SM
      N_("X11 Session Management"),
#endif // HAVE_SM
      N_("D-BUS support"),
#ifdef HAVE_HAL
      N_("HAL support"),
#endif // USE_HAL
      N_("Audio backend: GStreamer"),
#ifdef USE_GCONF
      N_("Configuration backend: Gconf"),
#else // USE_GCONF
      N_("Configuration backend: XML file"),
#endif
#ifdef USE_AMAZON
      N_("Amazon album cover support"),
#endif // USE_AMAZON
#ifdef HAVE_GUI
      N_("Core GUI (Winamp 2.x skinning engine)"),
#endif // HAVE_GUI
#ifdef HAVE_ALSA
      N_("ALSA Support (Linux)"),
#endif
#ifdef HAVE_SUNAUDIO
      N_("SUN Audio support")
#endif
    };


static void
print_version (void)
{
  gint i;

  g_print ("%s %s",
           PACKAGE,
           VERSION);

  if (strlen(RV_REVISION))
      g_print (" (%s-R%s)",
               RV_LAST_CHANGED_DATE,
               RV_REVISION);

  g_print (_("\nCopyright (c) 2005-2006 BMP Project <http://www.beep-media-player.org>\n\n"));

  g_print (_("Built the %s on %s with:\n"),
           BUILD_DATE,
           BUILD_ARCH);

  for (i = 0; i < G_N_ELEMENTS (features); i++)
      g_print ("* %s\n", _(features[i]));

  g_print ("\n");
}

static void
setup_i18n (void)
{
  setlocale (LC_ALL, "");

  bindtextdomain (PACKAGE, LOCALE_DIR);
  bind_textdomain_codeset (PACKAGE, "UTF-8");
  textdomain (PACKAGE);
}

gint
main (gint argc, gchar **argv)
{
  DBusConnection    *connection;
  DBusGConnection   *bus;
  DBusGProxy        *remote_object;
  DBusError          dbus_error;
  gboolean	     has_owner;
  GError            *error = NULL;
  gboolean           startup_only;
  GOptionContext    *oc_bmp;

  setup_i18n ();

  if (argc == 1)
    {
        startup_only = TRUE;
        goto STARTUP;
    }
  else
    {
        startup_only = FALSE;
    }

  oc_bmp = g_option_context_new(" - Run BMPx and/or perform actions on BMPx");
  g_option_context_add_main_entries (oc_bmp, bmp_options, PACKAGE);

  if (!g_option_context_parse (oc_bmp, &argc, &argv, &error))
    {
      g_printerr (_("\nInvalid argument: '%s'\nPlease run '%s --help' for help on usage\n\n"), error->message, argv[0]);
      g_error_free (error);
      return EXIT_FAILURE;
    }

  if (show_version)
    {
      print_version ();
      return EXIT_SUCCESS;
    }

  STARTUP:

  error = NULL;
  g_type_init ();
  g_thread_init (NULL);

  dbus_g_type_specialized_init ();

  {
    GLogLevelFlags fatal_mask;

    fatal_mask = g_log_set_always_fatal (G_LOG_FATAL_MASK);
    fatal_mask |= G_LOG_LEVEL_WARNING | G_LOG_LEVEL_CRITICAL;
    g_log_set_always_fatal (fatal_mask);
  }

  bus = dbus_g_bus_get (DBUS_BUS_SESSION, &error);
  if (!bus)
    {
      g_printerr (_("%s: Couldn't connect to session bus: %s\n\n"), argv[0], error->message);
      return EXIT_FAILURE;
    }

  dbus_error_init (&dbus_error);
  connection = dbus_g_connection_get_connection (bus);
  has_owner = dbus_bus_name_has_owner (connection, BMP_DBUS_INTERFACE, &dbus_error);

  remote_object = dbus_g_proxy_new_for_name (bus,
                                             BMP_DBUS_SERVICE,
                                             BMP_DBUS_PATH,
                                             BMP_DBUS_INTERFACE);

  if (!has_owner && startup_only)
    {
      if (!dbus_g_proxy_call (remote_object, "Startup", &error,
                          G_TYPE_INVALID, G_TYPE_INVALID))
                printf(error->message);

        goto END;
    }
  else
  if (has_owner && startup_only)
    {
        if (!dbus_g_proxy_call (remote_object, "UiRaise", &error,
                          G_TYPE_INVALID, G_TYPE_INVALID))
                printf(error->message);

        goto END;
    }

  if (quit)
    {
        if (!dbus_g_proxy_call (remote_object, "Quit", &error,
                          G_TYPE_INVALID, G_TYPE_INVALID))
                printf(error->message);

        goto END;
    }

  if (play_next)
    {
        if (!dbus_g_proxy_call (remote_object, "GoNext", &error,
                          G_TYPE_INVALID, G_TYPE_INVALID))
                printf(error->message);

        goto END;
    }

  if (play_prev)
    {
        if (!dbus_g_proxy_call (remote_object, "GoPrev", &error,
                          G_TYPE_INVALID, G_TYPE_INVALID))
                printf(error->message);

        goto END;
    }

  if (play_pause)
    {
        if (!dbus_g_proxy_call (remote_object, "Pause", &error,
                          G_TYPE_INVALID, G_TYPE_INVALID))
                printf(error->message);

        goto END;
    }

  if (play_stop)
    {
        if (!dbus_g_proxy_call (remote_object, "Stop", &error,
                          G_TYPE_INVALID, G_TYPE_INVALID))
                printf(error->message);

        goto END;
    }

  if (play)
    {
        if (!dbus_g_proxy_call (remote_object, "Play", &error,
                          G_TYPE_INVALID, G_TYPE_INVALID))
                printf(error->message);

        goto END;
    }

  if (display)
    {
        if (!dbus_g_proxy_call (remote_object, "UiStart", &error,
                          G_TYPE_STRING, display, 
                          G_TYPE_INVALID, G_TYPE_INVALID));

        goto END;
    }

#if 0
  if (! strcmp(argv[1], "PlayTrack"))
    {
        gint track;

        track = strtol (argv[2], NULL, 10);

        if (!dbus_g_proxy_call (remote_object, "PlayTrack", &error,
                          G_TYPE_INT, track-1,
                          G_TYPE_INVALID, G_TYPE_INVALID));

        goto END;
    }

  if (! strcmp(argv[1], "VolumeSet"))
    {
        gint volume;

        volume = strtol (argv[2], NULL, 10);

        if (!dbus_g_proxy_call (remote_object, "VolumeSet", &error,
                          G_TYPE_INT, volume,
                          G_TYPE_INVALID, G_TYPE_INVALID));

        goto END;
    }

  if (!strcmp(argv[1], "Repeat"))
    {
        gboolean repeat;

        if (argc == 3)
            repeat = (strtol (argv[2], NULL, 10)) ? TRUE : FALSE;
        else
            repeat = TRUE;

        if (!dbus_g_proxy_call (remote_object, "RepeatSet", &error,
                          G_TYPE_BOOLEAN, repeat,
                          G_TYPE_INVALID, G_TYPE_INVALID));

        goto END;
    }

  if (!strcmp(argv[1], "Shuffle"))
    {
        gboolean shuffle;

        if (argc == 3)
            shuffle = (strtol (argv[2], NULL, 10)) ? TRUE : FALSE;
        else
            shuffle = TRUE;

        if (!dbus_g_proxy_call (remote_object, "ShuffleSet", &error,
                          G_TYPE_BOOLEAN, shuffle,
                          G_TYPE_INVALID, G_TYPE_INVALID));

        goto END;
    }
#endif

  if (add_uris)
    {
        gchar **uri_list;
        gint    n,
                rv;

        uri_list = g_new (gchar*, argc+1);

        for (n = 1; n < argc; n++)
          {
            uri_list[n-1] = g_strdup (argv[n]);
          }
        uri_list[n-1] = NULL;

        if (!dbus_g_proxy_call (remote_object, "AddUriList", &error,
                          G_TYPE_STRV, uri_list,
                          G_TYPE_INT, (gint)-1,
                          G_TYPE_BOOLEAN, FALSE,
                          G_TYPE_BOOLEAN, FALSE,
                          G_TYPE_INT, (gint)-1,
                          G_TYPE_INVALID,
                          G_TYPE_INT, &rv,
                          G_TYPE_INVALID));

        g_strfreev (uri_list);

        goto END;
    }

  if (add_files)
    {
        gchar **uri_list;
        gint    n,
                rv;

        uri_list = g_new (gchar*, argc+1);

        for (n = 1; n < argc; n++)
          {
            GError  *error = NULL;
            gchar   *filename,
                    *uri;

            if (argv[n][0] != '/')
              {
                filename = g_build_filename (g_getenv("PWD"), argv[n], NULL);
              }
            else
              {
                filename = g_strdup (argv[n]);
              }

            uri = g_filename_to_uri (filename, NULL, &error);
            g_free (filename);
            if (error)
              {
                g_error_free (error);
                error = NULL;
              }
            uri_list[n-1] = uri;
          }
        uri_list[n-1] = NULL;

        if (!dbus_g_proxy_call (remote_object, "AddUriList", &error,
                          G_TYPE_STRV, uri_list,
                          G_TYPE_INT, (gint)-1,
                          G_TYPE_BOOLEAN, FALSE,
                          G_TYPE_BOOLEAN, FALSE,
                          G_TYPE_INT, (gint)-1,
                          G_TYPE_INVALID,
                          G_TYPE_INT, &rv,
                          G_TYPE_INVALID));

        g_strfreev (uri_list);

        goto END;
    }

  if (play_uris)
    {
        gchar **uri_list;
        gint    n,
                rv;

        uri_list = g_new (gchar*, argc+1);

        for (n = 1; n < argc; n++)
          {
            uri_list[n-1] = g_strdup(argv[n]);
          }
        uri_list[n-1] = NULL;

        if (!dbus_g_proxy_call (remote_object, "AddUriList", &error,
                          G_TYPE_STRV, uri_list,
                          G_TYPE_INT, (gint)-1,
                          G_TYPE_BOOLEAN, TRUE,
                          G_TYPE_BOOLEAN, TRUE,
                          G_TYPE_INT, (gint)-1,
                          G_TYPE_INVALID,
                          G_TYPE_INT, &rv,
                          G_TYPE_INVALID));

        g_strfreev (uri_list);

        goto END;
    }

  if (play_files)
    {
        gchar **uri_list;
        gint    n,
                rv;

        uri_list = g_new (gchar*, argc+1);

        for (n = 1; n < argc; n++)
          {
            GError  *error = NULL;
            gchar   *filename,
                    *uri;

            if (argv[n][0] != '/')
              {
                filename = g_build_filename (g_getenv("PWD"), argv[n], NULL);
              }
            else
              {
                filename = g_strdup (argv[n]);
              }

            uri = g_filename_to_uri (filename, NULL, &error);
            g_free (filename);
            if (error)
              {
                g_error_free (error);
                error = NULL;
              }
            uri_list[n-1] = uri;
          }
        uri_list[n-1] = NULL;

        if (!dbus_g_proxy_call (remote_object, "AddUriList", &error,
                          G_TYPE_STRV, uri_list,
                          G_TYPE_INT, (gint)-1,
                          G_TYPE_BOOLEAN, TRUE,
                          G_TYPE_BOOLEAN, TRUE,
                          G_TYPE_INT, (gint)-1,
                          G_TYPE_INVALID,
                          G_TYPE_INT, &rv,
                          G_TYPE_INVALID));

        goto END;
    }

  END:

  return EXIT_SUCCESS;
}
