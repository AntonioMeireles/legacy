/* -*- Mode: C; tab-width: 8; indent-tabs-mode: nil; c-basic-offset: 8 -*- */
/*
 * Chroma widget set
 * (C) 2005 M. Derezynski <internalerror@gmail.com>
 *
 */

#include <math.h>
#include <stdlib.h>
#include <string.h>
#include <gtk/gtk.h>
#include <gdk/gdk.h>
#include <gdk/gdkkeysyms.h>
#include <gdk/gdkx.h>
#include <X11/Xlib.h>

#include <chroma/chroma-list.h>
#include <chroma/chroma-list-column.h>
#include <chroma/chroma-list-selection.h>
#include <chroma/chroma-vscrollbar.h>
#include <chroma/dnd.h>

#include "draw.h"
#include "libchroma-marshalers.h"

#define NONE (-1)

static void chroma_list_class_init     (ChromaListClass *klass);

static void chroma_list_init           (ChromaList      *widget);

static void chroma_list_realize        (GtkWidget       *widget);

static void chroma_list_size_allocate  (GtkWidget       *widget,
				        GtkAllocation   *allocation);

static void chroma_list_send_configure (ChromaList      *widget);

static void
chroma_list_drag_leave	    (GtkWidget		  *widget,
			     GdkDragContext	  *drag_context,
			     guint		   time_); 
 
static gboolean
chroma_list_drag_motion	    (GtkWidget		  *widget,
			     GdkDragContext	  *drag_context,
			     gint		   x,
			     gint		   y,
			     guint		   time_);

static gboolean
chroma_list_button_press    (GtkWidget		  *widget,
			     GdkEventButton	  *event);

static gboolean
chroma_list_button_release  (GtkWidget		  *widget,
			     GdkEventButton	  *event);

static gboolean
chroma_list_key_press	    (GtkWidget		  *widget,
			     GdkEventKey	  *event);


static gboolean
chroma_list_scroll	    (GtkWidget		  *widget,
			     GdkEventScroll	  *event);

static gboolean
chroma_list_motion	    (GtkWidget	          *widget,
			     GdkEventMotion       *event);

typedef enum {
    CHROMA_LIST_SIGNAL_ROW_ACTIVATED,
    CHROMA_LIST_SIGNAL_CURSOR_POSITION,
    CHROMA_LIST_SIGNAL_DND,

    CHROMA_LIST_N_SIGNALS
} ChromaListSignals;
static guint signals[CHROMA_LIST_N_SIGNALS] = {0};

typedef enum {
    CHROMA_LIST_PROP_OFFSET = 1,
    CHROMA_LIST_PROP_N_ITEMS,
    CHROMA_LIST_PROP_ROW_HEIGHT,
    CHROMA_LIST_PROP_RESERVED_SPACE,
    CHROMA_LIST_PROP_SHOW_HEADERS,

    CHROMA_LIST_N_PROPERTIES
} ChromaListProperties;

enum {
    SIGNAL_ROW_CHANGED,
    SIGNAL_ROW_DELETED,
    SIGNAL_ROW_INSERTED,
    SIGNAL_ROWS_REORDERED,

    SIGNAL_SORT_COLUMN_CHANGED, //GtkTreeSortable
    
    N_MODEL_SIGNALS
};

enum {
    SIGNAL_POSITION,
    SIGNAL_STEP_UP,
    SIGNAL_STEP_DOWN,
    
    N_ADJUSTMENT_SIGNALS
};

typedef enum {
    SCROLL_DIRECTION_UP,
    SCROLL_DIRECTION_DOWN,
} ScrollDirection;

struct _ChromaListPrivate {
    gboolean		       dispose_has_run;

    GtkTreeModel	      *model;
    gulong		       model_signals[N_MODEL_SIGNALS];
    ChromaListRowSwapFunc      model_row_swap_func;
    

    ChromaVScrollbar	      *adjustment;
    gulong		       adjustment_signals[N_ADJUSTMENT_SIGNALS];

    GList		      *selected_rows;
    GtkTreeRowReference	      *last_pressed_row;

    GtkSortType		       sort_type;
    gint		       sort_column_id;
    gint		       sort_trigger;

    ChromaListColumn	      *number_column;

    ChromaListCellDataFunc    *cell_data_funcs;
    gpointer		      *cell_data_funcs_data;

    GPtrArray		      *columns;
    gdouble		      *column_widths;
    gdouble		      *column_xalign;
    gdouble		      *column_yalign;
    gboolean		      *column_show;
    gint		       n_columns;
    gint		       n_columns_visible;
    gdouble		      *pixel_widths;

    gint		       header_size;
    gint		       row_height;
    gint		       cellspacing;
    gint		       offset;

    guint		       all_columns_mask;

    gboolean		       active_row_drag;
    gboolean		       active_column_resize;
    gboolean		       button_press;

    gint		       grabbed_position;

    gint		       adjactent_l;
    gint		       adjactent_r;
    gdouble		       resize_position;

    guint		       scroll_timeout_source_id;
    ScrollDirection	       scroll_direction; 
    gint		       scroll_step;

    /* Parameters */
    GtkSelectionMode	       selection_mode;
    ChromaListDropMode	       drop_mode;
    gboolean		       use_numbers;
    gint		       reserved_space;
    gboolean		       show_headers;

    gboolean		       drop;
    gint		       drop_row;

    /* Drawing stuff */
    GdkPixmap		      *pm_backingstore;
    cairo_surface_t	      *cs_selection;

    PangoFontMetrics	      *metrics;
};

#define COLUMN_MINIMAL_WIDTH 50.0

G_LOCK_DEFINE(PROCESS_CELLS);
G_LOCK_DEFINE(SCROLL_OFFSET);

/* Rendering Function Prototypes */
static void
cl_process_cells	      (ChromaList *chroma_list, gint *rows, guint columns); 

static void
cl_recreate_pm_backingstore   (ChromaList *chroma_list);

static void
cl_recreate_cs_selection      (ChromaList *chroma_list);

static guint
gint_count_digits (gint n)
{
    guint count = 0;

    n = ABS (n);
    do {
	count++;
	n /= 10;
    } while (n > 0);

    return count;
}

static gdouble 
pixel_width_to_percent (ChromaList	*chroma_list, 
		        gdouble		 pixel_width)
{
    gdouble  total_width;
    gdouble  width;

    total_width = GTK_WIDGET (chroma_list)->allocation.width - 
		  (chroma_list->priv->n_columns_visible*chroma_list->priv->cellspacing) -
		  chroma_list->priv->reserved_space;

    width = pixel_width / total_width; 

    return width;
}

static void 
cl_recalc_pixel_widths (ChromaList *chroma_list)
{
    gdouble   *pixel_widths;
    gdouble    total_width;
    gint       n;

    if (chroma_list->priv->pixel_widths) g_free (chroma_list->priv->pixel_widths);

    total_width  = GTK_WIDGET (chroma_list)->allocation.width - 
		   (chroma_list->priv->n_columns_visible*chroma_list->priv->cellspacing) -
		   chroma_list->priv->reserved_space;

    pixel_widths = g_new0 (gdouble, chroma_list->priv->n_columns);

    for (n = 0; n < chroma_list->priv->n_columns; n++) 
      {
	if (chroma_list->priv->column_show[n])
	    pixel_widths[n] = total_width * chroma_list->priv->column_widths[n];  
	else
	    pixel_widths[n] = 0; 
      }

    chroma_list->priv->pixel_widths = pixel_widths; 
}

void
cl_recalc_reserved_space (ChromaList *chroma_list)
{

  if (chroma_list->priv->use_numbers)
      chroma_list->priv->reserved_space = (pango_font_metrics_get_approximate_digit_width (chroma_list->priv->metrics)/PANGO_SCALE)*
				      (gint_count_digits(gtk_tree_model_iter_n_children(chroma_list->priv->model,NULL))+3);
  else
      chroma_list->priv->reserved_space = chroma_list->priv->cellspacing;
}

static void
cl_initialize_metrics (ChromaList *chroma_list)
{
    chroma_list->priv->metrics = pango_context_get_metrics (gtk_widget_get_pango_context (GTK_WIDGET (chroma_list)),
				        GTK_WIDGET (chroma_list)->style->font_desc, 
				        pango_context_get_language(gtk_widget_get_pango_context(GTK_WIDGET (chroma_list))));

    chroma_list->priv->row_height  = (pango_font_metrics_get_ascent  (chroma_list->priv->metrics)/PANGO_SCALE) + 
				(pango_font_metrics_get_descent (chroma_list->priv->metrics)/PANGO_SCALE) + 4;

    if (chroma_list->priv->show_headers)
      chroma_list->priv->header_size = chroma_list->priv->row_height + 7;
    else
      chroma_list->priv->header_size = 0; 
}

/* DnD */
static void
chroma_list_drag_end (GtkWidget	      *widget,
		      GdkDragContext  *context)

{
      CHROMA_LIST (widget)->priv->drop = FALSE;
      gtk_widget_queue_draw (widget);
}

static void
chroma_list_drag_leave (GtkWidget      *widget,
			GdkDragContext *context,
			guint	        time)
		
{
      CHROMA_LIST (widget)->priv->drop = FALSE;
      gtk_widget_queue_draw (widget);
}


static void
chroma_list_drag_data_received (GtkWidget	  *widget,
				GdkDragContext	  *context,
				gint		   x,
				gint		   y,
				GtkSelectionData   *selection_data,
				guint		   info,
				guint		   time) 
			
{
    gchar	   **uri_strv;
    gchar	    *uri_string;

    g_return_if_fail(selection_data != NULL);

    if (!selection_data->data)
      {
  	  gtk_drag_finish (context, FALSE, FALSE, time);
          return;
      }

    uri_string = g_strdup((char*)selection_data->data);
    g_strstrip (uri_string);
    uri_strv = g_uri_list_extract_uris (uri_string);
    gtk_drag_finish (context, TRUE, FALSE, time);

    g_signal_emit (G_OBJECT(widget), 
		   signals[CHROMA_LIST_SIGNAL_DND], 
		   0, 
		   CHROMA_LIST(widget)->priv->drop_row + CHROMA_LIST(widget)->priv->offset,
		   uri_strv);

}

static gboolean
chroma_list_drag_motion (GtkWidget	  *widget,
			 GdkDragContext	  *context,
			 gint		   x,
			 gint		   y,
			 guint		   time)


{
    GdkAtom target;
    gint    position;

    target = gtk_drag_dest_find_target (widget, context, NULL);
    if (target == GDK_NONE)
      {
	gdk_drag_status (context, 0, time);
	return FALSE;
      }

    CHROMA_LIST(widget)->priv->drop = TRUE;

    position = (y - CHROMA_LIST(widget)->priv->header_size) / CHROMA_LIST(widget)->priv->row_height;

    if (gtk_tree_model_iter_n_children (CHROMA_LIST(widget)->priv->model, NULL))
	{
	    if ((position+CHROMA_LIST(widget)->priv->offset) > chroma_list_get_length (CHROMA_LIST(widget)))
		 position = (chroma_list_get_length (CHROMA_LIST(widget)) - CHROMA_LIST(widget)->priv->offset);
	    CHROMA_LIST(widget)->priv->drop_row = position; 
	}
    else
	{
	    CHROMA_LIST(widget)->priv->drop_row = 0; 
	}

    gtk_widget_queue_draw (widget);

    return TRUE;
}

/* END DnD */

void
chroma_list_refresh (ChromaList *chroma_list)
{
    g_return_if_fail(CHROMA_IS_LIST(chroma_list));

    if (chroma_list_get_n_item_display (chroma_list) <= 0) return; 

    cl_recreate_pm_backingstore  (chroma_list);
    cl_recreate_cs_selection     (chroma_list);

    cl_recalc_reserved_space	 (chroma_list);
    cl_recalc_pixel_widths	 (chroma_list);
    cl_process_cells		 (chroma_list, NULL, chroma_list->priv->all_columns_mask);

    gtk_widget_queue_draw        (GTK_WIDGET (chroma_list));
}

void
chroma_list_set_font (ChromaList *chroma_list, PangoFontDescription *font_desc)
{
    g_return_if_fail(CHROMA_IS_LIST(chroma_list));

    gtk_widget_modify_font (GTK_WIDGET (chroma_list), font_desc); 
    cl_initialize_metrics (chroma_list);
    chroma_list_refresh (chroma_list);
}

void
chroma_list_set_selection_mode (ChromaList * chroma_list,
                                GtkSelectionMode selection_mode)
{
    g_return_if_fail(CHROMA_IS_LIST(chroma_list));

    if ((selection_mode != GTK_SELECTION_MULTIPLE) &&
        (selection_mode != GTK_SELECTION_SINGLE))
        return;

    chroma_list->priv->selection_mode = selection_mode;
}

void
chroma_list_set_cell_data_func (ChromaList		    *chroma_list,
				gint			     column, 
				ChromaListCellDataFunc	     cell_data_func, 
				gpointer		     data)
{
    g_return_if_fail (CHROMA_IS_LIST(chroma_list));
    g_return_if_fail (column < chroma_list->priv->n_columns);

    chroma_list->priv->cell_data_funcs[column] = cell_data_func;
    chroma_list->priv->cell_data_funcs_data[column] = data;
}

void
chroma_list_set_column_visible (ChromaList	  *chroma_list,
			        gint		   column,
			        gboolean	   visible) 
{
    g_return_if_fail (CHROMA_IS_LIST(chroma_list));
    g_return_if_fail (column < chroma_list->priv->n_columns);

    if (chroma_list->priv->column_show[column] != visible)
      {
	  chroma_list->priv->column_show[column] = visible; 
	
	  if (visible)
	    chroma_list->priv->n_columns_visible++;
	  else
	    chroma_list->priv->n_columns_visible--;
      }
}

void
chroma_list_set_column_header (ChromaList	  *chroma_list,
			       gint		   column,
			       const gchar	  *caption) 
{
    ChromaListColumn *list_column;

    g_return_if_fail (CHROMA_IS_LIST(chroma_list));
    g_return_if_fail (column < chroma_list->priv->n_columns);

    list_column = g_ptr_array_index (chroma_list->priv->columns, column);
    
    g_object_set (G_OBJECT(list_column), "name", caption, NULL);
}

void
chroma_list_set_column_show_header (ChromaList		*chroma_list, 
				    gint		 column, 
				    gboolean		 show) 
{
    ChromaListColumn *list_column;

    g_return_if_fail (CHROMA_IS_LIST(chroma_list));

    list_column = g_ptr_array_index (chroma_list->priv->columns, column);
    g_object_set (G_OBJECT(list_column), "show_name", show, NULL);
}

void
chroma_list_set_column_width (ChromaList	*chroma_list, 
			      gint		 column, 
			      gdouble		 width)
{
    g_return_if_fail (CHROMA_IS_LIST(chroma_list));

    chroma_list->priv->column_widths[column] = width; 
}

gdouble
chroma_list_get_column_width (ChromaList	*chroma_list, 
			      gint		 column)
			    
{
    g_return_val_if_fail (CHROMA_IS_LIST(chroma_list), 0.0);

    return chroma_list->priv->column_widths[column];
}

ChromaListColumn*
chroma_list_get_column (ChromaList *chroma_list, gint _idx)
{
    g_return_val_if_fail (CHROMA_IS_LIST(chroma_list), NULL);

    return g_ptr_array_index (chroma_list->priv->columns, _idx);
}

void
chroma_list_set_column_xalign (ChromaList *chroma_list, gint _idx, gdouble xalign)
{
    g_return_if_fail (CHROMA_IS_LIST(chroma_list));

    chroma_list->priv->column_xalign[_idx] = xalign;
    g_object_set (G_OBJECT(g_ptr_array_index (chroma_list->priv->columns, _idx)), "xalign", xalign, NULL);
}

void
chroma_list_set_column_yalign (ChromaList *chroma_list, gint _idx, gdouble yalign)
{
    g_return_if_fail (CHROMA_IS_LIST(chroma_list));

    chroma_list->priv->column_yalign[_idx] = yalign;
    g_object_set (G_OBJECT(g_ptr_array_index (chroma_list->priv->columns, _idx)), "yalign", yalign, NULL);
}

static void
cl_render_row (ChromaList	    *chroma_list,
	       GtkTreeIter	    *iter,
	       gint		     k,
	       guint		     r_columns)
{
    ChromaListColumn    *column;
    GValue	         value_o = {0,};
    GValue	         value = {0,};
    gint	         n, 
		         render_position;
    gint		 x, y, w, h;
    gboolean	         selected = FALSE, current = FALSE, clear = TRUE;
    cairo_t		*cr;
    double		 r, g, b, a;
    GtkTreeRowReference *reference;
    GtkTreePath		*path_c,
			*path_r;

    g_return_if_fail (CHROMA_IS_LIST(chroma_list));

    //We start rendering the real columns after the the reserved space for the list index numbers
    render_position = chroma_list->priv->reserved_space;

    //Check for row being selected or current
    reference = g_object_get_data (G_OBJECT(chroma_list->priv->model), "current");
    if (reference)
      {
	path_r = gtk_tree_model_get_path (GTK_TREE_MODEL(chroma_list->priv->model), iter);
	path_c = gtk_tree_row_reference_get_path (reference);

	if (path_r && path_c && (!gtk_tree_path_compare (path_r, path_c))) current = TRUE;
  
	if (path_r) gtk_tree_path_free (path_r);
	if (path_c) gtk_tree_path_free (path_c);
      }

    if (chroma_list_selection_iter_get_selected (CHROMA_LIST_SELECTION (chroma_list), iter)) selected = TRUE;

    //Create local cairo context
    cr = gdk_cairo_create (CHROMA_LIST(chroma_list)->priv->pm_backingstore);

    //Check for general row clear
    if (r_columns == chroma_list->priv->all_columns_mask)
      {
	    cairo_rectangle (cr, 0, 
			     k * chroma_list->priv->row_height + chroma_list->priv->header_size,
			     GTK_WIDGET(chroma_list)->allocation.width, 
			     chroma_list->priv->row_height);
	    chroma_gdk_color_to_rgba (&(GTK_WIDGET (chroma_list)->style->bg[GTK_STATE_NORMAL]), &r, &g, &b, &a);
	    cairo_set_source_rgba (cr, r, g, b, 1.0);
	    cairo_fill (cr);
	    clear = FALSE;
      }

    if (chroma_list->priv->use_numbers)
      {
	g_value_init (&value, G_TYPE_INT);  
	g_value_set_int (&value, k+1+chroma_list->priv->offset);

	if (current)
	  {
	      g_object_set (G_OBJECT(chroma_list->priv->number_column), "foreground", &(GTK_WIDGET (chroma_list)->style->fg[GTK_STATE_PRELIGHT]), NULL);
	      g_object_set (G_OBJECT(chroma_list->priv->number_column), "background", &(GTK_WIDGET (chroma_list)->style->bg[GTK_STATE_NORMAL]), NULL);
	  }
	else
	  {
	      g_object_set (G_OBJECT(chroma_list->priv->number_column), "foreground", &(GTK_WIDGET (chroma_list)->style->fg[GTK_STATE_NORMAL]), NULL);
	      g_object_set (G_OBJECT(chroma_list->priv->number_column), "background", &(GTK_WIDGET (chroma_list)->style->bg[GTK_STATE_NORMAL]), NULL);
	  }

	g_object_set (chroma_list->priv->number_column, "font", GTK_WIDGET (chroma_list)->style->font_desc, NULL);
	g_object_set (chroma_list->priv->number_column, "row_height", chroma_list->priv->row_height, NULL);

	g_object_set (G_OBJECT(chroma_list->priv->number_column), "xalign", 1.0, NULL);
	g_object_set (G_OBJECT(chroma_list->priv->number_column), "yalign", 0.5, NULL);

	chroma_list_column_cell_render (chroma_list->priv->number_column,
					GTK_WIDGET (chroma_list),
					&value,	
					CHROMA_LIST(chroma_list)->priv->pm_backingstore,
					chroma_list->priv->reserved_space,
					0, k*chroma_list->priv->row_height + chroma_list->priv->header_size);

	if ((selected) && !(r_columns == chroma_list->priv->all_columns_mask))
	  {
	    cairo_set_source_surface (cr, chroma_list->priv->cs_selection, 0, k*chroma_list->priv->row_height + chroma_list->priv->header_size + 1);
	    cairo_rectangle (cr, 0, 
				 k*chroma_list->priv->row_height + chroma_list->priv->header_size + 1, 
				 chroma_list->priv->reserved_space, 
				 chroma_list->priv->row_height);
	    cairo_fill (cr);
	  }

	g_value_unset (&value);
      }

    /* First let the columns render the TreeModel data */
    for (n = 0; n < chroma_list->priv->n_columns; n++) 
      {
	if (!chroma_list->priv->column_show[n]) continue;
	if (!(r_columns & (1 << n))) goto RENDER_END; 

	//Clear cell background
	if (clear)
	  {
	    cairo_rectangle (cr, render_position, 
			     k * chroma_list->priv->row_height + chroma_list->priv->header_size,
			     chroma_list->priv->pixel_widths[n] + chroma_list->priv->cellspacing, 
			     chroma_list->priv->row_height);
	    chroma_gdk_color_to_rgba (&(GTK_WIDGET (chroma_list)->style->bg[GTK_STATE_NORMAL]), &r, &g, &b, &a);
	    cairo_set_source_rgba (cr, r, g, b, 1.0);
	    cairo_fill (cr);
	  }

	gtk_tree_model_get_value        (chroma_list->priv->model,
                                         iter, 
                                         n, 
                                         &value_o); 

	g_value_init (&value, G_VALUE_TYPE(&value_o));
	g_value_copy (&value_o, &value);
	g_value_unset (&value_o);

	if (chroma_list->priv->cell_data_funcs[n])
	  {
	    chroma_list->priv->cell_data_funcs[n](chroma_list,
					      chroma_list->priv->model,
					      iter,
					      &value,
					      chroma_list->priv->cell_data_funcs_data[n]);
	  }

	column = g_ptr_array_index (chroma_list->priv->columns, n);

	if (current)
	  {
	      g_object_set (G_OBJECT(column), "foreground", &(GTK_WIDGET (chroma_list)->style->fg[GTK_STATE_PRELIGHT]), NULL);
	      g_object_set (G_OBJECT(column), "background", &(GTK_WIDGET (chroma_list)->style->bg[GTK_STATE_NORMAL]), NULL);
	  }
	else
	  {
	      g_object_set (G_OBJECT(column), "foreground", &(GTK_WIDGET (chroma_list)->style->fg[GTK_STATE_NORMAL]), NULL);
	      g_object_set (G_OBJECT(column), "background", &(GTK_WIDGET (chroma_list)->style->bg[GTK_STATE_NORMAL]), NULL);
	  }

	g_object_set (G_OBJECT(column), "font", GTK_WIDGET (chroma_list)->style->font_desc, NULL);
	g_object_set (G_OBJECT(column), "row_height", chroma_list->priv->row_height, NULL);

	chroma_list_column_cell_render (column,
					GTK_WIDGET (chroma_list),
					&value,
					CHROMA_LIST(chroma_list)->priv->pm_backingstore,
					chroma_list->priv->pixel_widths[n], // space allowed to render within	
					render_position, 
					k*chroma_list->priv->row_height + chroma_list->priv->header_size);

	g_value_unset (&value);

	if ((selected) && !(r_columns == chroma_list->priv->all_columns_mask))
	  {
	    cairo_set_source_surface (cr, chroma_list->priv->cs_selection, 0, k*chroma_list->priv->row_height + chroma_list->priv->header_size + 1);
	    cairo_rectangle (cr, render_position, 
				 k*chroma_list->priv->row_height + chroma_list->priv->header_size + 1, 
				 chroma_list->priv->pixel_widths[n] + chroma_list->priv->cellspacing, 
				 chroma_list->priv->row_height);
	    cairo_fill (cr);
	  }

	RENDER_END:
	render_position += (chroma_list->priv->pixel_widths[n] + chroma_list->priv->cellspacing); 
      }

    if (selected && (r_columns == chroma_list->priv->all_columns_mask))
      {
	    cairo_set_source_surface (cr, chroma_list->priv->cs_selection, 0, k*chroma_list->priv->row_height + chroma_list->priv->header_size + 1);
	    cairo_rectangle (cr, 0,
				 k*chroma_list->priv->row_height + chroma_list->priv->header_size + 1, 
				 GTK_WIDGET(chroma_list)->allocation.width,
				 chroma_list->priv->row_height);
	    cairo_fill (cr);
      }

    cairo_destroy (cr);

    x = 0; 
    w = GTK_WIDGET(chroma_list)->allocation.width; 
    y = CHROMA_LIST(chroma_list)->priv->header_size + (CHROMA_LIST(chroma_list)->priv->row_height * k);
    h = CHROMA_LIST(chroma_list)->priv->row_height; 

    gtk_widget_queue_draw_area (GTK_WIDGET(chroma_list),
				      x, y,
				      w, h);
    gdk_flush ();
}

static void
cl_process_cells (ChromaList	    *chroma_list,
		  gint		    *rows,
		  guint		     columns)
{
    GtkTreePath  *path;
    GtkTreeIter   iter;
    gint          n; 
	
    G_LOCK (PROCESS_CELLS);

    if (rows)
	  {
	    for (n = 0; rows[n] != NONE; n++)
	      {
		if ((rows[n] - chroma_list->priv->offset) >= chroma_list_get_n_item_display (chroma_list)) continue;

		path = gtk_tree_path_new_from_indices (rows[n], -1);
		if (path && gtk_tree_model_get_iter (chroma_list->priv->model, &iter, path))
		  {
		    gtk_tree_path_free (path);

		    cl_render_row (chroma_list, 
				   &iter,
				   rows[n] - chroma_list->priv->offset,
				   columns);

		  }
	      }

	      g_free (rows);
	  }
    else 
	  {
	    path = gtk_tree_path_new_from_indices (chroma_list->priv->offset, -1);
	    if (path && gtk_tree_model_get_iter (chroma_list->priv->model, &iter, path))
	      {
		gtk_tree_path_free (path);
		for (n = 0; n < (chroma_list_get_n_item_display(chroma_list)); n++)
		  {
		    cl_render_row (chroma_list, 
				&iter,
				n,
			        columns);

		    if (!gtk_tree_model_iter_next (chroma_list->priv->model, &iter)) break;
		  }
	      }
	  }

  G_UNLOCK (PROCESS_CELLS);
}

static void
cl_recreate_cs_selection (ChromaList *chroma_list)
{
    cairo_t *cr;
    cairo_pattern_t *cr_pattern;
    double r,g,b,a;

    if (chroma_list->priv->cs_selection) cairo_surface_destroy (chroma_list->priv->cs_selection);

    chroma_list->priv->cs_selection = 
	cairo_image_surface_create (CAIRO_FORMAT_ARGB32,
				    GTK_WIDGET(chroma_list)->allocation.width - 1,
				    chroma_list->priv->row_height);

    cr = cairo_create (chroma_list->priv->cs_selection); 

    //Clear background
    cairo_save (cr); 
    cairo_set_operator (cr, CAIRO_OPERATOR_CLEAR);
    cairo_paint (cr);
    cairo_restore (cr);

    //Create selection bar
    chroma_gdk_color_to_rgba (&(GTK_WIDGET (chroma_list)->style->fg[GTK_STATE_PRELIGHT]), &r, &g, &b, &a);
    cr_pattern = cairo_pattern_create_linear (0,
					      chroma_list->priv->row_height/2,
					      GTK_WIDGET (chroma_list)->allocation.width - 1,
					      chroma_list->priv->row_height/2);

    cairo_pattern_add_color_stop_rgba (cr_pattern, 0.0, r, g, b, 0.4);
    cairo_pattern_add_color_stop_rgba (cr_pattern, 0.3, r, g, b, 0.28);
    cairo_pattern_add_color_stop_rgba (cr_pattern, 0.6, r, g, b, 0.20);
    cairo_pattern_add_color_stop_rgba (cr_pattern, 1.0, r, g, b, 0.15);

    cairo_pattern_set_filter (cr_pattern, CAIRO_FILTER_BILINEAR);

    chroma_draw_rounded_rectangle_pattern (cr,
                        4, 0, 
                        GTK_WIDGET (chroma_list)->allocation.width-(2*chroma_list->priv->cellspacing-1) - 1, chroma_list->priv->row_height-2.5,
                        cr_pattern,
                        0.8,
                        TRUE,
                        4.5);

#if 0
    draw_rounded_rectangle_aqua (cr,
                        4, 0, 
                        GTK_WIDGET (chroma_list)->allocation.width-(2*chroma_list->priv->cellspacing-1) - 1, chroma_list->priv->row_height-2,
			&(GTK_WIDGET (chroma_list)->style->fg[GTK_STATE_PRELIGHT]),
                        0.2,
			1.0,
                        TRUE,
                        4.5);
#endif

    chroma_draw_rounded_rectangle (cr,
                        4, 0, 
                        GTK_WIDGET (chroma_list)->allocation.width-(2*chroma_list->priv->cellspacing-1) - 1, chroma_list->priv->row_height-2,
			&(GTK_WIDGET (chroma_list)->style->fg[GTK_STATE_PRELIGHT]),
                        0.5,
			1.0,
                        FALSE,
                        4.5);

    cairo_surface_reference (chroma_list->priv->cs_selection);
    cairo_pattern_destroy (cr_pattern);
    cairo_destroy (cr);
}

static void
cl_recreate_pm_backingstore (ChromaList *chroma_list)
{
    if (!GTK_WIDGET_REALIZED(GTK_WIDGET (chroma_list))) return;

    if (chroma_list->priv->pm_backingstore)
      {
        gdk_drawable_unref (chroma_list->priv->pm_backingstore);
	chroma_list->priv->pm_backingstore = NULL;
      }

    if (chroma_list->priv->model)
      {
	if ((GTK_WIDGET (chroma_list)->allocation.width > 0) && (GTK_WIDGET (chroma_list)->allocation.height > 0))
          {
	    chroma_list->priv->pm_backingstore = gdk_pixmap_new (gtk_widget_get_parent (GTK_WIDGET (chroma_list))->window,
					   GTK_WIDGET (chroma_list)->allocation.width,
					   GTK_WIDGET (chroma_list)->allocation.height,
					   gdk_drawable_get_depth (gtk_widget_get_parent(GTK_WIDGET (chroma_list))->window));

	    gdk_draw_rectangle (chroma_list->priv->pm_backingstore,
			GTK_WIDGET (chroma_list)->style->bg_gc[GTK_STATE_NORMAL],	
			TRUE,
			0, 0,
			GTK_WIDGET (chroma_list)->allocation.width,
			GTK_WIDGET (chroma_list)->allocation.height);
	  }
      }
}

static gboolean
chroma_list_configure (GtkWidget		*widget,
		       GdkEventConfigure	*event)
{
  ChromaList *chroma_list = CHROMA_LIST(widget);  
  gdouble     size;

  if (chroma_list->priv->adjustment && 
      (chroma_list_get_n_item_display(chroma_list) != 0) && 
      (chroma_list_get_length(chroma_list) != 0))
    {
	size = (gdouble)chroma_list_get_length (chroma_list)/(gdouble)chroma_list_get_n_item_display (chroma_list);
	chroma_vscrollbar_set_grip_size (chroma_list->priv->adjustment, size); 
    }

  if (chroma_list_get_n_item_display (chroma_list) >= gtk_tree_model_iter_n_children (chroma_list->priv->model, NULL))
    {
	chroma_list->priv->offset = 0;
    }

  chroma_list_refresh (chroma_list);
  return FALSE;
}

GtkWidget*
chroma_list_new (void)
{
    ChromaList *chroma_list;

    chroma_list = g_object_new(chroma_list_get_type(), NULL);

    return GTK_WIDGET (chroma_list);
}

static gboolean
chroma_list_button_release (GtkWidget	      *widget, 
			    GdkEventButton    *event) 

{
    ChromaList	*chroma_list = CHROMA_LIST(widget);

    chroma_list->priv->active_row_drag = FALSE;
    chroma_list->priv->active_column_resize = FALSE;
    chroma_list->priv->grabbed_position = NONE;

    gdk_window_set_cursor (widget->window, NULL);

    return FALSE;
}

static gboolean
chroma_list_key_press	    (GtkWidget		  *widget,
			     GdkEventKey	  *event)
{
    ChromaList *chroma_list = CHROMA_LIST(widget);

    g_return_val_if_fail (GTK_IS_WIDGET (widget), FALSE);
    g_return_val_if_fail (CHROMA_IS_LIST (widget), FALSE);

    chroma_list = CHROMA_LIST(widget);

    if (!chroma_list->priv->last_pressed_row)
      {
	  GtkTreePath *path;

	  path = gtk_tree_path_new_from_indices (0, -1);
	  chroma_list->priv->last_pressed_row = gtk_tree_row_reference_new (chroma_list->priv->model, path);
	  chroma_list_selection_path_set_selected (CHROMA_LIST_SELECTION(widget), path, TRUE);
	  gtk_tree_path_free (path);
	  return FALSE;
      }

    switch (event->keyval)
    {
            case GDK_Return:
            case GDK_KP_Enter:
            {
	      if (chroma_list->priv->last_pressed_row)
		{
		    GtkTreePath	     *path;

		    path = gtk_tree_row_reference_get_path (chroma_list->priv->last_pressed_row);
		    if (path)
		      {
			  gint position;

			  position = gtk_tree_path_get_indices (path)[0];
			  gtk_tree_path_free (path);
			  g_signal_emit (chroma_list, signals[CHROMA_LIST_SIGNAL_ROW_ACTIVATED], 0, position);
		      }
		}
            }
            break;

	    case GDK_Page_Up:
	    {
		  GtkTreePath *path;
		  GtkTreeIter  iter;
		  gint	       position = chroma_list->priv->offset;

		  position -= chroma_list_get_n_item_display (chroma_list);

		  position = (position < 0) ? 0 : position;

		  chroma_list_scroll_to_offset (chroma_list, position); 
		  chroma_list_selection_unselect_all (CHROMA_LIST_SELECTION(widget));	

		  path = gtk_tree_path_new_from_indices (position, -1);
		  gtk_tree_row_reference_free (chroma_list->priv->last_pressed_row);
		  chroma_list->priv->last_pressed_row = gtk_tree_row_reference_new (chroma_list->priv->model, path);
		  gtk_tree_model_get_iter (chroma_list->priv->model, &iter, path);

		  chroma_list_selection_iter_set_selected (CHROMA_LIST_SELECTION(chroma_list), &iter, TRUE);
		  gtk_tree_path_free (path);

		  g_signal_emit (chroma_list, signals[CHROMA_LIST_SIGNAL_CURSOR_POSITION], 0, position); 
	    }
	    break;

	    case GDK_Page_Down:
	    {
		  GtkTreePath *path;
		  GtkTreeIter  iter;
		  gint	       position = chroma_list->priv->offset;

		  position += chroma_list_get_n_item_display (chroma_list);

		  position = (position > (chroma_list_get_length(chroma_list)-chroma_list_get_n_item_display(chroma_list))) ? 
		       (chroma_list_get_length(chroma_list)-chroma_list_get_n_item_display(chroma_list))
		     : position;

		  chroma_list_scroll_to_offset (chroma_list, position); 
		  chroma_list_selection_unselect_all (CHROMA_LIST_SELECTION(widget));	

		  path = gtk_tree_path_new_from_indices (position, -1);
		  gtk_tree_row_reference_free (chroma_list->priv->last_pressed_row);
		  chroma_list->priv->last_pressed_row = gtk_tree_row_reference_new (chroma_list->priv->model, path);
		  gtk_tree_model_get_iter (chroma_list->priv->model, &iter, path);

		  chroma_list_selection_iter_set_selected (CHROMA_LIST_SELECTION(chroma_list), &iter, TRUE);
		  gtk_tree_path_free (path);

		  g_signal_emit (chroma_list, signals[CHROMA_LIST_SIGNAL_CURSOR_POSITION], 0, position); 
	    }
	    break;

	    case GDK_Home:
	    {
		  GtkTreePath *path;
		  GtkTreeIter  iter;
		  gint	       position = 0;

		  chroma_list_scroll_to_offset (chroma_list, position); 
		  chroma_list_selection_unselect_all (CHROMA_LIST_SELECTION(widget));	

		  path = gtk_tree_path_new_from_indices (position, -1);
		  gtk_tree_row_reference_free (chroma_list->priv->last_pressed_row);
		  chroma_list->priv->last_pressed_row = gtk_tree_row_reference_new (chroma_list->priv->model, path);
		  gtk_tree_model_get_iter (chroma_list->priv->model, &iter, path);

		  chroma_list_selection_iter_set_selected (CHROMA_LIST_SELECTION(chroma_list), &iter, TRUE);
		  gtk_tree_path_free (path);

		  g_signal_emit (chroma_list, signals[CHROMA_LIST_SIGNAL_CURSOR_POSITION], 0, position); 
	    }
	    break;

	    case GDK_End:
	    {
		  GtkTreePath *path;
		  GtkTreeIter  iter;
		  gint	       position = chroma_list_get_length (chroma_list)-1;

		  chroma_list_scroll_to_offset (chroma_list, chroma_list_get_length(chroma_list)-chroma_list_get_n_item_display(chroma_list)); 
		  chroma_list_selection_unselect_all (CHROMA_LIST_SELECTION(widget));	

		  path = gtk_tree_path_new_from_indices (position, -1);
		  gtk_tree_row_reference_free (chroma_list->priv->last_pressed_row);
		  chroma_list->priv->last_pressed_row = gtk_tree_row_reference_new (chroma_list->priv->model, path);
		  gtk_tree_model_get_iter (chroma_list->priv->model, &iter, path);

		  chroma_list_selection_iter_set_selected (CHROMA_LIST_SELECTION(chroma_list), &iter, TRUE);
		  gtk_tree_path_free (path);
	    }
	    break;

            case GDK_Up:
            {
	      gboolean multiple;
	      multiple = chroma_list_selection_multiple_selected (CHROMA_LIST_SELECTION(chroma_list)); 
   
	      if (chroma_list->priv->last_pressed_row)
		{
		    GtkTreePath	     *path;
		    GtkTreeIter	      iter;
		    gint	      position;

		    path = gtk_tree_row_reference_get_path (chroma_list->priv->last_pressed_row);
		    if (path)
		      {
			  position = gtk_tree_path_get_indices (path)[0] - 1;

			  if (position < 0)
			    {
			      gtk_tree_path_free (path);
			      return FALSE;
			    }

			  if (position < chroma_list->priv->offset)
			    {
				  chroma_list_scroll_to_offset (chroma_list, chroma_list->priv->offset-1);
			    }

			  if (!(event->state & GDK_SHIFT_MASK)) chroma_list_selection_unselect_all (CHROMA_LIST_SELECTION(widget));	
			  gtk_tree_path_free (path);
			  path = gtk_tree_path_new_from_indices (position, -1);
			  gtk_tree_row_reference_free (chroma_list->priv->last_pressed_row);
			  chroma_list->priv->last_pressed_row = gtk_tree_row_reference_new (chroma_list->priv->model, path);
			  gtk_tree_model_get_iter (chroma_list->priv->model, &iter, path);
			  chroma_list_selection_iter_set_selected (CHROMA_LIST_SELECTION(chroma_list), &iter, TRUE);
			  gtk_tree_path_free (path);
			  if (!(event->state & GDK_SHIFT_MASK))
			    {
			      g_signal_emit (chroma_list, signals[CHROMA_LIST_SIGNAL_CURSOR_POSITION], 0, position);
			    }
			  else
			    {
			      g_signal_emit (chroma_list, signals[CHROMA_LIST_SIGNAL_CURSOR_POSITION], 0, -1);
			    }
		      }
		}
            }
            break;

	    case GDK_Down:
	    {
	      gboolean multiple;
	      multiple = chroma_list_selection_multiple_selected (CHROMA_LIST_SELECTION(chroma_list)); 
 
	      if (chroma_list->priv->last_pressed_row)
		{
		    GtkTreePath	     *path;
		    GtkTreeIter	      iter;
		    gint	      position;

		    path = gtk_tree_row_reference_get_path (chroma_list->priv->last_pressed_row);
		    if (path)
		      {
			  gint max;
  
			  max = chroma_list_get_n_item_display (chroma_list)-1;
			  if ((chroma_list_get_length (chroma_list)-1) < max) max = (chroma_list_get_length (chroma_list)-1);
  
			  position = gtk_tree_path_get_indices (path)[0] + 1;

			  if (position > (chroma_list_get_length (chroma_list)-1))
			    {
				gtk_tree_path_free (path);
				return FALSE;
			    }

			  if (position > (chroma_list->priv->offset+max))
			    {
				  chroma_list_scroll_to_offset (chroma_list, chroma_list->priv->offset+1);
			    }

			  if (!(event->state & GDK_SHIFT_MASK)) chroma_list_selection_unselect_all (CHROMA_LIST_SELECTION(widget));	
			  gtk_tree_path_free (path);
			  path = gtk_tree_path_new_from_indices (position, - 1);
			  gtk_tree_row_reference_free (chroma_list->priv->last_pressed_row);
			  chroma_list->priv->last_pressed_row = gtk_tree_row_reference_new (chroma_list->priv->model, path);
			  gtk_tree_model_get_iter (chroma_list->priv->model, &iter, path);
			  chroma_list_selection_iter_set_selected (CHROMA_LIST_SELECTION(chroma_list), &iter, TRUE);
			  gtk_tree_path_free (path);
			  if (!(event->state & GDK_SHIFT_MASK))
			    {
			      g_signal_emit (chroma_list, signals[CHROMA_LIST_SIGNAL_CURSOR_POSITION], 0, position);
			    }
			  else
			    {
			      g_signal_emit (chroma_list, signals[CHROMA_LIST_SIGNAL_CURSOR_POSITION], 0, -1);
			    }
		      }
		}
	    }
	    break;
  
	  default: break;

      }

      return FALSE;
}

#define SINGLE_CLICK (event->type == GDK_BUTTON_PRESS)
#define DOUBLE_CLICK (event->type == GDK_2BUTTON_PRESS)

#define BUTTON_LEFT  (event->button == 1)
#define BUTTON_RIGHT (event->button == 3)

#define INSIDE_ROWS (event->y > chroma_list->priv->header_size)
#define INSIDE_HEADERS (event->y <= chroma_list->priv->header_size)

#define RESIZE_POSITION (chroma_list->priv->resize_position != NONE)

static gboolean
chroma_list_button_press (GtkWidget	  *widget,
			  GdkEventButton  *event)
{
    ChromaList *chroma_list = CHROMA_LIST(widget);

    g_return_val_if_fail(CHROMA_IS_LIST(chroma_list), FALSE);

    if (!chroma_list->priv->model) return FALSE;

    if (BUTTON_LEFT && INSIDE_HEADERS && SINGLE_CLICK && RESIZE_POSITION)
      {
	  chroma_list->priv->active_column_resize = TRUE;
	  return TRUE;
      }

    if (BUTTON_LEFT && INSIDE_ROWS && DOUBLE_CLICK && !RESIZE_POSITION)
      {
	  gint row;

	  row = ((event->y - chroma_list->priv->header_size) / chroma_list->priv->row_height) + chroma_list->priv->offset;
	  if (row > (chroma_list_get_length (chroma_list)-1)) return FALSE;

	  if (!(event->state & GDK_SHIFT_MASK) && !(event->state & GDK_CONTROL_MASK)) 
	    {
	      g_signal_emit (chroma_list, signals[CHROMA_LIST_SIGNAL_CURSOR_POSITION], 0, row);
	      g_signal_emit (chroma_list, signals[CHROMA_LIST_SIGNAL_ROW_ACTIVATED], 0, row);
	    }

	  return FALSE;
      }

    if (BUTTON_LEFT && INSIDE_ROWS && SINGLE_CLICK && !RESIZE_POSITION)
      {
	  GtkTreePath *path;
	  GtkTreeIter  iter;
	  gint row;

	  row = ((event->y - chroma_list->priv->header_size) / chroma_list->priv->row_height) + chroma_list->priv->offset;
	  if (row > (chroma_list_get_length (chroma_list)-1)) return FALSE;

	  path = gtk_tree_path_new_from_indices (row, -1);
	  gtk_tree_model_get_iter (chroma_list->priv->model, &iter, path);
	  gtk_tree_path_free (path);
  
	  chroma_list->priv->active_row_drag = TRUE;
	  chroma_list->priv->grabbed_position = row;

	  if (!(event->state & GDK_SHIFT_MASK) && !(event->state & GDK_CONTROL_MASK)) 
	    {
	      GtkTreePath *path;
	      gint	   n; 
	      gboolean	   multiple;
 
	      n = 0;
	      multiple = (g_list_length (chroma_list->priv->selected_rows)>1) ? TRUE : FALSE;
 
	      chroma_list_selection_unselect_all (CHROMA_LIST_SELECTION(chroma_list));	
	      chroma_list_selection_iter_set_selected (CHROMA_LIST_SELECTION(chroma_list), &iter, TRUE); 

	      gtk_tree_row_reference_free (chroma_list->priv->last_pressed_row);
	      path = gtk_tree_model_get_path (chroma_list->priv->model, &iter);
	      chroma_list->priv->last_pressed_row = gtk_tree_row_reference_new (chroma_list->priv->model, path); 
	      gtk_tree_path_free (path);
	      g_signal_emit (chroma_list, signals[CHROMA_LIST_SIGNAL_CURSOR_POSITION], 0, row);
	    }
	  else
	  if ((event->state & GDK_CONTROL_MASK) == GDK_CONTROL_MASK)
	    {
	      gboolean selected = chroma_list_selection_iter_get_selected(CHROMA_LIST_SELECTION(chroma_list), &iter);
	      chroma_list_selection_iter_set_selected (CHROMA_LIST_SELECTION(chroma_list), &iter, !selected);

	      gtk_tree_row_reference_free (chroma_list->priv->last_pressed_row);
	      path = gtk_tree_model_get_path (chroma_list->priv->model, &iter);
	      if (!selected)
		{
		  chroma_list->priv->last_pressed_row = gtk_tree_row_reference_new (chroma_list->priv->model, path); 
		}
	      else
		{
		  chroma_list->priv->last_pressed_row = NULL;
		}
	      gtk_tree_path_free (path);

	      g_signal_emit (chroma_list, signals[CHROMA_LIST_SIGNAL_CURSOR_POSITION], 0, row);
	    }
	  if ((event->state & GDK_SHIFT_MASK) == GDK_SHIFT_MASK)
	    {
	      GtkTreePath *path;
	      gint last_pressed_row;

	      if (!chroma_list->priv->last_pressed_row) return FALSE;

	      path = gtk_tree_row_reference_get_path (chroma_list->priv->last_pressed_row);
	      if (path)
		{
		  last_pressed_row = gtk_tree_path_get_indices (path)[0];
		  gtk_tree_path_free (path);
		}
	      else
		{
		  last_pressed_row = 0;
		}
	    
	      if (row < last_pressed_row) 
		{
		    GtkTreePath *path_l;
		    GtkTreeIter  iter_l;
		    gint n;
  
		    for (n = row; n <= last_pressed_row; n++)
		      {
			  path_l = gtk_tree_path_new_from_indices (n, -1);
			  gtk_tree_model_get_iter (chroma_list->priv->model, &iter_l, path_l);
		  	  gtk_tree_path_free (path_l);
  
			  chroma_list_selection_iter_set_selected (CHROMA_LIST_SELECTION(chroma_list), &iter_l, TRUE); 
		      }

		    g_signal_emit (chroma_list, signals[CHROMA_LIST_SIGNAL_CURSOR_POSITION], 0, n-1);
		}
	      else
	      if (row > last_pressed_row)
		{
		    GtkTreePath *path_l;
		    GtkTreeIter  iter_l;
		    gint n;
  
		    for (n = last_pressed_row; n <= row; n++)
		      {
			  path_l = gtk_tree_path_new_from_indices (n, -1);
			  gtk_tree_model_get_iter (chroma_list->priv->model, &iter_l, path_l);
		  	  gtk_tree_path_free (path_l);
  
			  chroma_list_selection_iter_set_selected (CHROMA_LIST_SELECTION(chroma_list), &iter_l, TRUE); 
		      }

		    g_signal_emit (chroma_list, signals[CHROMA_LIST_SIGNAL_CURSOR_POSITION], 0, n-1);
		}
	    }

	  return FALSE;
      }

    if (BUTTON_LEFT && INSIDE_HEADERS && GTK_IS_TREE_SORTABLE(chroma_list->priv->model))
      {
	gdouble x;
	gint    n;

	x = chroma_list->priv->reserved_space;

	for (n = 0; n < chroma_list->priv->n_columns; n ++)
	  {
	    if ((event->x >= x) &&
	        (event->x <  x+chroma_list->priv->pixel_widths[n]))
	      {
		  GtkSortType sort_type;
		  gint col;

		  if (chroma_list->priv->sort_column_id == n)
		    {
			chroma_list->priv->sort_trigger++;
			sort_type = (chroma_list->priv->sort_type == GTK_SORT_ASCENDING) ? GTK_SORT_DESCENDING : GTK_SORT_ASCENDING;
			col = n;
		    }
		  else
		    {
			chroma_list->priv->sort_trigger = 0;
			sort_type = GTK_SORT_ASCENDING;
			col = n;
		    }

		  if (chroma_list->priv->sort_trigger == 2)
		    {
			chroma_list->priv->sort_trigger = 0;
			sort_type = GTK_SORT_ASCENDING;
			col = GTK_TREE_SORTABLE_UNSORTED_SORT_COLUMN_ID;

		    	gtk_tree_sortable_set_sort_column_id (GTK_TREE_SORTABLE(chroma_list->priv->model),
						        chroma_list->priv->sort_column_id,
							GTK_SORT_ASCENDING);
		    }

		  gtk_tree_sortable_set_sort_column_id (GTK_TREE_SORTABLE(chroma_list->priv->model),
						        col,
							sort_type);

		  return FALSE;
	      }
	    x += chroma_list->priv->pixel_widths[n] + chroma_list->priv->cellspacing;
	  }
      }

    return FALSE;
}

void
chroma_list_scroll_up	    (ChromaList		  *chroma_list)
{
    chroma_list_scroll_to_offset (chroma_list, chroma_list->priv->offset - chroma_list->priv->scroll_step); 
}

void
chroma_list_scroll_down     (ChromaList		  *chroma_list)
{
    chroma_list_scroll_to_offset (chroma_list, chroma_list->priv->offset + chroma_list->priv->scroll_step); 
}


static gboolean
chroma_list_scroll	    (GtkWidget		  *widget,
			     GdkEventScroll	  *event)
{
    ChromaList	  *chroma_list = CHROMA_LIST (widget);

    g_return_val_if_fail (GTK_IS_WIDGET(widget), FALSE);
    g_return_val_if_fail (CHROMA_IS_LIST(chroma_list), FALSE);

    if (event->direction == GDK_SCROLL_DOWN)
      {
	chroma_list_scroll_down (chroma_list);
      }
    else
    if (event->direction == GDK_SCROLL_UP)
      {
	chroma_list_scroll_up   (chroma_list);
      }

    return FALSE;
}

G_LOCK_DEFINE(MOVE_ROWS);

static gboolean
scroll_list (ChromaList *chroma_list)
{
    switch (chroma_list->priv->scroll_direction)
      {
	  case SCROLL_DIRECTION_UP:
	    {
	      gint	   position;

	      position = chroma_list->priv->offset - 1;
	      if (position < 0)
		{
		  chroma_list->priv->scroll_timeout_source_id = 0;
		  return FALSE;
		}

	      chroma_list->priv->model_row_swap_func (chroma_list->priv->model,
						      chroma_list->priv->grabbed_position,
						      position);
	      chroma_list->priv->grabbed_position = position;
	      chroma_list_scroll_to_offset (chroma_list, position);
	      break;
	    }

	  case SCROLL_DIRECTION_DOWN:
	    {
	      break;
	    }

      }

    return TRUE;
}

static void
destroy_scroll_source (ChromaList *chroma_list)
{
    //Destroy the scrolling source
    GSource *source;

    if (chroma_list->priv->scroll_timeout_source_id > 0)
      {
	  source = g_main_context_find_source_by_id (NULL, chroma_list->priv->scroll_timeout_source_id);
	  g_source_destroy (source);
	  chroma_list->priv->scroll_timeout_source_id = 0;
      }
}

static gboolean
chroma_list_motion (GtkWidget	    *widget,
		    GdkEventMotion  *event)

{
    ChromaList	     *chroma_list = CHROMA_LIST(widget);

    gint	      x, y;
    GdkModifierType   state;

    g_return_val_if_fail(CHROMA_IS_LIST(chroma_list), FALSE);

    if (!chroma_list->priv->model)
	return FALSE;

    if (event->is_hint)
      {
	gdk_window_get_pointer (event->window, &x, &y, &state);
      }
    else
      {
	x = event->x;
	y = event->y;
	state = event->state;
      }

    if ((chroma_list->priv->resize_position != NONE) && 
	(y > chroma_list->priv->header_size))
      {
	  chroma_list->priv->resize_position = NONE; 
	  gdk_window_set_cursor (widget->window, NULL);
	  return FALSE;
      }

    //Column resize
    if (chroma_list->priv->active_column_resize)
      {
	  gint    pixel_width_l,
		  pixel_width_r;

	  gdouble column_width_l,
		  column_width_r;

	  gint    delta;
	  gint    l = chroma_list->priv->adjactent_l;
	  gint    r = chroma_list->priv->adjactent_r;

	  guint   columns = 0;

	  delta = x - chroma_list->priv->resize_position;
  
	  if (delta > 0)
	    {
                  pixel_width_l  = chroma_list->priv->pixel_widths[l];
                  pixel_width_r  = chroma_list->priv->pixel_widths[r];

                  pixel_width_l += delta;
                  pixel_width_r -= delta;

                  column_width_l = pixel_width_to_percent (chroma_list, pixel_width_l);
                  column_width_r = pixel_width_to_percent (chroma_list, pixel_width_r);

		  if (pixel_width_r > COLUMN_MINIMAL_WIDTH)
		    {
			chroma_list->priv->column_widths[l] = column_width_l;
			chroma_list->priv->column_widths[r] = column_width_r;

			chroma_list->priv->pixel_widths[l] = pixel_width_l;
			chroma_list->priv->pixel_widths[r] = pixel_width_r;

			columns |= 1 << l;
			columns |= 1 << r;
			goto EXIT_LOOP;    	
		    }
	    }
	  else if (delta < 0)
	    {
                  pixel_width_l   = chroma_list->priv->pixel_widths[l];
                  pixel_width_r   = chroma_list->priv->pixel_widths[r];

                  pixel_width_l  += delta;
                  pixel_width_r  -= delta;

                  column_width_l  = pixel_width_to_percent (chroma_list, pixel_width_l);
                  column_width_r  = pixel_width_to_percent (chroma_list, pixel_width_r);

		  if (pixel_width_l > COLUMN_MINIMAL_WIDTH)
		    {
			chroma_list->priv->column_widths[l] = column_width_l;
			chroma_list->priv->column_widths[r] = column_width_r;

			chroma_list->priv->pixel_widths[l] = pixel_width_l;
			chroma_list->priv->pixel_widths[r] = pixel_width_r;

			columns |= 1 << l;
			columns |= 1 << r;
			goto EXIT_LOOP;    	
		    }
	    }
  
	  return FALSE;

	  EXIT_LOOP:	  
	  chroma_list->priv->resize_position = x; 
	  cl_process_cells (chroma_list, NULL, columns);
	  gtk_widget_queue_draw (GTK_WIDGET (chroma_list));
	  return FALSE;
      }

    //Row drag is active
    if (chroma_list->priv->active_row_drag)
      {
	gint  position,
	      position_max;

	G_LOCK(MOVE_ROWS);

	position = ((y - chroma_list->priv->header_size) / chroma_list->priv->row_height) + chroma_list->priv->offset;
	if (position < 0)
	  {
	    destroy_scroll_source (chroma_list);
	    return FALSE;
	  }

	position_max = chroma_list_get_n_item_display (chroma_list) + chroma_list->priv->offset - 1;
	if (position_max > (chroma_list_get_length (chroma_list)-1)) position_max = chroma_list_get_length (chroma_list)-1;
	if (position > position_max) 
	  {
	    G_UNLOCK(MOVE_ROWS);
	    return FALSE;
	  }

        if (!(chroma_list->priv->grabbed_position - position))
	  {
	    G_UNLOCK(MOVE_ROWS);
	    return FALSE;
	  } 
  
	if (position < chroma_list->priv->offset)
	  {
	    chroma_list_scroll_to_offset (chroma_list, chroma_list->priv->offset - 1);
	    chroma_list->priv->scroll_timeout_source_id =
		g_timeout_add_full (G_PRIORITY_HIGH_IDLE+20, 100, (GSourceFunc) scroll_list, chroma_list, NULL);
	    chroma_list->priv->scroll_direction = SCROLL_DIRECTION_UP;
	  }
	else
	  {
	    destroy_scroll_source (chroma_list);
	  }

	if ((position - chroma_list->priv->offset) > (chroma_list_get_n_item_display (chroma_list)-1)) 
	  {
	    G_UNLOCK(MOVE_ROWS);
	    return FALSE;
	  }

	chroma_list->priv->model_row_swap_func (chroma_list->priv->model,
						chroma_list->priv->grabbed_position,
						position);

        chroma_list->priv->grabbed_position = position;
	G_UNLOCK(MOVE_ROWS);
	return FALSE;
      }

    //Check if we're in between a particular header
    if ((y <= chroma_list->priv->header_size) && 
	(!chroma_list->priv->active_row_drag) && 
	(!chroma_list->priv->active_column_resize) &&
	GTK_WIDGET_HAS_FOCUS(GTK_WIDGET(chroma_list)))
      {
	gint l, r, n, hx; 

	hx    = chroma_list->priv->reserved_space;
	l     = -1; 
	r     = -1;

	//Find left border
	for (n = 0; n < (chroma_list->priv->n_columns-1); n++)
	  {
	      if (!chroma_list->priv->column_show[n]) continue;
	      if ((hx + chroma_list->priv->pixel_widths[n]) > x) break;

	      l = n;
	      hx += chroma_list->priv->pixel_widths[n] + chroma_list->priv->cellspacing;
	  }

	//Find right border
	for (n = l+1; n < (chroma_list->priv->n_columns-1); n++)
	  {
	      if (!chroma_list->priv->column_show[n])
		{
		    continue;
		}
	      else
		{
		    r = n;
		    break;
		}
	  }

	if ((l == -1) || (r == -1)) return FALSE;

	hx -= chroma_list->priv->cellspacing;
	if ((x >= (hx)) &&
	    (x <= (hx+(chroma_list->priv->cellspacing*2))) &&
	    (hx > (chroma_list->priv->cellspacing+chroma_list->priv->reserved_space)) &&
	    (hx < (GTK_WIDGET(chroma_list)->allocation.width - (chroma_list->priv->cellspacing*2))) && 
	    ((r < chroma_list->priv->n_columns) && chroma_list->priv->column_show[r]) && (r != chroma_list->priv->n_columns))
	  {
	      GdkCursor *cursor;
	      chroma_list->priv->adjactent_l	= l;
	      chroma_list->priv->adjactent_r	= r;
	      chroma_list->priv->resize_position = hx + chroma_list->priv->cellspacing/2; 

	      cursor = gdk_cursor_new_from_name (gdk_display_get_default (), "sb_h_double_arrow");
	      gdk_window_set_cursor (widget->window, cursor);

	      return FALSE;
	  }
	else
	  {
	      chroma_list->priv->resize_position = NONE; 
	      gdk_window_set_cursor (widget->window, NULL);
	      return FALSE;
	  }
      }

    return FALSE;
}

static gboolean
chroma_list_expose (GtkWidget	    *widget,
		    GdkEventExpose  *event) 
{
    ChromaList	 *chroma_list = CHROMA_LIST(widget);
    gdouble	  x;
    gint	  n;

    cairo_t	 *cr;

    double	  r,
		  g,
		  b,
		  a;

    g_return_val_if_fail(CHROMA_IS_LIST(chroma_list), FALSE);

    if (!chroma_list->priv->model)
	return FALSE;

    if (!chroma_list->priv->pm_backingstore)
        cl_recreate_pm_backingstore (chroma_list);

    gdk_draw_drawable (GTK_WIDGET (chroma_list)->window, 
		       GTK_WIDGET (chroma_list)->style->fg_gc[GTK_STATE_NORMAL],
                       chroma_list->priv->pm_backingstore, 
		       event->area.x,  event->area.y,
		       event->area.x,  event->area.y,
		       event->area.width, event->area.height); 

    //Create local cairo context
    cr = gdk_cairo_create (GTK_WIDGET (chroma_list)->window);

    //Draw column headers
    x = chroma_list->priv->reserved_space;

    if (event->area.y <= chroma_list->priv->header_size)
      for (n = 0; n < chroma_list->priv->n_columns; n ++)
	{
	  PangoLayout	  *layout;
	  PangoAttrList	  *attr_list;
	  PangoAttribute  *attr;
	  PangoRectangle   rect1, 
			   rect2;

	  gchar		  *text;
	  gboolean	   show_name;

	  g_object_get (G_OBJECT(g_ptr_array_index (chroma_list->priv->columns, n)), "show_name", &show_name, NULL);

	  if (!show_name)
	    {
	      x += chroma_list->priv->pixel_widths[n];
	      continue;
	    }

	  if (n == chroma_list->priv->sort_column_id)
	      a = 0.4;
	  else
	      a = 0.2;

#if 0
	  draw_rounded_rectangle_aqua (cr, x, (gdouble)4, 
				(gdouble)chroma_list->priv->pixel_widths[n], (gdouble)chroma_list->priv->header_size - 7, 
				 &(GTK_WIDGET (chroma_list)->style->fg[GTK_STATE_PRELIGHT]), a, 0.4, TRUE, 4.0);
#endif
	  chroma_draw_rounded_rectangle (cr, x, (gdouble)4, 
				(gdouble)chroma_list->priv->pixel_widths[n], (gdouble)chroma_list->priv->header_size - 7.5, 
				 &(GTK_WIDGET (chroma_list)->style->fg[GTK_STATE_PRELIGHT]), a, 0.4, TRUE, 4.0);

	  chroma_draw_rounded_rectangle (cr, x, (gdouble)4, 
				(gdouble)chroma_list->priv->pixel_widths[n], (gdouble)chroma_list->priv->header_size - 7, 
				 &(GTK_WIDGET (chroma_list)->style->fg[GTK_STATE_PRELIGHT]), 1.0, 0.6, FALSE, 4.0);

	  if (n == chroma_list->priv->sort_column_id)
	    {
		GdkRectangle *rect;

		rect = g_new0 (GdkRectangle, 1);
		rect->x = x + chroma_list->priv->pixel_widths[n] - chroma_list->priv->header_size + 8; 
		rect->y = 4;
		rect->width = chroma_list->priv->header_size-9; 
		rect->height = chroma_list->priv->header_size-9; 

		chroma_draw_arrow (cr, 
			    rect, 
			    &(GTK_WIDGET (chroma_list)->style->fg[GTK_STATE_PRELIGHT]),
			    (chroma_list->priv->sort_type == GTK_SORT_ASCENDING) ? GTK_ARROW_DOWN : GTK_ARROW_UP);

		g_free (rect);

	    }

	  g_object_get (G_OBJECT(g_ptr_array_index (chroma_list->priv->columns, n)), "name", &text, NULL); 

	  if (text)
	    {
		chroma_gdk_color_to_rgba (&(GTK_WIDGET (chroma_list)->style->fg[GTK_STATE_PRELIGHT]), &r, &g, &b, &a);

		attr_list = pango_attr_list_new();
		attr = pango_attr_foreground_new (r * 65535, g * 65535, b * 65535);
		pango_attr_list_insert (attr_list, attr);

		layout = pango_cairo_create_layout (cr);
		pango_layout_set_attributes (layout, attr_list);

		pango_layout_set_markup (layout, text, strlen(text));

		pango_layout_set_font_description (layout, GTK_WIDGET (chroma_list)->style->font_desc); 
		pango_layout_set_ellipsize (layout, PANGO_ELLIPSIZE_END);
		pango_layout_set_alignment (layout, PANGO_ALIGN_LEFT);
		pango_layout_set_width (layout, (chroma_list->priv->pixel_widths[n]-8) * PANGO_SCALE);
		pango_layout_get_pixel_extents (layout, &rect1, &rect2);

		cairo_move_to (cr, x+6., ((gdouble)((chroma_list->priv->header_size - rect2.height)/2)-1.)+2);

		cairo_set_source_rgb (cr, r,g,b);
		pango_cairo_show_layout (cr, layout);

		g_object_unref (layout);
		g_free (text);
	    }

	  x += chroma_list->priv->pixel_widths[n] + chroma_list->priv->cellspacing;
	}

    if (chroma_list->priv->drop)
      {
        gint x, y, w;

        x = chroma_list->priv->cellspacing; 
        y = (chroma_list->priv->row_height * chroma_list->priv->drop_row) + chroma_list->priv->header_size + 2;
        w = GTK_WIDGET (chroma_list)->allocation.width-(2*chroma_list->priv->cellspacing);

	chroma_gdk_color_to_rgba (&(GTK_WIDGET (chroma_list)->style->fg[GTK_STATE_PRELIGHT]), &r, &g, &b, &a);

        cairo_set_line_width(cr, 0.7);
        cairo_move_to (cr, x, y-0.5);
        cairo_line_to (cr, x + w, y-0.5);
        cairo_set_source_rgba (cr, r, g, b, 1.0);
        cairo_set_line_cap (cr, CAIRO_LINE_CAP_ROUND);
        cairo_set_line_join (cr, CAIRO_LINE_JOIN_ROUND);
        cairo_stroke(cr);
      }

    cairo_destroy (cr);

    if (GTK_WIDGET_HAS_FOCUS(widget))
      {
	gtk_paint_focus  (widget->style,
                          widget->window, 
                          GTK_STATE_PRELIGHT, 
                          NULL, 
                          widget, 
                          "", 
                          1, 
                          0, 
                          widget->allocation.width-2, 
                          widget->allocation.height); 
      }

    return FALSE;
}

static gboolean
chroma_list_leave_notify (GtkWidget *widget,
                          GdkEventCrossing *event)
{
    g_return_val_if_fail (GTK_IS_WIDGET (widget), FALSE);
    g_return_val_if_fail (CHROMA_IS_LIST (widget), FALSE);

    CHROMA_LIST(widget)->priv->resize_position = NONE;
    gdk_window_set_cursor (widget->window, NULL);
    return FALSE;
}

/* Convenience stuff for setting properties */
void
chroma_list_set_use_numbers (ChromaList	      *chroma_list,
			     gboolean	       use_numbers)
{
    g_return_if_fail(CHROMA_IS_LIST(chroma_list));

    chroma_list->priv->use_numbers = use_numbers;
    chroma_list_refresh (chroma_list);
}

gint
chroma_list_get_n_item_display (ChromaList *chroma_list)
{
    gint n_items;

    g_return_val_if_fail(CHROMA_IS_LIST(chroma_list), -1);

    if (!chroma_list->priv->row_height) return 0;

    n_items = (GTK_WIDGET (chroma_list)->allocation.height - chroma_list->priv->header_size) / chroma_list->priv->row_height;
    return n_items;
}

gint
chroma_list_get_length (ChromaList *chroma_list)
{
    g_return_val_if_fail(CHROMA_IS_LIST(chroma_list), -1);

    if (!chroma_list->priv->model) return 0;
    return gtk_tree_model_iter_n_children (chroma_list->priv->model, NULL); 
}

GtkTreeModel*
chroma_list_get_model (ChromaList *chroma_list)
{
    g_return_val_if_fail(CHROMA_IS_LIST(chroma_list), NULL);
    return chroma_list->priv->model;
}

void
on_row_changed      (GtkTreeModel  *treemodel,
                      GtkTreePath   *arg1,
                      GtkTreeIter   *arg2,
                      ChromaList    *chroma_list)
{
  gint *rows;
  gint  index;

  index = gtk_tree_path_get_indices(arg1)[0];

  if ((index >= chroma_list->priv->offset) &&
      (index < (chroma_list->priv->offset+chroma_list_get_n_item_display (chroma_list))))
    {
      rows = realloc (NULL, 2*sizeof(gint));
      rows[0] = index;
      rows[1] = -1;
      cl_process_cells (chroma_list, rows, chroma_list->priv->all_columns_mask);
    }
}

void
on_row_deleted      (GtkTreeModel  *treemodel,
                      GtkTreePath   *path,
                      ChromaList    *chroma_list)
{
  cl_recalc_reserved_space (chroma_list);
  cl_recalc_pixel_widths (chroma_list);

  chroma_vscrollbar_set_grip_size (chroma_list->priv->adjustment, 
				   (gdouble)chroma_list_get_length(chroma_list)/(gdouble)chroma_list_get_n_item_display(chroma_list));

  if (chroma_list_get_length (chroma_list) < chroma_list_get_n_item_display (chroma_list))
      g_object_set (G_OBJECT(chroma_list), "offset", (gint)0, NULL);
}

void
on_row_inserted      (GtkTreeModel   *treemodel,
                       GtkTreePath    *arg1,
                       GtkTreeIter    *arg2,
                       ChromaList     *chroma_list)
{
  if (GTK_WIDGET_VISIBLE(chroma_list->priv->adjustment))
    chroma_vscrollbar_set_grip_size (chroma_list->priv->adjustment, 
				     (gdouble)chroma_list_get_length(chroma_list)/(gdouble)chroma_list_get_n_item_display(chroma_list));
}

void
on_rows_reordered      (GtkTreeModel	*treemodel,
		         GtkTreePath	*arg1,
			 GtkTreeIter	*arg2,
                         gint	  	*arg3,
                         ChromaList	*chroma_list)
{
  gint *rows;
  gint  n,
	start,
	end,
	ctr;

  ctr   = 0;
  start = chroma_list->priv->offset; 
  end   = chroma_list->priv->offset + chroma_list_get_n_item_display (chroma_list); 
  rows = NULL;

  for (n = 0; n < chroma_list_get_length (chroma_list); n++)
    {
      if ((arg3[n] != n) && ((arg3[n] >= start) && (arg3[n] <end)))
	{
	  rows = realloc (rows, (ctr*sizeof(gint)) + sizeof(gint));
	  rows[ctr] = arg3[n];
	  ctr++;
	}
    }

  rows = realloc (rows, (ctr*sizeof(gint)) + sizeof(gint));
  rows[ctr] = -1;

  cl_process_cells (chroma_list, rows, chroma_list->priv->all_columns_mask);
}

void
on_adjustment_position (ChromaVScrollbar *adjustment,
			gdouble		  position,
			gpointer	  data)
{
    gint offset = 0, n_items = 0, n_item_display = 0;

    ChromaList *chroma_list = CHROMA_LIST (data);

    G_LOCK (SCROLL_OFFSET);

    n_items =
      chroma_list_get_length (chroma_list);
    n_item_display =
      chroma_list_get_n_item_display (chroma_list);

    if (n_items < n_item_display) 
      {
	G_UNLOCK (SCROLL_OFFSET);
	return;
      }

    offset = (n_items - n_item_display) * position;

    if (offset >= 0)
      {
	if (chroma_list->priv->offset != offset)
	  g_object_set (G_OBJECT(chroma_list), "offset", offset, NULL);
      }

    G_UNLOCK (SCROLL_OFFSET);
}

static void
on_adjustment_step_up	(ChromaVScrollbar   *scrollbar,
			 ChromaList	    *chroma_list)
{
    chroma_list_scroll_up   (chroma_list);
}

static void
on_adjustment_step_down (ChromaVScrollbar   *scrollbar,
			 ChromaList	    *chroma_list)
{
    chroma_list_scroll_down (chroma_list);
}

static void
on_sort_column_changed	(GtkTreeSortable *treesortable,
			 ChromaList	 *chroma_list)
{
    gtk_tree_sortable_get_sort_column_id (treesortable,
					  &(chroma_list->priv->sort_column_id),
					  &(chroma_list->priv->sort_type));

    cl_process_cells (chroma_list, NULL, chroma_list->priv->all_columns_mask);
    gtk_widget_queue_draw (GTK_WIDGET (chroma_list));
}

void
chroma_list_set_model (ChromaList	      *chroma_list,
		       GtkTreeModel	      *model,
		       ChromaListRowSwapFunc   model_row_swap_func)
{
    ChromaListColumn *column;
    gint n;

    g_return_if_fail(CHROMA_IS_LIST(chroma_list));

    if (chroma_list->priv->model)
      {
	for (n = 0; n < N_MODEL_SIGNALS; n++)
	  {
	    if (chroma_list->priv->model_signals[n])
		g_signal_handler_disconnect (chroma_list->priv->model, chroma_list->priv->model_signals[n]); 
	  }
	g_object_unref (chroma_list->priv->model);

	if (chroma_list->priv->columns && (chroma_list->priv->n_columns > 0))
	  {
	    for (n = 0; n < chroma_list->priv->n_columns; n++) 
	      {
		g_object_unref (g_ptr_array_index (chroma_list->priv->columns, n));
		g_ptr_array_remove_fast (chroma_list->priv->columns, 0);
	      }
	    g_ptr_array_free (chroma_list->priv->columns, FALSE);

	    g_free (chroma_list->priv->column_widths);
	    g_free (chroma_list->priv->column_xalign);
	    g_free (chroma_list->priv->column_yalign);
	 }
      }

    chroma_list->priv->model = model;
    if (!model) return;

    g_object_ref (chroma_list->priv->model);

    chroma_list->priv->model_row_swap_func = model_row_swap_func;

    chroma_list->priv->model_signals[SIGNAL_ROW_CHANGED] =
	    g_signal_connect_data           ((gpointer)chroma_list->priv->model,
                                             "row-changed", 
                                             G_CALLBACK(on_row_changed), 
                                             chroma_list, 
                                             NULL, 
                                             0); 

    chroma_list->priv->model_signals[SIGNAL_ROW_DELETED] =
	    g_signal_connect_data           ((gpointer)chroma_list->priv->model,
                                             "row-deleted", 
                                             G_CALLBACK(on_row_deleted), 
                                             chroma_list, 
                                             NULL, 
                                             0); 

    chroma_list->priv->model_signals[SIGNAL_ROW_INSERTED] =
	    g_signal_connect_data           ((gpointer)chroma_list->priv->model,
                                             "row-inserted", 
                                             G_CALLBACK(on_row_inserted), 
                                             chroma_list, 
                                             NULL, 
                                             0); 

    chroma_list->priv->model_signals[SIGNAL_ROWS_REORDERED] =
	    g_signal_connect_data           ((gpointer)chroma_list->priv->model,
                                             "rows-reordered", 
                                             G_CALLBACK(on_rows_reordered), 
                                             chroma_list, 
                                             NULL, 
                                             0); 

    if (GTK_IS_TREE_SORTABLE(chroma_list->priv->model))
      {
	  chroma_list->priv->model_signals[SIGNAL_SORT_COLUMN_CHANGED] =
	    g_signal_connect_data           ((gpointer)chroma_list->priv->model,
                                             "sort-column-changed", 
                                             G_CALLBACK(on_sort_column_changed), 
                                             chroma_list, 
                                             NULL, 
                                             0); 
	  gtk_tree_sortable_get_sort_column_id (GTK_TREE_SORTABLE(chroma_list->priv->model),
					  &(chroma_list->priv->sort_column_id),
					  &(chroma_list->priv->sort_type));
      }

    chroma_list->priv->columns = g_ptr_array_new();
    chroma_list->priv->n_columns = gtk_tree_model_get_n_columns (chroma_list->priv->model); 
    chroma_list->priv->all_columns_mask = 0; 
    for (n = 0; n < chroma_list->priv->n_columns; n++) chroma_list->priv->all_columns_mask |= 1 << n; 

    chroma_list->priv->n_columns_visible = gtk_tree_model_get_n_columns (chroma_list->priv->model); 

    chroma_list->priv->column_show = g_new0(gboolean, chroma_list->priv->n_columns); 
    for (n = 0; n < chroma_list->priv->n_columns; chroma_list->priv->column_show[n++] = TRUE); 

    chroma_list->priv->column_widths = g_new0(gdouble, chroma_list->priv->n_columns); 
    chroma_list->priv->column_xalign = g_new0(gdouble, chroma_list->priv->n_columns); 
    chroma_list->priv->column_yalign = g_new0(gdouble, chroma_list->priv->n_columns); 

    chroma_list->priv->cell_data_funcs = g_new0 (ChromaListCellDataFunc, chroma_list->priv->n_columns);
    chroma_list->priv->cell_data_funcs_data = g_new0 (gpointer, chroma_list->priv->n_columns);

    for (n = 0; n < chroma_list->priv->n_columns; n++) 
      {
	column = chroma_list_column_new();		

	g_object_set (column, "font", GTK_WIDGET (chroma_list)->style->font_desc, NULL);
	g_object_set (column, "foreground", &(GTK_WIDGET (chroma_list)->style->fg[GTK_STATE_NORMAL]), NULL);
	g_object_set (column, "background", &(GTK_WIDGET (chroma_list)->style->bg[GTK_STATE_NORMAL]), NULL);

	g_ptr_array_add (chroma_list->priv->columns, column);

	chroma_list->priv->column_yalign[n] = 0.5;
	chroma_list->priv->column_xalign[n] = 0.0;
	chroma_list->priv->column_widths[n] = 1.0;
      }

    g_object_set (chroma_list, "offset", (gint)0, NULL);

    cl_recalc_reserved_space (chroma_list);
    cl_recalc_pixel_widths (chroma_list);
    cl_recreate_pm_backingstore (chroma_list);

    gtk_widget_queue_draw (GTK_WIDGET (chroma_list));
}

void
chroma_list_set_adjustment (ChromaList	      *chroma_list,
			    ChromaVScrollbar  *adjustment)
{
    gint n;

    g_return_if_fail(CHROMA_IS_LIST(chroma_list));

    if (chroma_list->priv->adjustment)
      {
	for (n = 0; n < N_MODEL_SIGNALS; n++)
	    g_signal_handler_disconnect (chroma_list->priv->adjustment, chroma_list->priv->adjustment_signals[n]); 

	g_object_unref (chroma_list->priv->adjustment);
      }

    chroma_list->priv->adjustment = adjustment;
    g_object_ref (adjustment);

    chroma_list->priv->adjustment_signals[SIGNAL_POSITION] =
	    g_signal_connect_data           ((gpointer)chroma_list->priv->adjustment,
                                             "position", 
                                             G_CALLBACK(on_adjustment_position), 
                                             chroma_list, 
                                             NULL, 
                                             0); 

    chroma_list->priv->adjustment_signals[SIGNAL_STEP_UP] =
	    g_signal_connect_data           ((gpointer)chroma_list->priv->adjustment,
                                             "step_up", 
                                             G_CALLBACK(on_adjustment_step_up), 
                                             chroma_list, 
                                             NULL, 
                                             0); 

    chroma_list->priv->adjustment_signals[SIGNAL_STEP_DOWN] =
	    g_signal_connect_data           ((gpointer)chroma_list->priv->adjustment,
                                             "step_down", 
                                             G_CALLBACK(on_adjustment_step_down), 
                                             chroma_list, 
                                             NULL, 
                                             0); 

}

void
chroma_list_set_drop_mode   (ChromaList		*chroma_list,
			     ChromaListDropMode  mode)
{
    g_return_if_fail(CHROMA_IS_LIST(chroma_list));

    chroma_list->priv->drop_mode = mode;
}

gint
chroma_list_get_row_height    (ChromaList     *chroma_list)
{
    g_return_val_if_fail(CHROMA_IS_LIST(chroma_list), -1);

    return chroma_list->priv->row_height;
}

void
chroma_list_set_cursor_position	    (ChromaList		*chroma_list,
				     gint		 offset_)
{
    GtkTreePath		  *path;

    path = gtk_tree_path_new_from_indices (offset_, -1); 
    chroma_list_selection_unselect_all (CHROMA_LIST_SELECTION(chroma_list));
  
    if (chroma_list->priv->last_pressed_row) gtk_tree_row_reference_free (chroma_list->priv->last_pressed_row);
    chroma_list->priv->last_pressed_row = gtk_tree_row_reference_new (chroma_list->priv->model, path);
    chroma_list_selection_path_set_selected (CHROMA_LIST_SELECTION(chroma_list), path, TRUE);
    gtk_tree_path_free (path);

    g_signal_emit (chroma_list, signals[CHROMA_LIST_SIGNAL_CURSOR_POSITION], 0, offset_); 
}

void
chroma_list_scroll_to_offset  (ChromaList     *chroma_list,
			       gint	       offset)
{
      gdouble position, total_area, scroll_area;

      g_return_if_fail (CHROMA_IS_LIST (chroma_list));

      total_area  = ((chroma_list_get_length (chroma_list) - chroma_list_get_n_item_display (chroma_list)) * chroma_list->priv->row_height);
      scroll_area = offset * chroma_list->priv->row_height; 

      position = scroll_area / total_area; 

      if (position < 0) position = 0;
      if (position > 1) position = 1;

      if (offset < 0) offset = 0;
      if (offset > (chroma_list_get_length (chroma_list) - chroma_list_get_n_item_display (chroma_list)))
          offset = (chroma_list_get_length (chroma_list) - chroma_list_get_n_item_display (chroma_list));

      g_object_set (G_OBJECT(chroma_list->priv->adjustment), "position_noemit", position, NULL);

      if (offset >= 0)
	{
	    g_object_set (G_OBJECT(chroma_list), "offset", offset, NULL);
	}
}

/* GObject stuff */
static void
chroma_list_set_property (GObject	*object,
                          guint		 property_id,
                          const GValue	*value,
                          GParamSpec    *pspec)
{
    ChromaList *chroma_list = (ChromaList *) object;

    switch (property_id) {

    case CHROMA_LIST_PROP_OFFSET:
      {
	    gint *rows = NULL;
	    gint  delta;

	    if (!chroma_list->priv->model) return;

	    delta = g_value_get_int(value) - chroma_list->priv->offset; 
	    if (!delta) return;

	    if (abs(delta) >= chroma_list_get_n_item_display (chroma_list))
              {
                chroma_list->priv->offset = g_value_get_int(value);

		cl_process_cells (chroma_list, rows, chroma_list->priv->all_columns_mask);
		// gtk_widget_queue_draw (GTK_WIDGET (chroma_list));
		break;
	      }

	    /* If the delta is positive, we need to move a lower part upwards */
	    if (delta > 0)
              {
		    gint  start,
			  height,
			  n;
		  
		    start  = abs(delta);
		    height = chroma_list_get_n_item_display(chroma_list)-start;

		    gdk_draw_drawable (chroma_list->priv->pm_backingstore,

				       GTK_WIDGET (chroma_list)->style->fg_gc[GTK_STATE_NORMAL],
				       chroma_list->priv->pm_backingstore,

				       0, (start  * chroma_list->priv->row_height) + chroma_list->priv->header_size,
				       0, chroma_list->priv->header_size,
				      -1, (height * chroma_list->priv->row_height));

		    chroma_list->priv->offset = g_value_get_int(value);

		    rows = g_new0 (gint,start+1);
	
		    for (n = 0; n < start; n++)
		      {
			rows[n] = (chroma_list_get_n_item_display(chroma_list)-1) + chroma_list->priv->offset - n; 
	              }
		    rows[start] = -1; 
	      }
	    else if (delta < 0)
              {
		    gint  start,
			  height,
			  n;

		    start  = abs(delta);
		    height = chroma_list_get_n_item_display(chroma_list)-start;

		    gdk_draw_drawable (chroma_list->priv->pm_backingstore,

				       GTK_WIDGET (chroma_list)->style->fg_gc[GTK_STATE_NORMAL],
				       chroma_list->priv->pm_backingstore,

				       0, chroma_list->priv->header_size,
				       0, start  * chroma_list->priv->row_height + chroma_list->priv->header_size,
				      -1, height * chroma_list->priv->row_height);

		    chroma_list->priv->offset = g_value_get_int(value);

		    rows = g_new0 (gint,start+1);

		    for (n = 0; n < start; n++)
		      {
			rows[n] = n + chroma_list->priv->offset;
	              }
		    rows[start] = -1; 
	      }

	    cl_process_cells (chroma_list, rows, chroma_list->priv->all_columns_mask);
	    gtk_widget_queue_draw (GTK_WIDGET (chroma_list));
	    gdk_flush ();
        }
        break;

      case CHROMA_LIST_PROP_SHOW_HEADERS:
	{
          chroma_list->priv->show_headers = g_value_get_boolean (value);

	  if (chroma_list->priv->show_headers)
	    chroma_list->priv->header_size = chroma_list->priv->row_height + 7;
          else
	    chroma_list->priv->header_size = 0; 

	  gtk_widget_queue_draw (GTK_WIDGET (chroma_list));
	}
	break;

    default:
        /* We don't have any other property... */
        g_assert(FALSE);
        break;
    }
}

static void
chroma_list_get_property(GObject    *object,
                         guint	     property_id,
                         GValue	    *value,
			 GParamSpec *pspec)
{
    switch (property_id)
    {

    case CHROMA_LIST_PROP_OFFSET:
        {
	    g_value_set_int (value, CHROMA_LIST(object)->priv->offset);
	}
    break;
 

    case CHROMA_LIST_PROP_N_ITEMS:
        {
            if (CHROMA_LIST(object)->priv->model == NULL)
                g_value_set_int(value, (gint) 0);
            else
                g_value_set_int(value, gtk_tree_model_iter_n_children (CHROMA_LIST(object)->priv->model, NULL));
        }
        break;

    case CHROMA_LIST_PROP_RESERVED_SPACE:
        {
            g_value_set_int(value, CHROMA_LIST(object)->priv->reserved_space);
        }
        break;

    case CHROMA_LIST_PROP_ROW_HEIGHT:
        {
            g_value_set_int(value, CHROMA_LIST(object)->priv->row_height);
        }
        break;

    case CHROMA_LIST_PROP_SHOW_HEADERS:
	{
          g_value_set_boolean (value, CHROMA_LIST(object)->priv->show_headers);
	}
	break;

    default:
        /* We don't have any other property... */
        g_assert(FALSE);
        break;
    }
}

static void
chroma_list_dispose(GObject * obj)
{
    ChromaList *chroma_list = (ChromaList *) obj;

    if (chroma_list->priv->dispose_has_run) return; 

    chroma_list->priv->dispose_has_run = TRUE;
    if (chroma_list->priv->cs_selection) cairo_surface_destroy (chroma_list->priv->cs_selection);
}

static void
chroma_list_finalize(GObject * obj)
{
    ChromaList *chroma_list = (ChromaList *) obj;

    /*
     * Here, complete object destruction.
     * You might not need to do much...
     */
    g_free(chroma_list->priv);
}

static GObject *
chroma_list_constructor(GType type,
                        guint n_construct_properties,
                        GObjectConstructParam * construct_properties)
{
    GObject *obj;

    {
        /* Invoke parent constructor. */
        ChromaListClass *klass;
        GObjectClass *parent_class;
        klass = CHROMA_LIST_CLASS(g_type_class_peek(CHROMA_TYPE_LIST));
        parent_class = G_OBJECT_CLASS(g_type_class_peek_parent(klass));
        obj = parent_class->constructor(type,
                                        n_construct_properties,
                                        construct_properties);
    }

    /* do stuff. */

    return obj;
}

static void
chroma_list_class_init (ChromaListClass *class)
{
    GObjectClass    *gobject_class = G_OBJECT_CLASS (class);
    GtkWidgetClass  *widget_class  = GTK_WIDGET_CLASS (class);

    widget_class->realize		= chroma_list_realize;
    widget_class->size_allocate		= chroma_list_size_allocate;

    widget_class->drag_leave		= chroma_list_drag_leave;
    widget_class->drag_motion		= chroma_list_drag_motion;
    widget_class->drag_end		= chroma_list_drag_end;
    widget_class->drag_data_received	= chroma_list_drag_data_received;

    widget_class->button_press_event	= chroma_list_button_press; 
    widget_class->button_release_event	= chroma_list_button_release;
    widget_class->key_press_event	= chroma_list_key_press;

    widget_class->scroll_event		= chroma_list_scroll;

    widget_class->motion_notify_event	= chroma_list_motion;
    widget_class->expose_event		= chroma_list_expose;
    widget_class->leave_notify_event	= chroma_list_leave_notify;
    widget_class->configure_event	= chroma_list_configure;

    gobject_class->set_property		= chroma_list_set_property;
    gobject_class->get_property		= chroma_list_get_property;
    gobject_class->dispose		= chroma_list_dispose;
    gobject_class->finalize		= chroma_list_finalize;
    gobject_class->constructor		= chroma_list_constructor;

    /**
     *
     * ChromaList:show-headers: 
     *
     * Determines whether to show column headers
     *
     * Since: 0.1
     */
    g_object_class_install_property (gobject_class,
                                     CHROMA_LIST_PROP_SHOW_HEADERS, g_param_spec_boolean ("show-headers",
							      				  "show-headers",
											  "Show Headers?",
										  TRUE, G_PARAM_READABLE));
    /**
     *
     * ChromaList:offset: 
     *
     * Current list offset (uppermost row) 
     *
     * Since: 0.1
     */
    g_object_class_install_property (gobject_class,
                                     CHROMA_LIST_PROP_OFFSET, g_param_spec_int("offset",
									       "offset",
									       "offset",
								      0, G_MAXINT, 0, G_PARAM_READWRITE));
    /**
     *
     * ChromaList:n-items: 
     *
     * Number of items in the list 
     *
     * Since: 0.1
     */
    g_object_class_install_property (gobject_class,
                                     CHROMA_LIST_PROP_N_ITEMS, g_param_spec_int("n-items",
									        "n-items",
									        "n-items",
									0, G_MAXINT, 0, G_PARAM_READABLE));

    /**
     *
     * ChromaList:row-height: 
     *
     * Number of items in the list 
     *
     * Since: 0.1
     */
    g_object_class_install_property (gobject_class,
                                    CHROMA_LIST_PROP_ROW_HEIGHT, g_param_spec_int("row-height",
									          "row-height",
										  "row-height",
									0, G_MAXINT, 0, G_PARAM_READABLE));

    signals[CHROMA_LIST_SIGNAL_CURSOR_POSITION] =
        g_signal_new("cursor-position",
                     G_OBJECT_CLASS_TYPE(gobject_class),
                     G_SIGNAL_RUN_FIRST,
                     G_STRUCT_OFFSET(ChromaListClass, cursor_position),
                     NULL, NULL,
                     g_cclosure_marshal_VOID__INT, G_TYPE_NONE, 1, G_TYPE_INT);

    signals[CHROMA_LIST_SIGNAL_ROW_ACTIVATED] =
        g_signal_new("row_activated",
                     G_OBJECT_CLASS_TYPE(gobject_class),
                     G_SIGNAL_RUN_FIRST,
                     G_STRUCT_OFFSET(ChromaListClass, row_activated),
                     NULL, NULL,
                     g_cclosure_marshal_VOID__INT,
                     G_TYPE_NONE, 1, G_TYPE_INT);

    signals[CHROMA_LIST_SIGNAL_DND] =
        g_signal_new("dnd",
                     G_OBJECT_CLASS_TYPE(gobject_class),
                     G_SIGNAL_RUN_FIRST,
                     G_STRUCT_OFFSET(ChromaListClass, dnd),
                     NULL, NULL,
                     libchroma_VOID__INT_BOXED,
                     G_TYPE_NONE, 2, G_TYPE_INT, G_TYPE_STRV);

}

static void
on_list_selection_path_selected	    (ChromaListSelectionInterface   *selection,
				     GtkTreePath		    *path,
				     gpointer			     data)
{
      gint *rows;
      gint  position;

      position = gtk_tree_path_get_indices (path)[0];

      if ((position < CHROMA_LIST(data)->priv->offset) ||
	  (position > (CHROMA_LIST(data)->priv->offset+(chroma_list_get_n_item_display (CHROMA_LIST(data)))))) return;

      rows = g_new0 (gint,2);
      rows[0] = position;
      rows[1] = NONE; 

      cl_process_cells (CHROMA_LIST (data), rows, CHROMA_LIST(data)->priv->all_columns_mask);
}

static void
on_list_selection_path_unselected   (ChromaListSelectionInterface   *selection,
				     GtkTreePath		    *path,
				     gpointer			     data)
{
      gint *rows;
      gint  position;

      position = gtk_tree_path_get_indices (path)[0];
  
      if ((position < CHROMA_LIST(data)->priv->offset) ||
	  (position > CHROMA_LIST(data)->priv->offset+(chroma_list_get_n_item_display (CHROMA_LIST(data))))) return;

      rows = g_new0 (gint,2);
      rows[0] = position;
      rows[1] = NONE; 

      cl_process_cells (CHROMA_LIST (data), rows, CHROMA_LIST(data)->priv->all_columns_mask);
}

static void
chroma_list_init (ChromaList *chroma_list)
{
    chroma_list->priv = g_new(ChromaListPrivate, 1);
    chroma_list->priv->dispose_has_run = FALSE;

    chroma_list->priv->model	  = NULL;

    chroma_list->priv->adjustment	  = NULL;

    chroma_list->priv->use_numbers	  = FALSE;

    chroma_list->priv->offset	  = 0;
    chroma_list->priv->n_columns  = 0;

    chroma_list->priv->row_height     = 0; 
    chroma_list->priv->reserved_space = 0;

    chroma_list->priv->cellspacing    = 4;

    chroma_list->priv->selection_mode = GTK_SELECTION_MULTIPLE;
    chroma_list->priv->drop_mode      = CHROMA_LIST_DROP_ROWS;

    chroma_list->priv->active_row_drag	    = FALSE;
    chroma_list->priv->active_column_resize = FALSE;
    chroma_list->priv->grabbed_position	    = 0;
    chroma_list->priv->button_press	    = FALSE;

    chroma_list->priv->drop	= FALSE;
    chroma_list->priv->drop_row = NONE;

    chroma_list->priv->scroll_timeout_source_id = 0;
    chroma_list->priv->scroll_step = 3; //FIXME: Make this configurable

    chroma_list->priv->pm_backingstore  = NULL;
    chroma_list->priv->cs_selection	= NULL;

    chroma_list->priv->columns	      = NULL;
    chroma_list->priv->column_widths  = NULL;

    chroma_list->priv->number_column = chroma_list_column_new ();		

    chroma_list->priv->show_headers = TRUE;

    chroma_list->priv->sort_type = GTK_SORT_ASCENDING;
    chroma_list->priv->sort_column_id = GTK_TREE_SORTABLE_UNSORTED_SORT_COLUMN_ID; 
    chroma_list->priv->sort_trigger = 0;

    chroma_list->priv->selected_rows    = NULL;
    chroma_list->priv->last_pressed_row = NULL; 
    chroma_list->priv->pixel_widths	= NULL; 

    chroma_list->priv->adjactent_l      = NONE;
    chroma_list->priv->adjactent_r      = NONE;
    chroma_list->priv->resize_position  = NONE;

    cl_initialize_metrics (chroma_list);
    cl_drag_dest_set (GTK_WIDGET (chroma_list));

    g_signal_connect (CHROMA_LIST_SELECTION (chroma_list),
		      "path-selected",
		      G_CALLBACK (on_list_selection_path_selected),
		      chroma_list);

    g_signal_connect (CHROMA_LIST_SELECTION (chroma_list),
		      "path-unselected",
		      G_CALLBACK (on_list_selection_path_unselected),
		      chroma_list);
}

void
chroma_list_size (ChromaList *widget_list,
		       gint            width,
		       gint            height)
{
  g_return_if_fail (CHROMA_IS_LIST (widget_list));

  GTK_WIDGET (widget_list)->requisition.width = width;
  GTK_WIDGET (widget_list)->requisition.height = height;

  gtk_widget_queue_resize (GTK_WIDGET (widget_list));
}

static void
chroma_list_realize (GtkWidget *widget)
{
  ChromaList *widget_list;
  GdkWindowAttr attributes;
  gint attributes_mask;

  g_return_if_fail (CHROMA_IS_LIST (widget));

  widget_list = CHROMA_LIST (widget);
  GTK_WIDGET_SET_FLAGS (widget, GTK_REALIZED | GTK_CAN_FOCUS);

  attributes.window_type = GDK_WINDOW_CHILD;
  attributes.x = widget->allocation.x;
  attributes.y = widget->allocation.y;
  attributes.width = widget->allocation.width;
  attributes.height = widget->allocation.height;
  attributes.wclass = GDK_INPUT_OUTPUT;
  attributes.visual = gtk_widget_get_visual (widget);
  attributes.colormap = gtk_widget_get_colormap (widget);
  attributes.event_mask = gtk_widget_get_events (widget) | GDK_EXPOSURE_MASK | GDK_ALL_EVENTS_MASK;

  attributes_mask = GDK_WA_X | GDK_WA_Y | GDK_WA_VISUAL | GDK_WA_COLORMAP;

  widget->window = gdk_window_new (gtk_widget_get_parent_window (widget), &attributes, attributes_mask);
  gdk_window_set_user_data (widget->window, widget_list);

  widget->style = gtk_style_attach (widget->style, widget->window);
  gtk_style_set_background (widget->style, widget->window, GTK_STATE_NORMAL);

  chroma_list_send_configure (CHROMA_LIST (widget));
}

static void
chroma_list_size_allocate (GtkWidget     *widget,
				GtkAllocation *allocation)
{
  g_return_if_fail (CHROMA_IS_LIST (widget));
  g_return_if_fail (allocation != NULL);

  widget->allocation = *allocation;

  if (GTK_WIDGET_REALIZED (widget))
    {
      gdk_window_move_resize (widget->window,
			      allocation->x, allocation->y,
			      allocation->width, allocation->height);

      chroma_list_send_configure (CHROMA_LIST (widget));
    }
}

static void
chroma_list_send_configure (ChromaList *chroma_list)
{
  GtkWidget *widget;
  GdkEvent *event = gdk_event_new (GDK_CONFIGURE);

  widget = GTK_WIDGET (chroma_list);

  event->configure.window = g_object_ref (widget->window);
  event->configure.send_event = TRUE;
  event->configure.x = widget->allocation.x;
  event->configure.y = widget->allocation.y;
  event->configure.width = widget->allocation.width;
  event->configure.height = widget->allocation.height;

  gtk_widget_event (widget, event);
  gdk_event_free (event);
}

static gboolean
list_selection_path_get_selected (ChromaListSelectionInterface *chroma_list, 
				  GtkTreePath		       *path)
{
    g_return_val_if_fail (CHROMA_IS_LIST(chroma_list), FALSE);

    GtkTreeModel	  *model;
    GtkTreeRowReference	  *rref;
    GList		  *iter_list;
    gboolean		   found = FALSE;

    g_return_val_if_fail (CHROMA_IS_LIST_SELECTION(chroma_list), FALSE);

    model = CHROMA_LIST(chroma_list)->priv->model;
    rref = gtk_tree_row_reference_new (model, path);

    iter_list = CHROMA_LIST(chroma_list)->priv->selected_rows;

    for ( ; iter_list; iter_list = iter_list->next)
      {
	  GtkTreePath		*path_cmp;
	  GtkTreeRowReference   *rref_cmp;

	  rref_cmp = (GtkTreeRowReference *)iter_list->data; 
	  if (!rref_cmp) continue;
	  path_cmp = gtk_tree_row_reference_get_path (rref_cmp);
	  if (!path_cmp) continue;

	  if (!gtk_tree_path_compare (path, path_cmp))
	    {
		gtk_tree_path_free (path_cmp);
		found = TRUE;
		break;
	    }
      }

    gtk_tree_row_reference_free (rref);

    return found;
}

static gboolean
list_selection_iter_get_selected (ChromaListSelectionInterface *chroma_list, 
				  GtkTreeIter		       *iter)
{
    g_return_val_if_fail (CHROMA_IS_LIST(chroma_list), FALSE);

    GtkTreePath		  *path;
    GtkTreeModel	  *model;
    GtkTreeRowReference	  *rref;
    GList		  *iter_list;
    gboolean		   found = FALSE;

    g_return_val_if_fail (CHROMA_IS_LIST_SELECTION(chroma_list), FALSE);

    model = CHROMA_LIST(chroma_list)->priv->model;
    path = gtk_tree_model_get_path (model, iter);
    rref = gtk_tree_row_reference_new (model, path);

    iter_list = CHROMA_LIST(chroma_list)->priv->selected_rows;

    for ( ; iter_list; iter_list = iter_list->next)
      {
	  GtkTreePath		*path_cmp;
	  GtkTreeRowReference   *rref_cmp;

	  rref_cmp = (GtkTreeRowReference *)iter_list->data; 
	  if (!rref_cmp) continue;
	  path_cmp = gtk_tree_row_reference_get_path (rref_cmp);
	  if (!path_cmp) continue;

	  if (!gtk_tree_path_compare (path, path_cmp))
	    {
		gtk_tree_path_free (path_cmp);
		found = TRUE;
		break;
	    }
      }

    gtk_tree_path_free (path);
    gtk_tree_row_reference_free (rref);

    return found;
}

static void
list_selection_iter_set_selected (ChromaListSelectionInterface *chroma_list, 
				  GtkTreeIter		       *iter, 
				  gboolean		        selected)
{
    GtkTreePath		  *path;
    GtkTreeModel	  *model;
    GtkTreeRowReference	  *rref;

    g_return_if_fail (CHROMA_IS_LIST_SELECTION(chroma_list));

    model = CHROMA_LIST(chroma_list)->priv->model;
    path = gtk_tree_model_get_path (model, iter);
    rref = gtk_tree_row_reference_new (model, path);

    if (selected)
      {
	  if (!chroma_list_selection_iter_get_selected (chroma_list, iter))
	    {
		CHROMA_LIST(chroma_list)->priv->selected_rows = g_list_append (CHROMA_LIST(chroma_list)->priv->selected_rows, rref);
		chroma_list_selection_path_selected (chroma_list, path);
	    }
      }
    else
      {
	  GList *iter_list;
	  iter_list = CHROMA_LIST(chroma_list)->priv->selected_rows;

	  for ( ; iter_list; iter_list = iter_list->next)
	    {
		GtkTreePath	      *path_cmp;
		GtkTreeRowReference   *rref_cmp;

		rref_cmp = (GtkTreeRowReference *)iter_list->data; 
		if (!rref_cmp) continue;
		path_cmp = gtk_tree_row_reference_get_path (rref_cmp);
		if (!path_cmp) continue;

		if (!gtk_tree_path_compare (path, path_cmp))
		  {
		      CHROMA_LIST(chroma_list)->priv->selected_rows = g_list_remove_link (CHROMA_LIST(chroma_list)->priv->selected_rows, iter_list);
		      gtk_tree_path_free (path_cmp);
		      gtk_tree_row_reference_free (rref_cmp);
		      chroma_list_selection_path_unselected (chroma_list, path);
		      break;
		  }
	    }

	gtk_tree_row_reference_free (rref);
      }

    gtk_tree_path_free (path);
}

static void
list_selection_path_set_selected (ChromaListSelectionInterface *chroma_list, 
				  GtkTreePath		       *path, 
				  gboolean		        selected)
{
    GtkTreeModel	  *model;
    GtkTreeRowReference	  *rref;

    g_return_if_fail (CHROMA_IS_LIST_SELECTION(chroma_list));

    model = CHROMA_LIST(chroma_list)->priv->model;
    rref = gtk_tree_row_reference_new (model, path);

    if (selected)
      {
	  if (!chroma_list_selection_path_get_selected (chroma_list, path))
	    {
	      CHROMA_LIST(chroma_list)->priv->selected_rows = g_list_append (CHROMA_LIST(chroma_list)->priv->selected_rows, rref);
	      chroma_list_selection_path_selected (chroma_list, path);
	    }
      }
    else
      {
	  GList *iter_list;
	  iter_list = CHROMA_LIST(chroma_list)->priv->selected_rows;

	  for ( ; iter_list; iter_list = iter_list->next)
	    {
		GtkTreePath	      *path_cmp;
		GtkTreeRowReference   *rref_cmp;

		rref_cmp = (GtkTreeRowReference *)iter_list->data; 
		if (!rref_cmp) continue;
		path_cmp = gtk_tree_row_reference_get_path (rref_cmp);
		if (!path_cmp) continue;

		if (!gtk_tree_path_compare (path, path_cmp))
		  {
		      CHROMA_LIST(chroma_list)->priv->selected_rows = g_list_remove_link (CHROMA_LIST(chroma_list)->priv->selected_rows, iter_list);
		      gtk_tree_path_free (path_cmp);
		      gtk_tree_row_reference_free (rref_cmp);
		      chroma_list_selection_path_unselected (chroma_list, path);
		      break;
		  }
	    }

	gtk_tree_row_reference_free (rref);
      }
}

static void
list_selection_unselect_all (ChromaListSelectionInterface *chroma_list) 
{
    GList *iter_list;
    GList *path_list;

    iter_list = CHROMA_LIST(chroma_list)->priv->selected_rows;
    path_list = NULL;

    for ( ; iter_list; iter_list = iter_list->next)
      {
	  GtkTreeRowReference   *rref;
	  GtkTreePath		*path;

	  rref = (GtkTreeRowReference *)iter_list->data; 
	  path = gtk_tree_row_reference_get_path (rref);
	  if (path) path_list = g_list_append (path_list, path);
      }

    for ( ; path_list; path_list = path_list->next)
      {
	  chroma_list_selection_path_set_selected (chroma_list, (GtkTreePath*) path_list->data, FALSE);
      }
    g_list_foreach (g_list_first(path_list), (GFunc)gtk_tree_path_free, NULL);

    g_list_foreach (CHROMA_LIST(chroma_list)->priv->selected_rows, (GFunc)gtk_tree_row_reference_free, NULL);
    CHROMA_LIST(chroma_list)->priv->selected_rows = NULL;
}

static void
list_selection_select_all   (ChromaListSelectionInterface *chroma_list) 
{
    GtkTreeIter	iter;
    gboolean	proceed;    

    proceed = gtk_tree_model_get_iter_first (CHROMA_LIST(chroma_list)->priv->model, &iter);

    while (proceed)
      {
	  chroma_list_selection_iter_set_selected (chroma_list, &iter, TRUE);
	  proceed = gtk_tree_model_iter_next (CHROMA_LIST(chroma_list)->priv->model, &iter);
      }
}

static GtkTreePath*
list_selection_get_selected       (ChromaListSelectionInterface *chroma_list) 
{
    g_return_val_if_fail (CHROMA_IS_LIST(chroma_list), FALSE);

    GList		  *iter_list;
    GtkTreePath		  *path;
    GtkTreeRowReference   *rref;

    g_return_val_if_fail (CHROMA_IS_LIST_SELECTION(chroma_list), FALSE);

    iter_list = CHROMA_LIST(chroma_list)->priv->selected_rows;
    if (!iter_list) return NULL;
    if (iter_list->next != NULL) return NULL;

    rref = (GtkTreeRowReference *)iter_list->data; 
    if (!rref) return NULL; //error
    path = gtk_tree_row_reference_get_path (rref);
    if (!path) return NULL; //error

    return path;
}

static GList*
list_selection_get_selected_paths (ChromaListSelectionInterface *chroma_list) 
{
    g_return_val_if_fail (CHROMA_IS_LIST(chroma_list), FALSE);

    GList		  *iter_list;
    GList		  *paths = NULL;

    g_return_val_if_fail (CHROMA_IS_LIST_SELECTION(chroma_list), FALSE);

    iter_list = CHROMA_LIST(chroma_list)->priv->selected_rows;

    for ( ; iter_list; iter_list = iter_list->next)
      {
	  GtkTreePath		*path;
	  GtkTreeRowReference   *rref;

	  rref = (GtkTreeRowReference *)iter_list->data; 
	  if (!rref) continue;
	  path = gtk_tree_row_reference_get_path (rref);
	  if (!path) continue;

	  paths = g_list_append (paths, path);
      }

    return paths;
}

static void
list_selection_remove_selected (ChromaListSelectionInterface *chroma_list) 
{
    GtkTreeModel	  *model;
    GList		  *iter_list;

    g_return_if_fail (CHROMA_IS_LIST_SELECTION(chroma_list));

    iter_list = CHROMA_LIST(chroma_list)->priv->selected_rows;
    model = CHROMA_LIST(chroma_list)->priv->model;

    for ( ; iter_list; iter_list = iter_list->next)
      {
	  GtkTreePath		*path;
	  GtkTreeRowReference   *rref;
	  GtkTreeIter		 iter;

	  rref = (GtkTreeRowReference *)iter_list->data; 
	  if (!rref) continue;
	  path = gtk_tree_row_reference_get_path (rref);
	  if (!path) continue;

	  chroma_list_selection_path_removing (chroma_list, path);

	  gtk_tree_model_get_iter (model, &iter, path); 
	  gtk_list_store_remove (GTK_LIST_STORE(model), &iter);
      }

    g_list_foreach (CHROMA_LIST(chroma_list)->priv->selected_rows, (GFunc)gtk_tree_row_reference_free, NULL);
    CHROMA_LIST(chroma_list)->priv->selected_rows = NULL;
}

static gboolean
list_selection_multiple_selected (ChromaListSelectionInterface *chroma_list) 
{
    g_return_val_if_fail (CHROMA_IS_LIST_SELECTION(chroma_list), FALSE);

    if (CHROMA_LIST(chroma_list)->priv->selected_rows == NULL) return FALSE;
    if (CHROMA_LIST(chroma_list)->priv->selected_rows->next != NULL) return TRUE;

    return FALSE;
}

static void
chroma_list_selection_init (ChromaListSelectionInterface *iface)
{
    iface->get_selected_paths = list_selection_get_selected_paths; 
    iface->get_selected	      = list_selection_get_selected; 

    iface->iter_get_selected  = list_selection_iter_get_selected; 
    iface->iter_set_selected  = list_selection_iter_set_selected; 

    iface->path_get_selected  = list_selection_path_get_selected; 
    iface->path_set_selected  = list_selection_path_set_selected; 

    iface->select_all	      = list_selection_select_all; 
    iface->unselect_all	      = list_selection_unselect_all; 

    iface->remove_selected    = list_selection_remove_selected; 

    iface->multiple_selected  = list_selection_multiple_selected; 
}

GType
chroma_list_get_type (void)
{
    static GType list_type = 0;

    if (!list_type)
     {
         static const GTypeInfo list_info = {
             sizeof (ChromaListClass),
             NULL,
             NULL,
             (GClassInitFunc) chroma_list_class_init,
             NULL,
             NULL,
             sizeof (ChromaList),
             0,
             (GInstanceInitFunc) chroma_list_init,
         };

         static const GInterfaceInfo list_selection_info = {
             (GInterfaceInitFunc) chroma_list_selection_init,
             NULL,
             NULL
         };

         list_type =
             g_type_register_static (GTK_TYPE_WIDGET, "ChromaList",
                                     &list_info, 0);

         g_type_add_interface_static (list_type,
                                      CHROMA_TYPE_LIST_SELECTION, 
				      &list_selection_info);

     }

    return list_type;
}
