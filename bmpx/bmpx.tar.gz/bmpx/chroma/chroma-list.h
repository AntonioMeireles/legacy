/* -*- Mode: C; tab-width: 8; indent-tabs-mode: nil; c-basic-offset: 8 -*- */
/*
 * Chroma widget set
 * (C) 2005 M. Derezynski <internalerror@gmail.com>
 *
 */

#ifndef CHROMA_LIST_H
#define CHROMA_LIST_H

/*
 * Potentially, include other headers on which this header depends.
 */

#include <gtk/gtk.h>
#include <gtk/gtkwidget.h>
#include <chroma/chroma-vscrollbar.h>
#include <chroma/chroma-list-column.h>

G_BEGIN_DECLS

#define CHROMA_TYPE_LIST                  (chroma_list_get_type ())
#define CHROMA_LIST(obj)                  (G_TYPE_CHECK_INSTANCE_CAST ((obj), CHROMA_TYPE_LIST, ChromaList))
#define CHROMA_LIST_CLASS(klass)          (G_TYPE_CHECK_CLASS_CAST ((klass), CHROMA_TYPE_LIST, ChromaListClass))
#define CHROMA_IS_LIST(obj)               (G_TYPE_CHECK_INSTANCE_TYPE ((obj), CHROMA_TYPE_LIST))
#define CHROMA_IS_LIST_CLASS(klass)       (G_TYPE_CHECK_CLASS_TYPE ((klass), CHROMA_TYPE_LIST))
#define CHROMA_LIST_GET_CLASS(obj)        (G_TYPE_INSTANCE_GET_CLASS ((obj), CHROMA_TYPE_LIST, ChromaListClass))

typedef struct _ChromaList ChromaList;
typedef struct _ChromaListClass ChromaListClass;
typedef struct _ChromaListPrivate ChromaListPrivate;

struct _ChromaList {
        GtkWidget widget;

        ChromaListPrivate *priv;
};

struct _ChromaListClass {

        GtkWidgetClass parent_class;

        void (*changed)           (ChromaList *list);
        void (*row_activated)     (ChromaList *list, gint index);
        void (*cursor_position)   (ChromaList *list, gint index);
        void (*dnd)               (ChromaList *list, gint index, gchar **uri_strv);
};

typedef enum {
        CHROMA_LIST_ALIGN_LEFT,
        CHROMA_LIST_ALIGN_CENTER
} ChromaListAlignMode;

typedef enum {
        CHROMA_LIST_DROP_ROWS,
        CHROMA_LIST_DROP_WHOLE,
} ChromaListDropMode;

/* This function will _transform_ the value eventually, so it's not const */
typedef void (*ChromaListCellDataFunc) (ChromaList      *self,
                                        GtkTreeModel    *model,
                                        GtkTreeIter     *iter,
                                        GValue          *value,
                                        gpointer         data);

typedef void (*ChromaListRowSwapFunc)  (GtkTreeModel    *model,
                                        gint             pos_1,
                                        gint             pos_2);

GType
chroma_list_get_type              (void);

GtkWidget*
chroma_list_new                   (void);

void
chroma_list_refresh               (ChromaList *self);

void
chroma_list_set_font              (ChromaList           *self,
                                   PangoFontDescription *font_desc);

gint
chroma_list_get_drop_position     (ChromaList       *self);

gint
chroma_list_get_n_item_display    (ChromaList       *self);

gint
chroma_list_get_length            (ChromaList       *self);

void
chroma_list_set_model             (ChromaList               *self,
                                   GtkTreeModel             *model,
                                   ChromaListRowSwapFunc     model_row_swap_func);

GtkTreeModel*
chroma_list_get_model             (ChromaList       *self);

ChromaListColumn*
chroma_list_get_column            (ChromaList       *self,
                                   gint              index);

void
chroma_list_set_cell_data_func    (ChromaList               *self,
                                   gint                      column,
                                   ChromaListCellDataFunc    cell_data_func,
                                   gpointer                  data);

void
chroma_list_set_column_xalign       (ChromaList         *self,
                                     gint                index,
                                     gdouble             xalign);

void
chroma_list_set_column_yalign       (ChromaList         *self,
                                     gint                index,
                                     gdouble             yalign);

void
chroma_list_set_column_visible      (ChromaList         *self,
                                     gint                index,
                                     gboolean            visible);


void
chroma_list_set_adjustment          (ChromaList         *self,
                                     ChromaVScrollbar   *adjustment);

void
chroma_list_set_column_width        (ChromaList         *self,
                                     gint                column,
                                     gdouble             width);

gdouble
chroma_list_get_column_width        (ChromaList         *self,
                                     gint                column);

gint
chroma_list_get_row_height          (ChromaList         *self);

void
chroma_list_set_column_header       (ChromaList         *self,
                                     gint                column,
                                     const gchar        *caption);

void
chroma_list_set_column_show_header  (ChromaList         *self,
                                     gint                column,
                                     gboolean            show);

void
chroma_list_set_use_numbers         (ChromaList         *self,
                                     gboolean            use_numbers);

void
chroma_list_set_drop_mode           (ChromaList         *self,
                                     ChromaListDropMode  mode);

void
chroma_list_scroll_to_offset        (ChromaList         *self,
                                     gint                offset_);

void
chroma_list_set_cursor_position     (ChromaList         *self,
                                     gint                offset_);

void
chroma_list_scroll_up		    (ChromaList		*self);

void
chroma_list_scroll_down		    (ChromaList		*self);

G_END_DECLS

#endif /* CHROMA_LIST_H */



