/* -*- Mode: C; tab-width: 8; indent-tabs-mode: nil; c-basic-offset: 8 -*- */
/*
 * Chroma widget set
 * (C) 2005 M. Derezynski <internalerror@gmail.com>
 */

#include <gtk/gtk.h>
#include <gtk/gtkrange.h>
#include <gtk/gtkscrollbar.h>
#include <math.h>

#include <chroma/chroma-vscrollbar.h>
#include <chroma/chroma-list.h>
#include "draw.h"

#define VS_ELMT_INNER_SPACING 2 

G_DEFINE_TYPE (ChromaVScrollbar, chroma_vscrollbar, GTK_TYPE_WIDGET)

static void chroma_vscrollbar_realize       (GtkWidget           *widget);
static void chroma_vscrollbar_size_allocate (GtkWidget           *widget,
					     GtkAllocation       *allocation);
static void chroma_vscrollbar_send_configure (GtkWidget     *widget);

static gboolean
chroma_vscrollbar_button_press (GtkWidget *self, GdkEventButton *event); 

static gboolean
chroma_vscrollbar_button_release (GtkWidget *self, GdkEventButton *event);

static gboolean
chroma_vscrollbar_scroll (GtkWidget *widget, GdkEventScroll *event);

#if 0
static gboolean
chroma_vscrollbar_key_press(GtkWidget *self, GdkEventKey *event);
#endif
 
static gboolean
chroma_vscrollbar_motion (GtkWidget *self, GdkEventMotion *event); 

static gboolean
chroma_vscrollbar_expose (GtkWidget *widget, GdkEventExpose *event);

typedef enum {
	AREA_NONE,
	AREA_SLIDER,
	AREA_STEPPER_UP,
	AREA_STEPPER_DOWN

} ChromaVScrollbarActiveArea;

typedef enum {
	CHROMA_V_SCROLLBAR_PROP_SLIDER_SIZE = 1,
	CHROMA_V_SCROLLBAR_PROP_POSITION,
	CHROMA_V_SCROLLBAR_PROP_POSITION_NOEMIT,

	CHROMA_V_SCROLLBAR_N_PROPERTIES
} ChromaVScrollbarProperties;

typedef enum {
    CHROMA_VSCROLLBAR_SIGNAL_POSITION,
    CHROMA_VSCROLLBAR_SIGNAL_STEP_UP,
    CHROMA_VSCROLLBAR_SIGNAL_STEP_DOWN,

    CHROMA_VSCROLLBAR_N_SIGNALS
} ChromaVScrollbarSignals;
static guint signals[CHROMA_VSCROLLBAR_N_SIGNALS] = {0};

#define MIN_SLIDER_HEIGHT 12

struct _ChromaVScrollbarPrivate
{
        gboolean dispose_has_run;

	gint     press_area;
	gint	 mouse_area;

	gdouble  size;	       // Range from 0.0 to 1.0, which is basically percent
	gdouble  position;     // Range from 0.0 to 1.0
};

static void
chroma_vscrollbar_init (ChromaVScrollbar *self)
{
    self->priv = g_new (ChromaVScrollbarPrivate, 1);

    self->priv->dispose_has_run = FALSE;
    self->priv->mouse_area = AREA_NONE;
    self->priv->press_area = AREA_NONE;
    self->priv->size = 1.0;
    self->priv->position = 0.0;
}

static void
chroma_vscrollbar_set_property (GObject      *object,
				guint         property_id,
				const GValue *value,
				GParamSpec   *pspec)
{
    ChromaVScrollbar *self = CHROMA_VSCROLLBAR(object);
    switch (property_id)
      {
	    case CHROMA_V_SCROLLBAR_PROP_SLIDER_SIZE:
	      {
		self->priv->size = g_value_get_double (value);
		gtk_widget_queue_draw (GTK_WIDGET(object));
	      }
	    break;

	    case CHROMA_V_SCROLLBAR_PROP_POSITION:
	      {
		self->priv->position = g_value_get_double (value);
	        g_signal_emit (object, signals[CHROMA_VSCROLLBAR_SIGNAL_POSITION], 0, self->priv->position);	
		gtk_widget_queue_draw (GTK_WIDGET(object));
	      }
	    break;

	    case CHROMA_V_SCROLLBAR_PROP_POSITION_NOEMIT:
	      {
		self->priv->position = g_value_get_double (value);
		gtk_widget_queue_draw (GTK_WIDGET(object));
	      }
	    break;

	    default:
	      {
		G_OBJECT_WARN_INVALID_PROPERTY_ID (object, property_id, pspec);
	      }
	    break;
      }
}

static void
chroma_vscrollbar_get_property (GObject      *object,
                        guint         property_id,
                        GValue       *value,
                        GParamSpec   *pspec)
{
    ChromaVScrollbar *self = CHROMA_VSCROLLBAR(object);
    switch (property_id)
      {
	    case CHROMA_V_SCROLLBAR_PROP_SLIDER_SIZE:
	      {
		g_value_set_double (value, self->priv->size); 
	      }
	    break;

	    case CHROMA_V_SCROLLBAR_PROP_POSITION:
	      {
		g_value_set_double (value, self->priv->position); 
	      }
	    break;

	    default:
	      {
		G_OBJECT_WARN_INVALID_PROPERTY_ID (object, property_id, pspec);
	      }
	    break;
      }
}

static GObject *
chroma_vscrollbar_constructor (GType                  type,
                       guint                  n_construct_properties,
                       GObjectConstructParam *construct_properties)
{
        GObject *obj;

        {
                /* Invoke parent constructor. */
                ChromaVScrollbarClass *klass;
                GObjectClass *parent_class;
                klass = CHROMA_VSCROLLBAR_CLASS (g_type_class_peek (CHROMA_TYPE_VSCROLLBAR));
                parent_class = G_OBJECT_CLASS (g_type_class_peek_parent (klass));
                obj = parent_class->constructor (type,
                                                 n_construct_properties,
                                                 construct_properties);
        }

        /* do stuff. */

        return obj;
}

static void
chroma_vscrollbar_dispose (GObject *obj)
{
        ChromaVScrollbar *self = (ChromaVScrollbar *)obj;

        if (self->priv->dispose_has_run) {
                /* If dispose did already run, return. */
                return;
        }
        /* Make sure dispose does not run twice. */
        self->priv->dispose_has_run = TRUE;

        /*
         * In dispose, you are supposed to free all types referenced from this
         * object which might themselves hold a reference to self. Generally,
         * the most simple solution is to unref all members on which you own a
         * reference.
         */
}

static void
chroma_vscrollbar_finalize (GObject *obj)
{
        ChromaVScrollbar *self = (ChromaVScrollbar *)obj;

        /*
         * Here, complete object destruction.
         * You might not need to do much...
         */
        g_free (self->priv);
}

GtkWidget*
chroma_vscrollbar_new (void)
{
  ChromaVScrollbar *scrollbar;

  scrollbar = g_object_new (chroma_vscrollbar_get_type (), NULL);

  return GTK_WIDGET(scrollbar); 
}

void
chroma_vscrollbar_set_grip_size (ChromaVScrollbar *self, gdouble size)
{
    gdouble slider_height   = 0.0, 
	    slider_area     = 0.0, 
	    boundary_top    = 0.0,
	    boundary_bottom = 0.0;

    g_return_if_fail (CHROMA_IS_VSCROLLBAR(self));

    slider_area     = GTK_WIDGET(self)->allocation.height - (2.0*GTK_WIDGET(self)->allocation.width) - (2.0*VS_ELMT_INNER_SPACING);
    slider_height   = slider_area * self->priv->size; 

    boundary_top    = (GTK_WIDGET(self)->allocation.width + VS_ELMT_INNER_SPACING);
    boundary_bottom = (GTK_WIDGET(self)->allocation.width + slider_area) - slider_height + VS_ELMT_INNER_SPACING;

    size = 1.0/size;

    if (size > 1.0) size = 1.;
    if (size < 0.0) size = 0.;

    g_object_set (G_OBJECT(self), "slider_size", size, NULL);

    gtk_widget_queue_draw (GTK_WIDGET(self));
}

static gboolean
chroma_vscrollbar_motion (GtkWidget *widget, GdkEventMotion *event)
{
    ChromaVScrollbar *self = CHROMA_VSCROLLBAR(widget);
    GdkModifierType state;
    gint x, y;
    gdouble slider_height   = 0.0, 
	    slider_area     = 0.0, 
	    boundary_top    = 0.0,
	    boundary_bottom = 0.0,
	    position        = 0.0,
	    slider_y	    = 0.0,
	    percent	    = 0.0;

    if (event->is_hint)
	gdk_window_get_pointer (event->window, &x, &y, &state);
    else
      {
	x = event->x;
	y = event->y;
	state = event->state;
      }
 
    if (self->priv->press_area != AREA_SLIDER) return FALSE;

    slider_area     = widget->allocation.height - (2.0*GTK_WIDGET(self)->allocation.width) - (2.0*VS_ELMT_INNER_SPACING);
    slider_height   = slider_area * self->priv->size; 

    boundary_top    = (GTK_WIDGET(self)->allocation.width + VS_ELMT_INNER_SPACING);
    boundary_bottom = (GTK_WIDGET(self)->allocation.width + slider_area) - slider_height + VS_ELMT_INNER_SPACING;

    slider_y = y - boundary_top-(slider_height/2.0);
    percent  = (boundary_bottom - boundary_top)/100.0;
    position = (slider_y / percent)/100.0;

    if (position < 0) position = 0;
    if (position > 1) position = 1;

    g_object_set (G_OBJECT(self), "position", position, NULL);

    return FALSE;
}

static gboolean
chroma_vscrollbar_button_release (GtkWidget *widget, GdkEventButton *event)
{
    ChromaVScrollbar *self = CHROMA_VSCROLLBAR(widget);

    g_return_val_if_fail (CHROMA_IS_VSCROLLBAR(self), FALSE);
    
    self->priv->press_area = AREA_NONE;
    gtk_widget_queue_draw (GTK_WIDGET(self));

    return FALSE;
}

static gboolean
chroma_vscrollbar_button_press (GtkWidget *widget, GdkEventButton *event)
{
    ChromaVScrollbar *self = CHROMA_VSCROLLBAR(widget);
    gdouble slider_height   = 0.0, 
	    slider_area     = 0.0, 
	    boundary_top    = 0.0,
	    boundary_bottom = 0.0,
	    slider_y	    = 0.0,
	    percent	    = 0.0;

    g_return_val_if_fail (CHROMA_IS_VSCROLLBAR(self), FALSE);

    slider_area     = widget->allocation.height - (2.0*GTK_WIDGET(self)->allocation.width) - (2.0*VS_ELMT_INNER_SPACING);
    slider_height   = slider_area * self->priv->size; 

    boundary_top    = (GTK_WIDGET(self)->allocation.width + VS_ELMT_INNER_SPACING);
    boundary_bottom = (GTK_WIDGET(self)->allocation.width + slider_area) - slider_height + VS_ELMT_INNER_SPACING;

    /* Check for 'a' stepper */
    if (event->y <= GTK_WIDGET(self)->allocation.width)
      {
	self->priv->press_area = AREA_STEPPER_UP;
	g_signal_emit (self, signals[CHROMA_VSCROLLBAR_SIGNAL_STEP_UP], 0);	
      }
    /* Check for 'd' stepper */
    else if (event->y >= (GTK_WIDGET(self)->allocation.height - GTK_WIDGET(self)->allocation.width))
      {
	self->priv->press_area = AREA_STEPPER_DOWN;
	g_signal_emit (self, signals[CHROMA_VSCROLLBAR_SIGNAL_STEP_DOWN], 0);	
      }
    /* Check for slider */
#if 0
    else if ( (event->y-(slider_height/2.0) >= boundary_top) && 
              (event->y-(slider_height/2.0) <= boundary_bottom) ) 
#endif
    else if ( (event->y > (GTK_WIDGET(self)->allocation.width + VS_ELMT_INNER_SPACING)) &&
	      (event->y < ((GTK_WIDGET(self)->allocation.height - GTK_WIDGET(self)->allocation.width) - VS_ELMT_INNER_SPACING)) )
      {
	gdouble position = 0.0;

	self->priv->press_area = AREA_SLIDER;

        slider_y = event->y - boundary_top-(slider_height/2.0);
        percent  = (boundary_bottom - boundary_top)/100.0;
        position = (slider_y / percent)/100.0;

        if (position < 0) position = 0;
	if (position > 1) position = 1;

	g_object_set (G_OBJECT(self), "position", position, NULL);
      }
    /* Must be some other area in between... */
    else
      {
	self->priv->press_area = AREA_NONE;
      }

    gtk_widget_queue_draw (GTK_WIDGET(self));
    return FALSE;
}

static gboolean
chroma_vscrollbar_scroll (GtkWidget *widget, GdkEventScroll *event)
{
    ChromaVScrollbar *self = CHROMA_VSCROLLBAR(widget);
    ChromaList *chroma_list;

    chroma_list = g_object_get_data (G_OBJECT(self), "list");

    if (chroma_list && CHROMA_IS_LIST(chroma_list))
      {
	if (event->direction == GDK_SCROLL_DOWN)
	  {
	    chroma_list_scroll_down (chroma_list);
	  }
	else
	if (event->direction == GDK_SCROLL_UP)
	  {
	    chroma_list_scroll_up   (chroma_list);
	  }
      }

    return FALSE;
}

static void
draw_stepper (cairo_t	   *cr,
	      GdkRectangle *rect,
	      GdkColor	   *color,
	      GtkArrowType  arrow_type,
	      gboolean	    clicked,
	      gboolean	    prelighted)
{
    gint x, y, w, h;

    x = rect->x;
    y = rect->y;
    w = rect->width;
    h = rect->height;

    if (clicked)
      {
	  chroma_draw_rounded_rectangle (cr, x, y, w, w, color, 0.2, 0.1, TRUE, 3);
      }

    chroma_draw_rounded_rectangle (cr, x, y, w, w, color, 1.0, 0.7, FALSE, 3);
    chroma_draw_arrow (cr, rect, color, arrow_type); 
}

static void
draw_slider (cairo_t *cr,
	     GdkRectangle *rect,
	     GdkColor *color,
	     gboolean clicked,
	     gboolean prelighted)
{
    gdouble xr, yr, wr, hr;

    xr = rect->x;
    yr = rect->y;
    wr = rect->width;
    hr = rect->height;

    chroma_draw_rounded_rectangle (cr, xr, yr, wr, hr, color, 0.2, 0.1, TRUE, 3);
    chroma_draw_rounded_rectangle (cr, xr, yr, wr, hr, color, 1.0, 0.7, FALSE, 3);
}

static gboolean
chroma_vscrollbar_expose (GtkWidget *widget, GdkEventExpose *event)
{
    ChromaVScrollbar  *self = CHROMA_VSCROLLBAR(widget);
    GdkRectangle      *rect_a = NULL,
		      *rect_d = NULL,
		      *rect_slider = NULL;
    GdkColor	      *color = NULL;
    cairo_t	      *cr;

    gdouble slider_height   = 0.0, 
	    slider_area     = 0.0, 
	    boundary_top    = 0.0,
	    boundary_bottom = 0.0;

    g_return_val_if_fail (CHROMA_IS_VSCROLLBAR(self), FALSE);
	
    cr = gdk_cairo_create (GTK_WIDGET(self)->window);

    color = &(widget->style->fg[GTK_STATE_PRELIGHT]);

    rect_a = g_new0 (GdkRectangle,1);
    rect_d = g_new0 (GdkRectangle,1);
    rect_slider = g_new0 (GdkRectangle,1);

    slider_area     = widget->allocation.height - (2.0*GTK_WIDGET(self)->allocation.width) - (2.0*VS_ELMT_INNER_SPACING);
    slider_height   = slider_area * self->priv->size; 

    slider_height   = (slider_height < MIN_SLIDER_HEIGHT) ? MIN_SLIDER_HEIGHT : slider_height;

    boundary_top    = (GTK_WIDGET(self)->allocation.width + VS_ELMT_INNER_SPACING);
    boundary_bottom = (GTK_WIDGET(self)->allocation.width + slider_area) - slider_height + VS_ELMT_INNER_SPACING;

    rect_slider->x      = 1; 
    rect_slider->y      = boundary_top + ((slider_area-slider_height)*self->priv->position);
    rect_slider->width  = widget->allocation.width - 2; 
    rect_slider->height = slider_height - 2; 

    draw_slider (cr, 
		 rect_slider,
		 color, 
		 self->priv->press_area == AREA_SLIDER, 
                 self->priv->mouse_area == AREA_SLIDER);

    /* Rectangular steppah */
    rect_a->x = 1;
    rect_a->y = 1;
    rect_a->width = widget->allocation.width - 2;
    rect_a->height = widget->allocation.width - 1;

    rect_d->x = 1;
    rect_d->y = widget->allocation.height - widget->allocation.width - 1;
    rect_d->width = widget->allocation.width - 2;
    rect_d->height = widget->allocation.width - 1;

    /* 'a' stepper */
    draw_stepper (cr,
		  rect_a,
		  color,
		  GTK_ARROW_UP,
		  self->priv->press_area == AREA_STEPPER_UP, 
                  self->priv->mouse_area == AREA_STEPPER_UP);

    /* 'd' stepper */
    draw_stepper (cr,
		  rect_d,
		  color,
		  GTK_ARROW_DOWN,
		  self->priv->press_area == AREA_STEPPER_DOWN, 
                  self->priv->mouse_area == AREA_STEPPER_DOWN);

    cairo_destroy (cr);

    return FALSE;
}

static void
chroma_vscrollbar_realize (GtkWidget *widget)
{
  ChromaVScrollbar    *widget_list;
  GdkWindowAttr	       attributes;
  gint		       attributes_mask;

  g_return_if_fail (CHROMA_IS_VSCROLLBAR (widget));

  widget_list = CHROMA_VSCROLLBAR (widget);
  GTK_WIDGET_SET_FLAGS (widget, GTK_REALIZED);

  attributes.window_type = GDK_WINDOW_CHILD;
  attributes.x = widget->allocation.x;
  attributes.y = widget->allocation.y;
  attributes.width = widget->allocation.width;
  attributes.height = widget->allocation.height;
  attributes.wclass = GDK_INPUT_OUTPUT;
  attributes.visual = gtk_widget_get_visual (widget);
  attributes.colormap = gtk_widget_get_colormap (widget);
  attributes.event_mask = gtk_widget_get_events (widget) | GDK_EXPOSURE_MASK | GDK_ALL_EVENTS_MASK;

  attributes_mask = GDK_WA_X | GDK_WA_Y | GDK_WA_VISUAL | GDK_WA_COLORMAP;

  widget->window = gdk_window_new (gtk_widget_get_parent_window (widget), &attributes, attributes_mask);
  gdk_window_set_user_data (widget->window, widget_list);

  widget->style = gtk_style_attach (widget->style, widget->window);
  gtk_style_set_background (widget->style, widget->window, GTK_STATE_NORMAL);

  chroma_vscrollbar_send_configure (GTK_WIDGET(widget));
}

static void
chroma_vscrollbar_size_allocate (GtkWidget     *widget,
				GtkAllocation *allocation)
{
  g_return_if_fail (CHROMA_IS_VSCROLLBAR (widget));
  g_return_if_fail (allocation != NULL);

  widget->allocation = *allocation;

  if (GTK_WIDGET_REALIZED (widget))
    {
      gdk_window_move_resize (widget->window,
			      allocation->x, allocation->y,
			      allocation->width, allocation->height);

      chroma_vscrollbar_send_configure (GTK_WIDGET(widget));
    }
}

static void
chroma_vscrollbar_send_configure (GtkWidget *widget)
{
  GdkEvent *event = gdk_event_new (GDK_CONFIGURE);

  event->configure.window = g_object_ref (widget->window);
  event->configure.send_event = TRUE;
  event->configure.x = widget->allocation.x;
  event->configure.y = widget->allocation.y;
  event->configure.width = widget->allocation.width;
  event->configure.height = widget->allocation.height;

  gtk_widget_event (widget, event);
  gdk_event_free (event);
}

static void
chroma_vscrollbar_class_init (ChromaVScrollbarClass *g_class)
{
    GtkWidgetClass *widget_class = GTK_WIDGET_CLASS (g_class);
    GObjectClass *gobject_class = G_OBJECT_CLASS (g_class);

    gobject_class->set_property = chroma_vscrollbar_set_property;
    gobject_class->get_property = chroma_vscrollbar_get_property;
    gobject_class->dispose = chroma_vscrollbar_dispose;
    gobject_class->finalize = chroma_vscrollbar_finalize;
    gobject_class->constructor = chroma_vscrollbar_constructor;

    widget_class->realize = chroma_vscrollbar_realize;
    widget_class->size_allocate = chroma_vscrollbar_size_allocate;
    widget_class->expose_event = chroma_vscrollbar_expose;
    widget_class->motion_notify_event = chroma_vscrollbar_motion;
    widget_class->button_press_event = chroma_vscrollbar_button_press; 
    widget_class->button_release_event = chroma_vscrollbar_button_release;
    widget_class->scroll_event = chroma_vscrollbar_scroll;

    /* Properties */
    g_object_class_install_property(gobject_class,
                                    CHROMA_V_SCROLLBAR_PROP_SLIDER_SIZE,
				    g_param_spec_double ("slider_size",
						         "slider_size",
							 "slider_size", 0, 1.0, 1.0, G_PARAM_READWRITE));


    g_object_class_install_property(gobject_class,
				    CHROMA_V_SCROLLBAR_PROP_POSITION, 
				    g_param_spec_double ("position",
							 "position",
							 "position", 0, 1.0, 0, G_PARAM_READWRITE));

    g_object_class_install_property(gobject_class,
				    CHROMA_V_SCROLLBAR_PROP_POSITION_NOEMIT, 
				    g_param_spec_double ("position_noemit",
							 "position_noemit",
							 "position_noemit", 0, 1.0, 0, G_PARAM_WRITABLE));

    /* Signals */
    signals[CHROMA_VSCROLLBAR_SIGNAL_POSITION] =
        g_signal_new("position",
                     G_OBJECT_CLASS_TYPE(gobject_class),
                     G_SIGNAL_RUN_FIRST,
                     G_STRUCT_OFFSET(ChromaVScrollbarClass, position),
                     NULL, NULL,
                     g_cclosure_marshal_VOID__DOUBLE, G_TYPE_NONE, 1, G_TYPE_DOUBLE);

    signals[CHROMA_VSCROLLBAR_SIGNAL_STEP_UP] =
        g_signal_new("step_up",
                     G_OBJECT_CLASS_TYPE(gobject_class),
                     G_SIGNAL_RUN_FIRST,
                     G_STRUCT_OFFSET(ChromaVScrollbarClass, step_up),
                     NULL, NULL,
                     g_cclosure_marshal_VOID__VOID, G_TYPE_NONE, 0);

    signals[CHROMA_VSCROLLBAR_SIGNAL_STEP_DOWN] =
        g_signal_new("step_down",
                     G_OBJECT_CLASS_TYPE(gobject_class),
                     G_SIGNAL_RUN_FIRST,
                     G_STRUCT_OFFSET(ChromaVScrollbarClass, step_down),
                     NULL, NULL,
                     g_cclosure_marshal_VOID__VOID, G_TYPE_NONE, 0);

}
