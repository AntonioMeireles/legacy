/* -*- Mode: C; tab-width: 8; indent-tabs-mode: nil; c-basic-offset: 8 -*- */
/*
 * Chroma widget set
 * (C) 2005 M. Derezynski <internalerror@gmail.com>
 *
 */

#ifndef CHROMA_VSCROLLBAR_H
#define CHROMA_VSCROLLBAR_H

/*
 * Potentially, include other headers on which this header depends.
 */
#include <glib-object.h>

G_BEGIN_DECLS

#define CHROMA_TYPE_VSCROLLBAR            (chroma_vscrollbar_get_type ())
#define CHROMA_VSCROLLBAR(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), CHROMA_TYPE_VSCROLLBAR, ChromaVScrollbar))
#define CHROMA_VSCROLLBAR_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass), CHROMA_TYPE_VSCROLLBAR, ChromaVScrollbarClass))
#define CHROMA_IS_VSCROLLBAR(obj)         (GTK_CHECK_TYPE ((obj), CHROMA_TYPE_VSCROLLBAR))
#define CHROMA_IS_VSCROLLBAR_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass), CHROMA_TYPE_VSCROLLBAR))
#define CHROMA_VSCROLLBAR_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj), CHROMA_TYPE_VSCROLLBAR, ChromaVScrollbarClass))

typedef struct _ChromaVScrollbar ChromaVScrollbar;
typedef struct _ChromaVScrollbarClass ChromaVScrollbarClass;
typedef struct _ChromaVScrollbarPrivate ChromaVScrollbarPrivate;

struct _ChromaVScrollbar {
        GtkWidget parent;

        ChromaVScrollbarPrivate *priv;
};

struct _ChromaVScrollbarClass {
        GtkWidgetClass parent;

        void (*position)  (ChromaVScrollbar *self, gdouble position);

        void (*step_up)   (ChromaVScrollbar *self);
        void (*step_down) (ChromaVScrollbar *self);
};

/* used by CHROMA_TYPE_VSCROLLBAR */
GType
chroma_vscrollbar_get_type (void);

GtkWidget*
chroma_vscrollbar_new (void);

void
chroma_vscrollbar_set_grip_size (ChromaVScrollbar     *self,
                                 gdouble               size);

G_END_DECLS

#endif /* CHROMA_VSCROLLBAR_H */
