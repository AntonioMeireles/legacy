#include <gtk/gtk.h>

G_BEGIN_DECLS

//Designate dropped data types that we know and care about
enum {
    CL_DROP_PLAINTEXT,
    CL_DROP_URLENCODED,
    CL_DROP_STRING,
};

//Drag data format listing for gtk_drag_dest_set()
static const GtkTargetEntry cl_drop_types[] = {
    {"text/plain",		    0, CL_DROP_PLAINTEXT},
    {"text/uri-list",		    0, CL_DROP_URLENCODED},
    {"STRING",			    0, CL_DROP_STRING},
};

#define cl_drag_dest_set(widget) \
    gtk_drag_dest_set(widget, \
		      (GtkDestDefaults) (GTK_DEST_DEFAULT_MOTION | GTK_DEST_DEFAULT_DROP), \
		      cl_drop_types, 3, \
                      (GdkDragAction) (GDK_ACTION_MOVE | GDK_ACTION_COPY | GDK_ACTION_LINK | GDK_ACTION_ASK))

G_END_DECLS
