#include <stdlib.h>
#include <string.h>
#include <math.h>

#include <glib/gi18n.h>

#include <gtk/gtk.h>
#include <gdk/gdk.h>
#include <gdk/gdkx.h>
#include <X11/Xlib.h>

#include "draw.h"

void
chroma_gdk_color_to_rgba (GdkColor *color, double *r, double *g, double *b, double *a)
{
  *r = color->red   / 65535.0;
  *g = color->green / 65535.0;
  *b = color->blue  / 65535.0;
  *a = 1;
}

void
chroma_draw_polygon (cairo_t *cr, GdkColor *color, double alpha, CCoords points[], gint n_points, gboolean fill)
{
	gint n;
	double r,g,b,a;

 	cairo_set_line_width (cr, 1.0);
	chroma_gdk_color_to_rgba (color, &r, &g, &b, &a);

	cairo_move_to (cr, points[0].x, points[0].y);

	for (n = 1; n < n_points; n++)
		cairo_line_to (cr, points[n].x, points[n].y);

	cairo_line_to (cr, points[0].x, points[0].y);
	cairo_set_source_rgba (cr, r, g, b, alpha);

	if (fill)
		cairo_fill (cr);
	else
		cairo_stroke (cr);

	cairo_fill (cr);
}

void
chroma_draw_rounded_rectangle_pattern (cairo_t *cr, 
					    double xc, 
					    double yc, 
					    double _w, 
					    double _h, 
					    cairo_pattern_t *cr_pattern, 
					    double line_width, 
					    gboolean fill, 
					    gdouble rounding_offset)
{
    cairo_set_line_width (cr, line_width);

    cairo_move_to (cr, xc, yc+(rounding_offset*2));

    cairo_curve_to (cr, 	xc, yc+rounding_offset,
				xc, yc+0.5,
				xc+rounding_offset, yc+0.5);

    cairo_line_to  (cr, xc+_w-(rounding_offset*2), yc+0.5);

    cairo_curve_to (cr, xc+_w-rounding_offset, yc+0.5,
			xc+_w, yc+0.5,
			xc+_w, yc+rounding_offset);

    cairo_line_to (cr,  xc+_w, yc+_h-(rounding_offset*2));

    cairo_curve_to (cr, xc+_w, yc+_h-rounding_offset,
		        xc+_w, yc+_h-0.5,
			xc+_w-rounding_offset, yc+_h-0.5);

    cairo_line_to (cr, xc+(rounding_offset*2), yc+_h-0.5);

    cairo_curve_to (cr, xc+rounding_offset, yc+_h-0.5,
			xc, yc+_h-0.5,
			xc, yc+_h-rounding_offset);


    cairo_close_path (cr);
    cairo_set_source (cr, cr_pattern); 

    if (fill)
      cairo_fill (cr);
    else
      cairo_stroke (cr);
}

void
chroma_draw_rounded_rectangle (cairo_t *cr, 
				    double xc, 
				    double yc, 
				    double _w, 
				    double _h, 
				    GdkColor *color, 
				    double alpha, 
				    double line_width, 
				    gboolean fill, 
				    gdouble rounding_offset)
{
    double r, g, b, a;

    cairo_set_line_width (cr, line_width);

    cairo_move_to (cr, xc, yc+(rounding_offset*2));

    cairo_curve_to (cr, 	xc, yc+rounding_offset,
				xc, yc+0.5,
				xc+rounding_offset, yc+0.5);

    cairo_line_to  (cr, xc+_w-(rounding_offset*2), yc+0.5);

    cairo_curve_to (cr, xc+_w-rounding_offset, yc+0.5,
			xc+_w, yc+0.5,
			xc+_w, yc+rounding_offset);

    cairo_line_to (cr,  xc+_w, yc+_h-(rounding_offset*2));

    cairo_curve_to (cr, xc+_w, yc+_h-rounding_offset,
		        xc+_w, yc+_h-0.5,
			xc+_w-rounding_offset, yc+_h-0.5);

    cairo_line_to (cr, xc+(rounding_offset*2), yc+_h-0.5);

    cairo_curve_to (cr, xc+rounding_offset, yc+_h-0.5,
			xc, yc+_h-0.5,
			xc, yc+_h-rounding_offset);


    cairo_close_path (cr);
    chroma_gdk_color_to_rgba (color, &r, &g, &b, &a);
    cairo_set_source_rgba (cr, r, g, b, alpha);

    if (fill)
      cairo_fill (cr);
    else
      cairo_stroke (cr);
}

void
chroma_draw_rounded_rectangle_aqua	   (cairo_t *cr, 
				    double xc, 
				    double yc, 
				    double _w, 
				    double _h, 
				    GdkColor *color, 
				    double alpha, 
				    double line_width, 
				    gboolean fill, 
				    gdouble rounding_offset)
{
    double r, g, b, a;

    chroma_draw_rounded_rectangle (cr, xc, yc, _w, _h, color, alpha, line_width, fill, rounding_offset);

    cairo_set_line_width (cr, line_width);
    cairo_move_to (cr, xc, yc+(_h/2.2));
    cairo_curve_to (cr, 	xc, yc+rounding_offset,
				xc, yc+0.5,
				xc+rounding_offset, yc+0.5);
    cairo_line_to  (cr, xc+_w-(rounding_offset*2), yc+0.5);
    cairo_curve_to (cr, xc+_w-rounding_offset, yc+0.5,
			xc+_w, yc+0.5,
			xc+_w, yc+rounding_offset);
    cairo_line_to (cr,  xc+_w, yc+(_h/2.2));

    cairo_close_path (cr);
    chroma_gdk_color_to_rgba (color, &r, &g, &b, &a);
    cairo_set_source_rgba (cr, r, g, b, alpha+0.06);

    if (fill)
      {
	cairo_fill (cr);
      }
    else
      {
	cairo_stroke (cr);
      }
}

void
chroma_draw_arrow   (cairo_t		*cr,
	        GdkRectangle	*rect,
	        GdkColor	*color,
	        GtkArrowType	 arrow_type)
{
    CCoords points[3];
    gint x,y,w,h;
    
    x = rect->x;
    y = rect->y;
    w = rect->width;
    h = rect->height;

    switch (arrow_type)
	{
	    case GTK_ARROW_UP:
	      {
	        points[0].x = x+(w/2);
	        points[0].y = y+5;

	        points[1].x = x+w-3;
	        points[1].y = y+(h/2)+2;

	        points[2].x = x+3;
	        points[2].y = y+(h/2)+2;

		chroma_draw_polygon (cr, color, 0.8, points, 3, TRUE);
	      }
	    break;

	    case GTK_ARROW_DOWN:
	      {
	        points[0].x = x+(w/2);
	        points[0].y = (y+h)-4;

	        points[1].x = x+w-3;
	        points[1].y = (y+h/2)-1;

	        points[2].x = x+3;
	        points[2].y = (y+h/2)-1;

		chroma_draw_polygon (cr, color, 0.8, points, 3, TRUE);
	      }
	    break;

	    default: break;
       }
}

static void
ce_draw_insertion_cursor (GtkWidget        *widget,
		       GdkDrawable      *drawable,
		       GdkGC            *gc,
		       GdkRectangle     *location,
		       GtkTextDirection  direction,
		       gboolean          draw_arrow)
{
  gint stem_width;
  gint arrow_width;
  gint x, y;
  gint i;
  gfloat cursor_aspect_ratio;
  gint offset;
  
  g_return_if_fail (direction != GTK_TEXT_DIR_NONE);

  /* When changing the shape or size of the cursor here,
   * propagate the changes to gtktextview.c:text_window_invalidate_cursors().
   */

  gtk_widget_style_get (widget, "cursor-aspect-ratio", &cursor_aspect_ratio, NULL);
  
  stem_width = location->height * cursor_aspect_ratio + 1;
  arrow_width = stem_width + 1;

  /* put (stem_width % 2) on the proper side of the cursor */
  if (direction == GTK_TEXT_DIR_LTR)
    offset = stem_width / 2;
  else
    offset = stem_width - stem_width / 2;
  
  for (i = 0; i < stem_width; i++)
    gdk_draw_line (drawable, gc,
		   location->x + i - offset, location->y,
		   location->x + i - offset, location->y + location->height - 1);

  if (draw_arrow)
    {
      if (direction == GTK_TEXT_DIR_RTL)
        {
          x = location->x - offset - 1;
          y = location->y + location->height - arrow_width * 2 - arrow_width + 1;
  
          for (i = 0; i < arrow_width; i++)
            {
              gdk_draw_line (drawable, gc,
                             x, y + i + 1,
                             x, y + 2 * arrow_width - i - 1);
              x --;
            }
        }
      else if (direction == GTK_TEXT_DIR_LTR)
        {
          x = location->x + stem_width - offset;
          y = location->y + location->height - arrow_width * 2 - arrow_width + 1;
  
          for (i = 0; i < arrow_width; i++) 
            {
              gdk_draw_line (drawable, gc,
                             x, y + i + 1,
                             x, y + 2 * arrow_width - i - 1);
              x++;
            }
        }
    }
}

/**
 * gtk_draw_insertion_cursor:
 * @widget:  a #GtkWidget
 * @drawable: a #GdkDrawable 
 * @area: rectangle to which the output is clipped, or %NULL if the
 *        output should not be clipped
 * @location: location where to draw the cursor (@location->width is ignored)
 * @is_primary: if the cursor should be the primary cursor color.
 * @direction: whether the cursor is left-to-right or
 *             right-to-left. Should never be #GTK_TEXT_DIR_NONE
 * @draw_arrow: %TRUE to draw a directional arrow on the
 *        cursor. Should be %FALSE unless the cursor is split.
 * 
 * Draws a text caret on @drawable at @location. This is not a style function
 * but merely a convenience function for drawing the standard cursor shape.
 *
 * Since: 2.4
 **/
void
chroma_draw_insertion_cursor (GtkWidget        *widget,
			   GdkDrawable      *drawable,
			   GdkRectangle     *area,
			   GdkRectangle     *location,
			   gboolean          is_primary,
			   GtkTextDirection  direction,
			   gboolean          draw_arrow)
{
  GdkGC *gc;

  g_return_if_fail (GTK_IS_WIDGET (widget));
  g_return_if_fail (GDK_IS_DRAWABLE (drawable));
  g_return_if_fail (location != NULL);
  g_return_if_fail (direction != GTK_TEXT_DIR_NONE);

  gc = gdk_gc_new (widget->window); 
  gdk_gc_set_rgb_fg_color (gc, &(widget->style->text [GTK_STATE_ACTIVE]));
  
  if (area)
    gdk_gc_set_clip_rectangle (gc, area);
  
  ce_draw_insertion_cursor (widget, drawable, gc,
			 location, direction, draw_arrow);

  gdk_gc_destroy (gc); 

#if 0 
  if (area)
    gdk_gc_set_clip_rectangle (gc, NULL);
#endif
}
