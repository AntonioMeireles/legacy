#include <gtk/gtk.h>
#include <chroma/chroma-list-selection.h>

enum {
  PATH_SELECTED,
  PATH_UNSELECTED,
  PATH_REMOVING,
  
  SIG_LAST
};

static guint signals[SIG_LAST] = { 0 };

/* Container Plugin IFace */
static void
chroma_list_selection_base_init (gpointer g_class)
{
        static gboolean initialized = FALSE;

        if (!initialized)
	  {
	    signals[PATH_SELECTED] =
		g_signal_new ("path_selected",
                      CHROMA_TYPE_LIST_SELECTION,
                      G_SIGNAL_RUN_FIRST,
                      G_STRUCT_OFFSET (ChromaListSelectionInterface, path_selected),
                      NULL, NULL,
                      gtk_marshal_VOID__BOXED,
                      G_TYPE_NONE, 1,
                      GTK_TYPE_TREE_PATH);

	    signals[PATH_UNSELECTED] =
		g_signal_new ("path_unselected",
                      CHROMA_TYPE_LIST_SELECTION,
                      G_SIGNAL_RUN_FIRST,
                      G_STRUCT_OFFSET (ChromaListSelectionInterface, path_unselected),
                      NULL, NULL,
                      gtk_marshal_VOID__BOXED,
                      G_TYPE_NONE, 1,
                      GTK_TYPE_TREE_PATH);

	    signals[PATH_REMOVING] =
		g_signal_new ("path_removing",
                      CHROMA_TYPE_LIST_SELECTION,
                      G_SIGNAL_RUN_FIRST,
                      G_STRUCT_OFFSET (ChromaListSelectionInterface, path_removing),
                      NULL, NULL,
                      gtk_marshal_VOID__BOXED,
                      G_TYPE_NONE, 1,
                      GTK_TYPE_TREE_PATH);


                initialized = TRUE;
	  }
}

GType
chroma_list_selection_get_type (void)
{
        static GType type = 0;
        if (type == 0) {
                static const GTypeInfo info = {
                        sizeof (ChromaListSelectionInterface),
                        chroma_list_selection_base_init,   /* base_init */
                        NULL,   /* base_finalize */
                        NULL,   /* class_init */
                        NULL,   /* class_finalize */
                        NULL,   /* class_data */
                        0,
                        0,      /* n_preallocs */
                        NULL    /* instance_init */
                };
                type = g_type_register_static (G_TYPE_INTERFACE, "ChromaListSelectionInterface", &info, 0);
        }
        return type;
}

GtkTreePath*
chroma_list_selection_get_selected       (ChromaListSelectionInterface *self)
{
	g_return_val_if_fail (CHROMA_IS_LIST_SELECTION(self), NULL);

        return CHROMA_LIST_SELECTION_GET_IFACE (self)->get_selected (self);
}

GList*
chroma_list_selection_get_selected_paths (ChromaListSelectionInterface *self)
{
	g_return_val_if_fail (CHROMA_IS_LIST_SELECTION(self), NULL);

        return CHROMA_LIST_SELECTION_GET_IFACE (self)->get_selected_paths (self);
}

gboolean
chroma_list_selection_iter_get_selected (ChromaListSelectionInterface *self, 
					 GtkTreeIter		      *iter)
{
	g_return_val_if_fail (CHROMA_IS_LIST_SELECTION(self), FALSE);

        return CHROMA_LIST_SELECTION_GET_IFACE (self)->iter_get_selected (self, iter);
}

void
chroma_list_selection_iter_set_selected (ChromaListSelectionInterface	*self,
					 GtkTreeIter			*iter,
					 gboolean			 selected)
{
	g_return_if_fail (CHROMA_IS_LIST_SELECTION(self));

	CHROMA_LIST_SELECTION_GET_IFACE (self)->iter_set_selected (self, iter, selected);
}

gboolean
chroma_list_selection_path_get_selected (ChromaListSelectionInterface	*self,
				         GtkTreePath			*path)
{
	g_return_val_if_fail (CHROMA_IS_LIST_SELECTION(self), FALSE);

	return CHROMA_LIST_SELECTION_GET_IFACE (self)->path_get_selected (self, path);
}

void
chroma_list_selection_path_set_selected (ChromaListSelectionInterface	*self,
				         GtkTreePath			*path,
					 gboolean			 selected)
{
	g_return_if_fail (CHROMA_IS_LIST_SELECTION(self));

	CHROMA_LIST_SELECTION_GET_IFACE (self)->path_set_selected (self, path, selected);
}

void
chroma_list_selection_select_all   (ChromaListSelectionInterface *self)
{
	g_return_if_fail (CHROMA_IS_LIST_SELECTION(self));

	CHROMA_LIST_SELECTION_GET_IFACE (self)->select_all (self);
}

void
chroma_list_selection_unselect_all (ChromaListSelectionInterface *self)
{
	g_return_if_fail (CHROMA_IS_LIST_SELECTION(self));

	CHROMA_LIST_SELECTION_GET_IFACE (self)->unselect_all (self);
}

void
chroma_list_selection_remove_selected (ChromaListSelectionInterface *self)
{
	g_return_if_fail (CHROMA_IS_LIST_SELECTION(self));

	CHROMA_LIST_SELECTION_GET_IFACE (self)->remove_selected (self);
}

gboolean
chroma_list_selection_multiple_selected (ChromaListSelectionInterface *self)
{
	g_return_val_if_fail (CHROMA_IS_LIST_SELECTION(self), FALSE);

	return CHROMA_LIST_SELECTION_GET_IFACE (self)->multiple_selected (self);
}

void
chroma_list_selection_path_selected	  (ChromaListSelectionInterface	*self,
					   GtkTreePath			*path)
{
	g_return_if_fail (CHROMA_IS_LIST_SELECTION(self));
	g_signal_emit (self, signals[PATH_SELECTED], 0, path);
}

void
chroma_list_selection_path_unselected	  (ChromaListSelectionInterface	*self,
					   GtkTreePath			*path)
{
	g_return_if_fail (CHROMA_IS_LIST_SELECTION(self));
	g_signal_emit (self, signals[PATH_UNSELECTED], 0, path);
}

void
chroma_list_selection_path_removing	  (ChromaListSelectionInterface *self,
					   GtkTreePath		        *path)
{
	g_return_if_fail (CHROMA_IS_LIST_SELECTION(self));
	g_signal_emit (self, signals[PATH_REMOVING], 0, path);
}

