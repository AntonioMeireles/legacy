/* GTK - The GIMP Toolkit
 * Copyright (C) 1995-1997 Peter Mattis, Spencer Kimball and Josh MacDonald
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the
 * Free Software Foundation, Inc., 59 Temple Place - Suite 330,
 * Boston, MA 02111-1307, USA.
 */

/*
 * Modified by the GTK+ Team and others 1997-2000.  See the AUTHORS
 * file for a list of people on the GTK+ Team.  See the ChangeLog
 * files for a list of changes.  These files are distributed with
 * GTK+ at ftp://ftp.gtk.org/pub/gtk/. 
 */

#ifndef CHROMA_ENTRY_H
#define CHROMA_ENTRY_H


#include <gdk/gdk.h>
#include <gtk/gtkeditable.h>
#include <gtk/gtkimcontext.h>
#include <pango/pango.h>

G_BEGIN_DECLS

#define CHROMA_TYPE_ENTRY                  (chroma_entry_get_type ())
#define CHROMA_ENTRY(obj)                  (G_TYPE_CHECK_INSTANCE_CAST ((obj), CHROMA_TYPE_ENTRY, ChromaEntry))
#define CHROMA_ENTRY_CLASS(klass)          (G_TYPE_CHECK_CLASS_CAST ((klass), CHROMA_TYPE_ENTRY, ChromaEntryClass))
#define CHROMA_IS_ENTRY(obj)               (G_TYPE_CHECK_INSTANCE_TYPE ((obj), CHROMA_TYPE_ENTRY))
#define CHROMA_IS_ENTRY_CLASS(klass)       (G_TYPE_CHECK_CLASS_TYPE ((klass), CHROMA_TYPE_ENTRY))
#define CHROMA_ENTRY_GET_CLASS(obj)        (G_TYPE_INSTANCE_GET_CLASS ((obj), CHROMA_TYPE_ENTRY, ChromaEntryClass))


typedef struct _ChromaEntry       ChromaEntry;
typedef struct _ChromaEntryClass  ChromaEntryClass;

struct _ChromaEntry
{
  GtkWidget  widget;

  gchar     *text;

  guint      editable : 1;
  guint      visible  : 1;
  guint      overwrite_mode : 1;
  guint      in_drag : 1;	/* Dragging within the selection */

  guint16 text_length;	/* length in use, in chars */
  guint16 text_max_length;

  /*< private >*/
  GdkWindow *text_area;
  GtkIMContext *im_context;
  GtkWidget   *popup_menu;
  
  gint         current_pos;
  gint         selection_bound;
  
  PangoLayout *cached_layout;
  guint        cache_includes_preedit : 1;

  guint        need_im_reset : 1;

  guint        has_frame : 1;

  guint        activates_default : 1;

  guint        cursor_visible : 1;

  guint        in_click : 1;	/* Flag so we don't select all when clicking in entry to focus in */

  guint        is_cell_renderer : 1;
  guint        editing_canceled : 1; /* Only used by GtkCellRendererText */

  guint        mouse_cursor_obscured : 1;
  
  guint        select_words : 1;
  guint        select_lines : 1;
  guint        resolved_dir : 4; /* PangoDirection */
  guint   button;
  guint   blink_timeout;
  guint   recompute_idle;
  gint    scroll_offset;
  gint    ascent;	/* font ascent, in pango units  */
  gint    descent;	/* font descent, in pango units  */
  
  guint16 text_size;	/* allocated size, in bytes */
  guint16 n_bytes;	/* length in use, in bytes */

  guint16 preedit_length;	/* length of preedit string, in bytes */
  guint16 preedit_cursor;	/* offset of cursor within preedit string, in chars */

  gint dnd_position;		/* In chars, -1 == no DND cursor */

  gint drag_start_x;
  gint drag_start_y;
  
  gunichar invisible_char;

  gint width_chars;
};

struct _ChromaEntryClass
{
  GtkWidgetClass parent_class;

  /* Action signals
   */
  void (* activate)           (ChromaEntry       *entry);
  void (* move_cursor)        (ChromaEntry       *entry,
			       GtkMovementStep step,
			       gint            count,
			       gboolean        extend_selection);
  void (* insert_at_cursor)   (ChromaEntry       *entry,
			       const gchar    *str);
  void (* delete_from_cursor) (ChromaEntry       *entry,
			       GtkDeleteType   type,
			       gint            count);
  void (* backspace)          (ChromaEntry       *entry);
  void (* cut_clipboard)      (ChromaEntry       *entry);
  void (* copy_clipboard)     (ChromaEntry       *entry);
  void (* paste_clipboard)    (ChromaEntry       *entry);
  void (* toggle_overwrite)   (ChromaEntry       *entry);

  /* Padding for future expansion */
  void (*_gtk_reserved1) (void);
  void (*_gtk_reserved2) (void);
  void (*_gtk_reserved3) (void);
};

GType      chroma_entry_get_type       		(void) G_GNUC_CONST;
GtkWidget* chroma_entry_new            		(void);
void       chroma_entry_set_visibility 		(ChromaEntry      *entry,
						 gboolean       visible);

gboolean   chroma_entry_get_visibility             (ChromaEntry      *entry);

void       chroma_entry_set_invisible_char         (ChromaEntry      *entry,
						    gunichar       ch);

gunichar   chroma_entry_get_invisible_char         (ChromaEntry      *entry);

void       chroma_entry_set_has_frame              (ChromaEntry      *entry,
						    gboolean       setting);

gboolean   chroma_entry_get_has_frame              (ChromaEntry      *entry);

/* text is truncated if needed */
void       chroma_entry_set_max_length 		(ChromaEntry      *entry,
						 gint           max);

gint       chroma_entry_get_max_length             (ChromaEntry      *entry);

void       chroma_entry_set_activates_default      (ChromaEntry      *entry,
						    gboolean       setting);

gboolean   chroma_entry_get_activates_default      (ChromaEntry      *entry);

void       chroma_entry_set_width_chars            (ChromaEntry      *entry,
						    gint           n_chars);

gint       chroma_entry_get_width_chars            (ChromaEntry      *entry);

/* Somewhat more convenient than the GtkEditable generic functions
 */
void       chroma_entry_set_text                   (ChromaEntry      *entry,
						    const gchar   *text);

/* returns a reference to the text */
G_CONST_RETURN gchar* chroma_entry_get_text        (ChromaEntry      *entry);

PangoLayout* chroma_entry_get_layout               (ChromaEntry      *entry);
void         chroma_entry_get_layout_offsets       (ChromaEntry      *entry,
						    gint          *x,
						    gint          *y);

void       chroma_entry_set_alignment              (ChromaEntry      *entry,
						    gfloat         xalign);

gfloat     chroma_entry_get_alignment              (ChromaEntry      *entry);

gint       chroma_entry_layout_index_to_text_index (ChromaEntry      *entry,
						    gint           layout_index);

gint       chroma_entry_text_index_to_layout_index (ChromaEntry      *entry,
						    gint           text_index);

/* private */
void      _chroma_entry_get_borders                (ChromaEntry *entry,
						    gint     *xborder,
						    gint     *yborder);

G_END_DECLS

#endif /* CHROMA_ENTRY_H */
