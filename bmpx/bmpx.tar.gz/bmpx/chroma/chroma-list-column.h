#ifndef _CHROMA_LIST_COLUMN_H
#define _CHROMA_LIST_COLUMN_H

#include <glib-object.h>

G_BEGIN_DECLS

#define CHROMA_TYPE_LIST_COLUMN                 (chroma_list_column_get_type())
#define CHROMA_LIST_COLUMN(obj)                 (G_TYPE_CHECK_INSTANCE_CAST((obj),CHROMA_TYPE_LIST_COLUMN,ChromaListColumn))
#define CHROMA_LIST_COLUMN_CLASS(klass)         (G_TYPE_CHECK_CLASS_CAST((klass),CHROMA_TYPE_LIST_COLUMN,ChromaListColumnClass))
#define CHROMA_IS_LIST_COLUMN(obj)              (G_TYPE_CHECK_INSTANCE_TYPE ((obj), CHROMA_TYPE_LIST_COLUMN))
#define CHROMA_IS_LIST_COLUMN_CLASS(klass)      (G_TYPE_CHECK_CLASS_TYPE((klass),CHROMA_TYPE_LIST_COLUMN))
#define CHROMA_LIST_COLUMN_GET_CLASS(obj)       (G_TYPE_INSTANCE_GET_CLASS((obj),CHROMA_TYPE_LIST_COLUMN,ChromaListColumnClass))

typedef struct _ChromaListColumn ChromaListColumn;
typedef struct _ChromaListColumnClass ChromaListColumnClass;
typedef struct _ChromaListColumnPrivate ChromaListColumnPrivate;

struct _ChromaListColumn {
        GObject parent;

        ChromaListColumnPrivate *priv;
};

struct _ChromaListColumnClass {
        GObjectClass parent;

};

GType
chroma_list_column_get_type (void);

ChromaListColumn*
chroma_list_column_new (void);

/* The GValue must be a copy because it may be modified using a cell_data_func, see above */
gboolean
chroma_list_column_cell_render (ChromaListColumn        *self,
                                GtkWidget               *parent, 
                                GValue                  *value,
                                GdkDrawable             *drawable,
                                gint                     w,
                                gint                     x,
                                gint                     y);

G_END_DECLS

#endif
