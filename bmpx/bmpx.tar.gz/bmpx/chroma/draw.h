#ifndef _DRAW_UTIL_H
#define _DRAW_UTIL_H

#include <gtk/gtk.h>
#include <gdk/gdk.h>

typedef struct {
    double x;
    double y;
} CCoords;

void
chroma_draw_polygon	      (cairo_t	    *cr,
			       GdkColor	    *color,
			       double	     alpha,
			       CCoords	     points[],
			       gint	     n_points,
			       gboolean	     fill);

void
chroma_draw_rectangle_simple  (cairo_t	    *cr,
			       GdkColor	    *color,
			       double	     alpha,
			       gint	     x,
			       gint	     y,
			       gint	     width,
			       gint	     height);

void
chroma_draw_rounded_rectangle_pattern (cairo_t		 *cr, 
				       double		  xc, 
				       double		  yc, 
				       double		  _w, 
				       double		  _h, 
				       cairo_pattern_t   *cr_pattern, 
				       double		  line_width, 
				       gboolean		  fill, 
				       gdouble		  rounding_offset);

void
chroma_draw_rounded_rectangle (cairo_t		*cr, 
			       double		 xc, 
			       double		 yc, 
			       double		 _w, 
			       double		 _h, 
			       GdkColor	        *color, 
			       double		 alpha, 
			       double		 line_width, 
			       gboolean		 fill, 
			       gdouble		 rounding_offset);

void
chroma_draw_rounded_rectangle_aqua (cairo_t		*cr, 
				    double		 xc, 
				    double		 yc, 
				    double		 _w, 
				    double		 _h, 
				    GdkColor	        *color, 
				    double		 alpha, 
				    double		 line_width, 
				    gboolean		 fill, 
				    gdouble		 rounding_offset);


void
chroma_draw_arrow   (cairo_t		    *cr,
		     GdkRectangle	    *rect,
		     GdkColor		    *color,
		     GtkArrowType	     arrow_type);
 
void
chroma_gdk_color_to_rgba (GdkColor *color, double *r, double *g, double *b, double *a);

void
chroma_draw_insertion_cursor (GtkWidget        *widget,
			   GdkDrawable      *drawable,
			   GdkRectangle     *area,
			   GdkRectangle     *location,
			   gboolean          is_primary,
			   GtkTextDirection  direction,
			   gboolean          draw_arrow);

#endif
