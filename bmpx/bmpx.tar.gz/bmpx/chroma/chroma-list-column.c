#include <string.h>
#include <gtk/gtk.h>
#include <chroma/chroma-list-column.h>

G_DEFINE_TYPE (ChromaListColumn, chroma_list_column, G_TYPE_OBJECT)

typedef enum {

    // RW
    CHROMA_LIST_COLUMN_PROP_COLOR_FOREGROUND = 1,
    CHROMA_LIST_COLUMN_PROP_COLOR_BACKGROUND,
    CHROMA_LIST_COLUMN_PROP_FONT_DESCRIPTION,
    CHROMA_LIST_COLUMN_PROP_ROW_HEIGHT,
    CHROMA_LIST_COLUMN_PROP_XALIGN,
    CHROMA_LIST_COLUMN_PROP_YALIGN,

    CHROMA_LIST_COLUMN_PROP_NAME,
    CHROMA_LIST_COLUMN_PROP_SHOW_NAME,
    
    CHROMA_LIST_COLUMN_N_PROPERTIES 

} ChromaListColumnProperties;


struct _ChromaListColumnPrivate {

    gboolean			    disposed;

    GtkCellRenderer		   *r_text;
    GtkCellRenderer		   *r_pixbuf;

    /* Properties */
    
    // RO 
    gint			    cell_width;
    gint			    cell_height;

    // RW
    GdkColor			   *foreground;
    GdkColor			   *background;
    PangoFontDescription	   *font_description;
    gdouble			    xalign;
    gdouble			    yalign;
    gint			    row_height;
    gchar			   *name;
    gboolean			    show_name;
};

static void
chroma_list_column_set_property (GObject      *object,
				 guint         property_id,
				 const GValue *value,
				 GParamSpec   *pspec)
{
	ChromaListColumn *self = CHROMA_LIST_COLUMN(object);

        switch (property_id)
	  {
	    case CHROMA_LIST_COLUMN_PROP_COLOR_FOREGROUND:
	      {
		if (self->priv->foreground)
		    gdk_color_free (self->priv->foreground);

		self->priv->foreground = g_boxed_copy(GDK_TYPE_COLOR,g_value_get_boxed(value));
		g_object_set (self->priv->r_text, "foreground-gdk", self->priv->foreground, NULL);
	      } 
	    break;

	    case CHROMA_LIST_COLUMN_PROP_COLOR_BACKGROUND:
	      {
		if (self->priv->background)
		    gdk_color_free (self->priv->background);

		self->priv->background = g_boxed_copy(GDK_TYPE_COLOR,g_value_get_boxed(value));
		g_object_set (self->priv->r_text, "background-gdk", self->priv->background, NULL);
	      } 
	    break;

	    case CHROMA_LIST_COLUMN_PROP_FONT_DESCRIPTION:
	      {
		if (self->priv->font_description)
		    pango_font_description_free (self->priv->font_description);

		self->priv->font_description = g_boxed_copy(PANGO_TYPE_FONT_DESCRIPTION,g_value_get_boxed(value));
		g_object_set (self->priv->r_text, "font-desc", self->priv->font_description, NULL);
	      }
	    break;

	    case CHROMA_LIST_COLUMN_PROP_ROW_HEIGHT:
	      {
		self->priv->row_height = g_value_get_int (value);
	      }
	    break;

 	    case CHROMA_LIST_COLUMN_PROP_XALIGN:
	      {
		self->priv->xalign = g_value_get_double (value);
		g_object_set (self->priv->r_text, "xalign", self->priv->xalign, NULL);
	      }
	    break;

 	    case CHROMA_LIST_COLUMN_PROP_YALIGN:
	      {
		self->priv->yalign = g_value_get_double (value);
		g_object_set (self->priv->r_text, "yalign", self->priv->yalign, NULL);
	      }
	    break;

 	    case CHROMA_LIST_COLUMN_PROP_NAME:
	      {
		if (self->priv->name) g_free (self->priv->name);
		self->priv->name = g_value_dup_string (value);
	      }
	    break;

 	    case CHROMA_LIST_COLUMN_PROP_SHOW_NAME:
	      {
		self->priv->show_name = g_value_get_boolean (value);
	      }
	    break;

	    default: g_assert (FALSE); break;
          }
}

static void
chroma_list_column_get_property (GObject      *object,
				 guint         property_id,
				 GValue       *value,
				 GParamSpec   *pspec)
{
    ChromaListColumn *self = CHROMA_LIST_COLUMN (object);

        switch (property_id)
	  {
	    case CHROMA_LIST_COLUMN_PROP_COLOR_FOREGROUND:
	      {
		g_value_set_boxed (value, g_boxed_copy(GDK_TYPE_COLOR,self->priv->foreground));
	      } 
	    break;

	    case CHROMA_LIST_COLUMN_PROP_COLOR_BACKGROUND:
	      {
		g_value_set_boxed (value, g_boxed_copy(GDK_TYPE_COLOR,self->priv->background));
	      } 
	    break;

	    case CHROMA_LIST_COLUMN_PROP_FONT_DESCRIPTION:
	      {
		g_value_set_boxed (value, g_boxed_copy(PANGO_TYPE_FONT_DESCRIPTION,self->priv->font_description));
	      }
	    break;

	    case CHROMA_LIST_COLUMN_PROP_ROW_HEIGHT:
	      {
		g_value_set_int (value, self->priv->row_height);
	      }
	    break;

 	    case CHROMA_LIST_COLUMN_PROP_XALIGN:
	      {
		g_value_set_double (value, self->priv->xalign); 
	      }
	    break;

 	    case CHROMA_LIST_COLUMN_PROP_YALIGN:
	      {
		g_value_set_double (value, self->priv->yalign); 
	      }
	    break;

 	    case CHROMA_LIST_COLUMN_PROP_NAME:
	      {
		g_value_set_string (value, self->priv->name);
	      }
	    break;

 	    case CHROMA_LIST_COLUMN_PROP_SHOW_NAME:
	      {
		g_value_set_boolean (value, self->priv->show_name);
	      }
	    break;

	    default: g_assert (FALSE); break;
          }
}

static void
chroma_list_column_init (ChromaListColumn *self)
{
	self->priv = g_new(ChromaListColumnPrivate,1);

	self->priv->disposed = FALSE;

	self->priv->r_text = gtk_cell_renderer_text_new();
	g_object_set (self->priv->r_text, "background-set", TRUE, NULL); 

	self->priv->r_pixbuf = gtk_cell_renderer_pixbuf_new();

	self->priv->cell_width = 0;
	self->priv->cell_height = 0;
	self->priv->font_description = 0;
	self->priv->foreground = NULL;
	self->priv->background = NULL;
	self->priv->row_height = 0;
	self->priv->name = NULL;
	self->priv->show_name = FALSE;
}

static GObject*
chroma_list_column_constructor (GType                  type,
				guint                  n_construct_properties,
				GObjectConstructParam *construct_properties)
{
        GObject *obj;

        {
                ChromaListColumnClass *klass;
                GObjectClass *parent_class;
                klass = CHROMA_LIST_COLUMN_CLASS (g_type_class_peek (CHROMA_TYPE_LIST_COLUMN));
                parent_class = G_OBJECT_CLASS (g_type_class_peek_parent (klass));
                obj = parent_class->constructor (type,
                                                 n_construct_properties,
                                                 construct_properties);
        }

        return obj;
}

static void
chroma_list_column_dispose (GObject *obj)
{
        ChromaListColumn *self = (ChromaListColumn *)obj;

        if (self->priv->disposed)
	    return;

        self->priv->disposed = TRUE;
}

static void
chroma_list_column_finalize (GObject *obj)
{
        ChromaListColumn *self = (ChromaListColumn *)obj;

        g_free (self->priv);
}


static void
chroma_list_column_class_init (ChromaListColumnClass *g_class)
{
    GObjectClass *gobject_class = G_OBJECT_CLASS (g_class);
    GParamSpec *pspec = NULL;

    gobject_class->set_property = chroma_list_column_set_property;
    gobject_class->get_property = chroma_list_column_get_property;
    gobject_class->dispose      = chroma_list_column_dispose;
    gobject_class->finalize     = chroma_list_column_finalize;
    gobject_class->constructor  = chroma_list_column_constructor;

    /* Xalign */
    pspec = g_param_spec_double ("xalign",
                                 "xalign",
                                 "Cell xalign", 0, 1, 0, G_PARAM_READWRITE);
    g_object_class_install_property (gobject_class, CHROMA_LIST_COLUMN_PROP_XALIGN, pspec);

    /* Yalign */
    pspec = g_param_spec_double ("yalign",
                                 "yalign",
                                 "Cell yalign", 0, 1, 0.5, G_PARAM_READWRITE);
    g_object_class_install_property (gobject_class, CHROMA_LIST_COLUMN_PROP_YALIGN, pspec);

    /* Color FG */
    pspec = g_param_spec_boxed ("foreground",
                                "foreground",
                                "FG Color", GDK_TYPE_COLOR, G_PARAM_READWRITE); 
    g_object_class_install_property (gobject_class, CHROMA_LIST_COLUMN_PROP_COLOR_FOREGROUND, pspec);

    /* Color BG */
    pspec = g_param_spec_boxed ("background",
                                "background",
                                "BG Color", GDK_TYPE_COLOR, G_PARAM_READWRITE); 
    g_object_class_install_property (gobject_class, CHROMA_LIST_COLUMN_PROP_COLOR_BACKGROUND, pspec);

    /* Pango Font Description */
    pspec = g_param_spec_boxed ("font",
                                "font",
                                "Font Description", PANGO_TYPE_FONT_DESCRIPTION, G_PARAM_READWRITE); 
    g_object_class_install_property (gobject_class, CHROMA_LIST_COLUMN_PROP_FONT_DESCRIPTION, pspec);

    /* Row height */ 
    pspec = g_param_spec_int ("row_height",
                              "row_height",
                              "Row Height", 0, G_MAXINT, 0, G_PARAM_READWRITE); 
    g_object_class_install_property (gobject_class, CHROMA_LIST_COLUMN_PROP_ROW_HEIGHT, pspec);

    /* Name */ 
    pspec = g_param_spec_string ("name",
                                 "name",
                                 "Name", NULL, G_PARAM_READWRITE); 
    g_object_class_install_property (gobject_class, CHROMA_LIST_COLUMN_PROP_NAME, pspec);

    /* Show name */ 
    pspec = g_param_spec_boolean ("show_name",
                                  "show_name",
                                  "Show Name", FALSE, G_PARAM_READWRITE); 
    g_object_class_install_property (gobject_class, CHROMA_LIST_COLUMN_PROP_SHOW_NAME, pspec);

}

/* Load a new song from file */
ChromaListColumn*
chroma_list_column_new (void)
{
	ChromaListColumn* self;

	self = g_object_new(chroma_list_column_get_type(),NULL);

	return self;			
}

gboolean
chroma_list_column_cell_render (ChromaListColumn	*self,
				GtkWidget		*parent,
				GValue			*value,
				GdkDrawable		*drawable,
				gint			 w,
			        gint			 x,
			        gint		         y)
{
    GType type;

    g_return_val_if_fail (CHROMA_IS_LIST_COLUMN(self), FALSE);
    g_return_val_if_fail (value != NULL, FALSE);
    g_return_val_if_fail (GTK_IS_WIDGET(parent), FALSE);
    g_return_val_if_fail ((w > 0), FALSE);

    type = G_VALUE_TYPE (value);
    if ((type != G_TYPE_INT) && (type != G_TYPE_STRING) && (type != GDK_TYPE_PIXBUF))
      {
	// g_log (G_LOG_DOMAIN,G_LOG_LEVEL_CRITICAL,"%s: Unable to render data of type %s", G_STRLOC, g_type_name(type));
	return FALSE;
      }

    type = G_VALUE_TYPE (value);
    if ((type != G_TYPE_INT) && (type != G_TYPE_STRING) && (type != GDK_TYPE_PIXBUF))
      {
	// g_log (G_LOG_DOMAIN,G_LOG_LEVEL_CRITICAL,"%s: Unable to render data of type %s", G_STRLOC, g_type_name(type));
	return FALSE;
      }

    if (type == G_TYPE_STRING)
	  {
	    GdkRectangle *rect, *rect_cell;

	    rect = g_new0 (GdkRectangle,1);
	    rect_cell = g_new0 (GdkRectangle,1);

	    gtk_cell_renderer_set_fixed_size (self->priv->r_text,
					      w,
					      self->priv->row_height);

	    g_object_set (self->priv->r_text, "text", g_value_get_string (value), NULL);
	    g_object_set (self->priv->r_text, "ellipsize", PANGO_ELLIPSIZE_END, NULL); 
	    rect->x = x;
	    rect->y = y; 
	    rect->width  = w; 
	    rect->height = self->priv->row_height; 

	    memcpy (rect_cell, rect, sizeof(GdkRectangle));
	    rect_cell->width -= 8; // Some space between the cells, this *could* be maybe configurable too
	    rect_cell->x += 6;

	    gtk_cell_renderer_render (self->priv->r_text,
				      drawable, 
				      parent, 
				      rect,
				      rect_cell,
				      rect,
				      0);

	    g_free (rect);
	    g_free (rect_cell);
	  }
	else if (type == G_TYPE_INT)
	  {
	    GdkRectangle *rect, *rect_cell;
	    gchar *text;

	    rect = g_new0 (GdkRectangle,1);
	    rect_cell = g_new0 (GdkRectangle,1);

	    gtk_cell_renderer_set_fixed_size (self->priv->r_text,
					      w,
					      self->priv->row_height);

	    text = g_strdup_printf ("%d", g_value_get_int(value));
	    g_object_set (self->priv->r_text, "text", text, NULL);
	    g_object_set (self->priv->r_text, "ellipsize", PANGO_ELLIPSIZE_NONE, NULL); 
	    g_free (text);
	    rect->x = x;
	    rect->y = y; 
	    rect->width  = w; 
	    rect->height = self->priv->row_height; 

	    memcpy (rect_cell, rect, sizeof(GdkRectangle));
	    rect_cell->width -= 8; // Some space between the cells, this could be configurable too

	    gtk_cell_renderer_render (self->priv->r_text,
				      drawable,				      
				      parent, 
				      rect,
				      rect_cell,
				      rect,
				      0);
	    g_free (rect);
	    g_free (rect_cell);
	  }
#if 0
	else if (type == GDK_TYPE_PIXBUF)
	  {
	    GdkRectangle *rect;
	    GdkGC *gc;

	    rect = g_new0 (GdkRectangle,1);

	    gtk_cell_renderer_set_fixed_size (self->priv->r_text,
					      width,
					      self->priv->row_height);

	    g_object_set (self->priv->r_pixbuf, "pixbuf", GDK_PIXBUF(g_value_get_object(value)), NULL);

	    g_object_set (self->priv->r_pixbuf, "xalign", self->priv->xalign, NULL);
	    g_object_set (self->priv->r_pixbuf, "yalign", self->priv->yalign, NULL);
	    g_object_set (self->priv->r_pixbuf, "xpad", 0, NULL);
	    g_object_set (self->priv->r_pixbuf, "ypad", 0, NULL);

	    rect->x = 0;
	    rect->y = 0; 
	    rect->width  = width; 
	    rect->height = self->priv->row_height; 

	    if (self->priv->cell)
		g_object_unref (self->priv->cell);

	    self->priv->cell = gdk_pixmap_new (parent->window,
						  width,
						  self->priv->row_height,
						  gdk_drawable_get_depth(parent->window));

	    gc = gdk_gc_new (self->priv->cell);
	    gdk_gc_set_rgb_fg_color (gc, self->priv->background);
	    gdk_draw_rectangle (self->priv->cell,
			        gc,
				TRUE,
				0, 0,
			        width,
				self->priv->row_height);
	    gdk_gc_destroy (gc);
    
	    gtk_cell_renderer_render (self->priv->r_pixbuf,
				      self->priv->cell, 
				      parent, 
				      rect,
				      rect,
				      rect,
				      0);
	  }
#endif

    return TRUE;
}


