/* -*- Mode: C; tab-width: 8; indent-tabs-mode: nil; c-basic-offset: 8 -*- */
/*
 * Chroma widget set
 * (C) 2005 M. Derezynski <internalerror@gmail.com>
 *
 */

#ifndef _CHROMA_LIST_SELECTION_H
#define _CHROMA_LIST_SELECTION_H

/*
 * Potentially, include other headers on which this header depends.
 */

#include <gtk/gtk.h>
#include <gtk/gtkwidget.h>

G_BEGIN_DECLS

#define CHROMA_TYPE_LIST_SELECTION                (chroma_list_selection_get_type ())
#define CHROMA_LIST_SELECTION(obj)                (G_TYPE_CHECK_INSTANCE_CAST ((obj), CHROMA_TYPE_LIST_SELECTION, ChromaListSelectionInterface))
#define CHROMA_IS_LIST_SELECTION(obj)             (G_TYPE_CHECK_INSTANCE_TYPE ((obj), CHROMA_TYPE_LIST_SELECTION))
#define CHROMA_LIST_SELECTION_GET_IFACE(obj)      (G_TYPE_INSTANCE_GET_INTERFACE ((obj), CHROMA_TYPE_LIST_SELECTION, ChromaListSelectionInterface))

typedef struct _ChromaListSelection ChromaListSelection;
typedef struct _ChromaListSelectionInterface ChromaListSelectionInterface;

struct _ChromaListSelectionInterface {

        GTypeInterface parent_class;

        /* VMethods */
        GList*		(*get_selected_paths)   (ChromaListSelectionInterface *self);
        GtkTreePath*    (*get_selected)		(ChromaListSelectionInterface *self);
        gboolean	(*iter_get_selected)    (ChromaListSelectionInterface *self, GtkTreeIter *iter);
        void		(*iter_set_selected)    (ChromaListSelectionInterface *self, GtkTreeIter *iter, gboolean selected);
        gboolean	(*path_get_selected)    (ChromaListSelectionInterface *self, GtkTreePath *iter);
        void		(*path_set_selected)    (ChromaListSelectionInterface *self, GtkTreePath *iter, gboolean selected);

        void		(*select_all)           (ChromaListSelectionInterface *self);
        void		(*unselect_all)         (ChromaListSelectionInterface *self);

        void		(*remove_selected)      (ChromaListSelectionInterface *self);
        gboolean	(*multiple_selected)    (ChromaListSelectionInterface *self);

        /* Signals */
        void		(*path_selected)        (ChromaListSelectionInterface *self, GtkTreePath *path);
        void		(*path_unselected)      (ChromaListSelectionInterface *self, GtkTreePath *path);
        void		(*path_removing)        (ChromaListSelectionInterface *self, GtkTreePath *path);
};

GType
chroma_list_selection_get_type (void);

GList*
chroma_list_selection_get_selected_paths  (ChromaListSelectionInterface *self);

GtkTreePath*
chroma_list_selection_get_selected	  (ChromaListSelectionInterface *self);

gboolean
chroma_list_selection_iter_get_selected   (ChromaListSelectionInterface *self,
                                           GtkTreeIter                  *iter);

void
chroma_list_selection_iter_set_selected   (ChromaListSelectionInterface *self,
                                           GtkTreeIter                  *iter,
                                           gboolean                      selected);

gboolean
chroma_list_selection_path_get_selected   (ChromaListSelectionInterface *self,
                                           GtkTreePath                  *path);

void
chroma_list_selection_path_set_selected   (ChromaListSelectionInterface *self,
                                           GtkTreePath                  *path,
                                           gboolean                      selected);

void
chroma_list_selection_select_all          (ChromaListSelectionInterface *self);

void
chroma_list_selection_unselect_all        (ChromaListSelectionInterface *self);

void
chroma_list_selection_remove_selected     (ChromaListSelectionInterface *self);

gboolean
chroma_list_selection_multiple_selected   (ChromaListSelectionInterface *self);

/* Signal emissions */
void
chroma_list_selection_path_selected       (ChromaListSelectionInterface *self,
                                           GtkTreePath                  *path);

void
chroma_list_selection_path_unselected     (ChromaListSelectionInterface *self,
                                           GtkTreePath                  *path);

void
chroma_list_selection_path_removing	  (ChromaListSelectionInterface *self,
					   GtkTreePath		        *path);
	
G_END_DECLS

#endif /* CHROMA_LIST_SELECTION_H */
