/*  MCS
 *  Copyright (C) 2005-2006 M. Derezynski 
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License Version 2 as published
 *  by the Free Software Foundation.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 */

#include <config.h>

#include <libxml/tree.h>
#include <libxml/parser.h>
#include <libxml/xmlreader.h>
#include <libxml/xpath.h>
#include <libxml/xpathInternals.h>

#include <mcs/types.h>
#include <mcs/key.h>
#include <mcs/subscriber.h>
#include <mcs/mcs.h>

#include <iostream>
#include <sstream>
#include <fstream>

#include <boost/lexical_cast.hpp>

namespace {

//Auxilliaries for XPath queries

static int 
register_namespaces (xmlXPathContextPtr xpathCtx, const xmlChar* nsList)
{
    xmlChar* nsListDup;
    xmlChar* prefix;
    xmlChar* href;
    xmlChar* next;
    
    nsListDup = xmlStrdup(nsList);
    if(nsListDup == NULL)
    {
	fprintf(stderr, "Error: unable to strdup namespaces list\n");
	return(-1);	
    }
    
    next = nsListDup; 

    while (next != NULL)
    {
	/* skip spaces */
	while((*next) == ' ') next++;
	if((*next) == '\0') break;

	/* find prefix */
	prefix = next;
	next = (xmlChar*)xmlStrchr(next, '=');

	if(next == NULL)
	{
	    fprintf(stderr,"Error: invalid namespaces list format\n");
	    xmlFree(nsListDup);
	    return(-1);	
	}
	*(next++) = '\0';	
	
	/* find href */
	href = next;
	next = (xmlChar*)xmlStrchr(next, ' ');

	if(next != NULL)  
	{
	    *(next++) = '\0';	
	}

	/* do register namespace */
	if(xmlXPathRegisterNs(xpathCtx, prefix, href) != 0)
	{
	    fprintf(stderr,"Error: unable to register NS with prefix=\"%s\" and href=\"%s\"\n", prefix, href);
	    xmlFree(nsListDup);
	    return(-1);	
	}
    }
    
    xmlFree(nsListDup);

    return(0);
}

static xmlXPathObjectPtr
xml_execute_xpath_expression (xmlDocPtr	     doc, 
			      const xmlChar *xpathExpr,
                              const xmlChar *nsList)
{

    xmlXPathContextPtr xpathCtx;
    xmlXPathObjectPtr  xpathObj;

    /*
     * Create xpath evaluation context
     */
    xpathCtx = xmlXPathNewContext (doc);

    if (xpathCtx == NULL)
    {
         return NULL;
    }

    if (nsList)
    {
	register_namespaces (xpathCtx, nsList);
    }

    /*
     * Evaluate xpath expression
     */
    xpathObj = xmlXPathEvalExpression (xpathExpr, xpathCtx);
    if (xpathObj == NULL)
     {
         xmlXPathFreeContext (xpathCtx);
         return NULL;
     }

    /*
     * Cleanup
     */
    xmlXPathFreeContext (xpathCtx);

    return xpathObj;
}

};

namespace Mcs {

      Mcs::Mcs (const std::string& xml_filename, const std::string& root_node_name, double version) : xml_filename (xml_filename), root_node_name (root_node_name), version (version)
      {
      };

      Mcs::~Mcs ()
      {
	//Serialize the configuration into XML
	xmlDocPtr	  doc;
	xmlNodePtr	  root_node;
	std::stringstream version_str;

	doc = xmlNewDoc (BAD_CAST "1.0");
	version_str << this->version;

	//root node
	root_node = xmlNewNode (NULL, BAD_CAST root_node_name. c_str ());
	xmlSetProp (root_node, BAD_CAST "version", BAD_CAST (version_str. str(). c_str ()));
	xmlDocSetRootElement (doc, root_node);
    
	for (MDomains::iterator iter = domains. begin (); iter != domains. end (); iter++)
	  {
		std::string domain = (iter->first); 
		MKeys &keys = (iter->second);
		xmlNodePtr domain_node;

		//domain node
		domain_node = xmlNewNode (NULL, BAD_CAST "domain"); 
		xmlSetProp (domain_node, BAD_CAST("id"), BAD_CAST(domain. c_str ()));
		xmlAddChild (root_node, domain_node);
		
		for (MKeys::iterator iter = keys. begin (); iter !=  keys. end (); iter ++)
		  {
		      std::string key = iter->first; 
		      const KeyVariant &variant = (iter->second). get_value ();
		      KeyType type = (iter->second). get_type ();

		      xmlNodePtr key_node;
		      std::stringstream value_str;
		      std::string prop;

		      switch (type)
			{
			      case KEY_TYPE_INT:
				{
				  value_str << boost::get<int>(variant);
				  prop = "integer";
				  break;
				}

			      case KEY_TYPE_BOOL:
				{
				  value_str << (boost::get<bool>(variant) ? "TRUE" : "FALSE");
				  prop = "boolean";
				  break;
				}

			      case KEY_TYPE_STRING:
				{
				  value_str << boost::get<std::string>(variant);
				  prop = "string";
				  break;
				}

			      case KEY_TYPE_FLOAT:
				{
				  value_str << boost::get<double>(variant);
				  prop = "float";
				  break;
				}

			} // switch (type)	

		      key_node = xmlNewTextChild (domain_node, NULL, BAD_CAST ("key"), BAD_CAST (value_str. str (). c_str ())); 
		      xmlSetProp (key_node, BAD_CAST ("id"), BAD_CAST (key. c_str ()));
		      xmlSetProp (key_node, BAD_CAST ("type"), BAD_CAST (prop. c_str()));
		  }
	  }

	xmlChar *buffer;
	int len;
	xmlThrDefIndentTreeOutput (1);
	xmlKeepBlanksDefault (0);
	xmlDocDumpFormatMemoryEnc (doc, &buffer, &len, "utf-8", 1); 
	std::ofstream xml_doc_output (xml_filename. c_str ()); 
	xml_doc_output << reinterpret_cast<char*>(buffer);
	xml_doc_output. close ();
	delete buffer;
	xmlFreeDoc (doc);
      }; 

      void
      Mcs::load (VersionIgnore version_ignore)
      {
	  xmlDocPtr doc;
	  doc = xmlParseFile (xml_filename. c_str ());
	
	  if (!doc) throw Mcs::PARSE_ERROR;
  
	  //Traverse all registered keys and set the default value
	  for (MDomains::iterator iter = domains. begin (); iter != domains. end (); iter++)
	  {
		std::string domain = (iter->first); 
		MKeys &keys = (iter->second);

		for (MKeys::iterator iter = keys. begin (); iter !=  keys. end (); iter ++)
		  {
		      std::string key = (iter->first); 
		      KeyType type = (iter->second). get_type ();
		      Key &mkey = (iter->second);

		      KeyVariant variant;

		      std::stringstream xpath;
		      xmlXPathObjectPtr xpathObj;
		      std::string	nodeval;
		      char	       *nodeval_C;
		      
		      xpath << "/" << root_node_name << "/domain[@id='" << domain << "']/key[@id='" << key << "']";

		      xpathObj = xml_execute_xpath_expression (doc, BAD_CAST (xpath. str (). c_str ()), BAD_CAST ("mcs=http://beep-media-player.org/ns/mcs"));

		      if (!xpathObj)
			{
			  //g_log (G_LOG_DOMAIN, G_LOG_LEVEL_WARNING, "%s: No xpath result for '%s'", G_STRLOC, xpath. str (). c_str ());
			  mkey.unset ();
			  continue;
			}

		      if (!xpathObj->nodesetval)
			{
			  //g_log (G_LOG_DOMAIN, G_LOG_LEVEL_WARNING, "%s: No nodes in xpath result for '%s'", G_STRLOC, xpath. str (). c_str ());
			  mkey.unset ();
			  continue;
			}

		      if (!xpathObj->nodesetval->nodeNr)
			{
			  //g_log (G_LOG_DOMAIN, G_LOG_LEVEL_WARNING, "%s: Node count is zero for nodes in xpath result for '%s'", G_STRLOC, xpath. str (). c_str ());
			  mkey.unset ();
			  continue;
			}

		      if (xpathObj->nodesetval->nodeNr > 1) //XXX: There can only be ONE node!
			{
			  //g_log (G_LOG_DOMAIN, G_LOG_LEVEL_WARNING, "%s: More than one node found in xpath result for '%s'", G_STRLOC, xpath. str (). c_str ());
			  mkey.unset ();
			  continue;
			}

		      if (!xpathObj->nodesetval->nodeTab[0]->children)
			{
			  mkey.unset ();
			  continue;
			}

		      nodeval_C = reinterpret_cast<char*>(XML_GET_CONTENT(xpathObj->nodesetval->nodeTab[0]->children));
		      nodeval = nodeval_C;
		      delete nodeval_C;

		      switch (type)
			{
			      case KEY_TYPE_INT:
				{
				  variant = boost::lexical_cast<int>(nodeval);
    				  break;
				}

			      case KEY_TYPE_BOOL:
				{
				  variant = (!nodeval. compare ("TRUE")) ? true : false;
				  break;
				}

			      case KEY_TYPE_STRING:
				{
				  variant = std::string(nodeval);
				  break;
				}

			      case KEY_TYPE_FLOAT:
				{
				  variant = boost::lexical_cast<double>(nodeval);
				  break;
				}

			} // switch (type)	

			mkey. set_value (variant);

		      xmlXPathFreeObject (xpathObj);
		  }
	    } 

	  // xmlFreeDoc (doc);
      }

      bool
      Mcs::domain_key_exist (const std::string& domain, const std::string& key)
      {
	if (domains . find (domain) == domains . end()) return false;
	if (domains . find (domain)->second . find (key) == domains . find (domain)->second . end ()) return false;
	return true;
      }

      void 
      Mcs::register_domain (const std::string& domain)
      {
	if (domains. find (domain) == domains. end ())
	  {
	      domains[domain] = MKeys();
	      return; 
	  }
      }

      void
      Mcs::register_key (const std::string& domain, //Must be registered
                         const std::string& key,
                         const KeyVariant&  key_default,
			 KeyType	    key_type)
      {
	if (domains. find (domain) == domains. end()) return;
	domains. find (domain)->second[key] = Key ( domain, key, key_default, key_type );
      }

      void 
      Mcs::key_unset (const std::string& domain,
			 const std::string& key)
      {
	if (!domain_key_exist (domain, key)) return;
        return domains. find (domain)->second. find (key)->second. unset ();
      } 

      void 
      Mcs::subscribe (const std::string& name,   //Must be unique
                      const std::string& domain, //Must be registered 
                      const std::string& key,    //Must be registered,
                      SubscriberNotify   notify)
      {
	if (!domain_key_exist (domain, key)) return;
        return domains . find (domain)->second . find (key)->second . add_subscriber (name, notify);
      }

      void 
      Mcs::unsubscribe (const std::string& name,   //Must be unique
                        const std::string& domain, //Must be registered 
                        const std::string& key)    //Must be registered,
                        
      {
	if (!domain_key_exist (domain, key)) return;
        return domains . find (domain)->second . find (key)->second . remove_subscriber (name);
      }

};
