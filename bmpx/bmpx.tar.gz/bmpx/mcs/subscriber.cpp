#include <mcs/types.h>
#include <mcs/subscriber.h>

namespace Mcs {

      Subscriber::Subscriber (SubscriberNotify notify) : _notify (notify)
      {};

      Subscriber::Subscriber ()
      {};

      Subscriber::~Subscriber ()
      {
	_notify. disconnect ();
      }

      void
      Subscriber::notify (const std::string& domain, const std::string& key, const KeyVariant& value)
      {
	_notify (domain, key, value);
      }

};
