#include <gtkmm.h>
#include <mcs/types.h>
#include <mcs/key.h>
#include <mcs/mcs.h>
#include <mcs/gtk-bind.h>

namespace Mcs {

	Bind::Bind (Mcs::Mcs *mcs) : mcs (mcs) 
	{
	}	

	Bind::~Bind ()
	{
	}	

	//Gtk::SpinButton binding
	void
	Bind::spin_button_value_changed (Glib::RefPtr<Gtk::SpinButton>	spin_button,
					 const std::string&		domain,
					 const std::string&		key)
	{
	    KeyVariant key_value = spin_button->get_value_as_int ();
	    mcs->key_set (domain, key, key_value);
	}
	void
	Bind::bind_spin_button   (Glib::RefPtr<Gtk::SpinButton>  spin_button,
				  const std::string&	    domain,
				  const std::string&	    key)
	{
	    spin_button->signal_value_changed(). connect (sigc::bind (sigc::mem_fun(*this, &::Mcs::Bind::spin_button_value_changed), spin_button, domain, key));
	    spin_button->set_value (double(mcs->key_get<int>(domain, key)));
	}	

	//Gtk::Entry binding
	void
	Bind::entry_changed_cb (Glib::RefPtr<Gtk::Entry> entry,
			        const std::string&   domain,
			        const std::string&   key)
	{
	    KeyVariant key_value = std::string (entry->get_text ()); 
	    mcs->key_set (domain, key, key_value);
	}
	void
	Bind::bind_entry   (Glib::RefPtr<Gtk::Entry> entry,
			    const std::string& domain,
			    const std::string& key)
	{
	    entry->signal_changed(). connect (sigc::bind (sigc::mem_fun(*this, &::Mcs::Bind::entry_changed_cb), entry, domain, key));
	    entry->set_text (mcs->key_get<std::string>(domain, key));
	}	

	//Gtk::ToggleAction binding
	void
	Bind::action_toggled_cb (Glib::RefPtr<Gtk::ToggleAction> toggle_action,
			         const std::string&   domain,
			         const std::string&   key)
	{
	    KeyVariant key_value = toggle_action->get_active (); 
	    mcs->key_set (domain, key, key_value);
	}
	void
	Bind::bind_toggle_action (Glib::RefPtr<Gtk::ToggleAction> toggle_action,
				  const std::string&	 domain,
				  const std::string&   key)
	{
	    toggle_action->signal_toggled(). connect (sigc::bind (sigc::mem_fun(*this, &::Mcs::Bind::action_toggled_cb), toggle_action, domain, key));
	    toggle_action->set_active (mcs->key_get<bool>(domain, key));
	}	

	//Gtk::ToggleButton binding
	void
	Bind::button_toggled_cb (Glib::RefPtr<Gtk::ToggleButton> toggle_button,
			         const std::string&   domain,
			         const std::string&   key)
	{
	    KeyVariant key_value = toggle_button->get_active (); 
	    mcs->key_set (domain, key, key_value);
	}
	void
	Bind::bind_toggle_button (Glib::RefPtr<Gtk::ToggleButton> toggle_button,
				  const std::string&	 domain,
				  const std::string&	 key)
	{
	    toggle_button->signal_toggled(). connect (sigc::bind (sigc::mem_fun(*this, &::Mcs::Bind::button_toggled_cb), toggle_button, domain, key));
	    toggle_button->set_active (mcs->key_get<bool>(domain, key));
	}	

	//Gtk::FontButton binding
	void
	Bind::font_set_cb      (Glib::RefPtr<Gtk::FontButton> font_button,
			        const std::string&   domain,
			        const std::string&   key)
	{
	    KeyVariant key_value = std::string(font_button->get_font_name ()); 
	    mcs->key_set (domain, key, key_value);
	}
	void
	Bind::bind_font_button (Glib::RefPtr<Gtk::FontButton> font_button,
				const std::string&   domain,
				const std::string&   key)
	{
	    font_button->signal_font_set(). connect (sigc::bind (sigc::mem_fun(*this, &::Mcs::Bind::font_set_cb), font_button, domain, key));
	    font_button->property_font_name() = mcs->key_get<std::string>( domain, key);
	}	

	//Gtk::ComboBoxEntry binding
	void
	Bind::cbox_entry_changed_cb (Glib::RefPtr<Gtk::ComboBoxEntry> cbox_entry,
				     const std::string&   domain,
				     const std::string&   key)
	{
	    KeyVariant key_value = std::string(cbox_entry->get_entry()->get_text ()); 
	    mcs->key_set (domain, key, key_value);
	}

	void
	Bind::bind_cbox_entry 	(Glib::RefPtr<Gtk::ComboBoxEntry> cbox_entry,
				 const std::string&   domain,
				 const std::string&   key)
	{
	    cbox_entry->signal_changed(). connect (sigc::bind (sigc::mem_fun(*this, &::Mcs::Bind::cbox_entry_changed_cb), cbox_entry, domain, key));
	}

}; // Mcs
