
#ifndef HAVE_BMP

#include <mcs/config.h>
#if (1 != MCS_HAVE_GTK)
#  error "This MCS installation was built without GTK+ binding system support!"
#endif

#endif

#ifndef MCS_BIND_H
#define MCS_BIND_H

#include <gtkmm.h>
#include <mcs/base.h>

namespace Mcs {
  
      class Bind {

	public:

	  Bind (Mcs::Mcs *mcs);
	  ~Bind ();

	  void
	  spin_button_value_changed (Glib::RefPtr<Gtk::SpinButton>  spin_button,
				     const std::string&	    domain,
				     const std::string&	    key);
	  void
	  bind_spin_button	(Glib::RefPtr<Gtk::SpinButton>	    spin_button,
				 const std::string&		    domain,
				 const std::string&		    key);

	  void
	  bind_entry		(Glib::RefPtr<Gtk::Entry>	    entry,
				 const std::string&		    domain,
				 const std::string&		    key);
	  void
	  bind_toggle_action	(Glib::RefPtr<Gtk::ToggleAction>    toggle_action,
				 const std::string&		    domain,
				 const std::string&		    key);

	  void
	  bind_toggle_button	(Glib::RefPtr<Gtk::ToggleButton>    button,
				 const std::string&		    domain,
				 const std::string&		    key);

	  void
	  bind_font_button	(Glib::RefPtr<Gtk::FontButton>      font_button,
				 const std::string&		    domain,
				 const std::string&		    key);

	  void
	  bind_cbox_entry 	(Glib::RefPtr<Gtk::ComboBoxEntry>   cbox_entry,
				 const std::string&		    domain,
				 const std::string&		    key);

	private:
  
	  Mcs::Mcs *mcs;

	  void
	  entry_changed_cb	(Glib::RefPtr<Gtk::Entry>	  entry,
				 const std::string&		  domain,
				 const std::string&		  key);
	  void
	  action_toggled_cb     (Glib::RefPtr<Gtk::ToggleAction>  toggle_action,
			         const std::string&		  domain,
			         const std::string&		  key);

	  void
	  button_toggled_cb     (Glib::RefPtr<Gtk::ToggleButton>  toggle_button,
			         const std::string&		  domain,
			         const std::string&		  key);
	  void
	  font_set_cb		(Glib::RefPtr<Gtk::FontButton>    font_button,
			         const std::string&		  domain,
			         const std::string&		  key);

	  void
	  cbox_entry_changed_cb (Glib::RefPtr<Gtk::ComboBoxEntry> cbox_entry,
				 const std::string&		  domain,
				 const std::string&		  key);

      }; // Bind

}; // Mcs

#endif
