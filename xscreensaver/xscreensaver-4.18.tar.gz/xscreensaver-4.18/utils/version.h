static const char screensaver_id[] =
	"@(#)xscreensaver 4.18 (14-Aug-2004), by Jamie Zawinski (jwz@jwz.org)";
