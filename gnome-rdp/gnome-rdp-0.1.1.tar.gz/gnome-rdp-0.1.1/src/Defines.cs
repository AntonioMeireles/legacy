//
// Defines.cs
// Get the locale directory
//
// Authors: 
//	Martin Willemoes Hansen
//
// (C) 2004 Martin Willemoes Hansen
// 

namespace GnomeRDP {
	public struct Defines {
		public static string LOCALE_DIR = "/usr/local/share/locale";
		public static string VERSION = "0.1.1";
		public static string PACKAGE = "gnome-rdp";
	}			
}
