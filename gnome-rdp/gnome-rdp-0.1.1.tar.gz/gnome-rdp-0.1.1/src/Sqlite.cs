// created on 09/22/2005 at 18:33
using System;
using Gtk;
using Glade;
using System.Diagnostics;
using System.Data;
using Mono.Data.SqliteClient;
using System.Threading;
using Mono.Posix;

namespace GnomeRDP 
{
	public class Sqlite
	{
		private string ConnectionString;
		private IDbConnection dbcon;
		private IDbCommand dbcmd;	
		private IDataReader reader;
		private Window PWnd;
		
		public Sqlite(Window wnd)
		{
			this.PWnd = wnd;
		}
		
		public IDbConnection Connect(string connstr)
		{
			try
			{
				this.ConnectionString = "URI=file:" + connstr;
				this.dbcon = new SqliteConnection(this.ConnectionString);
				this.dbcon.Open();
			}
			catch
			{
				MessageDialog md = new MessageDialog(this.PWnd, DialogFlags.Modal, MessageType.Error, ButtonsType.Ok, Catalog.GetString("Error during the connection to database."));
				md.Run();
				md.Destroy();
				//System.Console.WriteLine("Error during the connection to database.");
			}
			this.dbcmd = this.dbcon.CreateCommand();
			return this.dbcon;
		}
		
		public bool Query(string query)
		{
			this.dbcmd.CommandText = query;
			try
			{
				this.reader = this.dbcmd.ExecuteReader();
				return true;
			}
			catch (System.Exception e)
			{
				MessageDialog md = new MessageDialog(this.PWnd, DialogFlags.Modal, MessageType.Error, ButtonsType.Ok, Catalog.GetString("Error:") + e.ToString());
				md.Run();
				md.Destroy();
				//System.Console.WriteLine("Error: " + e.ToString());
				return false;
			}
		}
		
		public bool FetchRow(out IDataReader result)
		{
			bool retval = false;
			
			try
			{
				if (reader.Read())
				{
					result = reader;
					retval = true;
				} 
				else 
				{
					result = null;
					retval = false;	
				}
			}
			catch
			{
				result = null;
				MessageDialog md = new MessageDialog(this.PWnd, DialogFlags.Modal, MessageType.Error, ButtonsType.Ok, Catalog.GetString("There was an error during reading of record."));
				md.Run();
				md.Destroy();				
				//System.Console.WriteLine("There was an error during reading of record.");
			}
			return retval;
		} 
		
		public void FreeResult()
		{
			this.reader.Close();
		}
		
		public void Close()
		{
			try
			{
				this.reader.Close();
			}
			catch {}
			this.dbcmd.Dispose();
			this.dbcon.Close();
		}
	}
}