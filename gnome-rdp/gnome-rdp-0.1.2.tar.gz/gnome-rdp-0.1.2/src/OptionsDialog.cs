// created on 09/21/2005 at 20:10
using System;
using Gtk;
using GtkSharp;
using Glade;

namespace GnomeRDP
{
	public class OptionsDialog : GladeDialog
	{
		[Widget]Image image6 = null;
		//[Widget]Label label18 = null;
		[Widget]ComboBox combobox1 = null;
		[Widget]ComboBox combobox2 = null;
		[Widget]ComboBox combobox3 = null;
		[Widget]ComboBox combobox6 = null;
		[Widget]ComboBox combobox7 = null;
		[Widget]ComboBox combobox8 = null;
		[Widget]ScrolledWindow scrolledwindow2;
		private TreeStore store = new TreeStore(typeof(string));
		private TreeView treeKeyboard;
		private TreeIter iter;
		private string[] keyboardList = {"ar", "da", "de", "de-ch", "en-gb", "en-us", "es", "et", +
			"fi", "fo", "fr", "fr-be", "fr-ca", "fr-ch", "hr", "hu", "is", "it", "ja", "ko", "lt", +
			"lv", "mk", "nl", "nl-be", "no", "pl", "pt", "pt-br", "ru", "sl", "sv", "th", "tr"};
		private Configuration cfg;
		
		public OptionsDialog (ref Configuration refCfg) : base ("dialog2")
		{
			TreeIter selIter;
			this.cfg = refCfg;
			treeKeyboard = new TreeView();
			treeKeyboard.HeadersVisible = false;
			treeKeyboard.AppendColumn("KEY", new CellRendererText(), "text", 0);
			selIter = iter;
			foreach (string keys in keyboardList)
			{
				iter = store.AppendValues(keys);
				if (keys == cfg.Cfg.keyboard_lang)
				{
					selIter = iter;
				}
			}
			treeKeyboard.Model = store;
			treeKeyboard.SetCursor(treeKeyboard.Model.GetPath(selIter), treeKeyboard.GetColumn(0), false); 	

			scrolledwindow2.Add(treeKeyboard);
			scrolledwindow2.ShowAll();
			image6.Pixbuf = Gdk.Pixbuf.LoadFromResource("colors_1.png");
			combobox2.Changed += new EventHandler(combobox2Changed);
			combobox1.Active = cfg.Cfg.sound_redirection;
			combobox2.Active = cfg.Cfg.color_depth;
			combobox3.Active = cfg.Cfg.screen_resolution;
			combobox6.Active = cfg.Cfg.connection_type;
			combobox7.Active = cfg.Cfg.window_mode;
			combobox8.Active = cfg.Cfg.terminal_size;
		}
		
		public int Run()
		{
			int retval = this.Dialog.Run();
			if ( retval == (int)Gtk.ResponseType.Ok )
			{
				TreeModel model = treeKeyboard.Model;
				treeKeyboard.Selection.GetSelected(out model, out iter);
				cfg.Cfg.color_depth = combobox2.Active;
				cfg.Cfg.screen_resolution = combobox3.Active;
				cfg.Cfg.sound_redirection = combobox1.Active;
				cfg.Cfg.keyboard_lang = (string)model.GetValue(iter, 0);
				cfg.Cfg.connection_type = combobox6.Active;
				cfg.Cfg.window_mode = combobox7.Active;
				cfg.Cfg.terminal_size = combobox8.Active;
			}
			this.Dialog.Destroy();
			return retval;
		}
		
		private void combobox2Changed (object sender, EventArgs a)
		{
			switch (combobox2.Active)
			{
				case 0:
					image6.Pixbuf = Gdk.Pixbuf.LoadFromResource("colors_1.png");
					break;
				case 1:
					image6.Pixbuf = Gdk.Pixbuf.LoadFromResource("colors_2.png");
					break;
				case 2:
					image6.Pixbuf = Gdk.Pixbuf.LoadFromResource("colors_3.png");
					break;
				case 3:
					image6.Pixbuf = Gdk.Pixbuf.LoadFromResource("colors_4.png");
					break;
					
			}
		} 
	}
}
