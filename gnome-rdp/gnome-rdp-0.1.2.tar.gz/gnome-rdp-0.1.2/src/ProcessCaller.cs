// created on 09/21/2005 at 18:15
using System;
using Gtk;
using GtkSharp;
using System.Threading;
using System.Diagnostics;
using System.IO;
using Mono.Posix;

namespace GnomeRDP 
{
	public class ProcessCaller
	{
		public Process process;
		public string FileName;
		public string Arguments;
		public string WorkingDirectory;
		public int SleepTime = 500;
		public bool CancelRequested = false;
		private Gtk.Window Wnd;
		
		public ProcessCaller()
		{
		}
		
		public void StartProcess(bool vnc, string passwd, Gtk.Window pwnd)
		{
			this.Wnd = pwnd;
			process = new Process();
			process.StartInfo.UseShellExecute = false;
			process.StartInfo.RedirectStandardOutput = true;
			process.StartInfo.RedirectStandardError = true;
			process.StartInfo.RedirectStandardInput = true;
			process.StartInfo.CreateNoWindow = false;
			process.StartInfo.FileName = this.FileName;
			process.StartInfo.Arguments = this.Arguments;
			process.StartInfo.WorkingDirectory = this.WorkingDirectory;
			process.Start();
			if (vnc)
			{
				process.StandardInput.WriteLine(passwd);
			}
			ThreadStart threadReadStdOutDelegate = new ThreadStart(ReadStdOut);
			Thread threadReadStdOut = new Thread(threadReadStdOutDelegate);
			threadReadStdOut.Start();
			ThreadStart threadReadStdErrDelegate = new ThreadStart(ReadStdErr);
			Thread threadReadStdErr = new Thread(threadReadStdErrDelegate);
			threadReadStdErr.Start();
			/*while (!process.HasExited)
			{
				
				Thread.Sleep(SleepTime);
				if (CancelRequested)
				{
					process.Kill();
				}
			}*/
		}
		
		public virtual void ReadStdOut()
		{
			//System.Console.WriteLine("StdOut: " + process.StandardOutput.ReadLine());
			string msg = process.StandardOutput.ReadLine();
			if (msg != null)
			{
				if (msg.Trim().Length > 0)
				{
					Gdk.Threads.Enter();
					MessageDialog md = new MessageDialog(this.Wnd, DialogFlags.Modal, MessageType.Info, ButtonsType.Close, msg);
					md.Run();
					md.Destroy();
					Gdk.Threads.Leave();
				}
			}										
		}
		
		public virtual void ReadStdErr()
		{
			//System.Console.WriteLine("StdErr: " + process.StandardError.ReadLine());
			string msg = process.StandardError.ReadLine();
			if (msg != null)
			{
				if (msg.Trim().Length > 0)
				{
					Gdk.Threads.Enter();
					MessageDialog md = new MessageDialog(this.Wnd, DialogFlags.Modal, MessageType.Info, ButtonsType.Close, msg);
					md.Run();
					md.Destroy();
					Gdk.Threads.Leave();
				}
			}													
		}
		
	}
}
