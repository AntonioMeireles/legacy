// created on 09/22/2005 at 12:54
using System;
using Gtk;
using GtkSharp;
using Glade;
using Vte;

namespace GnomeRDP
{
	public class TerminalDialog : GladeDialog
	{
		[Widget]VBox vbox11 = null;
		private Terminal term;
		
		public TerminalDialog() : base ("dialog3")
		{
			term = new Terminal();
			term.CursorBlinks = true;
			term.ScrollOnOutput = true;
			term.MouseAutohide = true;
			term.ScrollOnKeystroke = true;
 			term.BackgroundTransparent = true;
 			term.Encoding = "UTF-8";
			vbox11.PackStart(term);
			vbox11.ShowAll();
			//term.ChildExited += new EventHandler(OnChildExited);
		}
		/*
		public int Run(string cmd)
		{
			string[] argv = new string[] {""};
			string[] envv = {""};

			int pid = term.ForkCommand("ssh -t root@192.168.3.1", argv, envv, "/", false, true, true);
			int retval = this.Dialog.Run();
			this.Dialog.Destroy();
			return retval;
		}
		
		private void OnChildExited (object o, EventArgs args)
		{
			this.Dialog.Destroy();
		}
		*/
	}
}
