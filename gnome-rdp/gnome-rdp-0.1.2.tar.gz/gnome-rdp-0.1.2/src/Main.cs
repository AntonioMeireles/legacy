// project created on 09/20/2005 at 20:33
using System;
using Gtk;
using Glade;
using Gnome;
using System.Diagnostics;
using System.Data;
using Mono.Data.SqliteClient;
using System.Threading;
using Mono.Posix;

namespace GnomeRDP 
{
public class GladeApp
{
	[Widget]Image image1 = null;
	[Widget]Dialog dialog1 = null;
	[Widget]Button button1 = null;
	[Widget]Button button2 = null;
	[Widget]Button button3 = null;
	[Widget]Button button4 = null;
	[Widget]Button button5 = null;
	[Widget]Button button6 = null;
	[Widget]Button button7 = null;
	[Widget]ComboBoxEntry comboboxentry1 = null;
	[Widget]ComboBox combobox4 = null;
	[Widget]ComboBox combobox5 = null;
	[Widget]Gtk.Entry entry1 = null;
	[Widget]Gtk.Entry entry2 = null;
	[Widget]Gtk.Entry entry3 = null;
	[Widget]Gtk.Entry entry4 = null;
	[Widget]Label label5 = null;
	[Widget]Label label7 = null;
	[Widget]Label label6 = null;
	[Widget]CheckButton checkbutton1 = null;
	[Widget]ScrolledWindow scrolledwindow1 = null;
	private Gtk.Entry cbentry1;
	private string par = "";
	private ProcessCaller prc;
	private Configuration cfg; 
	private TreeStore storeSession = new TreeStore(typeof(string));
	private TreeView treeSession;
	private TreeIter iterSession;
	private string HOME = Environment.GetEnvironmentVariable("HOME");
	private IDataReader result;
	private Sqlite db;
	private int NORows;
	
	public static void Main (string[] args)
	{
		new GladeApp (args);
	}	

	public GladeApp (string[] args) 
	{
		Gdk.Threads.Init();
		Application.Init ();

		Glade.XML gxml = new Glade.XML (null, "gui.glade", "dialog1", "gnome-rdp");
		gxml.Autoconnect (this);
		cfg = new GnomeRDP.Configuration();

		Catalog.Init("gnome-rdp", GnomeRDP.Defines.LOCALE_DIR);
		if (!System.IO.File.Exists(HOME + "/.gnome-rdp.db"))
		{
			db = new Sqlite(this.dialog1);
			db.Connect(HOME + "/.gnome-rdp.db");
			db.Query("CREATE TABLE session (sessionname varchar(32), protocol int, computer varchar(32), user varchar(32), password varchar(32), domain varchar(32), srv_type int, color_depth int, screen_resolution int, sound_redirection int, keyboard_lang varchar(32), connection_type int, window_mode int, terminal_size int)");
			db.Close();
		}
		
		dialog1.Icon = Gdk.Pixbuf.LoadFromResource("gnome-rdp-icon.png");
		dialog1.SetDefaultSize(800, 50);
		dialog1.DeleteEvent += new Gtk.DeleteEventHandler(OnWindowDeleteEvent);
		dialog1.Title = "Gnome-RDP";
		dialog1.Resizable = true;
		cbentry1 = (Gtk.Entry)comboboxentry1.Child;
		image1.Pixbuf = Gdk.Pixbuf.LoadFromResource("title.png");
		button2.Clicked += new EventHandler(OnCancelClicked);
		button1.Clicked += new EventHandler(OnConnectClicked);
		button3.Clicked += new EventHandler(OnHelpClicked);
		button4.Clicked += new EventHandler(OnOptionsClicked);
		button5.Clicked += new EventHandler(OnLoadClicked);
		button6.Clicked += new EventHandler(OnSaveClicked);
		button7.Clicked += new EventHandler(OnDeleteClicked);
		button5.Sensitive = false;
		button6.Sensitive = false;
		button7.Sensitive = false;
		cbentry1.KeyReleaseEvent += new Gtk.KeyReleaseEventHandler(OnKeyReleaseEnter);
		entry1.KeyReleaseEvent += new Gtk.KeyReleaseEventHandler(OnKeyReleaseEnter);
		entry2.KeyReleaseEvent += new Gtk.KeyReleaseEventHandler(OnKeyReleaseEnter);
		entry3.KeyReleaseEvent += new Gtk.KeyReleaseEventHandler(OnKeyReleaseEnter);
		dialog1.WidgetEvent += new Gtk.WidgetEventHandler(OnWidgetEvent);
		entry4.Changed += new EventHandler(OnEntry4Changed);
		combobox5.Changed += new EventHandler(combobox5Changed);
		combobox4.Active = 1;
		combobox5.Active = 0;
		
		treeSession = new TreeView();
		treeSession.HeadersVisible = false;
		treeSession.AppendColumn(Catalog.GetString("Session name"), new CellRendererText(), "text", 0);
		this.RefreshSessionList();
		scrolledwindow1.Add(treeSession);
		treeSession.CursorChanged += new EventHandler(OnRowChanged);
		treeSession.RowActivated += new Gtk.RowActivatedHandler(OnRowActivated);
		scrolledwindow1.ShowAll();
		Gdk.Threads.Enter();
		Application.Run ();
		Gdk.Threads.Leave();
	}

	private void RefreshSessionList()
	{
		NORows = 0;
		storeSession.Clear();
		db = new Sqlite(this.dialog1);
		db.Connect(HOME + "/.gnome-rdp.db");
		db.Query("SELECT * FROM session ORDER BY sessionname");
		while (db.FetchRow(out result))
		{
			iterSession = storeSession.AppendValues(result[0]);
			NORows++;
		}
		treeSession.Model = storeSession;
		db.Close();			
	}

	public void DoWork()
	{
		//System.Console.WriteLine("Par: " + par);
		if (cfg.Cfg.protocol == 0)
		{
			prc = new ProcessCaller();
			prc.FileName = "rdesktop";
			prc.Arguments = par;
			prc.WorkingDirectory = "/";
			prc.StartProcess(false, "", this.dialog1);
		}
		if (cfg.Cfg.protocol == 1)
		{
			prc = new ProcessCaller();
			prc.FileName = "vncviewer";
			prc.Arguments = par;
			prc.WorkingDirectory = "/";
			prc.StartProcess(true, cfg.Cfg.password, this.dialog1);
		}
		if (cfg.Cfg.protocol == 2)
		{
			prc = new ProcessCaller();
			prc.FileName = "gnome-terminal";
			prc.Arguments = par;
			prc.WorkingDirectory = "/";
			prc.StartProcess(true, cfg.Cfg.password, this.dialog1);
		
			//TerminalDialog termWnd = new TerminalDialog();
			//termWnd.Run("ssh " + par);
		}
		this.dialog1.Hide();
		Gtk.Main.Iteration();
		Gtk.Main.IterationDo(false);		
		while (!prc.process.HasExited)
		{
			Thread.Sleep(prc.SleepTime);
			if (prc.CancelRequested)
			{
				prc.process.Kill();
			}
		}
		prc = null;
		this.dialog1.Show();
		Gtk.Main.IterationDo(true);		
	}
	
	// Connect the Signals defined in Glade
	private void OnWindowDeleteEvent (object sender, DeleteEventArgs a) 
	{
		Application.Quit ();
		a.RetVal = true;
	}

	private void OnCancelClicked (object sender, EventArgs a) 
	{
		Application.Quit ();
	}

	private void preConfiguration()
	{
		par = "";
		cfg.Cfg.computer = cbentry1.Text.Trim();
		cfg.Cfg.user = entry1.Text.Trim();
		cfg.Cfg.password = entry2.Text;
		cfg.Cfg.domain = entry3.Text.Trim();
		cfg.Cfg.protocol = combobox5.Active;
		cfg.Cfg.srv_type = combobox4.Active;
		cfg.Cfg.session_name = entry4.Text.Trim();
	}
	
	private void parseConfiguration()
	{
		if (cfg.Cfg.protocol == 0)
		{
			switch (cfg.Cfg.srv_type)
			{
				case 0:
					par += "-4";
					break;
				case 1:
					par += "-5";
					break;
			}
			
			if (cfg.Cfg.user.Length > 0) 
			{
				par += " -u " + cfg.Cfg.user;
			}
			if (cfg.Cfg.password.Length > 0) 
			{
				par += " -p " + cfg.Cfg.password;
			}
			if (cfg.Cfg.domain.Length > 0) 
			{
				par += " -d " + cfg.Cfg.domain;
			}
			switch (cfg.Cfg.color_depth) 
			{
				case 0:
					par += " -a 8";
					break;
				case 1:
					par += " -a 15";
					break;
				case 2:
					par += " -a 16";
					break;
				case 3:
					par += " -a 24";
					break;
			}
			switch (cfg.Cfg.screen_resolution)
			{
				case 0:
					par += " -g 640x480";
					break;
				case 1:
					par += " -g 800x600";
					break;
				case 2:
					par += " -f";
					break;
			}
			switch (cfg.Cfg.sound_redirection)
			{
				case 0:
					par += " -r sound:off";
					break;		
				case 1:
					par += " -0 -r sound:remote";
					break;
				case 2:
					par += " -0 -r sound:local";
					break;
			}
			par += " -k " + cfg.Cfg.keyboard_lang;		
			par += " " + cfg.Cfg.computer;
		}
		if (cfg.Cfg.protocol == 1)
		{
			if (cfg.Cfg.user.Length > 0) 
			{
				par += " -user" + cfg.Cfg.user;
			}
			if (cfg.Cfg.password.Length > 0) 
			{
				par += " -autopass";
			}
			if (cfg.Cfg.connection_type == 0)
			{
				par += " -viewonly";
			}
			if (cfg.Cfg.window_mode == 1)
			{
				par += " -fullscreen";
			}
			par += " -x11cursor " + cfg.Cfg.computer;
		}
		if (cfg.Cfg.protocol == 2)
		{
			par += "--command=\"ssh";
			if (cfg.Cfg.terminal_size == 1) 
			{
				par = " --full-screen --command=\"ssh";
			}						
			if (cfg.Cfg.user.Length > 0) 
			{
				par += " -l " + cfg.Cfg.user;
			}

			par += " " + cfg.Cfg.computer + "\"";
		}
	}
	
	private void LoadSession()
	{
		TreeModel model = treeSession.Model;
		treeSession.Selection.GetSelected(out model, out iterSession);
		cfg.Cfg.session_name = (string)model.GetValue(iterSession, 0);
		db = new Sqlite(this.dialog1);
		db.Connect(HOME + "/.gnome-rdp.db");
		db.Query("SELECT * FROM session WHERE sessionname = '" + cfg.Cfg.session_name + "'");
		if (db.FetchRow(out result))
		{
			cfg.Cfg.color_depth = Convert.ToInt32(result["color_depth"]);
			cfg.Cfg.computer = result["computer"].ToString();
			cfg.Cfg.connection_type = Convert.ToInt32(result["connection_type"]);
			cfg.Cfg.domain = result["domain"].ToString();
			cfg.Cfg.keyboard_lang = result["keyboard_lang"].ToString();
			cfg.Cfg.password = result["password"].ToString();
			cfg.Cfg.protocol = Convert.ToInt32(result["protocol"]);
			cfg.Cfg.screen_resolution = Convert.ToInt32(result["screen_resolution"]);
			cfg.Cfg.sound_redirection = Convert.ToInt32(result["sound_redirection"]);
			cfg.Cfg.srv_type = Convert.ToInt32(result["srv_type"]);
			cfg.Cfg.terminal_size = Convert.ToInt32(result["terminal_size"]);
			cfg.Cfg.user = result["user"].ToString();
			cfg.Cfg.window_mode = Convert.ToInt32(result["window_mode"]);
			entry4.Text = cfg.Cfg.session_name;
			cbentry1.Text = cfg.Cfg.computer;
			entry1.Text = cfg.Cfg.user;
			entry2.Text = cfg.Cfg.password;
			entry3.Text = cfg.Cfg.domain;
			combobox5.Active = cfg.Cfg.protocol;
			combobox4.Active = cfg.Cfg.srv_type;
		}
		db.Close();	
	}

	private void OnConnectClicked (object sender, EventArgs a) 
	{	
		this.preConfiguration();
		this.parseConfiguration();
		if (cfg.Cfg.computer.Length > 0) 
		{		
			DoWork();		
		} else {
			MessageDialog md = new MessageDialog(dialog1, DialogFlags.DestroyWithParent, MessageType.Error, ButtonsType.Close, "<b><big>" + Catalog.GetString("Computer isn't specified") + "</big></b>\n\n" + Catalog.GetString("Please specify the name or IP address of remote host."));
			md.Run();
			md.Destroy();
		}	
	}
	
	private void OnKeyReleaseEnter (object sender, KeyReleaseEventArgs a)
	{
		if (a.Event.Key == Gdk.Key.Return)
		{
			this.OnConnectClicked(this, EventArgs.Empty);
		}
	}
	
	private void OnOptionsClicked (object sender, EventArgs a)
	{
		OptionsDialog optionsDialog = new OptionsDialog(ref cfg);
		optionsDialog.Run();
	}
	
	private void OnSaveClicked (object sender, EventArgs a)
	{
		this.preConfiguration();
		if ((cfg.Cfg.session_name.Length > 0) && (cfg.Cfg.computer.Length > 0))
		{
			db = new Sqlite(this.dialog1);
			db.Connect(HOME + "/.gnome-rdp.db");
			db.Query("SELECT * FROM session WHERE sessionname = '" + cfg.Cfg.session_name + "'");
			if (!db.FetchRow(out result))
			{
				db.FreeResult();
				if (checkbutton1.Active)
				{
					db.Query("INSERT INTO session (sessionname, protocol, computer, user, password, domain, srv_type, " +
						"color_depth, screen_resolution, sound_redirection, keyboard_lang, connection_type, window_mode, " +
						"terminal_size) VALUES ('" + cfg.Cfg.session_name + "', " + cfg.Cfg.protocol + ", '" + cfg.Cfg.computer + 
						"', '" + cfg.Cfg.user + "', '" + cfg.Cfg.password + "', '" + cfg.Cfg.domain + "', " + cfg.Cfg.srv_type + ", " + cfg.Cfg.color_depth + 
						", " + cfg.Cfg.screen_resolution + ", " + cfg.Cfg.sound_redirection + ", '" + cfg.Cfg.keyboard_lang + 
						"', " + cfg.Cfg.connection_type + ", " + cfg.Cfg.window_mode + ", " + cfg.Cfg.terminal_size + ")");
				}
				else
				{
					db.Query("INSERT INTO session (sessionname, protocol, computer, user, password, domain, srv_type, " +
						"color_depth, screen_resolution, sound_redirection, keyboard_lang, connection_type, window_mode, " +
						"terminal_size) VALUES ('" + cfg.Cfg.session_name + "', " + cfg.Cfg.protocol + ", '" + cfg.Cfg.computer + 
						"', '" + cfg.Cfg.user + "', '', '" + cfg.Cfg.domain + "', " + cfg.Cfg.srv_type + ", " + cfg.Cfg.color_depth + 
						", " + cfg.Cfg.screen_resolution + ", " + cfg.Cfg.sound_redirection + ", '" + cfg.Cfg.keyboard_lang + 
						"', " + cfg.Cfg.connection_type + ", " + cfg.Cfg.window_mode + ", " + cfg.Cfg.terminal_size + ")");				
				}
			}
			else
			{
				MessageDialog md = new MessageDialog(dialog1, DialogFlags.DestroyWithParent, MessageType.Error, ButtonsType.Close, "<b><big>" + Catalog.GetString("Not unique session name") + "</big></b>\n\n" + Catalog.GetString("Please specify an unique session name."));
				md.Run();
				md.Destroy();									
			}
			db.Close();
			this.RefreshSessionList();
		}
		else
		{
			string msg = "<b><big>" + Catalog.GetString("Unknown error") + "</big></b>";
			if (cfg.Cfg.computer.Length <= 0)
			{
				msg = "<b><big>" + Catalog.GetString("Computer isn't specified") + "</big></b>\n\n" + Catalog.GetString("Please specify the name or IP address of remote host.");
			}
			else if (cfg.Cfg.session_name.Length <= 0)
			{
				msg = "<b><big>" + Catalog.GetString("Session name isn't specified") + "</big></b>\n\n" + Catalog.GetString("Please specify the name of the session.");
			}
			MessageDialog md = new MessageDialog(dialog1, DialogFlags.DestroyWithParent, MessageType.Error, ButtonsType.Close, msg);
			md.Run();
			md.Destroy();									
		}		
	}
	
	private void OnLoadClicked (object sender, EventArgs a)
	{
		this.LoadSession();
	}
	
	private void OnRowActivated(object sender, RowActivatedArgs a)
	{
		this.LoadSession();	
	}
	
	
	private void OnDeleteClicked (object sender, EventArgs a)
	{
		TreeModel model = treeSession.Model;
		treeSession.Selection.GetSelected(out model, out iterSession);
		string deleteSessionName = (string)model.GetValue(iterSession, 0);

		MessageDialog md = new MessageDialog(dialog1, DialogFlags.DestroyWithParent, MessageType.Question, ButtonsType.YesNo, "<b><big>" + Catalog.GetString("Confirm delete operation") + "</big></b>\n\n" + Catalog.GetString("Are you sure do you want to delete") + " '" + deleteSessionName + "' " + Catalog.GetString("session?"));
		int dresult = md.Run();
											
		if (dresult == (int)Gtk.ResponseType.Yes) 
		{
			db = new Sqlite(this.dialog1);
			db.Connect(HOME + "/.gnome-rdp.db");
			db.Query("DELETE FROM session WHERE sessionname = '" + deleteSessionName + "'");
			db.Close();
			this.RefreshSessionList();
			button5.Sensitive = false;
			button7.Sensitive = false;
		}
		md.Destroy();		
	}	
	
	private void OnRowChanged(object sender, EventArgs a)
	{	
	}
	
	
	private void OnEntry4Changed(object sender, EventArgs a)
	{
		if (entry4.Text.Trim().Length > 0)
		{
			button6.Sensitive = true;
		}
		else
		{
			button6.Sensitive = false;
		}
	}
		
	private void combobox5Changed (object sender, EventArgs a)
	{
		switch (combobox5.Active)
		{
			case 0:
				label5.Sensitive = true;
				entry1.Sensitive = true;
				label6.Sensitive = true;
				entry2.Sensitive = true;				
				label7.Sensitive = true;
				entry3.Sensitive = true;
				combobox4.Sensitive = true;	
				checkbutton1.Sensitive = true;
				break;
			case 1:
				label5.Sensitive = false;
				entry1.Sensitive = false;
				entry1.Text = "";
				label6.Sensitive = true;
				entry2.Sensitive = true;				
				label7.Sensitive = false;
				entry3.Sensitive = false;
				entry3.Text = "";
				combobox4.Sensitive = false;
				checkbutton1.Sensitive = true;	
				break;
			case 2:
				label5.Sensitive = true;
				entry1.Sensitive = true;
				label6.Sensitive = false;
				entry2.Sensitive = false;
				entry2.Text = "";				
				label7.Sensitive = false;
				entry3.Sensitive = false;
				entry3.Text = "";
				combobox4.Sensitive = false;
				checkbutton1.Sensitive = false;	
				break;												
		}
	}
	
	private void OnHelpClicked (object sender, EventArgs a)
	{
		string[] authors = {"Balazs Varkonyi <vbali@linuxforge.hu>"};
		string[] documenters = {""};
		Gdk.Pixbuf pixbuf = Gdk.Pixbuf.LoadFromResource("gnome-rdp.png");
		
		About ab = new Gnome.About(Defines.PACKAGE, Defines.VERSION, "Copyright (c) 2005 Balazs Varkonyi", "",
			authors, documenters, "", pixbuf);
		ab.Close += new EventHandler(OnAboutClose);
		ab.Run();
	}
	
	private void OnAboutClose(object sender, EventArgs a)
	{
	}
	
	private void OnWidgetEvent(object sender, WidgetEventArgs a)
	{
		TreeModel model = treeSession.Model;
		if ((treeSession.Selection.GetSelected(out model, out iterSession)) && (NORows > 0))
		{
			button5.Sensitive = true;
			button7.Sensitive = true;						
		}
		else
		{
			button5.Sensitive = false;
			button7.Sensitive = false;					
		}	
	}
}
}
