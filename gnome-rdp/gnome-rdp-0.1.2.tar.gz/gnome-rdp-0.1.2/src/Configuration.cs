// created on 09/22/2005 at 09:50
namespace GnomeRDP
{
	public class Configuration
	{
		public struct Config
		{
			public string session_name;
			public int protocol;
			public string computer;
			public string user;
			public string password;
			public string domain;
			public int srv_type;
			public int color_depth;
			public int screen_resolution;
			public int sound_redirection;
			public string keyboard_lang;
			public int connection_type;
			public int window_mode;
			public int terminal_size;
		}
		public Config Cfg;
	
		public Configuration()
		{
			Cfg = new Config();
			Cfg.keyboard_lang = "en-us";
		}
	}
}