

a = ['desktop-gnome', 'graphics', 'multimedia', 'multimedia']


