#! /bin/sh
genstrings *.m*
