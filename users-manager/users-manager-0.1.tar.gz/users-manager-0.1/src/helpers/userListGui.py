#!/usr/bin/python.2

## userListGui.py - show a list of existing users with gid > 500
## Copyright (C) 2003 Red Hat, Inc.
## Copyright (C) 2003 Brent Fox <bfox@redhat.com>

## This program is free software; you can redistribute it and/or modify
## it under the terms of the GNU General Public License as published by
## the Free Software Foundation; either version 2 of the License, or
## (at your option) any later version.

## This program is distributed in the hope that it will be useful,
## but WITHOUT ANY WARRANTY; without even the implied warranty of
## MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
## GNU General Public License for more details.

## You should have received a copy of the GNU General Public License
## along with this program; if not, write to the Free Software
## Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

## Author: Brent Fox

import gtk
import libuser
import signal
import gobject
import userHelperGui

#Allow <ctrl-c> to escape
if __name__ == "__main__":
    signal.signal (signal.SIGINT, signal.SIG_DFL)

##
## I18N
##
from rhpl.translate import _, N_
import rhpl.translate as translate
import rhpl.executil
domain = "redhat-config-users"
translate.textdomain (domain)

##
## Icon for windows
##

iconPixbuf = None      
try:
    iconPixbuf = gtk.gdk.pixbuf_new_from_file("/usr/share/redhat-config-users/pixmaps/redhat-config-users.png")
except:
    pass

class UserListGui:
    def destroy(self, args):
        if gtk.__dict__.has_key ("main_quit"):
            gtk.main_quit ()
        else:
            gtk.mainquit ()

    def __init__(self):
        self.admin = libuser.admin()

        self.mainWindow = gtk.Dialog()
        self.mainWindow.connect("destroy", self.destroy)
        self.mainWindow.set_title(_("Create a new user account"))
        self.mainWindow.set_border_width(10)
        self.mainWindow.set_position(gtk.WIN_POS_CENTER)

        self.nextButton = self.mainWindow.add_button('gtk-go-forward', 1)
        self.nextButton.connect("clicked", self.nextClicked)
        self.nextButton.set_sensitive(False)
        self.backButton = self.mainWindow.add_button('gtk-go-back', 2)
        self.backButton.connect("clicked", self.backClicked)
        self.finishButton = self.mainWindow.add_button('gtk-go-forward', 2)
        label = self.finishButton.get_children()[0].get_children()[0].get_children()[1]
        label.set_text(_("_Finish"))
        label.set_property("use_underline", True)
        self.finishButton.connect("clicked", self.finishClicked)

        self.notebook = gtk.Notebook()
        self.notebook.set_show_tabs(False)
        self.notebook.set_show_border(False)
         
        #Add icon to the top frame
        if iconPixbuf:
            self.mainWindow.set_icon(iconPixbuf)
            pixmap = gtk.Image()
            pixmap.set_from_pixbuf(iconPixbuf)

        self.userListVBox = gtk.VBox()
        self.userListVBox.set_border_width(5)
        self.userListVBox.set_spacing(10)

        titleHBox = gtk.HBox()
        titleHBox.pack_start(pixmap, False)

        label = gtk.Label("")
        label.set_markup("<span foreground='#000000' size='15000' font_family='Helvetica'><b>%s</b></span>" % (_("Choose the account you wish to change.")))
            
        label.set_line_wrap(True)
        label.set_alignment(0.0, 0.5)
        titleHBox.pack_start(label, True)
        self.userListVBox.pack_start(titleHBox, False, True)

        self.userStore = gtk.ListStore(gobject.TYPE_STRING, gobject.TYPE_PYOBJECT)
        self.userStore.set_sort_column_id(0, gtk.SORT_ASCENDING)

        userEntList = self.admin.enumerateUsersFull()
        for userEnt in userEntList:
            if userEnt.get(libuser.USERNAME)[0] != 'nfsnobody' and int(userEnt.get(libuser.UIDNUMBER)[0]) >= 500:
                iter = self.userStore.append()
                self.userStore.set_value(iter, 0, userEnt.get(libuser.USERNAME)[0])
                self.userStore.set_value(iter, 1, userEnt)                
        
        self.userView = gtk.TreeView(self.userStore)
        self.userView.get_selection().connect("changed", self.itemSelected)
        
        col = gtk.TreeViewColumn(None, gtk.CellRendererText(), text=0)
        self.userView.append_column(col)
        self.userView.set_property("headers-visible", False)
        self.userView.get_selection().set_mode(gtk.SELECTION_BROWSE)

        self.userViewSW = gtk.ScrolledWindow()
        self.userViewSW.set_policy(gtk.POLICY_AUTOMATIC, gtk.POLICY_AUTOMATIC)
        self.userViewSW.set_shadow_type(gtk.SHADOW_IN)
        self.userViewSW.add(self.userView)

        self.userListVBox.pack_start(self.userViewSW, True, 15)

        self.notebook.append_page(self.userListVBox, gtk.Label(""))

        #Add icon to the top frame
        if iconPixbuf:
            pixmap = gtk.Image()
            pixmap.set_from_pixbuf(iconPixbuf)

        self.editUserVBox = gtk.VBox()


        titleHBox = gtk.HBox()
        titleHBox.pack_start(pixmap, False)

        label = gtk.Label("")
        label.set_markup("<span foreground='#000000' size='15000' font_family='Helvetica'><b>%s</b></span>" % (_("Blah foo.")))
        label.set_line_wrap(True)
        label.set_alignment(0.0, 0.5)
        titleHBox.pack_start(label, True)
        self.editUserVBox.pack_start(titleHBox, False, True)
        
        self.usernameEntry = gtk.Entry()
        self.fullnameEntry = gtk.Entry()

        table = gtk.Table(2, 4)
        label = gtk.Label(_("_Username:"))
        label.set_use_underline(True)
        label.set_mnemonic_widget(self.usernameEntry)
        label.set_alignment(0.0, 0.5)
        table.attach(label, 0, 1, 0, 1, gtk.FILL)
        table.attach(self.usernameEntry, 1, 2, 0, 1, gtk.EXPAND | gtk.FILL, gtk.FILL, 5, 5)

        label = gtk.Label(_("Full Nam_e:"))
        label.set_use_underline(True)
        label.set_mnemonic_widget(self.fullnameEntry)
        label.set_alignment(0.0, 0.5)
        table.attach(label, 0, 1, 1, 2, gtk.FILL)
        table.attach(self.fullnameEntry, 1, 2, 1, 2, gtk.EXPAND | gtk.FILL, gtk.FILL, 5, 5)

        self.passwordButton = gtk.Button(_("Change password"))
        align = gtk.Alignment(1.0, 0.5)
        align.add(self.passwordButton)
        table.attach(align, 1, 2, 3, 4, gtk.FILL, gtk.FILL, 5, 5)

        self.editUserVBox.pack_start(table, True)
        self.notebook.append_page(self.editUserVBox, gtk.Label(""))

        #Remove the hsep from the dialog.  It's ugly
        hsep = self.mainWindow.get_children()[0].get_children()[0]
        self.mainWindow.get_children()[0].remove(hsep)

        self.mainWindow.vbox.pack_start(self.notebook)
        self.mainWindow.show_all()
        self.backButton.hide()
        self.finishButton.hide()
        if gtk.__dict__.has_key ("main"):
            gtk.main ()
        else:
            gtk.mainloop ()

    def nextClicked(self, *args):
        if self.userView.get_selection().get_selected():
            data, iter = userEnt = self.userView.get_selection().get_selected()
            userEnt = self.userStore.get_value(iter, 1)
            print userEnt.get(libuser.UIDNUMBER)
            self.usernameEntry.set_text(userEnt.get(libuser.USERNAME)[0])
            self.fullnameEntry.set_text(userEnt.get(libuser.GECOS)[0])

        self.notebook.set_current_page(1)
        self.backButton.show()
        self.finishButton.show()
        self.nextButton.hide()

    def backClicked(self, *args):
        self.notebook.set_current_page(0)
        self.backButton.hide()
        self.finishButton.hide()
        self.nextButton.show()
        
    def finishClicked(self, *args):
        if gtk.__dict__.has_key ("main_quit"):
            gtk.main_quit ()
        else:
            gtk.mainquit ()

    def itemSelected(self, *args):
        object, data = self.userView.get_selection().get_selected()        

        if data == None:
            self.nextButton.set_sensitive(False)
        else:
            self.nextButton.set_sensitive(True)
