#!/usr/bin/python.2

## userListGui.py - show a list of existing users with gid > 500
## Copyright (C) 2003 Red Hat, Inc.
## Copyright (C) 2003 Brent Fox <bfox@redhat.com>

## This program is free software; you can redistribute it and/or modify
## it under the terms of the GNU General Public License as published by
## the Free Software Foundation; either version 2 of the License, or
## (at your option) any later version.

## This program is distributed in the hope that it will be useful,
## but WITHOUT ANY WARRANTY; without even the implied warranty of
## MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
## GNU General Public License for more details.

## You should have received a copy of the GNU General Public License
## along with this program; if not, write to the Free Software
## Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

## Author: Brent Fox

import gtk
import libuser
import signal
import gobject
import os

#Allow <ctrl-c> to escape
if __name__ == "__main__":
    signal.signal (signal.SIGINT, signal.SIG_DFL)

##
## I18N
##
from rhpl.translate import _, N_
import rhpl.translate as translate
import rhpl.executil
domain = "users-manager"
translate.textdomain (domain)

##
## Icon for windows
##

iconPixbuf = None      
try:
    iconPixbuf = gtk.gdk.pixbuf_new_from_file("/usr/share/users-manager/pixmaps/users-manager.png")
except:
    pass

class DeleteUserGui:
    def destroy(self, args):
        if gtk.__dict__.has_key ("main_quit"):
            gtk.main_quit()
        else:
            gtk.mainquit()

    def __init__(self):
        self.admin = libuser.admin()

        self.mainWindow = gtk.Dialog()
        self.mainWindow.connect("destroy", self.destroy)
        self.mainWindow.set_title(_("Create a new user account"))
        self.mainWindow.set_border_width(10)
        self.mainWindow.set_position(gtk.WIN_POS_CENTER)

        self.cancelButton = self.mainWindow.add_button('gtk-cancel', 0)
        self.cancelButton.connect("clicked", self.destroy)        
        self.okButton = self.mainWindow.add_button('gtk-ok', 0)
        self.okButton.connect("clicked", self.okClicked)
         
        #Add icon to the top frame
        if iconPixbuf:
            self.mainWindow.set_icon(iconPixbuf)
            pixmap = gtk.Image()
            pixmap.set_from_pixbuf(iconPixbuf)

        internalVBox = gtk.VBox()
        internalVBox.set_border_width(5)
        internalVBox.set_spacing(10)

        titleHBox = gtk.HBox()
        titleHBox.pack_start(pixmap, False)

        label = gtk.Label("")
        label.set_markup("<span foreground='#000000' size='15000' font_family='Helvetica'><b>%s</b></span>" % (_("Choose the account you wish to delete.")))
            
        label.set_line_wrap(True)
        label.set_alignment(0.0, 0.5)
        titleHBox.pack_start(label, True)
        internalVBox.pack_start(titleHBox, False, True)

        self.userStore = gtk.ListStore(gobject.TYPE_STRING, gobject.TYPE_PYOBJECT)
        self.userStore.set_sort_column_id(0, gtk.SORT_ASCENDING)

        userEntList = self.admin.enumerateUsersFull()
        for userEnt in userEntList:
            if userEnt.get(libuser.USERNAME)[0] != 'nfsnobody' and int(userEnt.get(libuser.UIDNUMBER)[0]) >= 500:
                iter = self.userStore.append()
                self.userStore.set_value(iter, 0, userEnt.get(libuser.USERNAME)[0])
                self.userStore.set_value(iter, 1, userEnt)                
        
        self.userView = gtk.TreeView(self.userStore)
        col = gtk.TreeViewColumn(None, gtk.CellRendererText(), text=0)
        self.userView.append_column(col)
        self.userView.set_property("headers-visible", False)
        self.userView.get_selection().set_mode(gtk.SELECTION_BROWSE)

        self.userViewSW = gtk.ScrolledWindow()
        self.userViewSW.set_policy(gtk.POLICY_AUTOMATIC, gtk.POLICY_AUTOMATIC)
        self.userViewSW.set_shadow_type(gtk.SHADOW_IN)
        self.userViewSW.add(self.userView)

        internalVBox.pack_start(self.userViewSW, True, 15)

        #Remove the hsep from the dialog.  It's ugly
        hsep = self.mainWindow.get_children()[0].get_children()[0]
        self.mainWindow.get_children()[0].remove(hsep)
        
        self.mainWindow.vbox.pack_start(internalVBox)
        self.mainWindow.show_all()
        if gtk.__dict__.has_key ("main"):
            gtk.main ()
        else:
            gtk.mainloop ()

    def okClicked(self, *args):
        if self.userView.get_selection().get_selected():
            data, iter = userEnt = self.userView.get_selection().get_selected()
            userEnt = self.userStore.get_value(iter, 1)
            print userEnt.get(libuser.UIDNUMBER)

            user = userEnt.get(libuser.USERNAME)[0]
            homeDir = userEnt.get(libuser.HOMEDIRECTORY)[0]                    
            
            text = _("The user '%s' is about to be removed.  Are you sure you want to do this?" % user)
            dlg = gtk.MessageDialog(None, 0, gtk.MESSAGE_QUESTION, gtk.BUTTONS_YES_NO, text)
            dlg.set_position(gtk.WIN_POS_CENTER)
            dlg.set_modal(True)
            dlg.set_icon(iconPixbuf)
            homeDirCheckButton = None
            if os.access(homeDir, os.W_OK):
                #Only show this wiget if the homeDir exists in the first place
                homeDirCheckButton = gtk.CheckButton("Delete %s's home directory" % user)
                homeDirCheckButton.set_active(True)
                homeDirCheckButton.set_border_width(5)
                dlg.vbox.pack_start(homeDirCheckButton)
                dlg.show_all()

            rc = dlg.run()

            if rc == gtk.RESPONSE_NO:
                #bail out
                dlg.destroy()
                return
            else:
                #Ok, we're going to delete the user
                if homeDirCheckButton and homeDirCheckButton.get_active() == 1:
                    #Let's delete the home directory too
                    self.rmrf(homeDir)
                self.admin.deleteUser(userEnt)
                dlg.destroy()
            
        if gtk.__dict__.has_key ("main_quit"):
            gtk.main_quit()
        else:
            gtk.mainquit()

