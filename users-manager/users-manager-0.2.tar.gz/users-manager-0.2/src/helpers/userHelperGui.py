#!/usr/bin/python.2

## user_helper.py - generic helper for creating or modifying user accounts
## Copyright (C) 2003 Red Hat, Inc.
## Copyright (C) 2003 Brent Fox <bfox@redhat.com>

## This program is free software; you can redistribute it and/or modify
## it under the terms of the GNU General Public License as published by
## the Free Software Foundation; either version 2 of the License, or
## (at your option) any later version.

## This program is distributed in the hope that it will be useful,
## but WITHOUT ANY WARRANTY; without even the implied warranty of
## MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
## GNU General Public License for more details.

## You should have received a copy of the GNU General Public License
## along with this program; if not, write to the Free Software
## Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

## Author: Brent Fox

import gtk
import libuser
import signal
import sys

sys.path.append("/usr/share/redhat-config-users")
import asciiCheck
import messageDialog

#Allow <ctrl-c> to escape
if __name__ == "__main__":
    signal.signal (signal.SIGINT, signal.SIG_DFL)

##
## I18N
##
from rhpl.translate import _, N_
import rhpl.translate as translate
import rhpl.executil
domain = "redhat-config-users"
translate.textdomain (domain)

##
## Icon for windows
##

iconPixbuf = None      
try:
    iconPixbuf = gtk.gdk.pixbuf_new_from_file("/usr/share/redhat-config-users/pixmaps/redhat-config-users.png")
except:
    pass


class UserHelperGui:
    def destroy(self, args):
        if gtk.__dict__.has_key ("main_quit"):
            gtk.main_quit()
        else:
            gtk.mainquit()

    def createInternalVBox(self):
        self.usernameEntry = gtk.Entry()
        self.fullnameEntry = gtk.Entry()
        self.passwordEntry = gtk.Entry()
        self.passwordEntry.set_visibility(False)
        self.confirmEntry = gtk.Entry()
        self.confirmEntry.set_visibility(False)
        
        #Add icon to the top frame
        if iconPixbuf:
            pixmap = gtk.Image()
            pixmap.set_from_pixbuf(iconPixbuf)

        internalVBox = gtk.VBox()
        internalVBox.set_border_width(5)
        internalVBox.set_spacing(10)

        titleHBox = gtk.HBox()
        titleHBox.pack_start(pixmap, False)

        self.titleLabel = gtk.Label("")
        self.titleLabel.set_markup("<span foreground='#000000' size='15000' font_family='Helvetica'><b>%s</b></span>" % (_("Create a new user account")))

#        str = (_("Edit %s's account") % user)
#        self.titleLabel.set_markup("<span foreground='#000000' size='15000' font_family='Helvetica'><b>%s</b></span>" % (str))
            
        self.titleLabel.set_line_wrap(True)
        self.titleLabel.set_alignment(0.0, 0.5)
        titleHBox.pack_start(self.titleLabel, True)
        internalVBox.pack_start(titleHBox, False, True)

        label = gtk.Label(_("To create a new user account, enter the "
                            "username, full name, and password for the new user."))
        label.set_line_wrap(True)
        label.set_alignment(0.0, 0.5)
        internalVBox.pack_start(label, False)

        table = gtk.Table(2, 4)
        label = gtk.Label(_("_Username:"))
        label.set_use_underline(True)
        label.set_mnemonic_widget(self.usernameEntry)
        label.set_alignment(0.0, 0.5)
        table.attach(label, 0, 1, 0, 1, gtk.FILL)
        table.attach(self.usernameEntry, 1, 2, 0, 1, gtk.EXPAND | gtk.FILL, gtk.FILL, 5, 5)

        label = gtk.Label(_("Full Nam_e:"))
        label.set_use_underline(True)
        label.set_mnemonic_widget(self.fullnameEntry)
        label.set_alignment(0.0, 0.5)
        table.attach(label, 0, 1, 1, 2, gtk.FILL)
        table.attach(self.fullnameEntry, 1, 2, 1, 2, gtk.EXPAND | gtk.FILL, gtk.FILL, 5, 5)

        label = gtk.Label(_("_Password:"))
        label.set_use_underline(True)
        label.set_mnemonic_widget(self.passwordEntry)
        label.set_alignment(0.0, 0.5)
        table.attach(label, 0, 1, 2, 3, gtk.FILL)
        table.attach(self.passwordEntry, 1, 2, 2, 3, gtk.EXPAND | gtk.FILL, gtk.FILL, 5, 5)

        label = gtk.Label(_("Confir_m Password:"))
        label.set_use_underline(True)
        label.set_mnemonic_widget(self.confirmEntry)
        label.set_alignment(0.0, 0.5)
        table.attach(label, 0, 1, 3, 4, gtk.FILL)
        table.attach(self.confirmEntry, 1, 2, 3, 4, gtk.EXPAND | gtk.FILL, gtk.FILL, 5, 5)

        internalVBox.pack_start(table, False, 15)
        return internalVBox
    
    def __init__(self):
        self.admin = libuser.admin()

    def standAlone(self):
        self.mainWindow = gtk.Dialog()
        self.mainWindow.connect("destroy", self.destroy)
        self.mainWindow.set_title(_("Create a new user account"))
        self.mainWindow.set_border_width(10)
        self.mainWindow.set_position(gtk.WIN_POS_CENTER)

        #Set mainWindow icon
        if iconPixbuf:
            self.mainWindow.set_icon(iconPixbuf)

        self.cancelButton = self.mainWindow.add_button('gtk-cancel', 0)
        self.cancelButton.connect("clicked", self.destroy)        
        self.okButton = self.mainWindow.add_button('gtk-ok', 0)
        self.okButton.connect("clicked", self.okClicked)

        internalVBox = self.createInternalVBox()

        #Remove the hsep from the dialog.  It's ugly
        hsep = self.mainWindow.get_children()[0].get_children()[0]
        self.mainWindow.get_children()[0].remove(hsep)
        
        self.mainWindow.vbox.pack_start(internalVBox)
        self.mainWindow.show_all()
        if gtk.__dict__.has_key ("main"):
            gtk.main ()
        else:
            gtk.mainloop ()
        
    def okClicked(self, *args):
        userName = self.usernameEntry.get_text()
        fullName = self.fullnameEntry.get_text()
        pw = self.passwordEntry.get_text ()
        confirm = self.confirmEntry.get_text ()

        #Check for ascii-only strings
        if not asciiCheck.isUsernameOk(userName, self.usernameEntry):
            return

        if not asciiCheck.isNameOk(fullName, self.fullnameEntry):
            return

        if not asciiCheck.isPasswordOk(pw, self.passwordEntry):
            return

        if not asciiCheck.isPasswordOk(confirm, self.confirmEntry):
            return

        if userName == "":
            #The user name is blank, so complain
            messageDialog.show_message_dialog(_("Please specify a user name"))
            self.usernameEntry.grab_focus()
            return

        user = self.admin.lookupUserByName(userName)
        if user != None:
            #This user already exists, so complain
            messageDialog.show_message_dialog(_("An account with username '%s' already exists.") %userName)
            self.usernameEntry.set_text("")
            self.usernameEntry.grab_focus()
            return

        if pw == confirm and len (pw) >= 6:
            #If the passwords match, go on
            pass
        else:
            #The passwords don't match, so complain
            if not pw and not confirm:
                messageDialog.show_message_dialog(_("Please enter a password for the user."))
                self.passwordEntry.set_text("")
                self.confirmEntry.set_text("")                
                self.passwordEntry.grab_focus()
                return

            elif len (pw) < 6:
                messageDialog.show_message_dialog(_("The password is too short.  Please "
                                                    "use at least 6 characters."))
                self.passwordEntry.set_text("")
                self.confirmEntry.set_text("")                
                self.passwordEntry.grab_focus()
                return

            else:
                messageDialog.show_message_dialog(_("The passwords do not match."))
                self.passwordEntry.set_text("")
                self.confirmEntry.set_text("")                
                self.passwordEntry.grab_focus()
                return

        userEnt = self.admin.initUser(userName)
        userEnt.set(libuser.GECOS, [fullName])
        self.admin.addUser(userEnt)
        self.admin.setpassUser(userEnt, pw, 0)
        if gtk.__dict__.has_key ("main_quit"):
            gtk.main_quit ()
        else:
            gtk.mainquit ()

    def populateWidgets(self, userEnt):
        self.usernameEntry.set_text(userEnt.get(libuser.USERNAME)[0])
        self.fullnameEntry.set_text(userEnt.get(libuser.GECOS)[0])
        
