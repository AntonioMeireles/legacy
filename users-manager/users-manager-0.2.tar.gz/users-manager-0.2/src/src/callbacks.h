#include <gnome.h>


void
on_adminPrivCheck_toggled              (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_accountExpireCheck_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_accountLockCheck_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_pwExpireCheck_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_cancel_button_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_ok_button_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_add_user_activate                   (GtkMenuItem     *menuitem,
                                        gpointer         user_data);

void
on_add_group_activate                  (GtkMenuItem     *menuitem,
                                        gpointer         user_data);

void
on_properties_activate                 (GtkMenuItem     *menuitem,
                                        gpointer         user_data);

void
on_refreshButton_clicked               (GtkMenuItem     *menuitem,
                                        gpointer         user_data);

void
on_delete_activate                     (GtkMenuItem     *menuitem,
                                        gpointer         user_data);

void
on_exit_activate                       (GtkMenuItem     *menuitem,
                                        gpointer         user_data);

void
on_filter_activate                     (GtkMenuItem     *menuitem,
                                        gpointer         user_data);

void
on_manual_activate                     (GtkMenuItem     *menuitem,
                                        gpointer         user_data);

void
on_add_user_button_clicked             (GtkToolButton   *toolbutton,
                                        gpointer         user_data);

void
on_add_group_button_clicked            (GtkToolButton   *toolbutton,
                                        gpointer         user_data);

void
on_properties_button_clicked           (GtkToolButton   *toolbutton,
                                        gpointer         user_data);

void
on_delete_button_clicked               (GtkToolButton   *toolbutton,
                                        gpointer         user_data);

void
on_help_button_clicked                 (GtkToolButton   *toolbutton,
                                        gpointer         user_data);

void
on_filterEntry_activate                (GtkEntry        *entry,
                                        gpointer         user_data);

void
on_filterButton_clicked                (GtkButton       *button,
                                        gpointer         user_data);

gboolean
on_newUserNameEntry_focus_out_event    (GtkWidget       *widget,
                                        GdkEventFocus   *event,
                                        gpointer         user_data);

void
on_homeDirCheck_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_uidCheckButton_toggled              (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_userWin_cancel_button_clicked       (GtkButton       *button,
                                        gpointer         user_data);

void
on_userWin_ok_button_clicked           (GtkButton       *button,
                                        gpointer         user_data);
