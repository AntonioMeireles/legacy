#!/bin/bash
kids=(); 
let n=`perl -e 'print int(rand(256)),"\n";'`; 
echo $n ; 
for (( i=0, b=1; (i < 8) && ( ( i * 8 ) < n) ; i++, b <<=1  )) 
do 
if (( (n & b) == b )) ; then 
   (/usr/bin/dbus-send --system --dest=com.redhat.dhcp --type=method_call --print-reply --reply-timeout=20000 /com/redhat/dhcp/eth0 com.redhat.dhcp.up &);
    kids=(${kids[@]} $!); 
    echo -n 'UP '; 
else 
    (/usr/bin/dbus-send --system --dest=com.redhat.dhcp --type=method_call --print-reply --reply-timeout=20000 /com/redhat/dhcp/eth0 com.redhat.dhcp.down &);
    kids=(${kids[@]} $!); 
    echo -n 'DOWN '; 
fi; 
done; 
wait ${kids[@]};
sleep 4;
/usr/bin/dbus-send --system --dest=com.redhat.dhcp --type=method_call --print-reply --reply-timeout=20000 /com/redhat/dhcp/eth0 com.redhat.dhcp.up || exit $?;
sleep 4;
/usr/bin/dbus-send --system --dest=com.redhat.dhcp --type=method_call --print-reply --reply-timeout=20000 /com/redhat/dhcp/eth0 com.redhat.dhcp.down || exit $?;
