/*
  HeldenViewer - A program to search, download and view Youtube videos.
  Copyright (C) 2011 Benjamin Held (admin@heldenviewer.com)

  This program is free software: you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation, either version 3 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/
#ifndef YOUTUBELOADER_HH
#define YOUTUBELOADER_HH

// #include <string>
#include <QVariant>
#include <QThread>
#include <QEvent>
#include <QNetworkReply>

enum Message
{
  VIDEOSIZE, // Video size is known
  START_DOWNLOAD, // Download has been started
  DOWNLOAD_STATUS, // Download status changed (bytes have been downloaded)
  COMPLETE, //Download is complete
  DOWNLOADING_QUALITY, // The download is started with quality xxx
  LOADER_NETWORK_ERROR, // Network error occurred
  LOADER_BYTE_MISMATCH_ERROR // The start byte was >= video size
};
#include <QMetaType>
Q_DECLARE_METATYPE(Message);

//! To communicate with the outside world, YoutubeLoaderEvents are generated
class YoutubeLoaderEvent : public QEvent
{
  Message message_;
  int param_;
  QByteArray buf_;
  QVariant userData_;
public:
  YoutubeLoaderEvent(Message message, int param, QByteArray buf, QVariant userData)
  : QEvent(QEvent::Type(QEvent::User +100 )), message_(message), param_(param), buf_(buf), userData_(userData)
  {
  }
  Message message(){return message_;}
  int param(){return param_;}
  QByteArray buffer(){return buf_;}
  QVariant userData(){return userData_;}
};

class QNetworkAccessManager;
class QNetworkReply;
class QualityMap;

/**
  * The YoutubeLoader is a thread which needs a url to a youtube video and
  * then extracts the necessary information to download this video.
  * Necessary information includes the available download quality and the url
  * where the video is saved, which is extracted from the flash reply.
*/

class YoutubeLoader : public QThread
{
  Q_OBJECT
public:
  YoutubeLoader();
  ~YoutubeLoader();
  
  //! Additional user data can be set, to distinguish different calls to one instance
  void setUserdata(QVariant userdata);
  //! Set the url to the youtube video
  void setUrl(const QString & url);
  //! Set the object which receives the YoutubeLoaderEvents
  void setReceiverObject(QObject * sendEventsTo);
  //! Additionally one can resume a download, by specifying the startAtByte
  void startAtByte(int byte);
  //! Set the desired quality
  void setDesiredQuality(int quality);
protected:
  void run();
  void load(const QString & url);
private:
  void sendMessage(Message message, int param, QByteArray buf);
  void getURLForDifferentQualities(const QString& data, QualityMap &qualities);

  QVariant userData_;
  QObject * sendEventsTo_;
  
  QNetworkReply *flashDataReply_, *videoDataReply_, *videoDataReplyHeader_;
  QNetworkAccessManager *manager_;
  QString url_, getUrl_;
  int startByte_;
  int desiredQuality_;
private slots:
  void replyFinished(QNetworkReply* reply);
  void newDataReady();
};

#endif
