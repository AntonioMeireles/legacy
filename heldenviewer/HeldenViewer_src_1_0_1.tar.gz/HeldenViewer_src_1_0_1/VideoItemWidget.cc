/*
  HeldenViewer - A program to search, download and view Youtube videos.
  Copyright (C) 2011 Benjamin Held (admin@heldenviewer.com)

  This program is free software: you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation, either version 3 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/
#include "VideoItemWidget.hh"
#include <QGridLayout>

#include <QBoxLayout>
#include <QRadioButton>
#include <QDebug>
#include "YoutubeItem.hh"

VideoItemWidget::VideoItemWidget(QWidget* parent, Qt::WindowFlags f)
: QWidget(parent, f), height_(0)
{
  QGridLayout *gridLayout = new QGridLayout(this);
  scrollArea_ = new QScrollArea(this);
  gridLayout->addWidget(scrollArea_);
  
  containingWidget_ = new QWidget(scrollArea_);
//   containingWidget_->resize(500,3500);
  scrollArea_->setWidget(containingWidget_);
  boxLayout_ = new QVBoxLayout;
//  boxLayout_->setSizeConstraint(QLayout::SetMinimumSize);

  containingWidget_->setLayout(boxLayout_);
}

void VideoItemWidget::setSizeCorrectly()
{
  containingWidget_->setMinimumSize(1500,50+(height_)*boxLayout_->count());
  if(entryToItemMap_.size() == 0)
  {
    containingWidget_->setMinimumSize(1500,0);
    containingWidget_->setMaximumSize(1500,0);
  }
  else
  {
    containingWidget_->setMinimumSize(1500,50+(height_)*boxLayout_->count());
    containingWidget_->setMaximumSize(1500,50+(height_)*boxLayout_->count());
  }
}

void VideoItemWidget::addYoutubeItem(YoutubeItem* item)
{
  if(!height_) height_ = item->height();

  boxLayout_->addWidget(item);
  //containingWidget_->resize(1500, item->height()*boxLayout_->count());
  entryToItemMap_[item->videoEntry()] = item;
  setSizeCorrectly();
}

int VideoItemWidget::size()
{
  return boxLayout_->count();
}

void VideoItemWidget::deleteAll()
{

  for(int i = boxLayout_->count()-1; i >= 0; --i)
  {
    QLayoutItem *item = boxLayout_->itemAt(i);
    boxLayout_->removeItem(item);
    //delete item;
  }
  for(QMap<VideoEntry, YoutubeItem *>::iterator it = entryToItemMap_.begin(); it != entryToItemMap_.end(); ++it)
    delete it.value();
  entryToItemMap_.clear();
  setSizeCorrectly();
}

YoutubeItem* VideoItemWidget::item(const VideoEntry& entry) const
{
  QMap<VideoEntry, YoutubeItem *>::const_iterator it = entryToItemMap_.find(entry);
  if(it != entryToItemMap_.end())
    return it.value();
  return 0;
}

void VideoItemWidget::removeItem(const VideoEntry &entry)
{
  QMap<VideoEntry, YoutubeItem *>::iterator it = entryToItemMap_.find(entry);
  if(it != entryToItemMap_.end())
  {
    it.value()->setParent(0);
    it.value()->deleteLater();
    entryToItemMap_.erase(it);
    setSizeCorrectly();
  }

}

void VideoItemWidget::setWhichTab(VideoItemWidget::WhichTab whichTab)
{
  whichTab_ = whichTab;
  
  if(whichTab == SearchTab)
  {
/*    QPushButton *showMore = new QPushButton("Show more");
    boxLayout_->addWidget(showMore);
    showMore->show();
    containingWidget_->setMinimumSize(1500,100);
    containingWidget_->setMaximumSize(1500,100);*/
  }
  else if(whichTab == DownloadedTab)
  {
/*    QHBoxLayout *hBoxLayout = new QHBoxLayout;
    
    QRadioButton *radio1 = new QRadioButton("kjsada");
    QRadioButton *radio2 = new QRadioButton("kjsada");
    hBoxLayout->addWidget(new QLabel("Sort by"));
    hBoxLayout->addWidget(radio1);
    hBoxLayout->addWidget(radio2);
    hBoxLayout->setSizeConstraint(QLayout::SetFixedSize);
//     boxLayout_->addWidget(radio1);
    boxLayout_->addLayout(hBoxLayout);*/
  }
}

QMap< VideoEntry, YoutubeItem* >::iterator VideoItemWidget::begin()
{
  return entryToItemMap_.begin();
}
QMap< VideoEntry, YoutubeItem* >::iterator VideoItemWidget::end()
{
  return entryToItemMap_.end();
}
