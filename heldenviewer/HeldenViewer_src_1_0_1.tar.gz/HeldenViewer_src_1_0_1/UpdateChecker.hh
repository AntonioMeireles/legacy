/*
  HeldenViewer - A program to search, download and view Youtube videos.
  Copyright (C) 2011 Benjamin Held (admin@heldenviewer.com)

  This program is free software: you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation, either version 3 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/
#ifndef UPDATECHECKER_HH
#define UPDATECHECKER_HH


#include <QObject>
#include <QNetworkAccessManager>

class QWidget;
class QNetworkReply;

/**
  * Checks if updates are available by querying 
  * www.heldenviewer.com/updates/update.xml
*/
class UpdateChecker :public QObject
{
  Q_OBJECT
  
  QNetworkAccessManager manager_;
  QWidget *messageParent_;
private slots:
  void replyFinished(QNetworkReply*reply);
public:
  UpdateChecker(QWidget *messageParent);
  void checkForUpdates();
};

#endif // UPDATECHECKER_HH
