/*
  HeldenViewer - A program to search, download and view Youtube videos.
  Copyright (C) 2011 Benjamin Held (admin@heldenviewer.com)

  This program is free software: you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation, either version 3 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/
#ifndef YOUTUBEITEMMANAGER_HH
#define YOUTUBEITEMMANAGER_HH

#include <QMap>
#include "VideoEntry.hh"

class YoutubeItemModel;

/**
  * This class manages all YoutubeItemModels (formerly it managed all YoutubeItems)
  * This class makes it possible to have multiple YoutubeItems (guis) to show
  * the same video (model).
  * It can read/save the all entries to a data file.
*/

class YoutubeItemManager
{
  struct YoutubeItemStruct
  {
    YoutubeItemModel *item;
    
    YoutubeItemStruct();
    YoutubeItemStruct(YoutubeItemModel *item);
    void deleteLater();
  };
public:
//   typedef QMap<VideoEntry, YoutubeItemStruct> VideoMap;
  //! The QString is the unique VideoId
  typedef QMap<QString, YoutubeItemStruct> VideoMap;
private:
  VideoMap videoToYoutubeItem_;
  
  QString getDownloadsFile();
public:
  YoutubeItemManager();
  ~YoutubeItemManager();
  //! Returns the item if it is already in the map or creates a new model
  YoutubeItemModel *item(const VideoEntry &entry);
  //! Stops all downloads
  void stopAllDownloads();
  //! If an entry has been deleted from the hard disk, update the videoEntry and videoModel
  void updateVideoEntry(const VideoEntry& entry);
  //! If a video file was deleted, the byte count has to be updated
  void videoFileDeleted(const VideoEntry& entry);
  //! Returns all video entries in the reference parameter
  void getEntries(QVector<VideoEntry> &entries);
  
  //! Saves all items to a file
  void save();
  //! Returns the number of items read
  int load();
  
  //! Offer read access to the video list
  VideoMap::const_iterator begin();
  VideoMap::const_iterator end();
  
  //! Updates the default quality for all video entries
  void updateAccordingToOptions();
  
  //! Returns how many files need to be moved if the download directory changes.
  int needToMoveFilesIfDirectoryChanges();
  //! Check if the file corresponding to the video entry exists
  bool exists(const VideoEntry &entry);
};

#endif // YOUTUBEITEMMANAGER_HH
