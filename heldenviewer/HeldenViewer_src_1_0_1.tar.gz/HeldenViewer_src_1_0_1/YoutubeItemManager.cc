/*
  HeldenViewer - A program to search, download and view Youtube videos.
  Copyright (C) 2011 Benjamin Held (admin@heldenviewer.com)

  This program is free software: you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation, either version 3 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/
#include "YoutubeItemManager.hh"
#include "YoutubeItemModel.hh"
#include "StreamTypes.hh"
#include <QDesktopServices>
#include <QFileInfo>
#include <QDir>
#include <QDebug>

YoutubeItemManager::YoutubeItemManager()
{

}


YoutubeItemManager::~YoutubeItemManager()
{
  for(VideoMap::iterator it = videoToYoutubeItem_.begin(); it != videoToYoutubeItem_.end(); ++it)
    ((*it).item)->deleteLater();

}


void YoutubeItemManager::stopAllDownloads()
{
  for(VideoMap::iterator it = videoToYoutubeItem_.begin(); it != videoToYoutubeItem_.end(); ++it)
    ((*it).item)->stopDownload();
}



YoutubeItemManager::YoutubeItemStruct::YoutubeItemStruct()
{
  item = 0;
}
YoutubeItemManager::YoutubeItemStruct::YoutubeItemStruct(YoutubeItemModel* item)
: item(item)
{
}

void YoutubeItemManager::YoutubeItemStruct::deleteLater()
{
  if(item) item->deleteLater();
}

YoutubeItemModel* YoutubeItemManager::item(const VideoEntry& entry)
{
  VideoMap::iterator it = videoToYoutubeItem_.find(entry.videoId());
  if(it != videoToYoutubeItem_.end())
    return (*it).item;
  YoutubeItemStruct itemStruct(new YoutubeItemModel(entry));
  itemStruct.item->setViewState(YoutubeItemModel::NewVideo);
  videoToYoutubeItem_.insert(entry.videoId(), itemStruct);
  
  return itemStruct.item;
}

QString YoutubeItemManager::getDownloadsFile()
{
/*  QString location = QDesktopServices::storageLocation(QDesktopServices::DataLocation);
  #ifdef Q_WS_MAC
      location.insert(location.count() - QCoreApplication::applicationName().count(),
	  QCoreApplication::organizationName());
  #endif
  location += "/HeldenViewerDownloads.dat";
  return location;*/
  QString location =SettingsManager::instance().dataDirectory() + "HeldenViewerDownloads.dat";
  return location;
}


void YoutubeItemManager::save()
{
  QString location = getDownloadsFile();
  
  QFile file(location);
  if(!file.open(QIODevice::WriteOnly))
  {
    qDebug() << QObject::tr("Could not open %1").arg(location);
    return;
  }
//   qDebug("Writing %s", location.toLatin1().data());
  
  QDataStream out(&file);
  out.setVersion(QDataStream::Qt_4_6);
  qint32 numberOfSaveItems = videoToYoutubeItem_.size();
//   qDebug("Saving %d items", numberOfSaveItems);
  
  out << MAGIC_YOUTUBEITEMMANAGER;
  quint32 version = 1; out << version;
  out << (quint32)numberOfSaveItems;
  for(VideoMap::iterator it = videoToYoutubeItem_.begin(); it != videoToYoutubeItem_.end(); ++it)
  {
    if(it.value().item->viewState() == YoutubeItemModel::NewVideo)
      it.value().item->setViewState(YoutubeItemModel::Default);
    out << *it.value().item;
  }
}

int YoutubeItemManager::load()
{
  QString location = getDownloadsFile();
  
  QFile file(location);
  if(!file.open(QIODevice::ReadOnly))
  {
    qDebug() << QObject::tr("Could not read %1").arg(location);
    return 0;
  }

  QDataStream in(&file);
  in.setVersion(QDataStream::Qt_4_6);
  
  quint32 magicHeader;
  in >> magicHeader;
  //This case is the older version where no header existed, it cannot be read any longer
  quint32 version; in >> version;
  if(version != 1)
  {
    qDebug() << QObject::tr("Reading data file: Version is unknown: %1").arg(version);
    return 0;
  }
  quint32 items; in >> items;
  
  for(unsigned int i = 0; i < items; ++i)
  {
    try
    {
      YoutubeItemModel *model = new YoutubeItemModel(in);
      videoToYoutubeItem_[model->videoEntry().videoId()] = model;
    }
    catch(std::exception &e)
    {
      qDebug() << QObject::tr("Error: %1").arg(e.what());
    }
  }
  
//   qDebug("Read %d items", items);
  return items;
}

QMap< QString, YoutubeItemManager::YoutubeItemStruct >::const_iterator YoutubeItemManager::begin()
{
  return videoToYoutubeItem_.constBegin();
}
QMap< QString, YoutubeItemManager::YoutubeItemStruct >::const_iterator YoutubeItemManager::end()
{
  return videoToYoutubeItem_.constEnd();
}

void YoutubeItemManager::updateAccordingToOptions()
{
  for(VideoMap::iterator it = videoToYoutubeItem_.begin(); it != videoToYoutubeItem_.end(); ++it)
    it.value().item->updateAccordingToOptions();
}

int YoutubeItemManager::needToMoveFilesIfDirectoryChanges()
{
  int count = 0;
  for(VideoMap::iterator it = videoToYoutubeItem_.begin(); it != videoToYoutubeItem_.end(); ++it)
    if(it.value().item->state() != YoutubeItemModel::Normal || it.value().item->videoEntry().bytesDownloaded > 0)
      count++;
  return count;
}

void YoutubeItemManager::updateVideoEntry(const VideoEntry& entry)
{
  VideoMap::iterator it = videoToYoutubeItem_.find(entry.videoId());
  if(it != videoToYoutubeItem_.end())
    it.value().item->updateVideoEntry(entry);
}

void YoutubeItemManager::videoFileDeleted(const VideoEntry& entry)
{
  VideoMap::iterator it = videoToYoutubeItem_.find(entry.videoId());
  if(it != videoToYoutubeItem_.end())
    it.value().item->videoFileDeleted();

}

void YoutubeItemManager::getEntries(QVector< VideoEntry >& entries)
{
  
  for(VideoMap::const_iterator it = videoToYoutubeItem_.begin(); it != videoToYoutubeItem_.end(); ++it)
  {
    YoutubeItemModel *itemModel =  it.value().item;
    entries.push_back(itemModel->videoEntry());
  }    

}

bool YoutubeItemManager::exists(const VideoEntry& entry)
{
  return videoToYoutubeItem_.find(entry.videoId()) != videoToYoutubeItem_.end();
}
