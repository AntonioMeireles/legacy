/*
  HeldenViewer - A program to search, download and view Youtube videos.
  Copyright (C) 2011 Benjamin Held (admin@heldenviewer.com)

  This program is free software: you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation, either version 3 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/
#include "MainWindow.hh"
#include "YoutubeItem.hh"
#include "SettingsManager.hh"
#include "OptionDialog.hh"
#include "AboutDialog.hh"
#include "FilesMissingDialog.hh"
#include "CheckNewVideos.hh"
#include "ConfigurationWizard.hh"
#include "UpdateChecker.hh"
#include <QMessageBox>
#include <QDesktopWidget>
#include <QDebug>
#include <QMenu>
#include <QListView>
#include <QUrl>

MainWindow::MainWindow()
: Ui::MainWindow(), lastVideosBeginIndex_(1), updateChecker_(this)
{
  setupUi(this);
  setWindowIcon(QIcon(SettingsManager::instance().resourceDirectory() + "icon.png"));
  fr_videoIndices->hide();
  pb_newVideosProgress->hide();
  
  vw_searchResults->setWhichTab(VideoItemWidget::SearchTab);
  vw_activeDownloads->setWhichTab(VideoItemWidget::DownloadingTab);
  vw_completedDownloads->setWhichTab(VideoItemWidget::DownloadedTab);
  
  const QSettings &settings = SettingsManager::instance().settings();
  move(settings.value( "window/position", pos() ).toPoint());
  resize(settings.value( "window/size", size() ).toSize());
/*  adjustGeometryCorrectly(settings.value( "window/position", pos() ).toPoint(), 
                          settings.value( "window/size", size() ).toSize());*/
  
  if(settings.value( "window/maximized", true ).toBool())
    showMaximized();
//   showMaximized();
  
  connect(pb_authorSearch, SIGNAL (clicked()), this, SLOT(authorSearch()));
  connect(le_authorSearch, SIGNAL(returnPressed ()), this, SLOT(authorSearch()));
  connect(pb_videoSearch, SIGNAL (clicked()), this, SLOT(videoSearch()));
  connect(le_videoSearch, SIGNAL(returnPressed ()), this, SLOT(videoSearch()));
  connect(pb_checkNewVideos, SIGNAL(clicked()), this, SLOT(checkNewVideos()));
  
  connect(pb_showMoreVideos, SIGNAL(clicked()), this, SLOT(showMoreVideos()));
  connect(sb_videosStartIndex, SIGNAL(valueChanged ( int )), this, SLOT(beginIndexChanged(int)));
  connect(pb_showNextVideos, SIGNAL(clicked()), this, SLOT(showNextVideos()));
  
  connect(pb_deleteAllCompletedVideos, SIGNAL(clicked()), this, SLOT(deleteAllCompletedVideos()));
  connect(pb_clearActiveDownloads, SIGNAL(clicked()), this, SLOT(clearActiveDownloads()));
  
  connect(&youtubeQuery_, SIGNAL(recentVideos(const std::vector<VideoEntry> &, int)), this, SLOT(recentVideosSlot(const std::vector<VideoEntry> &, int)));
//   connect(lw_favorites, SIGNAL(itemDoubleClicked ( QListWidgetItem *)), this, SLOT(favoriteSelectedSlot( QListWidgetItem *)));
  connect(lv_favorites, SIGNAL(doubleClicked ( const QModelIndex &)), this, SLOT(favoriteSelectedSlot( const QModelIndex &)));
  connect(lv_favorites, SIGNAL( customContextMenuRequested ( const QPoint & )), this, SLOT( favoriteContextMenuRequested ( const QPoint &  )));
  
  connect(actionExit, SIGNAL(triggered()), this, SLOT(close()));
  connect(actionEditOptions, SIGNAL(triggered()), this, SLOT(editOptions()));
  connect(actionAboutHeldenViewer, SIGNAL(triggered()), this, SLOT(aboutDialog()));
  connect(actionCheckForUpdates, SIGNAL(triggered()), this, SLOT(checkForUpdates()));
  connect(actionHelp, SIGNAL(triggered()), this, SLOT(help()));

  connect(&CheckNewVideos::instance(), SIGNAL(finishedCheckNewVideos(const CheckNewVideos::FavoriteNewVideosVector &)), this, SLOT(finishedCheckNewVideos(const CheckNewVideos::FavoriteNewVideosVector &)));
  
  lv_favorites->setModel(&favoriteDataModel_);
  lv_favorites->setDragEnabled(true);
  lv_favorites->setAcceptDrops(true);
  lv_favorites->setDropIndicatorShown(true);
  lv_favorites->setDefaultDropAction(Qt::MoveAction);
  lv_favorites->setContextMenuPolicy(Qt::CustomContextMenu);
  
  
  if(youtubeItemManager_.load())
  {
    QVector<VideoEntry> entries;
    youtubeItemManager_.getEntries(entries);
    
    //First check if some video files have been altered
    QVector<FileInfo> fileInfo;
    
    if(FilesMissingDialog::videosMissing(entries, fileInfo))
    {
      FilesMissingDialog filesMissingDialog(&youtubeItemManager_,entries, fileInfo, this);
      filesMissingDialog.exec();
    }
    
    //Now create the YoutubeItems and add them to the correct container
    
    for(YoutubeItemManager::VideoMap::const_iterator it = youtubeItemManager_.begin(); it != youtubeItemManager_.end(); ++it)
    {
      YoutubeItemModel *itemModel =  it.value().item;
//       entries.push_back(itemModel->videoEntry());
      
      YoutubeItem *item;
//       if(itemModel->state() == YoutubeItemModel::Downloaded || itemModel->state() == YoutubeItemModel::Downloading)
      if(itemModel->videoEntry().bytesDownloaded > 0)
      {
        item = new YoutubeItem(itemModel);
        connectSlotsOfItem(item);
        
        if(itemModel->state() == YoutubeItemModel::Downloaded)
          vw_completedDownloads->addYoutubeItem(item);
        else
        {
          vw_activeDownloads->addYoutubeItem(item);
          itemModel->stopDownload();
        }
      }
    }
    
  }
  favoriteDataModel_.load();

  //Check if this is the first start
  if(!settings.contains( "window/position"))
  {
    setEnabled(false);
    show();
    ConfigurationWizard configurationWizard(this);
    configurationWizard.exec();
    setEnabled(true);
  }
}

void MainWindow::authorSearch()
{
//   youtubeQuery_.extractRecentVideos(le_authorSearch->text());
  youtubeQuery_.extractRecentVideos(YoutubeQuery::GeneralYoutubeQuery(YoutubeQuery::AUTHOR_VIDEOS,le_authorSearch->text(), 1, 25));
}

void MainWindow::videoSearch()
{
  youtubeQuery_.extractRecentVideos(YoutubeQuery::GeneralYoutubeQuery(YoutubeQuery::KEYWORD_VIDEOS,le_videoSearch->text(), 1, 25));
}



MainWindow::~MainWindow()
{
}

void MainWindow::connectSlotsOfItem(YoutubeItem *youtubeItem)
{
  connect(youtubeItem, SIGNAL(downloadStarted(const VideoEntry &)), this, SLOT(downloadStarted(const VideoEntry &)));
  connect(youtubeItem, SIGNAL(downloadFinished(const VideoEntry &)), this, SLOT(downloadFinished(const VideoEntry &)));
  connect(youtubeItem, SIGNAL(videoDeleted(const VideoEntry &)), this, SLOT(videoDeleted(const VideoEntry &)));
  connect(youtubeItem, SIGNAL(addAuthorAsFavorite(const QString &)), this, SLOT(addAuthorAsFavorite(const QString &)));  
}

void MainWindow::recentVideosSlot(const std::vector< VideoEntry >& videos, int videosTotal)
{
  if(videos.size())
    fr_videoIndices->show();
  else
    fr_videoIndices->hide();
  sb_videosStartIndex->setMaximum(videosTotal);
  sb_videosEndIndex->setMaximum(videosTotal);
  
  //Need to call the index Changed method if the oldValue is equal to the new value as otherwise the corresponding signal is not emitted
  if(youtubeQuery_.lastQuery().startIndex == sb_videosStartIndex->value())
    beginIndexChanged(sb_videosStartIndex->value());
  else
      sb_videosStartIndex->setValue(youtubeQuery_.lastQuery().startIndex);
  sb_videosEndIndex->setValue(youtubeQuery_.lastQuery().startIndex+youtubeQuery_.lastQuery().itemsToRetrieve-1);
  
  
  tw_results->setCurrentIndex(0);
  vw_searchResults->deleteAll();
  for(unsigned int i = 0; i < videos.size(); ++i)
  {
    youtubeItemManager_.updateVideoEntry(videos[i]);
    YoutubeItemModel *model = youtubeItemManager_.item(videos[i]);
    YoutubeItem *youtubeItem = new YoutubeItem(model);
//     youtubeItemManager_.addItem(videos[i], youtubeItem);
    connectSlotsOfItem(youtubeItem);
//     connect(youtubeItem, SIGNAL(stopDownload(const VideoEntry &)), this, SLOT(stopDownload(const VideoEntry &)));

//     vw_activeDownloads->addYoutubeItem(youtubeItem);
    vw_searchResults->addYoutubeItem(youtubeItem);
  }
  
}

void MainWindow::downloadStarted(const VideoEntry& entry)
{
  YoutubeItem *item = vw_activeDownloads->item(entry);
  //Item exists, do nothing
  if(item) return;
  item = new YoutubeItem(youtubeItemManager_.item(entry));
  vw_activeDownloads->addYoutubeItem(item);
  connectSlotsOfItem(item);
}

void MainWindow::downloadFinished(const VideoEntry& entry)
{
  //First add to completed downloads
  YoutubeItem *item = vw_completedDownloads->item(entry);
  //Item does not exist -> add it
  if(!item)
  {
    item = new YoutubeItem(youtubeItemManager_.item(entry));
    vw_completedDownloads->addYoutubeItem(item);
    connectSlotsOfItem(item);
  }  
  //Now delete from active downloads
  vw_activeDownloads->removeItem(entry);
}

void MainWindow::videoDeleted(const VideoEntry& entry)
{
  VideoItemWidget *both[2] = {vw_activeDownloads, vw_completedDownloads};
  for(int i = 0; i < 2; ++i)
  {
    both[i]->removeItem(entry);
  }
}

void MainWindow::favoriteSelectedSlot(const QModelIndex& item)
{
  
  youtubeQuery_.extractRecentVideos(YoutubeQuery::GeneralYoutubeQuery(YoutubeQuery::AUTHOR_VIDEOS,favoriteDataModel_.getName(item.row()), 1, 25));
}


void MainWindow::closeEvent(QCloseEvent* event)
{
  youtubeItemManager_.save();
  youtubeItemManager_.stopAllDownloads();
  favoriteDataModel_.save();
  
  QSettings &settings = SettingsManager::instance().settings();
  settings.setValue( "window/size", size());
  settings.setValue( "window/position", pos());
  settings.setValue( "window/maximized", isMaximized());
  
  QWidget::closeEvent(event);
}

void MainWindow::editOptions()
{
//   OptionDialog *optionDialog = new OptionDialog(this);
  OptionDialog optionDialog(&youtubeItemManager_,this);
  optionDialog.exec();
  youtubeItemManager_.updateAccordingToOptions();
}

void MainWindow::aboutDialog()
{
  AboutDialog aboutDialog;
  aboutDialog.exec();
}


void MainWindow::messageReceived(const QString& message)
{
  if(message == "raise window")
    raise();
}

void MainWindow::favoriteContextMenuRequested(const QPoint& pos)
{
//   QMenu *menu = new QMenu(lv_favorites);
  QMenu menu(tr("Favorite actions"), lv_favorites);
  QAction addAction(tr("Add favorite"), &menu);
  QAction deleteAction(tr("Delete item"), &menu);
  QModelIndex selectedIndex = lv_favorites->indexAt(pos);
  
  menu.addAction(&addAction);
  if(selectedIndex.isValid())
    menu.addAction(&deleteAction);
  
  QAction *action = menu.exec(lv_favorites->mapToGlobal(pos));
  if(action == &addAction)
  {
    favoriteDataModel_.insertRows(favoriteDataModel_.rowCount(), 1);
    lv_favorites->edit(favoriteDataModel_.index(favoriteDataModel_.rowCount()-1));
  }
  else if(action == &deleteAction)
  {
    favoriteDataModel_.removeRow(selectedIndex.row());
  }
}

void MainWindow::showMoreVideos()
{
  YoutubeQuery::GeneralYoutubeQuery lastQuery = youtubeQuery_.lastQuery();
  
  lastQuery.startIndex = sb_videosStartIndex->value();
  lastQuery.itemsToRetrieve = std::min(50, sb_videosEndIndex->value()-lastQuery.startIndex+1);
  youtubeQuery_.extractRecentVideos(lastQuery);
}

void MainWindow::beginIndexChanged(int newValue)
{
  sb_videosEndIndex->setMinimum(newValue);
  sb_videosEndIndex->setMaximum(newValue+49);
  sb_videosEndIndex->setValue(sb_videosEndIndex->value()-lastVideosBeginIndex_ + newValue);
  
  lastVideosBeginIndex_ = newValue;
}

void MainWindow::showNextVideos()
{
  int newBeginIndex = std::min(sb_videosStartIndex->maximum(), sb_videosEndIndex->value());
  
  sb_videosStartIndex->setValue(newBeginIndex);
  showMoreVideos();
}

void MainWindow::checkNewVideos()
{
  if(favoriteDataModel_.rowCount() == 0)
  {
    QMessageBox::information(this, "Sorry", "You have to add favorites before checking for new videos.");
    return;
  }
  
  lv_favorites->setEnabled(false);
  pb_checkNewVideos->setEnabled(false);
  pb_newVideosProgress->show();
  CheckNewVideos::instance().check(&favoriteDataModel_, &youtubeItemManager_, pb_newVideosProgress);
}

void MainWindow::finishedCheckNewVideos(const CheckNewVideos::FavoriteNewVideosVector& result)
{
  int newVideos = 0;
  for(int i = 0; i < result.size(); ++i)
  {
    favoriteDataModel_.setNewVideos(i, result[i].second);
    newVideos += result[i].second;
  }
  
  lv_favorites->setEnabled(true);
  pb_checkNewVideos->setEnabled(true);
  pb_newVideosProgress->hide();
  
  if(newVideos)
    QMessageBox::information(this,tr("New videos"), tr("There are %1 new video(s).").arg(newVideos));
  else
    QMessageBox::information(this,tr("No new videos"), tr("There are no new videos."));
  

}

void MainWindow::deleteAllCompletedVideos()
{
  int countCompleted = 0, countUnseen = 0;

  for(YoutubeItemManager::VideoMap::const_iterator it = youtubeItemManager_.begin(); it != youtubeItemManager_.end(); ++it)
    if(it.value().item->state() == YoutubeItemModel::Downloaded)
    {
      countCompleted++;
      if(it.value().item->viewState() != YoutubeItemModel::Seen)
        countUnseen++;
    }
  
  if(countCompleted == 0)
  {
    QMessageBox::information(this, "Sorry", "No videos have been downloaded so far.");
    return;
  }

  if(QMessageBox::question(this, tr("Are you sure?"), tr("Do you really want to delete all %n completed videos?",0,countCompleted) + tr("%n of those videos are unseen.", "", countUnseen), QMessageBox::Yes|QMessageBox::No) == QMessageBox::No)
    return;
  
  for(YoutubeItemManager::VideoMap::const_iterator it = youtubeItemManager_.begin(); it != youtubeItemManager_.end(); ++it)
    if(it.value().item->state() == YoutubeItemModel::Downloaded)
    {
      if(!it.value().item->deleteVideo())
        QMessageBox::critical(this, tr("Video could not be deleted."), tr("The video %1 - %2 could not be deleted.").arg(it.value().item->videoEntry().author).arg(it.value().item->videoEntry().title));
    }
  
  vw_completedDownloads->deleteAll();
}

void MainWindow::addAuthorAsFavorite(const QString &author)
{
  if(!favoriteDataModel_.contains(author))
    favoriteDataModel_.insert(FavoriteEntry(author));
  else
    QMessageBox::information(this, tr("Sorry, author is already a favorite"), tr("The author \"%1\" is already added to your favorite list").arg(author));
}

void MainWindow::checkForUpdates()
{
//   UpdateChecker updateChecker(this);
  updateChecker_.checkForUpdates();
  
}

void MainWindow::help()
{
  QMessageBox::information(this, tr("Getting help"), tr("Please visit <a href='www.heldenviewer.com'>www.heldenviewer.com</a> and check out the FAQ. If this does not answer your question, send a message to admin@heldenviewer.com"));
}

void MainWindow::clearActiveDownloads()
{
  if(QMessageBox::question(this, tr("Are you sure?"), tr("Do you really want to delete all active downloads?"), QMessageBox::Yes|QMessageBox::No) == QMessageBox::No)
    return;

  for(QMap<VideoEntry, YoutubeItem *>::iterator it = vw_activeDownloads->begin(); it != vw_activeDownloads->end(); ++it)
  {
    if(!it.value()->model()->deleteVideo())
        QMessageBox::critical(this, tr("Video could not be deleted."), tr("The video %1 - %2 could not be deleted.").arg(it.value()->model()->videoEntry().author).arg(it.value()->model()->videoEntry().title));
  }
  vw_activeDownloads->deleteAll();
}
