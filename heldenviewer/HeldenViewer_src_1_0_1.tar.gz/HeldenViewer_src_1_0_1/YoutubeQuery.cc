/*
  HeldenViewer - A program to search, download and view Youtube videos.
  Copyright (C) 2011 Benjamin Held (admin@heldenviewer.com)

  This program is free software: you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation, either version 3 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/
#include "YoutubeQuery.hh"
#include <QNetworkAccessManager>
#include <QUrl>
#include <QNetworkRequest>
#include <QNetworkReply>
#include <QDomDocument>
#include <QPixmap>
#include <QImage>
#include <QMessageBox>
#include <QDebug>

YoutubeQuery::YoutubeQuery()
: lastAuthorQuery_(AUTHOR_VIDEOS,"", 1, 25)
{
  manager_ = new QNetworkAccessManager(this);
  connect(manager_, SIGNAL(finished(QNetworkReply*)),
         this, SLOT(replyFinished(QNetworkReply*)));
}

YoutubeQuery::~YoutubeQuery()
{
  delete manager_;
}

QNetworkReply * YoutubeQuery::extractRecentVideos(const GeneralYoutubeQuery &query)
{
  lastAuthorQuery_ = query;
  
  QString url;
  if(query.type == AUTHOR_VIDEOS)
    url = "http://gdata.youtube.com/feeds/api/users/" + query.text + "/uploads?v=2&start-index=" + QString::number(query.startIndex) + "&max-results="+QString::number(query.itemsToRetrieve);
  else if(query.type == KEYWORD_VIDEOS)
  {
    QString escapedKeywords = query.text;
    escapedKeywords = QUrl::toPercentEncoding(escapedKeywords,"[]");
    
    url = "http://gdata.youtube.com/feeds/api/videos?q=" +escapedKeywords + "&start-index=" + QString::number(query.startIndex) + "&strict=true&v=2&max-results="+QString::number(query.itemsToRetrieve);
  }

  
  QNetworkReply *reply = manager_->get(QNetworkRequest(QUrl(url)));
//   qDebug("URL: %s", url.toLatin1().data());
  Request *request = new Request();
  request->name = query.text;
//   request->type = AUTHOR_VIDEOS;
  request->type = query.type;
  requestMap_[reply] = request;
  return reply;
}


QNetworkReply* YoutubeQuery::downloadThumbnail(const VideoEntry& entry)
{
  QString url = "http://img.youtube.com/vi/" + entry.videoId() + "/0.jpg";
  //qDebug("Downloading thumbnail: %s", url.toLatin1().data());
  QNetworkReply *reply = manager_->get(QNetworkRequest(QUrl(url)));
//   qDebug("%s", url.toLatin1().data());
  Request *request = new Request();
  request->type = DOWNLOAD_THUMBNAIL;
  requestMap_[reply] = request;
  return reply;
}

void YoutubeQuery::replyFinished(QNetworkReply* reply)
{
  if(requestMap_.find(reply) == requestMap_.end())
  {
    qDebug() << tr("Serious Error: Could not find network reply in map.");
    return;
  }
  Request *request = requestMap_[reply];
  if (reply->error() != QNetworkReply::NoError && request->type == AUTHOR_VIDEOS)
  {
    qDebug() << tr("No data could be retrieved for the author.\n Error string: %1").arg(reply->errorString());
    QMessageBox::critical(0, "Error", tr("No data could be retrieved for the author.\n Error string: %1").arg(reply->errorString()).toLatin1());
  }
  else if(reply->error() != QNetworkReply::NoError && request->type == DOWNLOAD_THUMBNAIL)
  {
    qDebug() << tr("Could not download thumbnail.\n Error string: %1").arg(reply->errorString());
  }
  else
  {
    if(reply->bytesAvailable())
    {
      //qDebug("Bytes available: %d", reply->bytesAvailable());
    //   request->content = reply->readAll().data();
//      qDebug() << tr("Bytes available: %1 bytes").arg(reply->bytesAvailable());
      request->content = reply->readAll();
//      if(request->type == DOWNLOAD_THUMBNAIL)
//        qDebug() << tr("Read %1 bytes").arg(request->content.size());
      processRequest(reply, request);
    }
    else qDebug() << tr("No bytes are available, request type: %1").arg(request->type);
  }

  //Clean up
  delete request;
  requestMap_.erase(requestMap_.find(reply));
  reply->deleteLater();
}

void YoutubeQuery::extractVideosFromAuthor(const QString &xmlContent, std::vector<VideoEntry> &videoEntries, int &authorVideosCount)
{
  QDomDocument document;
  document.setContent(xmlContent);

  QDomNodeList countEntry = document.elementsByTagName("openSearch:totalResults");
  
  if(countEntry.size ()  == 1)
  {
    authorVideosCount = countEntry.item(0).toElement().text().toInt();
//     qDebug("%d", countEntry.item(0).toElement().text().toInt());
  }
  else
    qDebug() << tr("Coult not retrieve the number of videos of the author");
  QDomNodeList entries = document.elementsByTagName("entry");
//   qDebug("entries: %d", entries.size());
//   qDebug("%s", xmlContent.toLatin1().data());
  
  QString videoId = "";
  for(int i = 0; i < entries.size(); ++i)
  {
    VideoEntry videoEntry;
    QDomNodeList childNodes = entries.item(i).childNodes();
    for(int j = 0; j < childNodes.size(); ++j)
    {
      QDomElement curElement = childNodes.item(j).toElement();
      if(childNodes.item(j).nodeName() == "title")
        videoEntry.title = curElement.text();
      if(curElement.tagName() == "published")
        videoEntry.published = curElement.text();
      if(curElement.tagName() == "updated")
        videoEntry.updated = curElement.text();
      
      if(childNodes.item(j).nodeName() == "author")
      {
        QDomNode authorNode = curElement.namedItem("name");
        if(authorNode.isNull())
        {
          qDebug() << tr("Author could not be extracted");
          return;
        }
        videoEntry.author = authorNode.toElement().text();
      }
      if(childNodes.item(j).nodeName() == "link")
      {
        if(curElement.attribute("rel") == "alternate")
          videoEntry.setUrl(curElement.attribute("href"));
      }
      
      if(curElement.tagName() == "yt:statistics")
        videoEntry.viewCount = curElement.attribute("viewCount");
      if(curElement.tagName() == "gd:rating")
      {
        videoEntry.numRaters = curElement.attribute("numRaters").toInt();
        videoEntry.ratingAverage = curElement.attribute("average").toDouble();
      }
      if(curElement.tagName() == "gd:comments")
      {
        QDomNodeList commentsChildren = curElement.childNodes();
        for(int k = 0; k < commentsChildren.size(); ++k)
        {
          QDomElement curCommentElement = commentsChildren.item(k).toElement();
          if(curCommentElement.tagName() == "gd:feedLink" && curCommentElement.hasAttribute("countHint"))
          {
            videoEntry.commentCount = curCommentElement.attribute("countHint").toInt();
//             qDebug("COmments:%d", videoEntry.commentCount);
          }
        }
      }
      if(curElement.tagName() == "media:group")
      {
        QDomNodeList mediaChildren = curElement.childNodes();
        for(int k = 0; k < mediaChildren.size(); ++k)
        {
          QDomElement curMediaElement = mediaChildren.item(k).toElement();
//           qDebug("tagname: %s", curMediaElement.tagName().toLatin1().data());
          if(curMediaElement.tagName() == "yt:videoid")
            videoId = curMediaElement.text();
//             qDebug("%s", curMediaElement.text().toLatin1().data());
          if(curMediaElement.hasAttribute("duration"))
            videoEntry.seconds  = mediaChildren.item(k).toElement().attribute("duration");
          if(curMediaElement.tagName() == "media:thumbnail")
            videoEntry.thumbnailUrl = curMediaElement.attribute("url");
        }
      }
    }
    if(videoId != "")
    {
      videoEntry.setVideoId(videoId);
//       qDebug("%s", videoEntry.videoId().toLatin1().data());
    }
/*    int countBytes = 
    videoEntry.title.toUtf8().size()+videoEntry.author.toUtf8().size()+
    videoEntry.published.toUtf8().size() + videoEntry.thumbnailUrl.toUtf8().size()+
    videoEntry.updated.toUtf8().size()+videoEntry.url().toUtf8().size() + videoEntry.videoId().toUtf8().size();
    qDebug("bytes: %d", countBytes);*/
/*    qDebug("%d\n \tauthor:%s\ttitle:%s\n\turl:%s\n\tduration:%s\n\tthumbnail:%s\n\tpublished:%s\n\tupdated:%s", i, 
           videoEntry.author.toLatin1().data(),videoEntry.title.toLatin1().data(), 
           videoEntry.url.toLatin1().data(),videoEntry.seconds.toLatin1().data(), 
           videoEntry.thumbnailUrl.toLatin1().data(), videoEntry.published.toLatin1().data(), 
           videoEntry.updated.toLatin1().data());*/
    videoEntries.push_back(videoEntry);
  }
}

void YoutubeQuery::processRequest(QNetworkReply* reply, YoutubeQuery::Request* request)
{
  if(request->type == AUTHOR_VIDEOS || request->type == KEYWORD_VIDEOS)
  {
    //qDebug("HIER, content: %s", QString(request->content).toLatin1().data());
    std::vector<VideoEntry> videoEntries;
    
/*    QStringList lines = QString(request->content).split('\n');
    for(unsigned int i = 0; i < lines.size(); ++i)
      qDebug("line %d: %s", i, lines[i].toLatin1().data());*/
    if(QString(request->content).indexOf("</entry>") == -1)
    {
//       qDebug("%s", QString(request->content).toLatin1().data());
      QString message = tr("No data could be retrieved for the author, most likely the author does not exist. Please try to use the video search and get the exact name of the author.");
      if(request->type == KEYWORD_VIDEOS)
        message = tr("No videos with the provided keywords were found.");
      QMessageBox::information(0, tr("Sorry"), message);
//       qDebug("%s", QString(request->content).toLatin1().data());
      lastAuthorQuery_.maxItemCount = 0;
      emit recentVideos(videoEntries, 0);
      return;
    }
    int videosCount = 0;
    extractVideosFromAuthor(request->content, videoEntries, videosCount);
    lastAuthorQuery_.maxItemCount = videosCount;
//     qDebug("Video count: %d", videosCount);
    emit recentVideos(videoEntries, videosCount);
  }
  else if(request->type == DOWNLOAD_THUMBNAIL)
  {
    QImage image;
    /*for(unsigned int i = 0; i < QImageReader::supportedImageFormats().size(); ++i)
      qDebug() << QImageReader::supportedImageFormats().at(i);*/
    if(!image.loadFromData(request->content))
      qDebug() << tr("Could not load image from data");
    QPixmap pixmap = QPixmap::fromImage(image);
    
    emit thumbnailReady(pixmap);
  }
}

YoutubeQuery::GeneralYoutubeQuery YoutubeQuery::lastQuery()
{
  return lastAuthorQuery_;
}
