<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="en_US">
<context>
    <name>AboutDialog</name>
    <message>
        <source>About</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>HeldenViewer Version 1.0</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:10pt; font-weight:400; font-style:italic;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Ubuntu&apos;;&quot;&gt;Copyright 2011&lt;/span&gt;&lt;span style=&quot; font-family:&apos;Ubuntu&apos;; font-style:normal;&quot;&gt; Benjamin Held (&lt;/span&gt;&lt;a href=&quot;mailto:admin@heldenviewer.com&quot;&gt;&lt;span style=&quot; font-family:&apos;Ubuntu&apos;; text-decoration: underline; color:#0057ae;&quot;&gt;admin@heldenviewer.com&lt;/span&gt;&lt;/a&gt;&lt;span style=&quot; font-family:&apos;Ubuntu&apos;; font-style:normal;&quot;&gt;)&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;HeldenViewer uses Qt 4.7 with dynamic linkage. Qt is licensed under the LGPL.&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;HeldenViewer is licensed under the GNU GPL version 3, see the file COPYING or &lt;a href=&quot;http://www.gnu.org/licenses/&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0057ae;&quot;&gt;http://www.gnu.org/licenses/&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ConfigurationWizard</name>
    <message>
        <source>HeldenViewer - first start</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>HeldenViewer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Setup the video player</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Welcome to HeldenViewer!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:7.8pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt;In order to view the downloaded videos, you have to provide a path to a video player which is capable of playing .flv video files. HeldenViewer has been tested with the free VideoLAN Client. It can be downloaded at &lt;/span&gt;&lt;a href=&quot;http://www.videolan.org/vlc/&quot;&gt;&lt;span style=&quot; font-size:8pt; text-decoration: underline; color:#0000ff;&quot;&gt;http://www.videolan.org/vlc/&lt;/span&gt;&lt;/a&gt;&lt;span style=&quot; font-size:8pt;&quot;&gt;.&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Choose video player:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>..</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Choose video save path:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You can change these values later on in the settings.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select Video player</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select save path</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No permission</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Can not write to this directory. Please select another directory.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No permission for directory &quot;%1&quot;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FavoriteDataModel</name>
    <message>
        <source>FavoriteDataModel: Row index is out range, should not happen.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>%1 (new: %2)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>getName: index is not valid. Should not happen. Row: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Could not open &quot;%1&quot; for reading.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Header or version of favorites file is damaged.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Could not open &quot;%1&quot; for writing</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FilesMissingDialog</name>
    <message>
        <source>File does not exist:&quot;%1&quot;.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>File has the wrong size, the download cannot be resumed:&quot;%1&quot;.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sorry</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The videos could still not be found.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Do you really want to delete the following files:
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Are you sure?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error while deleting</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Could not remove the file &quot;%1&quot;.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>HeldenViewer: Files are missing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Some files have been changed on the hard drive and cannot be found or have different sizes since the last start of HeldenViewer. You have now the chance to move the files back and press the retry button. Otherwise HeldenViewer will delete the entries with missing video files. The following files are affected:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Delete files with wrong size</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <source>Favorite actions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add favorite</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Delete item</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New videos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>There are %1 new video(s).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No new videos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>There are no new videos.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Are you sure?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Video could not be deleted.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The video %1 - %2 could not be deleted.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>HeldenViewer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Search results</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Videos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Video number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>-</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Only 50 entries can be shown at once.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show next videos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Active downloads</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Completed downloads</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Delete all completed videos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Help</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Search</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Video search</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Search for video with keyword</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Searches the metadata of all videos containing the keyword. The metadata consists of title, author, tags, ...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Author&apos;s videos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show videos of author</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You have to provide the exact name of the author.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Favorites</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Press the right mouse button to add new favorites or delete a favorit.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Depending on the number of favorites, this can take a while.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Check for new favorites&apos; videos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Neues Spiel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Quit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>About HeldenViewer</source>
        <translation type="unfinished"></translation>
    </message>
    <message numerus="yes">
        <source>%n of those videos are unseen.</source>
        <translation>
            <numerusform>One video has not been seen.</numerusform>
            <numerusform>%n videos have not been seen.</numerusform>
        </translation>
    </message>
    <message numerus="yes">
        <source>Do you really want to delete all %n completed videos?</source>
        <translation>
            <numerusform>Do you really want to delete the one completed video?</numerusform>
            <numerusform>Do you really want to delete the %n completed videos?</numerusform>
        </translation>
    </message>
    <message>
        <source>Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sorry, author is already a favorite</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The author &quot;%1&quot; is already added to your favorite list</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Check for updates</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Help</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Getting help</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Please visit &lt;a href=&apos;www.heldenviewer.com&apos;&gt;www.heldenviewer.com&lt;/a&gt; and check out the FAQ. If this does not answer your question, send a message to admin@heldenviewer.com</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Clear active downloads</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Do you really want to delete all active downloads?</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>OptionDialog</name>
    <message>
        <source>Select Video player</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select save path</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No permission</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Move files to new location</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>If you wish to change the output directory, then all %1 files which have been (partially) downloaded, will be copied to the new location and then removed from the old location. %2MB free space are required for this operation. Continue?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>File exists, overwrite?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The file %1 exists. Overwrite the existing file?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error while copying file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sorry, but an error occurred while copying the file %1 to %2. Now all files which have already been copied will be removed.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>HeldenViewer - Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Download quality</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select default quality:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>1080p</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>720p</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>480p</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>320p</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>240p</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>If default is not available, use</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Higher quality</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>buttonGroup</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Lower quality</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Paths</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>..</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Save videos to:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Logfile</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Language</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Choose language:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>English</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>German</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select video player (must be able to play .flv files):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Can not write to this directory. Please select another directory.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No permission for directory &quot;%1&quot;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>Sorry, HeldenViewer is already running.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The application HeldenViewer is already running, only one instance can run at the same time.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ERROR: No quality in map</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Could not find Quality.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Could not create path &quot;%1&quot;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> hours</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> minutes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Not reading a VideoEntry or the version is incorrect. magic: %1, version: %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Not reading a VideoEntry or the version is incorrect.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Could not set video id, this should not happen.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Unseen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Seen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Downloading</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Known</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Could not open %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Could not read %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Reading data file: Version is unknown: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error: %1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>UpdateChecker</name>
    <message>
        <source>Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Could not check for updates.
 Error string: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Could not retrieve the current version of HeldenViewer.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>New version available</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Version %1 of HeldenViewer is available, you can download it at &lt;a href=&apos;www.heldenviewer.com&apos;&gt;www.heldenviewer.com&lt;/a&gt;. </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No new version available</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>HeldenViewer is up to date.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>HeldenViewer is up to date. </source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>YoutubeItem</name>
    <message>
        <source>Error while starting external player</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Please navigate to File/Edit Options and check the path to the external video player, it could not be started.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> viewers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Resume download</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Start download</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Stop download</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Are you sure?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Do you really want to delete this video from your hard drive?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Thumbnail</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Title</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Views</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Duration</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Start Download</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Published</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>0MB / 1MB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Delete Video</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Quality:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>1080p</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>720p</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>480p</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>320p</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>240p</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add author &quot;%1&quot; as favorite</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>YoutubeItemModel</name>
    <message>
        <source>Not reading a YoutubeItemModel or the version is incorrect. magic: [%1], version: [%2]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Error: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Could not open file for writing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>writeRawData returned an error.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>An error occured</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>File %1 does not exist.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Could not delete video file: %1.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>YoutubeLoader</name>
    <message>
        <source>Wrong size of fmt_stream_map structure: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>An error occured, trying to access the url to get the flash data.
 Error string: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>An error occured, trying to access the video url.
 Error string: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>An error occured, trying to access the header of the video url.
 Error string: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Requesting to start at byte %1, but only %2 are available</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The file already exists and has most likely been downloaded in a lower quality. Please delete the file </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The video size could not be retrieved and so the video cannot be retrieved either, url was &quot;%1&quot;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>YoutubeQuery</name>
    <message>
        <source>Serious Error: Could not find network reply in map.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No data could be retrieved for the author.
 Error string: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Could not download thumbnail.
 Error string: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No bytes are available, request type: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Coult not retrieve the number of videos of the author</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Author could not be extracted</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No data could be retrieved for the author, most likely the author does not exist. Please try to use the video search and get the exact name of the author.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No videos with the provided keywords were found.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Sorry</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Could not load image from data</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
