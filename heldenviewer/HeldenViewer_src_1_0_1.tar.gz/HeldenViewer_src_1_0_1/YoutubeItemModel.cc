/*
  HeldenViewer - A program to search, download and view Youtube videos.
  Copyright (C) 2011 Benjamin Held (admin@heldenviewer.com)

  This program is free software: you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation, either version 3 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/
#include "YoutubeItemModel.hh"
#include "SettingsManager.hh"
#include "StreamTypes.hh"
#include <QFileInfo>
#include <stdexcept>
#include <QDir>
#include <QMessageBox>
#include <QGridLayout>
#include <QTextEdit>
#include <QDebug>
#include <QPixmap>

YoutubeItemModel::YoutubeItemModel(const VideoEntry& videoEntry)
: videoEntry_(videoEntry), state_(Normal), viewState_(Default)
{
  connect(&youtubeQuery_, SIGNAL(thumbnailReady(QPixmap)), this, SLOT(thumbnailReady(QPixmap)));
  
//   youtubeQuery_.downloadThumbnail(videoEntry);
  emit viewStateChanged(viewState_);
  
//   qDebug("New ItemModel, title: %s", videoEntry.title.toLatin1().data());
}

YoutubeItemModel::YoutubeItemModel(QDataStream &in)
{
  quint32 headerMagic, version;
  in >> headerMagic; in >> version;
  if(headerMagic != MAGIC_YOUTUBEITEMMODEL || version != 1)
  {
    qDebug() << tr("Not reading a YoutubeItemModel or the version is incorrect. magic: [%1], version: [%2]").arg(headerMagic).arg(version);
    return;
  }
  qint32 state, viewState; in >> state; in >> viewState;
  state_ =  State(state);
  viewState_ = ViewState(viewState);
  
  in >> videoEntry_;
  connect(&youtubeQuery_, SIGNAL(thumbnailReady(const QPixmap &)), this, SLOT(thumbnailReady(const QPixmap &)));
  

  if(state_ == Downloaded) videoEntry_.bytesDownloaded = videoEntry_.videoSize;
  
  //Only download the thumbnail for currently active downloads
/*  if(videoEntry_.bytesDownloaded > 0)
    youtubeQuery_.downloadThumbnail(videoEntry_);*/
  emit viewStateChanged(viewState_);
}


VideoEntry YoutubeItemModel::videoEntry() const
{
  return videoEntry_;
}

void YoutubeItemModel::startDownload(int desiredQuality)
{
  if(state_ == Downloading || state_ == Downloaded) return;
  youtubeDownloader_.setReceiverObject(this);
  youtubeDownloader_.setUrl(videoEntry_.url());
  youtubeDownloader_.setDesiredQuality(desiredQuality);
  
  try
  {
    setViewState(Unseen);
    youtubeDownloader_.start();
  }
  catch(std::exception &e)
  {
    qDebug() << tr("Error: %1").arg(e.what());
  }
  
  changeState(Downloading);
}

void YoutubeItemModel::changeState(YoutubeItemModel::State state)
{
  state_ = state;
  emit stateChanged(state);
}


void YoutubeItemModel::stopDownload()
{
  if(state_ == Downloading)
  {
    youtubeDownloader_.quit();
    saveFile_.close();
    changeState(Normal);
  }
}

const QPixmap& YoutubeItemModel::thumbnail() const
{
  return thumbnail_;
}

void YoutubeItemModel::thumbnailReady(QPixmap thumbnail)
{
  thumbnail_ = thumbnail;
//   qDebug("Thumbnail ready: %s, size:%d", videoEntry().url.toLatin1().data(), thumbnail.toImage().byteCount());
  QString filename = "HELDENVIEWER_OWN_TYPES_" + videoEntry_.videoId() + ".jpg";
  //qDebug("%s.bytes: %d, width:%d, height:%d", videoEntry_.videoId().toLatin1().data(), thumbnail.toImage().byteCount(), thumbnail.width(), thumbnail.height());
  thumbnail.save(filename);
//   thumbnail.save(filename);
  
  emit thumbnailReady();
}

YoutubeItemModel::State YoutubeItemModel::state() const
{
  return state_;
}

bool YoutubeItemModel::event(QEvent* event)
{
//   qDebug("Event %d, %d", event->type(),QEvent::User +100);
  if(event->type() == QEvent::User +100)
  {
    YoutubeLoaderEvent *youtubeLoaderEvent = static_cast<YoutubeLoaderEvent * >(event);
    QByteArray buffer = youtubeLoaderEvent->buffer();
    int param = youtubeLoaderEvent->param();
    switch(youtubeLoaderEvent->message())
    {
      case VIDEOSIZE:
	      videoEntry_.videoSize = param;
	      emit downloadStatusChanged();
	      break;
      case START_DOWNLOAD:
      {
	      QString filePath = SettingsManager::instance().filePath(videoEntry_);
	      saveFile_.setFileName(filePath);
	      qint64 fileSize = QFileInfo(filePath).size();
	      youtubeDownloader_.startAtByte(fileSize);
	      videoEntry_.bytesDownloaded = fileSize;
	
	      if(!saveFile_.open(QIODevice::WriteOnly|QIODevice::Append))
	        qDebug() << tr("Could not open file for writing");
// 	      qDebug() << tr("Writing file: %1").arg(filePath);
	      break;
      }
      case DOWNLOAD_STATUS:
      {
	      QDataStream stream(&saveFile_);
	
	      videoEntry_.bytesDownloaded += param;
	      if(stream.writeRawData(buffer, param)==-1)
	        qDebug() << tr("writeRawData returned an error.");
        break;
      }
      case COMPLETE:
      {
	      state_ = Downloaded;
        videoEntry_.bytesDownloaded = videoEntry_.videoSize;
	      emit stateChanged(state_);
        if(viewState_ != Seen) setViewState(Unseen);
	      saveFile_.close();
	      break;
      }
      case DOWNLOADING_QUALITY:
      {
        videoEntry_.downloadQuality = param;
        break;
      }
      case LOADER_NETWORK_ERROR:
      {
        stopDownload();
//         QMessageBox::critical(0, "An error occured", buffer);
        //Too handle long texts, this workaround is necessary
        QMessageBox *box = new QMessageBox(QMessageBox::Critical, tr("An error occured"), buffer);
        QGridLayout *layout = qobject_cast<QGridLayout *>(box->layout());
        if (layout) 
        {
            QTextEdit *edit = new QTextEdit(buffer);
            edit->setReadOnly(true);
            layout->addWidget(edit, 0, 1);
        }
        box->exec();
        delete box;


        break;
      }
      case LOADER_BYTE_MISMATCH_ERROR:
      {
        QMessageBox::critical(0, tr("An error occured"), buffer + SettingsManager::instance().filePath(videoEntry_));
        break;
      }
    }
    emit downloadStatusChanged();
    return true;
  }
  return QObject::event(event);
}

QDataStream& operator<<(QDataStream& out, const YoutubeItemModel& model)
{
  out << MAGIC_YOUTUBEITEMMODEL;
  quint32 version = 1;
  out << version;
  out << (qint32)model.state();
  out << (qint32)model.viewState();
//   out << model.videoEntry();
  if(model.videoEntry().bytesDownloaded > 0)
    model.videoEntry().save(out, false);
  else
    model.videoEntry().save(out, true);
  
  return out;
}



bool YoutubeItemModel::deleteVideo()
{
  QDir videoFile;
  QString videoFilePath = SettingsManager::instance().filePath(videoEntry_);
  videoEntry_.bytesDownloaded = 0;
  if(!videoFile.exists(videoFilePath))
  {
    qDebug() << tr("File %1 does not exist.").arg(videoFilePath);
    return false;
  }
  stopDownload();

  if(!videoFile.remove(videoFilePath))
  {
    qDebug() << tr("Could not delete video file: %1.").arg(videoFilePath);
    return false;
  }

  emit downloadStatusChanged();
  changeState(Normal);
  return true;
}

void YoutubeItemModel::updateAccordingToOptions()
{
  int newQuality = SettingsManager::instance().defaultQuality();
  if(newQuality != videoEntry_.downloadQuality && videoEntry_.bytesDownloaded == 0 && state_ == Normal)
  {
    videoEntry_.downloadQuality = newQuality;
    emit downloadStatusChanged();
    
  }
}

void YoutubeItemModel::setViewState(YoutubeItemModel::ViewState viewState)
{
  viewState_ = viewState;
  emit viewStateChanged(viewState);
}

void YoutubeItemModel::triggerUpdate()
{
  emit downloadStatusChanged();
  emit stateChanged(state_);
  emit viewStateChanged(viewState_);
}

void YoutubeItemModel::updateVideoEntry(const VideoEntry& entry)
{
  if(videoEntry_.update(entry))
  {
    triggerUpdate();
  }
}
void YoutubeItemModel::videoFileDeleted()
{
  videoEntry_.bytesDownloaded = 0;
  state_ = Normal;
  triggerUpdate();
}

YoutubeItemModel::ViewState YoutubeItemModel::viewState() const
{
  return viewState_;
}

void YoutubeItemModel::downloadThumbnail()
{
  if(thumbnail_.isNull())
    youtubeQuery_.downloadThumbnail(videoEntry_);
  else emit thumbnailReady(thumbnail_);
}
