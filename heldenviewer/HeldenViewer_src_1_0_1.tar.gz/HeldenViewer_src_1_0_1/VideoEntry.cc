/*
  HeldenViewer - A program to search, download and view Youtube videos.
  Copyright (C) 2011 Benjamin Held (admin@heldenviewer.com)

  This program is free software: you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation, either version 3 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/
#include "VideoEntry.hh"
#include <stdexcept>
#include "StreamTypes.hh"
#include <QDebug>

QString VideoEntry::getFormattedTime() const
{
  int secondsInt = seconds.toInt();
  int hours = secondsInt/3600;
  secondsInt -= hours*3600;
  int minutes = secondsInt/60;
  secondsInt -= minutes*60;
  
  QString hoursString = "";
  QString minutesString = "";
  if(hours)
    hoursString = QString::number(hours).rightJustified(2,'0') + ":";
  minutesString = QString::number(minutes).rightJustified(2,'0') + ":";
  
//   return hoursString + minutesString + QString("%1").arg(secondsInt, 2, 10, QChar('0')).toUpper();
  return hoursString + minutesString + QString::number(secondsInt).rightJustified(2,'0') + (hours ? QObject::tr(" hours") : QObject::tr(" minutes"));
// QString::number(secondsInt);
}


bool operator<(const VideoEntry &lhv, const VideoEntry &rhv)
{
  return lhv.videoId() < rhv.videoId();
/*  if(lhv.author != rhv.author) return lhv.author < rhv.author;
  if(lhv.published != rhv.published) return lhv.published < rhv.published;
  if(lhv.url() != rhv.url()) return lhv.url() < rhv.url();
  return false;*/
}

bool operator==(const VideoEntry &lhv, const VideoEntry &rhv)
{
  return lhv.videoId() == rhv.videoId();
/*  return lhv.author == rhv.author &&
    lhv.published == rhv.published &&
    lhv.url() == rhv.url();*/
}

QDataStream& operator>>(QDataStream& in, VideoEntry& videoEntry)
{
  
  quint32 headerMagic, version; 
  in >> headerMagic; in >> version;
  if((headerMagic != MAGIC_VIDEOENTRY_SHORT && headerMagic !=MAGIC_VIDEOENTRY_LONG) || (version != 1))
  {
    qDebug() << QObject::tr("Not reading a VideoEntry or the version is incorrect. magic: %1, version: %2").arg(headerMagic).arg(version);
//     return *this;
    throw std::logic_error(QObject::tr("Not reading a VideoEntry or the version is incorrect.").toStdString());
  }
  
  //Short version, read only url
  if(headerMagic == MAGIC_VIDEOENTRY_SHORT)
  {
    QString videoId; in >> videoId; videoEntry.setVideoId(videoId);
  }
  //Long version
  else
  {
    in >> videoEntry.author;
    in >> videoEntry.title;
    QString url; in >> url; videoEntry.setUrl(url);
    in >> videoEntry.bytesDownloaded;
    in >> videoEntry.videoSize;
    in >> videoEntry.published;
    in >> videoEntry.updated;
    in >> videoEntry.seconds;
    in >> videoEntry.thumbnailUrl;
    in >> videoEntry.viewCount;
    in >> videoEntry.downloadQuality;
    in >> videoEntry.numRaters;
    in >> videoEntry.ratingAverage;
    in >> videoEntry.commentCount;
  }
  return in;
}

QString VideoEntry::videoId() const
{
  return videoId_;
}

void VideoEntry::setVideoId(const QString& id)
{
  videoId_ = id;
//   url_ = "http://www.youtube.com/watch?v=" + videoId_;
}


QString VideoEntry::url() const
{
  return "http://www.youtube.com/watch?v=" + videoId_;
//   return url_;
}

void VideoEntry::setUrl(const QString& url)
{
//   url_ = url;
//   qDebug("URL:%s", url_.toLatin1().data());
  //Extract the video Id.
  int begin = url.indexOf("v=");
  if(begin == -1)
    qDebug() << QObject::tr("Could not set video id, this should not happen.");
  begin += 2;
  int end = url.indexOf("&", begin);
  if(end == -1) end = url.size();
  videoId_ = url.mid(begin, end-begin);
//   qDebug("Videoid: %s", videoId.toLatin1().data());
}

//Change from version 1.0 to 1.1 -> videoEntry.updated is now written directly after videoEntry.published
void VideoEntry::save(QDataStream& out, bool shortFormat)
{
  quint32 version = 1;
  if(shortFormat)
  {
//     out << QString("VES");
    out << MAGIC_VIDEOENTRY_SHORT;
    out << version;
    out << videoId();
  }
  else
  {
    out << MAGIC_VIDEOENTRY_LONG;
    out << version;
    out << author;
    out << title;
    out << url();
    out << bytesDownloaded;
    out << videoSize;
    out << published;
    out << updated;
    out << seconds;
    out << thumbnailUrl;
    out << viewCount;
    out << downloadQuality;
    out << numRaters;
    out << ratingAverage;
    out << commentCount;
  }  
}

bool VideoEntry::update(const VideoEntry& entry)
{
  bool updated = false;
  if(entry.author != author){updated = true;}
  else if(entry.commentCount != commentCount){updated = true;}
  else if(entry.numRaters != numRaters){updated = true;}
  else if(entry.published != published){updated = true;}
  else if(entry.ratingAverage != ratingAverage){updated = true;}
  else if(entry.seconds != seconds){updated = true;}
  else if(entry.thumbnailUrl != thumbnailUrl){updated = true;}
  else if(entry.title != title){updated = true;}
  else if(entry.updated != this->updated){updated = true;}
  else if(entry.videoId() != videoId()){updated = true;}
  else if(entry.viewCount != viewCount){updated = true;}
  if(updated)
    copyFields(entry);
  return updated;
}

void VideoEntry::copyFields(const VideoEntry& entry)
{
  //Do not copy downloadQuality, bytesDownloaded and videoSize
  author = entry.author;
  commentCount = entry.commentCount;
  numRaters = entry.numRaters;
  published = entry.published;
  ratingAverage = entry.ratingAverage;
  seconds = entry.seconds;
  thumbnailUrl = entry.thumbnailUrl;
  title = entry.title;
  updated = entry.updated;
  viewCount = entry.viewCount;
}
