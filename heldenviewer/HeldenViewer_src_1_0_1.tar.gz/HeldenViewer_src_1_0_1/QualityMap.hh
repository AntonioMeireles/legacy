/*
  HeldenViewer - A program to search, download and view Youtube videos.
  Copyright (C) 2011 Benjamin Held (admin@heldenviewer.com)

  This program is free software: you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation, either version 3 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/
#ifndef QUALITYMAP_HH
#define QUALITYMAP_HH

#include <QMap>

/**
  * Translates the qualities specified in a youtube video xml file
  * to the qualities used in the option dialog.
*/
class QualityMap
{
  QMap<int, QString> qualityToURL_;
  QMap<int, int> qualityOptionsToQualityYoutube_;
  
  int desiredQuality_;
  //! Translate quality from option menu which is from 0 to 5 for 1080p, 720p, ...
  //! to the quality which is required in the url
  int translateQuality(int quality);
  
public:
  QualityMap();
  //! Add a quality with the corresponding url
  void addItem(int quality, const QString &url);
  //! Selects the URL which corresponds to the chosen default quality (Can be received by SettingsManager)
  QString getCorrectURL();
  //! The desired quality is not always available, so this function
  //! returns the nearest to the desired quality which is available
  int getAvailableQualityNearestToDesired();
  //! Set the desired quality
  void setDesiredQuality(int quality);
};

#endif // QUALITYMAP_HH
