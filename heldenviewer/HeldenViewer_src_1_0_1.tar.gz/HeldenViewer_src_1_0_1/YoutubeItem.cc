/*
  HeldenViewer - A program to search, download and view Youtube videos.
  Copyright (C) 2011 Benjamin Held (admin@heldenviewer.com)

  This program is free software: you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation, either version 3 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/
#include "YoutubeItem.hh"
#include <QProcess>
#include "SettingsManager.hh"
#include <QMessageBox>
#include <QFileInfo>
#include "YoutubeItemModel.hh"
#include "YoutubeItemColors.hh"
#include <QDebug>
#include <QMenu>
#include <QAction>
#include <QDir>

YoutubeItem::YoutubeItem(YoutubeItemModel *videoItemModel, QWidget* parent, Qt::WindowFlags flags): 
QMainWindow(parent, flags), model_(videoItemModel)
{
  setupUi(this);
  setObjectName("YoutubeItem");
  setAttribute( Qt::WA_AlwaysShowToolTips);

  
  
  pb_downloadProgress->setValue(0);
  YoutubeItemColors::instance().addComboboxItems(cb_videoStatus);
//   setupGui(YoutubeItemModel::Normal);
  
  connect(model_, SIGNAL(thumbnailReady()), this, SLOT(thumbnailReady()));
//   la_thumbnail->setPixmap(model_->thumbnail());
  thumbnailReady();
  connect(model_, SIGNAL(downloadStatusChanged()), this, SLOT(downloadStatusChanged()));
  connect(model_, SIGNAL(stateChanged(YoutubeItemModel::State)), this, SLOT(stateChanged(YoutubeItemModel::State)));
  connect(model_, SIGNAL(viewStateChanged(YoutubeItemModel::ViewState)), this, SLOT(viewStateChanged(YoutubeItemModel::ViewState)));
  
  connect(pb_download, SIGNAL(clicked()), this, SLOT(toggleDownload()));
  connect(pb_viewVideo, SIGNAL(clicked()), this, SLOT(viewVideo()));
  connect(pb_deleteVideo, SIGNAL(clicked()), this, SLOT(deleteVideo()));
  
  connect(cb_videoStatus, SIGNAL(currentIndexChanged ( int)), this,SLOT( videoStatusChanged(int)));

  connect(this, SIGNAL( customContextMenuRequested ( const QPoint & )), this, SLOT( customContextMenuRequested ( const QPoint &  )));
  setContextMenuPolicy(Qt::CustomContextMenu);
  //Just a high number..
  pb_downloadProgress->setMaximum(1024*1024*1024);
  
  downloadStatusChanged();
  viewStateChanged(model_->viewState());
  setupGui(model_->state());
  
  model_->downloadThumbnail();
  
}


YoutubeItem::~YoutubeItem()
{
}


void YoutubeItem::stateChanged(YoutubeItemModel::State state)
{
  setupGui(state);
  
  if(state == YoutubeItemModel::Downloading)
    emit downloadStarted(model_->videoEntry());
  if(state == YoutubeItemModel::Downloaded)
    emit downloadFinished(model_->videoEntry());
}

void YoutubeItem::thumbnailReady()
{
  if(model_->thumbnail().isNull()) return;
  
  la_thumbnail->setPixmap(model_->thumbnail().scaled(la_thumbnail->width(), la_thumbnail->height(), Qt::KeepAspectRatio));
  QString filename = "HELDENVIEWER_OWN_TYPES_" + videoEntry().videoId() + ".jpg";
  QSize imageSize = model_->thumbnail().size();
  
  int width = model_->thumbnail().width(), height = width*(float)imageSize.height()/imageSize.width();
//   float aspect = (float)imageSize.height()/imageSize.width();
//   la_thumbnail->setToolTip("<html><img width=300 height=" + QString::number((int)(300*aspect)) + " src=\""+filename + "\"></img></html>");
  la_thumbnail->setToolTip("<html><img width=" + QString::number(width) + " height=" + QString::number(height) + " src=\""+filename + "\"></img></html>");
}

void YoutubeItem::toggleDownload()
{
  switch(model_->state())
  {
    case YoutubeItemModel::Normal:
      model_->startDownload(cb_quality->currentIndex());
      break;
    case YoutubeItemModel::Downloading:
      model_->stopDownload();
      break;
    case YoutubeItemModel::Downloaded:
      break;
  }
}

void YoutubeItem::viewVideo()
{
  QStringList parameters;
  QString file = QDir::toNativeSeparators(SettingsManager::instance().filePath(model_->videoEntry()));
  parameters << file;
    
  QProcess *myProcess = new QProcess(0);
  connect(myProcess, SIGNAL(error ( QProcess::ProcessError )), this, SLOT(error ( QProcess::ProcessError )));
  // Start the QProcess instance.
  myProcess->start(SettingsManager::instance().externalPlayer(), parameters);
  model_->setViewState(YoutubeItemModel::Seen);
}

void YoutubeItem::error(QProcess::ProcessError error)
{
  QMessageBox::critical(this, tr("Error while starting external player"), tr("Please navigate to File/Edit Options and check the path to the external video player, it could not be started."));
}

void YoutubeItem::setupGui(YoutubeItemModel::State state)
{
//   la_title->setText("<i><b>" + model_->videoEntry().author + "</b></i>: " + "<b><large><font size=5>" + model_->videoEntry().title.toLatin1() + "</font></b>");
  la_title->setText("<i><b>" + model_->videoEntry().author + "</b></i>: " + "<b><large><font size=5>" + QString::fromUtf8(model_->videoEntry().title.toLatin1()) + "</font></b>");
//   la_title->setText("<i><b>" + model_->videoEntry().author + "</b></i>: " + "<b><large><font size=5>" + QString(model_->videoEntry().title.toUtf8())+ "</font></b>");
/*  QFont font;
  font.setPointSize(16);
  font.setBold(true);*/
  
//   la_title->setFont(font);
  la_title->adjustSize();
  
  la_duration->setText(model_->videoEntry().getFormattedTime());
  la_duration->adjustSize();

  la_duration->setFixedWidth(la_duration->width()+5);
  
  la_views->setText(model_->videoEntry().viewCount + tr(" viewers"));
  la_views->adjustSize();
  la_views->setFixedWidth(la_views->width()+5);
  
  la_published->setText(model_->videoEntry().published.left(10));
  la_published->adjustSize();
  la_published->setFixedWidth(la_published->width()+5);
  
  pb_viewVideo->show();
  
  switch(state)
  {
    case YoutubeItemModel::Normal:
    {
//       if(pb_downloadProgress->value() > 0)
      if(model_->videoEntry().bytesDownloaded > 0)
      {
        pb_download->setText(tr("Resume download"));
//         pb_download->adjustSize();
        pb_downloadProgress->show();
        la_bytesDownloaded->show();
        pb_deleteVideo->show();
        cb_quality->setEnabled(false);
      }
      else
      {
        pb_downloadProgress->hide();
        la_bytesDownloaded->hide();
        pb_download->setText(tr("Start download"));
//         pb_download->adjustSize();
        pb_deleteVideo->hide();
        cb_quality->setEnabled(true);
        pb_viewVideo->hide();
      }
      pb_download->show();
    }
    break;
    
    case YoutubeItemModel::Downloading:
      pb_downloadProgress->show();
      la_bytesDownloaded->show();
      pb_download->show();
      pb_download->setText(tr("Stop download"));
//       pb_download->adjustSize();
      pb_deleteVideo->show();
      cb_quality->setEnabled(false);
    break;
    
    case YoutubeItemModel::Downloaded:
      pb_downloadProgress->show();
      la_bytesDownloaded->show();
      pb_download->hide();
      pb_deleteVideo->show();
      cb_quality->setEnabled(false);
      //pb_download->setText("Delete Video");
      //pb_download->setStyleSheet("background-color:red");
      //pb_download->setStyleSheet("background-color: red; border-style: outset; border-width: 2px; border-color: beige; min-width: 5em;padding: 2px;");

    break;
  }
}

void YoutubeItem::downloadStatusChanged()
{
  int videoSize = model_->videoEntry().videoSize;
  pb_downloadProgress->setMinimum(0);
  pb_downloadProgress->setMaximum(videoSize);
  
  int totalBytes = model_->videoEntry().bytesDownloaded;
  pb_downloadProgress->setValue(totalBytes);
  int preComma = 0;
  int totalBytesCopy = totalBytes/1024.0/1024.0;
  while(totalBytesCopy /= 10) preComma++;
  //qDebug("%d/%d", totalBytes, videoSize);
  //la_bytesDownloaded->setText(QString::number(totalBytes/1024.0/1024.0,'g',4).leftJustified(preComma+5,'0') + "/" + QString::number(videoSize/1024.0/1024.0) + "MB");
  la_bytesDownloaded->setText(QString::number(totalBytes/1024.0/1024.0) + "/" + QString::number(videoSize/1024.0/1024.0) + "MB");
  la_bytesDownloaded->adjustSize();
  cb_quality->setCurrentIndex(videoEntry().downloadQuality);
  setBackgroundColor();
}

VideoEntry YoutubeItem::videoEntry()
{
  return model_->videoEntry();
}

void YoutubeItem::deleteVideo()
{
  if(QMessageBox::question(this, tr("Are you sure?"), tr("Do you really want to delete this video from your hard drive?"), QMessageBox::Yes|QMessageBox::No, QMessageBox::No) == QMessageBox::Yes)
  {
    model_->stopDownload();
    model_->deleteVideo();
    emit videoDeleted(videoEntry());
  }
}

void YoutubeItem::viewStateChanged(YoutubeItemModel::ViewState state)
{
/*  la_state->setText( YoutubeItemColors::instance().getLabelText(model_));
  la_state->setStyleSheet("background-color:rgb(240,240,240)");
  la_state->adjustSize();*/
  
//   backgroundColor_ = YoutubeItemColors::instance().calcColorIndex(model_);
  setBackgroundColor();
}

void YoutubeItem::setBackgroundColor()
{
  
  setStyleSheet( "QWidget#YoutubeItem {background-color: " +
  YoutubeItemColors::instance().getColor(model_) + "}");
  YoutubeItemColors::instance().setComboboxItems(model_, cb_videoStatus);
  cb_videoStatus->setCurrentIndex(YoutubeItemColors::instance().calcColorIndex(model_));
}

void YoutubeItem::videoStatusChanged(int index)
{
}

void YoutubeItem::customContextMenuRequested(const QPoint &pos)
{
  QMenu menu(this);
  QAction addAction(tr("Add author \"%1\" as favorite").arg(videoEntry().author), &menu);
  //QAction deleteAction(tr("Delete item"), &menu);
  
  menu.addAction(&addAction);
  
  QAction *action = menu.exec(mapToGlobal(pos));
  if(action == &addAction)
  {
    emit addAuthorAsFavorite(videoEntry().author);
  }
}

YoutubeItemModel* YoutubeItem::model()
{
  return model_;
}
