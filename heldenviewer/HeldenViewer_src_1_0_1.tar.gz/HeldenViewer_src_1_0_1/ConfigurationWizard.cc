/*
  HeldenViewer - A program to search, download and view Youtube videos.
  Copyright (C) 2011 Benjamin Held (admin@heldenviewer.com)

  This program is free software: you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation, either version 3 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/
#include "ConfigurationWizard.hh"
#include "SettingsManager.hh"
#include <QFileDialog>
#include <QDebug>
#include <QMessageBox>

ConfigurationWizard::ConfigurationWizard(QWidget* parent, Qt::WindowFlags flags): QWizard(parent, flags)
{
  setupUi(this);
  
  connect(pb_selectVideoPlayerPath, SIGNAL(clicked()), this, SLOT(selectVideoPlayerPath()));
  connect(pb_selectVideoSavePath, SIGNAL(clicked()), this, SLOT(selectVideoSavePath()));
  
  le_videoSavePath->setText(SettingsManager::instance().savePath());

}

void ConfigurationWizard::selectVideoPlayerPath()
{
  QString dir = QFileDialog::getOpenFileName(this, tr("Select Video player"),  le_videoPlayerPath->text());
  if(dir != "")
    le_videoPlayerPath->setText(QDir::toNativeSeparators(dir));
}

void ConfigurationWizard::selectVideoSavePath()
{
  QString dir = QFileDialog::getExistingDirectory(this, tr("Select save path"), le_videoSavePath->text());
  if(dir != "")
  {
    if(dir.right(1) != "/" && dir.right(1) != "\\")
    {
      dir += QDir::separator();
    }
    if(!QFileInfo(dir).isWritable())
    {
      QMessageBox::critical(this, tr("No permission"), tr("Can not write to this directory. Please select another directory."));
      qDebug() << tr("No permission for directory \"%1\"").arg(dir);
    }
    else
    {
      le_videoSavePath->setText(QDir::toNativeSeparators(dir));
    }
  }
}


void ConfigurationWizard::accept()
{
  QSettings &settings = SettingsManager::instance().settings();
  
  settings.beginGroup("Options");
    settings.setValue("externalPlayer", le_videoPlayerPath->text());
    settings.setValue("saveVideoPath", le_videoSavePath->text());
  settings.endGroup();
  QDialog::accept();
}