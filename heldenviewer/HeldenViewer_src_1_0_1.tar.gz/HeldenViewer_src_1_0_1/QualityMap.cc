/*
  HeldenViewer - A program to search, download and view Youtube videos.
  Copyright (C) 2011 Benjamin Held (admin@heldenviewer.com)

  This program is free software: you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation, either version 3 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/
#include "QualityMap.hh"
#include "SettingsManager.hh"
#include <QDebug>

QualityMap::QualityMap()
: desiredQuality_(0)
{
	//1080p
  qualityOptionsToQualityYoutube_[0] = 37;
	//720p
  qualityOptionsToQualityYoutube_[1] = 22;
  //qualityOptionsToQualityYoutube_[2] = 35;
	//480p
	qualityOptionsToQualityYoutube_[2] = 44;
	//320p
  //qualityOptionsToQualityYoutube_[3] = 34;
	qualityOptionsToQualityYoutube_[3] = 43;
	
	//240p
  qualityOptionsToQualityYoutube_[4] = 18;
  qualityOptionsToQualityYoutube_[5] = 5;
}


void QualityMap::addItem(int quality, const QString& url)
{
  qualityToURL_[quality] = url;
}

int QualityMap::getAvailableQualityNearestToDesired()
{
  if(qualityToURL_.size() == 0)
  {
    qDebug() << QObject::tr("ERROR: No quality in map");
    return -1;
  }
    
  
//   int defaultQuality = SettingsManager::instance().defaultQuality();
  int quality = desiredQuality_;
  
  int add = 1;
  if(SettingsManager::instance().higherQuality()) add = -1;
  
  QMap<int,QString>::iterator it;
  do
  {
    it = qualityToURL_.find(translateQuality(quality));
    if(it == qualityToURL_.end())
    {
      quality += add;
      if(quality > 5)
      {
        quality = 5;
        add = -1;
      }
      if(quality < 0)
      {
        quality = 0;
        add = 1;
      }
    }
//     else quality = *it;
  }while(it == qualityToURL_.end());
  return quality;
}

QString QualityMap::getCorrectURL()
{
  return qualityToURL_[translateQuality(getAvailableQualityNearestToDesired())];
}

int QualityMap::translateQuality(int quality)
{
  if(qualityOptionsToQualityYoutube_.find(quality) == qualityOptionsToQualityYoutube_.end())
    qDebug() << QObject::tr("Could not find Quality.");
  return qualityOptionsToQualityYoutube_[quality];
}

void QualityMap::setDesiredQuality(int quality)
{
  desiredQuality_ = quality;
}
