/*
  HeldenViewer - A program to search, download and view Youtube videos.
  Copyright (C) 2011 Benjamin Held (admin@heldenviewer.com)

  This program is free software: you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation, either version 3 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/
#include "UpdateChecker.hh"

#include <QWidget>
#include <QMessageBox>
#include <QNetworkReply>
#include <QDebug>
#include <QDomDocument>
#include "SettingsManager.hh"

UpdateChecker::UpdateChecker(QWidget* messageParent)
: messageParent_(messageParent)
{
  connect(&manager_, SIGNAL(finished(QNetworkReply*)),
         this, SLOT(replyFinished(QNetworkReply*)));

}


void UpdateChecker::checkForUpdates()
{
  manager_.get(QNetworkRequest(QUrl("http://www.heldenviewer.de/updates/update2.xml")));
//   manager_.exec();
}

void UpdateChecker::replyFinished(QNetworkReply* reply)
{
  if (reply->error() != QNetworkReply::NoError)
  {
    QMessageBox::critical(messageParent_, tr("Error"), tr("Could not check for updates.\n Error string: %1").arg(reply->errorString()).toLatin1());
    return;
  }
  QByteArray xmlContent = reply->readAll();
  
  QDomDocument document;
  document.setContent(xmlContent);

  
  QDomNodeList versions = document.elementsByTagName("version");
  QDomNodeList versionStrings = document.elementsByTagName("versionString");
  if(document.documentElement().tagName() != "HeldenViewer" || versions.size() != 1 || versionStrings.size() != 1)
  {
    QMessageBox::critical(messageParent_, tr("Error"), tr("Could not retrieve the current version of HeldenViewer."));
    return;
  }
  int version = versions.at(0).toElement().text().toInt();
  QString versionString = versionStrings.at(0).toElement().text();
  
  //A special message can be shown, this is dependend on the flag specialMessageForNewVersion
  //If this flag is true, then the message is only shown if currentVersion < version on server, otherwise the message is always shown
  QDomNodeList specialMessages = document.elementsByTagName("specialMessage_"+SettingsManager::instance().language());
  QDomNodeList specialMessageForNewVersions = document.elementsByTagName("specialMessageForNewVersion");
  bool specialMessageForNewVersion = false;
  QString specialMessage="";
  if(specialMessages.size() == 1 && specialMessageForNewVersions.size() == 1)
  {
    specialMessageForNewVersion = specialMessageForNewVersions.at(0).toElement().text().toInt();
    specialMessage = specialMessages.at(0).toElement().text();
  }
  
  if(version > SettingsManager::instance().version())
    QMessageBox::information(messageParent_, tr("New version available"), tr("Version %1 of HeldenViewer is available, you can download it at <a href='www.heldenviewer.com'>www.heldenviewer.com</a>. ").arg(versionString)+specialMessage);
  else
  {
    if(specialMessageForNewVersion)
      QMessageBox::information(messageParent_, tr("No new version available"), tr("HeldenViewer is up to date."));
    else
      QMessageBox::information(messageParent_, tr("No new version available"), tr("HeldenViewer is up to date. ") + specialMessage);
      
      
  }
}
