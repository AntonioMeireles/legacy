/*
  HeldenViewer - A program to search, download and view Youtube videos.
  Copyright (C) 2011 Benjamin Held (admin@heldenviewer.com)

  This program is free software: you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation, either version 3 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/
#include "YoutubeItemColors.hh"
#include "YoutubeItemModel.hh"
#include <QComboBox>
#include <QStandardItemModel>
#include <QDebug>

YoutubeItemColors::YoutubeItemColors()
{
//   savedColors_ = false;
  
  colorVector_[COLOR_UNSEEN] = QColor(255,165,0);
  colorVector_[COLOR_SEEN] = QColor(21,255,40);
  colorVector_[COLOR_NEW] = Qt::yellow;
  colorVector_[COLOR_DOWNLOADING] = QColor(203,232,234);
  colorVector_[COLOR_DEFAULT] = QColor(255,255,255);
  
  colorStrings_[COLOR_UNSEEN] = QObject::tr("Unseen");
  colorStrings_[COLOR_SEEN] = QObject::tr("Seen");
  colorStrings_[COLOR_NEW] = QObject::tr("New");
  colorStrings_[COLOR_DOWNLOADING] = QObject::tr("Downloading");;
  colorStrings_[COLOR_DEFAULT] = QObject::tr("Known");;
  
  const int size = 40;
  for(int i = 0; i < COLOR_COUNT; ++i)
  {
    QImage current(size,size, QImage::Format_RGB32);
    current.fill(colorVector_[i].rgb());
    for(int k = 0; k < size; k++)
    {
      current.setPixel(k,0,0);
      current.setPixel(0,k,0);
      current.setPixel(size-1,k,0);
      current.setPixel(k,size-1,0);
    }
    
   colorIcons_[i] = QPixmap::fromImage(current);
   
/*    QString filename = "HELDENVIEWER_OWN_TYPES_" + colorStrings_[i] + ".png";
//     qDebug() << filename;
    QPixmap::fromImage(current).save(filename);*/
  }
}

YoutubeItemColors::YoutubeItemColors(const YoutubeItemColors& rhv)
{

}

YoutubeItemColors& YoutubeItemColors::operator=(const YoutubeItemColors& rhv)
{
  return *this;
}

YoutubeItemColors& YoutubeItemColors::instance()
{
  static YoutubeItemColors instance;
  return instance;
}

YoutubeItemColors::ColorIndex YoutubeItemColors::calcColorIndex(YoutubeItemModel* model)
{
  ColorIndex colorIndex = COLOR_DEFAULT;
  
  YoutubeItemModel::ViewState viewState = model->viewState();
  YoutubeItemModel::State state = model->state();
  if(state == YoutubeItemModel::Downloaded)
  {
    if(viewState != YoutubeItemModel::Seen)
      //Orange
      colorIndex = COLOR_UNSEEN;
  }
  else
  {
    if(model->videoEntry().bytesDownloaded > 0 || state == YoutubeItemModel::Downloading)
      colorIndex = COLOR_DOWNLOADING;
    else if(viewState == YoutubeItemModel::NewVideo)
      colorIndex = COLOR_NEW;
  }
  if(viewState == YoutubeItemModel::Seen)
    colorIndex = COLOR_SEEN;
  return colorIndex;
}

QColor YoutubeItemColors::calcColor(YoutubeItemModel *model)
{
  return colorVector_[calcColorIndex(model)];
}


QString YoutubeItemColors::getColor(YoutubeItemModel *model)
{
  QColor result = calcColor(model);
  return "rgb(" + QString::number(result.red()) + "," + QString::number(result.green()) +"," + QString::number(result.blue()) + ")";
}

void YoutubeItemColors::setComboboxItems(YoutubeItemModel* model, QComboBox* comboBox)
{
  ColorIndex colorIndex = calcColorIndex(model);
  QVector<bool> enabled(COLOR_COUNT, false);
  enabled[colorIndex] = true;
  for(int i = 0; i < COLOR_COUNT; ++i)
    ((QStandardItemModel*)comboBox->model())->item(i)->setEnabled(enabled[i]);
}

void YoutubeItemColors::setViewState(YoutubeItemModel* model, int selected)
{
  if(selected == COLOR_SEEN)
    model->setViewState(YoutubeItemModel::Seen);
  if(selected == COLOR_UNSEEN)
    model->setViewState(YoutubeItemModel::Unseen);
}

void YoutubeItemColors::addComboboxItems(QComboBox* comboBox)
{
//   comboBox->clear();
  for(int i = 0; i < COLOR_COUNT; ++i)
    comboBox->addItem(colorIcons_[i], colorStrings_[i]);
}

QString YoutubeItemColors::getColorFromIndex(YoutubeItemColors::ColorIndex index)
{
  QColor result = colorVector_[index];
  return "rgb(" + QString::number(result.red()) + "," + QString::number(result.green()) +"," + QString::number(result.blue()) + ")";
}

QString YoutubeItemColors::getLabelText(YoutubeItemModel* model)
{
  YoutubeItemColors::ColorIndex index = calcColorIndex(model);
  QString filename = "HELDENVIEWER_OWN_TYPES_" + colorStrings_[index] + ".png";
  return QString("<img src=\"%1\">%2").arg(filename).arg(colorStrings_[index]);
}

