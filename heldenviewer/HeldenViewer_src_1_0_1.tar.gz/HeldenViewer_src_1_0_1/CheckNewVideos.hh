/*
  HeldenViewer - A program to search, download and view Youtube videos.
  Copyright (C) 2011 Benjamin Held (admin@heldenviewer.com)

  This program is free software: you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation, either version 3 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/
#ifndef CHECKNEWVIDEOS_HH
#define CHECKNEWVIDEOS_HH

#include <QObject>
#include <QVector>
#include "YoutubeQuery.hh"
#include <QPair>

class YoutubeItemManager;
class FavoriteDataModel;
class QProgressBar;

/**
  * This class is able to check for new videos, given the FavoriteDataModel
  * which holds the names of all favorites. After the check method is called,
  * the class will emit the finishedCheckNewVideos method with the results
  * of the check. This class is a singleton, as parallel checks would make
  * it much more difficult.
*/

class CheckNewVideos : public QObject
{
  Q_OBJECT
  
public:
  //! Stores The names of the favorites and the number of new video items
  typedef QVector<QPair<QString,int> > FavoriteNewVideosVector;
private:
  CheckNewVideos();
  CheckNewVideos(const CheckNewVideos &rhv);
  CheckNewVideos &operator=(const CheckNewVideos &rhv);
  
//   FavoriteDataModel *favorites_;
  //! Is necessary to check if a video is new
  YoutubeItemManager *youtubeItemManager_;
  //! Holds the result of the check
  FavoriteNewVideosVector favoriteResultVector_;
  YoutubeQuery youtubeQuery_;
  //! Is used to indicate the progress of the check
  QProgressBar *progress_;
  
  //! Ensure to start a check only if working_ == false
  bool working_;
  //! As the network requests are asynchron, this index provides the
  //! necessary background information which author in favoriteResultVector_ is currently checked
  int currentIndex_;
private slots:
  //! Counts how many new videos are there, operating on author with index currentIndex_
  void recentVideos(const std::vector<VideoEntry> &videoEntries, int videosCount);
public:
  static CheckNewVideos &instance();
  //! The main function which needs the names of the favorites, provided by the
  //! FavoriteDataModel as well as the YoutubeItemManager in order to check if
  //! a video is new. The progressbar is used to show the progress of the operation
  //! as it may take a while for many favorites.
  void check(FavoriteDataModel *favorites, YoutubeItemManager *youtubeItemManager, QProgressBar *progress);
signals:
  void finishedCheckNewVideos(const CheckNewVideos::FavoriteNewVideosVector &result);
};




#endif