/*
  HeldenViewer - A program to search, download and view Youtube videos.
  Copyright (C) 2011 Benjamin Held (admin@heldenviewer.com)

  This program is free software: you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation, either version 3 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/
#include "SettingsManager.hh"
#include "VideoEntry.hh"
#include <QFileInfo>
#include <QDesktopServices>
#include <QDir>
#include <QDebug>
#include <QCoreApplication>

SettingsManager& SettingsManager::operator=(const SettingsManager& )
{
  return *this;
}
SettingsManager::SettingsManager()
: settings_(QSettings::IniFormat, QSettings::UserScope, QString("Heldensoftware"), QString("HeldenViewer"))
{
  
}
SettingsManager::SettingsManager(const SettingsManager& )
{

}

SettingsManager::~SettingsManager()
{
  
}

SettingsManager& SettingsManager::instance()
{
  static SettingsManager instance;
  return instance;
}


const QSettings &SettingsManager::settings() const
{
  return settings_;
}

QSettings &SettingsManager::settings()
{
  return settings_;
}

QString SettingsManager::externalPlayer() const
{
  return settings_.value("Options/externalPlayer", "vlc").toString();
}

int SettingsManager::defaultQuality() const
{
  return settings_.value("Options/defaultQuality", 0).toInt();
}
bool SettingsManager::higherQuality() const
{
  return settings_.value("Options/higherQuality", false).toBool();
}

QString SettingsManager::savePath() 
{
  QString path;
  path = settings_.value("Options/saveVideoPath", dataDirectory() + "/Videos/").toString();

  path = QFileInfo(path).absoluteDir().absolutePath();
  if(path != "" && path.right(1) != "/" && path.right(1) != "\\")
    path += QDir::separator();

  QDir dir;
  if(!dir.mkpath(path))
    qDebug() << QObject::tr("Could not create path \"%1\"").arg(path);
  return QDir::toNativeSeparators(path);
}

QString SettingsManager::filePath(const VideoEntry& entry)
{
  QString filename = "Heldenviewer-" + entry.videoId();
//   QString filename = entry.author + "-"  +entry.published.left(10)  + "-"+ entry.title;
//   QString title = entry.title;

  //Actually there should be no illegal characters in the video id
  //but you never know..
  QString illegalChars = "<>:\"/\\|?*.";
  for(int i = 0; i < illegalChars.size(); ++i)
    filename.replace(illegalChars[i], "-");
  return QFileInfo(savePath() + filename + ".flv").absoluteFilePath();
}

QString SettingsManager::dataDirectory()
{
  QString location = QDesktopServices::storageLocation(QDesktopServices::DataLocation);
  /*#ifdef Q_WS_MAC
      location.insert(location.count() - QCoreApplication::applicationName().count(),
    QCoreApplication::organizationName());
  #endif*/
  location += QDir::separator();

  QDir dir;
  //qDebug() << location;
  if(!dir.mkpath(QFileInfo(location).absoluteDir().absolutePath()))
    qDebug() << QObject::tr("Could not create path \"%1\"").arg(QFileInfo(location).absoluteDir().absolutePath());
  return location;

}

QString SettingsManager::logFilePath()
{
  return dataDirectory()+"HeldenViewer.log";
}

int SettingsManager::version()
{
  return 2;
}

QString SettingsManager::language()
{
  return language_;
}

void SettingsManager::setLanguage(const QString language)
{
  language_ = language;
}

QString SettingsManager::resourceDirectory()
{
#ifdef Q_WS_MAC
	QDir dir(QCoreApplication::applicationDirPath());
	dir.cdUp();
	dir.cd("Resources");
  return dir.absolutePath() + "/";
#else
  return "";
#endif
}

