/*
  HeldenViewer - A program to search, download and view Youtube videos.
  Copyright (C) 2011 Benjamin Held (admin@heldenviewer.com)

  This program is free software: you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation, either version 3 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/
#ifndef YOUTUBEITEM_HH
#define YOUTUBEITEM_HH

#include <QMainWindow>
#include "ui_YoutubeItem.h"
#include "VideoEntry.hh"
#include "YoutubeQuery.hh"
#include <QProcess>
#include "YoutubeItemModel.hh"
#include "YoutubeItemColors.hh"

/**
  * This class shows a widget containing all necessary information for one video
  * and enables the user to interact with this video in several ways:
  * start download, stop download, resume download, view video, delete video
  * There may be up to two YoutubeItems with the same model, as a YoutubeItem
  * can appear in the search tab and the downloading/downloaded tab.
*/
class YoutubeItem : public QMainWindow, private Ui::YoutubeItem
{
  Q_OBJECT
  
  YoutubeItemModel *model_;
  
  //! Sets the gui of the widget depending on the state
  void setupGui(YoutubeItemModel::State state);
  void setBackgroundColor();
private slots:
  //! Is called when the thumbnail is downloaded from the internet
  void thumbnailReady();
  //! connected to the start/stop download button
  void toggleDownload();
  //! Starts the external player with the filename to the video
  void viewVideo();
  //! Is emitting from the QProcess if an error occurred
  void error ( QProcess::ProcessError error );
  //! Is called if the state of the YoutubeItemModel changed
  void stateChanged(YoutubeItemModel::State state);
  //! Is called if the view state of the YoutubeItemModel changed
  void viewStateChanged(YoutubeItemModel::ViewState state);
  //! Deletes the video from the hard drive
  void deleteVideo();
  //! Does nothing at the moment
  void videoStatusChanged(int index);
  //! Displays a contextmenu to add the author to the favorites tab
  void customContextMenuRequested ( const QPoint &point  );
public slots:
  //! Updates the labels containing download status
  void downloadStatusChanged();

public:
  YoutubeItem(YoutubeItemModel *videoItemModel, QWidget* parent = 0, Qt::WindowFlags flags = 0);
  ~YoutubeItem();
  VideoEntry videoEntry();
  //! Return model
  YoutubeItemModel *model();
signals:
  void downloadStarted(const VideoEntry &entry);
  void downloadFinished(const VideoEntry &entry);
  void videoDeleted(const VideoEntry &entry);
  void addAuthorAsFavorite(const QString &author);
};

#endif // YOUTUBEITEM_HH
