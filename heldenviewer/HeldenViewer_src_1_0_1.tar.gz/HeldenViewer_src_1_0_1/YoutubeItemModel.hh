/*
  HeldenViewer - A program to search, download and view Youtube videos.
  Copyright (C) 2011 Benjamin Held (admin@heldenviewer.com)

  This program is free software: you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation, either version 3 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/
#ifndef YOUTUBEITEMMODEL_HH
#define YOUTUBEITEMMODEL_HH

#include <QObject>
#include <QPixmap>
#include "VideoEntry.hh"
#include "YoutubeQuery.hh"
#include "YoutubeLoader.hh"
#include <QFile>

/**
  * This class is the wrapper around the VideoEntry struct and stores the
  * state and view state of the video. It is also able to download the thumbnail and
  * handles the downloading of a video utilizing the YoutubeLoader.
*/

class YoutubeItemModel : public QObject
{
public:
  enum State{Normal = 0, Downloading, Downloaded};
  enum ViewState{Default = 0, NewVideo, Unseen, Seen};
private:
  Q_OBJECT
  

  VideoEntry videoEntry_;
  QPixmap thumbnail_;
  State state_;
  ViewState viewState_;
  YoutubeQuery youtubeQuery_;
  YoutubeLoader youtubeDownloader_;
  QFile saveFile_;
  
  void changeState(State state);
  void changeViewState(ViewState viewState);
private slots:
  void thumbnailReady(QPixmap thumbnail);
protected:
  virtual bool event(QEvent* event);
public:
  YoutubeItemModel(const VideoEntry &videoEntry);
  YoutubeItemModel(QDataStream &in);
  
  //! Starts the download of the thumbnail if not already downloaded
  //! Emits thumbnailReady after downloading
  void downloadThumbnail();
  //! Starts the download with the desired quality
  void startDownload(int desiredQuality);
  //! Stops the download
  void stopDownload();
  //! Deletes the video from the hard drive and resets the byteSize from the videoEntry
  bool deleteVideo();
  //! Updates the default download quality
  void updateAccordingToOptions();
  //! Set the view state of this video
  void setViewState(ViewState viewState);
  //! Emits the three signals: downloadStatusChanged, stateChanged, viewStateChanged
  void triggerUpdate();
  //! If a newer version of a video entry has been downloaded, then it is
  //! possible to update the saved/old video entry, this is especially interesting
  //! for fields like number of viewers and rating
  void updateVideoEntry(const VideoEntry &entry);
  //! If the video was somehow deleted, then the video entry has to be updated
  void videoFileDeleted();
  
  //! Return a copy of the video entry
  VideoEntry videoEntry() const;
  //! Return the thumbnail
  const QPixmap &thumbnail() const;
  //! Return the state
  State state() const;
  //! Return the view state
  ViewState viewState() const;
  
signals:
  void stateChanged(YoutubeItemModel::State newState);
  void viewStateChanged(YoutubeItemModel::ViewState newState);
  void thumbnailReady();
  void downloadStatusChanged();
};
QDataStream &operator<<(QDataStream &out, const YoutubeItemModel &model);

#endif // VIDEOITEMMODEL_HH
