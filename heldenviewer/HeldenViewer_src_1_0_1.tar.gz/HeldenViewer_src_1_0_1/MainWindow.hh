/*
  HeldenViewer - A program to search, download and view Youtube videos.
  Copyright (C) 2011 Benjamin Held (admin@heldenviewer.com)

  This program is free software: you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation, either version 3 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/
#ifndef MAINWINDOW_HH
#define MAINWINDOW_HH

#include <QMainWindow>
#include "ui_MainWindow.h"
#include "YoutubeQuery.hh"
#include "YoutubeItemManager.hh"
#include "FavoriteDataModel.hh"
#include "CheckNewVideos.hh"
#include "UpdateChecker.hh"

class YoutubeLoader;

/**
  * This is the main window of the application. It handles all events concerning
  * the gui elements and delegates most of them to other classes.
*/

class MainWindow : public QMainWindow, private Ui::MainWindow
{
Q_OBJECT

  YoutubeQuery youtubeQuery_;
//   VideoManager videoManager_;
  YoutubeLoader *loader;
  YoutubeItemManager youtubeItemManager_;
  FavoriteDataModel favoriteDataModel_;
  UpdateChecker updateChecker_;
  int lastVideosBeginIndex_;
  
  void connectSlotsOfItem(YoutubeItem *item);
private slots:
  //! This slot is called when the user clicks on the start download button
  //! of YoutubeItem, in order to identify the video, the VideoEntry structure
  //! is given.
  void downloadStarted(const VideoEntry &entry);
  //! This slot is analoguesly called if a download finishes
  void downloadFinished(const VideoEntry &entry);
  //! Another slot connected to YoutubeItem, which is called when the user requested
  //! the deletion of a video
  void videoDeleted(const VideoEntry& entry);

//   void stopDownload(const VideoEntry &entry);
//   void favoriteSelectedSlot( QListWidgetItem *item);
  //! If the user double clicks a favorite of the favorite list, then
  //! all videos of the favorite are shown
  void favoriteSelectedSlot( const QModelIndex &item);
  //! Called when the user selected File/Edit Options
  void editOptions();
  //! Shows the about dialog
  void aboutDialog();
  //! Check for updates in the internet
  void checkForUpdates();
  //! Show a messagebox where to get help
  void help();
  //! Allows to delete a favorite (if user right clicked on favorite) or
  //! to add another author as favorite
  void favoriteContextMenuRequested ( const QPoint & pos );
  //! Called when the begin index of the videos which are currently shown is called
  void beginIndexChanged(int newValue);
  //! Checks for new videos of the favorites (uses CheckNewVideos class)
  void checkNewVideos();
  //! Signal emitted by the CheckNewVideo class to present the results
  void finishedCheckNewVideos(const CheckNewVideos::FavoriteNewVideosVector &result);
  //! Delete all completed videos from the hard drive and from the completed
  //! downloads tab
  void deleteAllCompletedVideos();
  //! Do the same for the active downloads
  void clearActiveDownloads();
public slots:
  //! Shows the videos of the author which the user typed in le_authorSearch
  void authorSearch();
  //! Shows the videos which match the keyword the user provided
  void videoSearch();
  //! Shows the videos in the vector (creates new YoutubeItems)
  void recentVideosSlot(const std::vector<VideoEntry> &videos, int videosTotal);
  //! Is called by qtsingleapplication if the instance already exists
  void messageReceived(const QString &message);
  //! This is called if the "Show" button is pressed and updates the videos
  //! depending on the values of the two spinboxes sb_videoBeginIndex and endIndex
  void showMoreVideos();
  //! Shows the next 25 videos
  void showNextVideos();
  //! Add the author as favorite
  void addAuthorAsFavorite(const QString &author);
public:
  MainWindow();
  virtual ~MainWindow();
protected:
  virtual void  closeEvent ( QCloseEvent * event );
};

#endif 
