/*
  HeldenViewer - A program to search, download and view Youtube videos.
  Copyright (C) 2011 Benjamin Held (admin@heldenviewer.com)

  This program is free software: you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation, either version 3 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/
#ifndef FILESMISSINGDIALOG_HH
#define FILESMISSINGDIALOG_HH

#include <QDialog>
#include "ui_FilesMissingDialog.h"

#include <QVector>
#include "VideoEntry.hh"

struct FileInfo
{
  enum FileError{BYTE_MISMATCH, FILE_DOES_NOT_EXIST};
  unsigned int index;
  QString message;
  FileError fileError;
  
  FileInfo(){}
  FileInfo(unsigned int index, QString message, FileError error) : index(index), message(message), fileError(error){}
};

bool operator==(const FileInfo &lhv, const FileInfo&rhv);

class YoutubeItemManager;

/**
  * Shows a dialog if files are missing and offers the user the possibility
  * to move the files back to the expected place. If the byte number of files
  * differs from the previous start, then these files are also shown.
  * If the user does not take action, then all missing files are deleted from
  * the YoutubeItemManager and thereby no longer shown under the "Downloading"
  * and "Downloaded"-Tab.
  * The general proposition is to call videosMissing (which is static) in order
  * to get the videos which are missing and if this function returns true, then
  * call create a new instance of the class with the result of the videosMissing
  * function.
*/
class FilesMissingDialog : public QDialog, private Ui::FilesMissingDialog
{
  Q_OBJECT
  
  YoutubeItemManager *youtubeItemManager_;
  QVector<VideoEntry> &entries_;
  QVector<FileInfo> &fileInfo_;
  
  void setTextEditMessage();
private slots:
  void buttonClicked ( QAbstractButton * button);
  void deleteFiles();
public slots:
  virtual void accept ();
public:  
  FilesMissingDialog(YoutubeItemManager *youtubeItemManager, QVector<VideoEntry> &entries, QVector<FileInfo> &fileInfo, QWidget* parent = 0, Qt::WindowFlags f = 0);
  
  //! Checks if the videos in the entries are missing/have a byte mismatch
  //! if so, then an entry to the vector fileInfo is added for this file
  static bool videosMissing(const QVector<VideoEntry> &entries, QVector<FileInfo> &fileInfo);
protected:
  virtual void  closeEvent ( QCloseEvent * event );
};

#endif