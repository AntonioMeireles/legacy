/*
  HeldenViewer - A program to search, download and view Youtube videos.
  Copyright (C) 2011 Benjamin Held (admin@heldenviewer.com)

  This program is free software: you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation, either version 3 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/
#ifndef YOUTUBEQUERY_HH
#define YOUTUBEQUERY_HH

#include <QObject>
#include <vector>
#include <QHttp>
#include <map>
#include "VideoEntry.hh"
#include <QPixmap>

class QNetworkAccessManager;
class QNetworkReply;

/**
  * YoutubeQuery is able to find videos from the youtube platform.
  * It can be used to display videos of a specific author or
  * to find all videos matching a keyword. Generate a GeneralYoutubeQuery
  * and call extractRecentVideos. Then the signal recentVideos will be emitted.
  * The class can also be used to download thumbnails.
*/

class YoutubeQuery : public QObject
{
  Q_OBJECT
  
public:
  enum RequestType{AUTHOR_VIDEOS, DOWNLOAD_THUMBNAIL, KEYWORD_VIDEOS};
  
  struct GeneralYoutubeQuery
  {
    RequestType type;
    //! For AUTHOR_VIDEOS this is the author's name
    //! For KEYWORD_VIDEOS this is the keyword to search for.
    QString text;
    //! The start index and the number of items to be retrieved.
    int startIndex, itemsToRetrieve;
    //! Number of videos
    int maxItemCount;
    
    explicit GeneralYoutubeQuery(RequestType type, const QString &text, int startIndex=1, int itemsToRetrieve=25): type(type), text(text), startIndex(startIndex), itemsToRetrieve(itemsToRetrieve), maxItemCount(0){}
  };
private:
  
  QNetworkAccessManager *manager_;
  
  struct Request
  {
    RequestType type;
    QString name;
    
    QByteArray content;
  };
  
  std::map<QNetworkReply*, Request *> requestMap_;
  GeneralYoutubeQuery lastAuthorQuery_;
  
  void processRequest(QNetworkReply* reply, Request *request);
  void extractVideosFromAuthor(const QString &xmlContent, std::vector<VideoEntry> &videoEntries, int &authorVideosCount);
private slots:
  void replyFinished(QNetworkReply* reply);
public:
  YoutubeQuery();
  ~YoutubeQuery();
  //Returns reply
  QNetworkReply *extractRecentVideos(const GeneralYoutubeQuery &author);
  QNetworkReply *downloadThumbnail(const VideoEntry& entry);
  GeneralYoutubeQuery lastQuery();
signals:
  void recentVideos(const std::vector<VideoEntry> &videoEntries, int videosCount);
  void thumbnailReady(QPixmap image);
};

#endif // YOUTUBEQUERY_HH
