/*
  HeldenViewer - A program to search, download and view Youtube videos.
  Copyright (C) 2011 Benjamin Held (admin@heldenviewer.com)

  This program is free software: you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation, either version 3 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include "MainWindow.hh"
#include "PixmapFileEngine.hh"
#include "SettingsManager.hh"
#include <QtGui/QApplication>
#include <QtDebug>
#include <QFile>
#include <QTextStream>
#include <QtDebug>
#include <QFile>
#include <QTextStream>
#include <QTime>
#include <QtSingleApplication/QtSingleApplication>
#include <QTranslator>
#include <QMessageBox>
#include <QLibraryInfo>
#include <iostream>

// Linker settings MSVC: /SUBSYSTEM:WINDOWS
// Linker settings MINGW: -static-libgcc -mwindows -static-libstdc++
void initLogFile()
{
  QFile outFile(SettingsManager::instance().logFilePath());
  outFile.open(QIODevice::WriteOnly);
  QTextStream ts(&outFile);
  ts << "Starting logfile at " << QTime::currentTime().toString() << " on " << QDate::currentDate().toString() << "\r\n" << endl;
}

void myMessageHandler(QtMsgType type, const char *msg)
{
  QString txt;
  switch (type) {
  case QtDebugMsg:
    txt = QString("Debug: %1\r\n").arg(msg);
    break;
  case QtWarningMsg:
    txt = QString("Warning: %1\r\n").arg(msg);
  break;
  case QtCriticalMsg:
    txt = QString("Critical: %1\r\n").arg(msg);
  break;
  case QtFatalMsg:
    txt = QString("Fatal: %1\r\n").arg(msg);
  break;
  }

  QFile outFile(SettingsManager::instance().logFilePath());
  outFile.open(QIODevice::WriteOnly | QIODevice::Append);
  QTextStream ts(&outFile);
  ts << txt << endl;
  std::cout << txt.toStdString();
}

void setNames()
{
  QCoreApplication::setOrganizationName("Heldensoftware");
  QCoreApplication::setApplicationName("HeldenViewer");
  
}

int runApplication(int argc, char **argv, bool ownMessageHandler)
{
  QtSingleApplication app(argc, argv);
  setNames();
  //To register the engine, just create an instance
  PixmapFileEngineHandler engine;
  if(ownMessageHandler)
  {
    qInstallMsgHandler(myMessageHandler);
	initLogFile();
  }
	

  QSettings settings(QSettings::IniFormat, QSettings::UserScope,"Heldensoftware", "HeldenViewer");
  QString language = "en";
  if(settings.value("Options/language", QLocale::system().name().left(2) == "de" ? 1 : 0).toInt() == 1) 
    language = "de";
  QTranslator qtTranslator;
/*  qtTranslator.load("qt_" + QLocale::system().name(),
          QLibraryInfo::location(QLibraryInfo::TranslationsPath));*/
  if(language == "de")
    qtTranslator.load("qt_" + language + "_DE",
          QLibraryInfo::location(QLibraryInfo::TranslationsPath));
  else
    qtTranslator.load("qt_" + language + "_US",
          QLibraryInfo::location(QLibraryInfo::TranslationsPath));
  app.installTranslator(&qtTranslator);
  SettingsManager::instance().setLanguage(language);
  
  QTranslator myappTranslator;
  QString translationPath = SettingsManager::instance().resourceDirectory() + "HeldenViewer_" + language;
  myappTranslator.load(translationPath);
  app.installTranslator(&myappTranslator);
//   qDebug("%s", QLocale::system().name().left(2).toLatin1().data());
  //Check if application is running, if so then raise the window
  if (app.isRunning())
  {
    QMessageBox::information(0, QObject::tr("Sorry, HeldenViewer is already running."), QObject::tr("The application HeldenViewer is already running, only one instance can run at the same time."));
    app.sendMessage("raise window");
    return 0;
  }


  MainWindow mainWindow;
  app.connect(&app, SIGNAL(messageReceived(const QString &)), &mainWindow, SLOT(messageReceived(const QString &)));
  app.setActivationWindow(&mainWindow);

  mainWindow.show();
  return app.exec();
  
}

#ifndef _UNIX_
  #include <windows.h>
  #include <iostream>
  int WINAPI WinMain(HINSTANCE d1, HINSTANCE d2, LPSTR 
  d3, int d4)
  {
    int argc = 1;
    char *argv[1] = {"HeldenViewer.exe"};
    return runApplication(argc, argv, true);
  }
#else

  int main(int argc, char** argv)
  {
    return runApplication(argc, argv, true);
  }
#endif






