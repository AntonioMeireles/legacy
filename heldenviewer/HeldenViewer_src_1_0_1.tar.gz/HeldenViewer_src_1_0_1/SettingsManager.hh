/*
  HeldenViewer - A program to search, download and view Youtube videos.
  Copyright (C) 2011 Benjamin Held (admin@heldenviewer.com)

  This program is free software: you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation, either version 3 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/
#ifndef SETTINGSMANAGER_HH
#define SETTINGSMANAGER_HH

#include <QSettings>
#include <QNetworkAccessManager>

struct VideoEntry;

/**
  * A singleton class which handles the main settings of the application, these
  * include save path of the videos, language chosen, default quality of videos,...
*/
class SettingsManager
{
  SettingsManager();
  SettingsManager &operator=(const SettingsManager &);
  SettingsManager(const SettingsManager&);
  
  QSettings settings_;
  QString language_;
public:
  static SettingsManager &instance();
  ~SettingsManager();
  
  const QSettings &settings() const;
  QSettings &settings();
  
  void setLanguage(const QString language);
  
  QString externalPlayer() const;
  int defaultQuality() const;
  bool higherQuality() const;
  QString savePath() ;  
  QString filePath(const VideoEntry &entry);
  //QNetworkAccessManager *manager();
  QString logFilePath();
  
  /** Returns the path to the data directory with a seperator at the end
    * it also creates the directory if necessary to ensure that files can be
    * saved there
    */
  QString dataDirectory() ;
  QString language();
  QString resourceDirectory();
  int version();
};

#endif // SETTINGSMANAGER_HH
