//
// TomboyQueryable.cs
//
// Copyright (C) 2004 Christopher Orr
// Copyright (C) 2004 Novell, Inc.
//

//
// Permission is hereby granted, free of charge, to any person obtaining a
// copy of this software and associated documentation files (the "Software"),
// to deal in the Software without restriction, including without limitation
// the rights to use, copy, modify, merge, publish, distribute, sublicense,
// and/or sell copies of the Software, and to permit persons to whom the
// Software is furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in
// all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
// FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
// DEALINGS IN THE SOFTWARE.
//

using System;
using System.IO;

using Beagle.Daemon;
using Beagle.Util;

namespace Beagle.Daemon.TomboyQueryable {

	[QueryableFlavor (Name="Tomboy", Domain=QueryDomain.Local)]
	public class TomboyQueryable : LuceneQueryable {

		private static Logger log = Logger.Get ("TomboyQueryable");

		string notesDir;
		string backupDir;

		int wdNotes = -1;
		int wdBackup = -1;

		public TomboyQueryable () : base (Path.Combine (PathFinder.RootDir, "TomboyIndex"))
		{
			notesDir = Path.Combine (Environment.GetEnvironmentVariable ("HOME"), ".tomboy");
			backupDir = Path.Combine (notesDir, "Backup");
		}

		public override void Start () 
		{
			base.Start ();

			// If ~/.tomboy does not exist, watch ~ for it to be
			// created
			if (! Directory.Exists (notesDir) ) {
				log.Warn("Failed to Scan Tomboy, perhaps it is not installed");
				wdNotes = Inotify.Watch (Environment.GetEnvironmentVariable ("HOME"), Inotify.EventType.CreateSubdir);
				Inotify.Event += WatchForTomboy;
				return;
			}
			
			Inotify.EventType mask;
			mask = Inotify.EventType.MovedTo
				| Inotify.EventType.MovedFrom
				| Inotify.EventType.CreateFile
				| Inotify.EventType.DeleteFile
				| Inotify.EventType.Modify;

			wdNotes = Inotify.Watch (notesDir, mask);

			if (Directory.Exists (backupDir))
				wdBackup = Inotify.Watch (backupDir, mask);

			Inotify.Event += OnInotifyEvent;

			// Crawl all of our existing notes to make sure that
			// everything is up-to-date.
			log.Info ("Scanning Tomboy notes...");
			Stopwatch stopwatch = new Stopwatch ();
			int count = 0;
			stopwatch.Start ();
			DirectoryInfo dir = new DirectoryInfo (notesDir);
			foreach (FileInfo file in dir.GetFiles ()) {
				if (file.Extension == ".note") {
					IndexNote (file, Scheduler.Priority.Delayed);
					++count;
				}
			}
			stopwatch.Stop ();
			log.Info ("Scanned {0} notes in {1}", count, stopwatch);
		}

		private void OnInotifyEvent (int wd,
					     string path,
					     string subitem,
					     Inotify.EventType type,
					     uint cookie)
		{
			if (wd != wdNotes && wd != wdBackup)
				return;

			// Ignore operations on the directories themselves
			if (subitem == "")
				return;

			//Console.WriteLine ("*** {0} {1} {2}", path, subitem, type);

			// Ignore backup files, tmp files, etc.
			if (subitem != "Backup" && Path.GetExtension (subitem) != ".note")
				return;
			
			if (wd == wdNotes && type == Inotify.EventType.MovedTo) {
				if (subitem == "Backup") {
					Inotify.EventType mask;
					mask = Inotify.EventType.MovedTo
						| Inotify.EventType.MovedFrom
						| Inotify.EventType.CreateFile
						| Inotify.EventType.DeleteFile
						| Inotify.EventType.Modify;

					wdBackup = Inotify.Watch (backupDir, mask);
					log.Info("Tomboy: Backup dir was created, now watching");
				} else
					IndexNote (new FileInfo (Path.Combine (path, subitem)), Scheduler.Priority.Immediate);
				//Console.WriteLine ("Indexed {0}", Path.Combine (path, subitem));
			}

			if (wd == wdBackup && type == Inotify.EventType.MovedTo) {
				string oldPath = Path.Combine (notesDir, subitem);
				RemoveNote (oldPath);
				//Console.WriteLine ("Removing {0}", oldPath);
			}

		}

		private void WatchForTomboy (int wd,
					     string path,
 					     string subitem,
					     Inotify.EventType type,
					     uint cookie)
		{
			// Check if event is the tomboy directory being created
			// and index the notes
			if (subitem == ".tomboy" && path == Environment.GetEnvironmentVariable ("HOME")) {
				Inotify.Event -= WatchForTomboy;
				Inotify.Ignore (path);
				Start();
				return;
			}

		}

		private static Indexable NoteToIndexable (FileInfo file, Note note)
		{
			Indexable indexable = new Indexable (note.Uri);

			indexable.ContentUri = UriFu.PathToFileUri (file.FullName);

			indexable.Timestamp = note.timestamp;
			indexable.Type = "Note";

			// Beagle sees the XML as text/plain..
			indexable.MimeType = "text/plain";

			// Using dc:title for a note's subject is debateable?
			indexable.AddProperty (Property.NewKeyword ("dc:title", note.subject));
			indexable.AddProperty (Property.NewDate ("fixme:modified", note.timestamp));

			StringReader reader = new StringReader (note.text);
			indexable.SetTextReader (reader);
			
			return indexable;
		}

		private void IndexNote (FileInfo file, Scheduler.Priority priority)
		{
			if (this.FileAttributesStore.IsUpToDate (file.FullName))
				return;

			// Try and parse a Note from the given path
			Note note = TomboyNote.ParseNote (file);
			if (note == null)
				return;
			
			// A Note was returned; add it to the index
			Indexable indexable = NoteToIndexable (file, note);
			
			Scheduler.Task task = NewAddTask (indexable);
			task.Priority = priority;
			task.SubPriority = 0;
			ThisScheduler.Add (task);

			// Write a plain-text version of our note out into the
			// text cache
			try {
				TextWriter writer = TextCache.GetWriter (note.Uri);
				writer.Write (note.text);
				writer.Close ();
			} catch (Exception ex) {
				Console.WriteLine (">>>>> Caught exception writing {0} to text cache", note.Uri);
			}
		}
		
		private void RemoveNote (string path)
		{
			Uri uri = UriFu.PathToFileUri (path);
			Scheduler.Task task = NewRemoveTask (uri);
			task.Priority = Scheduler.Priority.Immediate;
			task.SubPriority = 0;
			ThisScheduler.Add (task);
		}
	}
}
