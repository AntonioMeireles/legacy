#
# guesslcd.py - guess LCD panel size based on X log output
#
# Michael Fulbright <msf@redhat.com>
#
# Copyright 1999-2003 Red Hat, Inc.
#
# This software may be freely redistributed under the terms of the GNU
# library public license.
#
# You should have received a copy of the GNU Library Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
#

import re
import string

from rhpl.log import log

def getSyncForRes(runres):
    if runres == "800x600":
	rc = ("31.5-48.5", "50-70")
    elif runres == "1024x768":
	rc =("31.5-48.5", "40-70")
    elif runres == "1280x1024":
	rc = ("31.5-67", "50-75")
    elif runres == "1400x1050":
	rc = ("31.5-90", "59-75")
    elif runres == "1600x1200":
	rc = ("31.5-90", "60")
    else:
	# just pick something reasonable for most modes
	rc = ("31.5-65.0", "50-90")

    return rc


#
# Source of templates in X Server sources:
#
#  ati     - atipreinit.c
#  r128    - r128_driver.c
#  radeon  - radeon_driver.c
#  neo     - neo_driver.c
#  savage  - savage_driver.
#
#
# Return tuple containing (xres, yres) as found. Values are integers.
#
def scanXLogForLCD(xlog, vid_driver):
    card_templates = { "ati"    : ".*panel.*detected.*",
		       "r128"   : ".*panel size: .*",
		       "radeon" : ".*panel size from bios.*",
		       "neo"    : ".*panel is a.*display.*",
		       "savage" : ".*LCD panel detected.*"
		     }

    log("in scanXLogForLCD: vid_driver = %s", vid_driver)
    if vid_driver not in card_templates.keys():
	return (None, None)

    template = card_templates[vid_driver]
    regx = re.compile(template)

    log("in scanXLogForLCD: template = %s", template);
    
    f = open(xlog, "r")
    lines = f.readlines()
    f.close()

    fndmatch = 0
    for l in lines:
	llower = string.lower(l)
#	log("looking at line |%s|", llower)
	if regx.match(llower):
	    fndmatch = 1
	    break

    if fndmatch:
	fndmatch = 0
	for testres in ["640x480", "800x600", "1024x480", "1024x768",
			"1280x960", "1280x1024", "1400x1050", "1600x1200"]:
	    if string.find(l, testres) != -1:
		fndmatch = 1
		break

    if fndmatch:
	idx = string.find(testres, 'x')
	xres = string.atoi(testres[:idx])
	yres = string.atoi(testres[idx+1:])

	return (xres, yres)
    else:
	return (None, None)
    
	

    
