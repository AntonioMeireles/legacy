#
# videocard.py - Install data and probing for video cards
#
# Matt Wilson <msw@redhat.com>
# Brent Fox <bfox@redhat.com>
# Mike Fulbright <msf@redhat.com>
# Bill Nottingham <notting@redhat.com>
#
# Copyright 2001-2005 Red Hat, Inc.
#
# This software may be freely redistributed under the terms of the GNU
# library public license.
#
# You should have received a copy of the GNU Library Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
#

import copy
import kudzu
import string
import os

from rhpl.log import log
from rhpl.executil import execWithCapture
from rhpl.translate import _
import rhpl.translate as translate
import rhpl

translate.textdomain('rhpxl')

drivers = {}

class VideoDriver:
# This class represents a X video driver. Mainly useful for system-config-display.
#    driver   - the driver name
#    description - a human-readable description of what cards this driver is for
    def __str__ (self):
	return "%s - %s" % (self.driver, self.description)

    def __init__ (self, driver = None, description = None):
	self.description = description
	self.driver = driver

    def setDriver(self, driver):
	self.driver = driver
    
    def getDriver(self):
	return self.driver
    
    def setDescription(self, desc):
	self.description = desc
    
    def getDescription(self):
	return self.description

def readDrivers ():
    global drivers
    
    # Reads the list of drivers. Prune those that don't exist on the system.
	
    if not os.access('/usr/share/hwdata/videodrivers', os.R_OK):
	return -1
    baseArch = rhpl.getArch()
    if baseArch in ("ia32e", "x86_64", "ppc64", "s390x", "sparc64"):
	libdir = 'lib64'
    else:
	libdir = 'lib'
	
    db = open ('/usr/share/hwdata/videodrivers')
    lines = db.readlines()
    db.close()
    drivers = {}
    for line in lines:
	line = string.strip(line)
	if line[0] == '#':
	    continue
	if string.find(line,'\t') == -1:
	    continue
	( driver, desc ) = string.splitfields (line, '\t', 1)
        if os.access('/usr/%s/xorg/modules/drivers/%s_drv.so' % (libdir, driver), os.R_OK) or os.access('/usr/%s/xorg/modules/drivers/%s_drv.o' % (libdir, driver), os.R_OK):
	    drivers[driver] = VideoDriver(driver = driver, description = desc)
	    
    # Add drivers that do exist that we don't have entries for.
    if os.access('/usr/%s/xorg/modules/drivers' % (libdir,) , os.R_OK):
	d = os.listdir('/usr/%s/xorg/modules/drivers' %(libdir,))
	    
	for module in d:
	    if module.endswith('_drv.so') or module.endswith('_drv.o'):
		module = module.replace('_drv.so','')
                module = module.replace('_drv.o','')
		if module != 'dummy' and module != 'atimisc':
		    if not drivers.has_key(module):
			drivers[module] = VideoDriver(driver = module, description = "Vendor-supplied driver for %s cards" % (module,))
    return 0

	
class VideoCard:
#
# This class represents the base data about a videocard. These are
# the internal members - PLEASE use methods to access values!
#
#    device   - if framebuffer running on card this is entry in /dev (string)
#    descr    - human readable description (string)
#    driver   - X driver
#    vidRam   - amount of video ram (in kB) (string)
#    pcibus   - PCI bus number of the card
#    pcidev   - PCI device number of the card
#    pcifn    - PCI fn number of the card
#
# These values will be None if undefined or not applicable.
#

    def __str__ (self):
        return "device: %s\ndriver : %s\ndescr : %s\nvidRam: %s\n" % (self.device, self.driver, self.descr, self.vidRam)


    def __init__ (self):
        self.device = None
        self.driver = None
        self.descr  = None
        self.vidRam = None
        self.pcibus = None
        self.pcidev = None
        self.pcifn = None
        
    def setDevice(self, device):
        self.device = device

    def setDescription(self, descr):
        self.descr = descr

    def setDriver(self, card):
        self.driver = card

    def setVideoRam(self, vidRam):
        self.vidRam = vidRam

    def setPCIBus(self, num):
        self.pcibus = num

    def setPCIDev(self, num):
        self.pcidev = num

    def setPCIFn(self, num):
        self.pcifn = num
        
    def getDriver(self):
        return self.driver
    
    def getVideoRam(self):
        return self.vidRam

    def getDescription(self):
        return self.descr

    def getDevice(self):
        return self.device

    def getPCIBus(self):
        return self.pcibus

    def getPCIDev(self):
        return self.pcidev

    def getPCIFn(self):
        return self.pcifn

class VideoCardInfo:

#
# This class represents the video cards on the system.
#
# Currently we only care about the primary card on the system.
# This can be found by using the VideoCardInfo::primaryCard() function.
#
# NOTE - X configuration is not represented here. This class is
#        intended only to reprsent the available hardware on the system
#
    def primaryCard(self):
	if self.videocards and self.primary < len(self.videocards):
	    return self.videocards[self.primary]
	else:
	    return None

    def possible_ram_sizes(self):
        #--Valid video ram sizes--
        return [512, 1024, 2048, 4096, 8192, 16384, 32768, 65536, 131072, 262144, 524288]

    def index_closest_ram_size(self, detected):
        possram = self.possible_ram_sizes()
        match = -1

        for i in range(0, len(possram)-1):
            if detected <= possram[i]:
                match = i
                break
            elif detected >= possram[i]-64 and detected < possram[i+1]-65:
                match = i
                break

        if match < 0:
            match = len(possram)-1
            
        return match

    def possible_depths(self):
        #--Valid bit depths--
        return ["8", "16", "24", "32"]

    def __str__(self):
        retstr = "primary: %s\nvidCards: %s\n" % (self.primary, self.videocards)
        if self.primaryCard():
            retstr = retstr + ("Primary Video Card Info:\n%s" % (str(self.primaryCard())))
        return retstr

    def reset(self):
        self.videocards = copy.deepcopy(self.orig_videocards)
        self.primary = self.orig_primary

    def runDDCProbeStub(self):
	cardID = None
	cardMem = None
	cardDescr = None
	
	probe = string.split (execWithCapture("/usr/sbin/ddcprobe",
					      ['ddcprobe', '--raw',
					      '--videocard']), '\n')
	for line in probe:
	    l = string.strip(line)
	    if len(l)<1:
		continue
	    rc = string.split(l, "=")
	    try:
		key = rc[0]
		val = rc[1]
		if key == "id":
		    cardID = val
		elif key == "mem":
		    cardMem = int(val)
		elif key == "description":
		    cardDescr = val
		else:
		    log("Unknown key/val in videocard::runDDCProbeStub = %s %s", key, val)
	    except:
		log("Ignoring bad ddcprobe output line |%s|", line)
		pass

	return (cardID, cardMem, cardDescr)



    def __init__ (self, skipDDCProbe = 0):

        cards = kudzu.probe (kudzu.CLASS_VIDEO,
                             kudzu.BUS_PCI | kudzu.BUS_SBUS,
                             kudzu.PROBE_ALL)
        
	cardID = None
	cardMem = None
	cardDescr = None
        if not skipDDCProbe:
	    try:
		(cardID, cardMem, cardDescr) = self.runDDCProbeStub()
	    except:
		log("Running videocard::runDDCProbeStub failed")
		pass


        # just use first video card we recognize
        # store as a list of class VideoCard
        self.videocards = []
        self.primary = None

        if readDrivers() < 0:
            return None

	index = 0
        for card in cards:
            
	    vc = VideoCard()
	    vc.setDevice(card.device)
	    vc.setDescription(card.desc)
	    vc.setPCIBus(card.pcibus)
	    vc.setPCIDev(card.pcidev)
	    vc.setPCIFn(card.pcifn)
	    
	    if drivers.has_key(card.xdriver):
		vc.setDriver(card.xdriver)
            elif 1 or (cardMem and cardMem > 0) or rhpl.getArch() == "x86_64":
            # insert a best guess at a card - if we got memory
	    # from probe we hope this means VESA BIOS works
            # or assume that if you're sticking a video card into an
            # x86_64 box, it supports vesa
	    	vc.setDriver('vesa')
	    else:
		vc = None

            # only append if we have something other than None.  then
            # if videohw.videocards = [], we have no video hardware
            # (aka the headless case)
            if vc is not None:
                self.videocards.append(vc)
                self.primary = 0
		
	if self.primary != None:
	    # VESA probe for videoram, etc.
	    # for now assume fb corresponds to primary video card
	    if cardMem and cardMem > 0:
		self.primaryCard().setVideoRam("%d" % (cardMem,))
	    # this is a hack, but it's probably safe to assume at least
	    # 16 megs of video ram on our non-i386 arches (since we can't
	    # probe them)
	    elif rhpl.getArch() != "i386":
		self.primaryCard().setVideoRam("16384")
