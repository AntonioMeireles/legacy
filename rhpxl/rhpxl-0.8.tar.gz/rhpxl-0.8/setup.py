#!/usr/bin/python2

from distutils.core import setup

setup(name='rhpxl', version='0.8',
      description='Python module for X configuration',
      author='Chris Lumens', author_email='clumens@redhat.com',
      data_files=[('sbin', ['ddcprobe']),
                  ('share/rhpxl', ['data/extramodes', 'data/vesamodes'])],
      url='http://fedoraproject.org/wiki/rhpxl',
      packages=['rhpxl'])
