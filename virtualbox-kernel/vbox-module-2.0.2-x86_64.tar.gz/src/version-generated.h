#ifndef ___version_generated_h___
#define ___version_generated_h___

#define VBOX_VERSION_MAJOR 2
#define VBOX_VERSION_MINOR 0
#define VBOX_VERSION_BUILD 2
#define VBOX_VERSION_STRING "2.0.2"

#endif
